#include "config.h"

#include <windows.h>

#include <vector>

#include "log.h"

namespace config {
namespace {

std::wstring Wide(const std::string& s) { return std::wstring(s.begin(), s.end()); }  // (ASCII keys only)

// B16: voice names can be non-ASCII.
std::string Utf8(const std::wstring& w) {
    if (w.empty()) return std::string();
    const int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()), nullptr, 0, nullptr, nullptr);
    std::string out(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()), &out[0], n, nullptr, nullptr);
    return out;
}

std::wstring FromUtf8(const std::string& s) {
    if (s.empty()) return std::wstring();
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), nullptr, 0);
    std::wstring out(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), &out[0], n);
    return out;
}

std::string Narrow(const std::wstring& s) {
    std::string out;
    for (wchar_t c : s) out += static_cast<char>(c);
    return out;
}

// Every key=value of an ini section.
std::map<std::string, int> Section(const std::wstring& path, const wchar_t* section) {
    std::map<std::string, int> out;
    std::vector<wchar_t> buf(16384);
    const DWORD n = GetPrivateProfileSectionW(section, buf.data(), static_cast<DWORD>(buf.size()), path.c_str());
    for (DWORD i = 0; i < n;) {
        const std::wstring line(&buf[i]);
        i += static_cast<DWORD>(line.size()) + 1;
        const size_t eq = line.find(L'=');
        if (eq == std::wstring::npos || line[0] == L';') continue;
        out[Narrow(line.substr(0, eq))] = _wtoi(line.substr(eq + 1).c_str());
    }
    return out;
}

const wchar_t* const kChannels[3] = {L"menu", L"stats", L"auto"};  // B16 [speech] keys

void Read(const std::wstring& path, Settings* s) {
    s->test_mode = GetPrivateProfileIntW(L"test", L"test_mode", s->test_mode ? 1 : 0, path.c_str()) != 0;
    const int v = static_cast<int>(GetPrivateProfileIntW(L"cues", L"volume", s->cue_volume, path.c_str()));
    s->cue_volume = v < 0 ? 0 : (v > 100 ? 100 : v);
    s->safe_edges = GetPrivateProfileIntW(L"edges", L"safe_edges", s->safe_edges ? 1 : 0, path.c_str()) != 0;
    s->pan_around_shank = GetPrivateProfileIntW(L"sound", L"pan_around_shank", s->pan_around_shank ? 1 : 0, path.c_str()) != 0;
    for (const auto& kv : Section(path, L"announce")) s->announce[kv.first] = kv.second != 0;
    for (const auto& kv : Section(path, L"keys")) {
        if (kv.second > 0 && kv.second < 256) s->keys[kv.first] = kv.second;
    }
    for (const auto& kv : Section(path, L"pads")) {  // B39 (B40b: -1 = cleared)
        if (kv.second > 0) s->pads[kv.first] = static_cast<unsigned>(kv.second);
        if (kv.second == -1) s->pads[kv.first] = 0;
    }
    // B16 [speech]
    for (int c = 0; c < 3; ++c) {
        s->speech_engine[c] = GetPrivateProfileIntW(L"speech", kChannels[c], s->speech_engine[c], path.c_str()) ? 1 : 0;
    }
    const int rate = static_cast<int>(GetPrivateProfileIntW(L"speech", L"rate", s->sapi_rate, path.c_str()));
    s->sapi_rate = rate < -10 ? -10 : (rate > 10 ? 10 : rate);
    const int vol = static_cast<int>(GetPrivateProfileIntW(L"speech", L"volume", s->sapi_volume, path.c_str()));
    s->sapi_volume = vol < 0 ? 0 : (vol > 100 ? 100 : vol);
    wchar_t voice[256] = {};
    const wchar_t* const kUnset = L"(unset)";
    GetPrivateProfileStringW(L"speech", L"voice", kUnset, voice, 256, path.c_str());
    if (wcscmp(voice, kUnset) != 0) s->sapi_voice = Utf8(voice);
    wchar_t quieter[1024] = {};  // B30-3
    GetPrivateProfileStringW(L"sound", L"quieter", kUnset, quieter, 1024, path.c_str());
    if (wcscmp(quieter, kUnset) != 0) s->quieter = Utf8(quieter);
}

}  // namespace

Settings Load(const std::wstring& ini_path, const std::wstring& user_path) {
    Settings s;
    const bool exists = GetFileAttributesW(ini_path.c_str()) != INVALID_FILE_ATTRIBUTES;
    const bool user = GetFileAttributesW(user_path.c_str()) != INVALID_FILE_ATTRIBUTES;
    if (exists) Read(ini_path, &s);
    if (user) Read(user_path, &s);  // (B18: test mode too, since F3 toggles and saves it)
    alog::Write("config: %s%s; test_mode=%d cue_volume=%d safe_edges=%d pan_around_shank=%d, %u announcement and %u key settings; "
                "speech menu=%d stats=%d auto=%d voice='%s' rate=%d volume=%d",
                exists ? "shank_access.ini loaded" : "no shank_access.ini (defaults)", user ? ", shank_access_user.ini loaded" : "",
                s.test_mode ? 1 : 0, s.cue_volume, s.safe_edges ? 1 : 0, s.pan_around_shank ? 1 : 0,
                static_cast<unsigned>(s.announce.size()), static_cast<unsigned>(s.keys.size()), s.speech_engine[0],
                s.speech_engine[1], s.speech_engine[2], s.sapi_voice.c_str(), s.sapi_rate, s.sapi_volume);
    return s;
}

bool Save(const std::wstring& user_path, const Settings& s) {
    const wchar_t* p = user_path.c_str();
    bool ok = WritePrivateProfileStringW(L"cues", L"volume", std::to_wstring(s.cue_volume).c_str(), p) != 0;
    ok &= WritePrivateProfileStringW(L"edges", L"safe_edges", s.safe_edges ? L"1" : L"0", p) != 0;
    ok &= WritePrivateProfileStringW(L"test", L"test_mode", s.test_mode ? L"1" : L"0", p) != 0;  // B18 (F3)
    ok &= WritePrivateProfileStringW(L"sound", L"pan_around_shank", s.pan_around_shank ? L"1" : L"0", p) != 0;
    for (const auto& kv : s.announce) ok &= WritePrivateProfileStringW(L"announce", Wide(kv.first).c_str(), kv.second ? L"1" : L"0", p) != 0;
    for (const auto& kv : s.keys) ok &= WritePrivateProfileStringW(L"keys", Wide(kv.first).c_str(), std::to_wstring(kv.second).c_str(), p) != 0;
    for (const auto& kv : s.pads) {  // (0 = cleared: -1, so a default doesn't come back)
        const std::wstring v = kv.second ? std::to_wstring(kv.second) : std::wstring(L"-1");
        ok &= WritePrivateProfileStringW(L"pads", Wide(kv.first).c_str(), v.c_str(), p) != 0;
    }
    for (int c = 0; c < 3; ++c) ok &= WritePrivateProfileStringW(L"speech", kChannels[c], s.speech_engine[c] ? L"1" : L"0", p) != 0;
    ok &= WritePrivateProfileStringW(L"speech", L"rate", std::to_wstring(s.sapi_rate).c_str(), p) != 0;
    ok &= WritePrivateProfileStringW(L"speech", L"volume", std::to_wstring(s.sapi_volume).c_str(), p) != 0;
    ok &= WritePrivateProfileStringW(L"speech", L"voice", FromUtf8(s.sapi_voice).c_str(), p) != 0;
    alog::Write("config: settings %s shank_access_user.ini", ok ? "saved to" : "could not be saved to");
    return ok;
}

}  // namespace config
