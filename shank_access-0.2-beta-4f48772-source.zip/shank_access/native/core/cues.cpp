#include "cues.h"

#include <windows.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>

#include "announce.h"
#include "enemies.h"
#include "jump_model.h"
#include "pathing.h"
#include "level_geometry.h"
#include "log.h"

namespace cues {
std::string NextMoveLocked(const position::Pos& s);  // (B48: NextMove under the lock already held)
namespace {

constexpr float kTile = 64.f;

struct Pickup {
    std::string kind;
    float x = 0, y = 0;
    unsigned seen_ms = 0;   // last beacon/in-reach report
    unsigned next_ms = 0;   // next beacon sound
    bool reached = false;   // an in-reach report has come
    unsigned reach_ms = 0;  // the last in-reach report
};

SRWLOCK g_lock = SRWLOCK_INIT;
unsigned g_next_edge_ms = 0;
bool g_edge_on = false;
int g_edge_surface = -1;  // the surface/end being cued (logged when it changes)
bool g_edge_right = true;
std::vector<Pickup> g_pickups;

// B7 hazards: tracked from their Lua reports (moving ones by predicted position).
struct Hazard {
    std::string kind;
    float x = 0, y = 0, vx = 0, vy = 0;
    unsigned seen_ms = 0, next_ms = 0;
    bool clear = false;       // barrels: a clear line of fire from Shank (B7b)
    unsigned clear_ms = 0;    // ...checked then (0 = never)
};
std::vector<Hazard> g_hazards;

// B8 enemies.
uintptr_t g_enemy_cued = 0;       // the enemy being ticked (for the log)
unsigned g_enemy_next_ms = 0;
uintptr_t g_locked = 0;           // B8-6: the locked enemy (0 = none)
float g_locked_x = 0;              // B23-2: where it was last (for the falling tone when it's killed)
std::set<uintptr_t> g_meats_seen;  // B21-1: the hanging meats shootable last tick
bool g_auto_lock_held = false;     // B21-1: the player turned the lock off: no auto lock until a meat newly appears
bool g_auto_locked = false;        // B23-5: the lock now is the mod's own (not L / K)
std::string g_locked_name;
unsigned g_inline_next_ms = 0;
int g_inline_aim = -99;           // the aim last reported in line (for the log)
// B29-1: a death or a falling scream heard (OnGameSound), matched to an enemy at the next tick (LiveEnemies).
struct DeathSound {
    float x, y;
    unsigned ms;
    bool fell;
    bool used = false;  // (B30-1: matched to an enemy that left the list)
};
std::vector<DeathSound> g_death_sounds;
struct Left {  // B30-1 / B31-1: an enemy that just left the list (decided kDeathDecideMs later)
    enemies::Enemy enemy;
    unsigned ms;
    bool mass;    // several left in the same tick
    bool locked;  // it was the locked one (its tone: the lock's own path, B23-2)
};
std::map<uintptr_t, unsigned> g_first_seen;  // B31-1: when each enemy first appeared
unsigned g_shank_died_ms = 0;               // B31-1: Shank's death voice last heard
std::vector<Left> g_left;
std::map<uintptr_t, enemies::Enemy> g_prev_enemies;  // the list last tick
std::map<uintptr_t, unsigned> g_fell;  // enemies heard screaming as they fall to their death, when

struct Windup {
    float x, y;
    unsigned ms;
    int kind;  // B9-1: 0 standard, 1 grab, 2 charge
};
std::vector<Windup> g_windups;
// B13-4: gunmen aiming (en_aim reports: a goon state tagged "aiming", or a gun's _pre state), until they fire.
struct Aim {
    float x, y;
    unsigned last_ms, next_ms;
};
std::vector<Aim> g_aims;
bool g_explosive_hint_said = false;  // B15-3: the explosives hint, once per level

// B8b: the ranged weapons (RANGE and ATTACK_ARC from stategraphs/shank/constants.lua).
// B9b: the tolerance is the whole ATTACK_ARC each side of the aim (the user hit a dog ~55 degrees below with the
// ~45 degree diagonal-down shot, 10 degrees off: half the arc (7.5) was too strict).
const Gun kGuns[] = {{"pistols", 40 * 64.f, 15.f},  {"uzi", 30 * 64.f, 20.f},     {"shotgun", 8 * 64.f, 30.f},
                     {"minigun", 40 * 64.f, 15.f},  {"flamethrower", 8 * 64.f, 15.f}, {"grenade launcher", 30 * 64.f, 20.f}};
int g_gun = 0;
float g_shank_x = 0, g_shank_y = 0;  // his last position (for the arm sounds)
bool g_shank_known = false;
std::vector<Windup> g_windups_played;  // recent ones (a combo's states merge into one warning)
std::map<uintptr_t, int> g_enemy_side;         // B8d: which side of Shank each enemy was on (-1 left, +1 right)
std::map<uintptr_t, unsigned> g_enemy_pass_ms;  // ...and its last pass whoosh
std::set<uintptr_t> g_special_said;            // B8d: special enemies already announced
// B9c boss openings.
std::map<uintptr_t, unsigned> g_open_until;     // enemy -> open until (en_vuln reports)
unsigned g_open_block_until = 0;                // B29-4: no opening bell until then (a finisher is running)
bool g_open_block = false;
float g_boss_hp = -1.f;                         // B29-4: the boss bar's last value (-1 = none seen)
bool g_boss_down = false;                       // ...0: the boss is defeated, out of the cue list
std::map<uintptr_t, unsigned> g_setup_until;    // B23-4: boss -> set up until (en_setup reports: Toro's charge)
uintptr_t g_prompt_hold_item = 0;               // B25: the Priest's grapple prompt, held while he's in the flames
unsigned g_prompt_hold_ms = 0;
unsigned g_wait_said_ms = 0;                   // B25b: when "Wait" was said
std::set<uintptr_t> g_setup_geo;                // B23-5..7: bosses lined up for an opening this tick (from positions)
uintptr_t g_setup_logged = 0;
uintptr_t g_prompt_item = 0;                    // the enemy showing the grapple prompt (0 = none)
std::map<std::string, unsigned> g_prompt_said;  // prompt -> when last spoken
std::string g_say_now;
uintptr_t g_open_logged = 0;
bool g_bell_high = false;
CameraPanFn g_camera_pan = nullptr;             // B8e
bool g_enemy_camera_pan = false;
int g_turn_facing = 0;                  // B19-2: the last reported facing (1 right, -1 left, 0 none yet)
bool g_hold_up = false, g_hold_down = false;  // B44-1: Up / Down held (the Lua reports up_on/up_off, down_on/down_off)
bool g_hold_fwd = false, g_hold_back = false;  // B44e: forward / back (to his facing) held (fwd_on/off, back_on/off)
std::vector<PlayCmd> g_pending_plays;   // sounds from reports (OnCue), played at the next Tick

std::string g_say;
std::string g_chapter;       // B29-2: the chapter's name to speak (Tick hands it over)
bool g_chapter_said = false;  // once per level load (Reset)
Area g_area;

bool Inside(float x, float y) {
    return !g_area.known || (x >= g_area.min_x - kAreaMarginPx && x <= g_area.max_x + kAreaMarginPx &&
                             y >= g_area.min_y - kAreaMarginPx && y <= g_area.max_y + kAreaMarginPx);
}

// B36b-2 (the user, 4-c: "let me walk out of mod range of a rifle goon who was perched ... maybe having enemies within an
// active arena boundry always sound no matter the distance"; he stood 318 px outside the arena's left edge): an enemy
// in the arena in force, or within kArenaEnemyMarginPx of it.
bool InArena(float x, float y) {
    return g_area.known && g_area.arena && x >= g_area.min_x - kArenaEnemyMarginPx && x <= g_area.max_x + kArenaEnemyMarginPx &&
           y >= g_area.min_y - kArenaEnemyMarginPx && y <= g_area.max_y + kArenaEnemyMarginPx;
}

float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

Pickup* Find(const std::string& kind, float x, float y) {
    for (Pickup& p : g_pickups) {
        if (p.kind == kind && std::fabs(p.x - x) <= kPickupMatchPx && std::fabs(p.y - y) <= kPickupMatchPx) return &p;
    }
    return nullptr;
}

Pickup& Track(const std::string& kind, float x, float y, unsigned now_ms) {
    Pickup* p = Find(kind, x, y);
    if (!p) {
        Pickup fresh;
        fresh.kind = kind;
        fresh.next_ms = now_ms + 150u * static_cast<unsigned>(g_pickups.size());  // several at once: staggered
        g_pickups.push_back(fresh);
        p = &g_pickups.back();
        alog::Write("cues: pickup %s at (%.0f, %.0f)", kind.c_str(), x, y);
    }
    p->x = x;  // dropped pickups fall and bounce
    p->y = y;
    p->seen_ms = now_ms;
    return *p;
}

PlayCmd PickupSound(audio::Sound sound, const Pickup& p, const position::Pos& s) {
    const float dx = p.x - s.x, dy = p.y - s.y;
    const float dist = std::sqrt(dx * dx + dy * dy);
    return PlayCmd{sound, Clamp(dx / kPanRangePx, -1.f, 1.f), Clamp(dy / kPixelsPerSemitone, -8.f, 8.f),
                   Clamp(1.f - dist / 2400.f, 0.25f, 1.f) * 0.8f};
}

const char* EndName(const level_geometry::End& e) {
    if (e.type == level_geometry::End::kWall) return "wall";
    if (e.type == level_geometry::End::kStep) return "step";
    return e.deadly ? "deadly drop" : "drop";
}

bool WallRunEnd(const position::Pos& s, level_geometry::Ahead* a);    // below
bool SlidePoleEnd(const position::Pos& s, level_geometry::Ahead* a);  // below

// 4-3 v2 (B4 G6): the edge ahead from the level geometry.
void EdgeCue(unsigned now_ms, const position::Pos& s, Output* out) {
    level_geometry::Ahead a = s.known ? level_geometry::EdgeAhead(s.x, s.y, s.facing_right) : level_geometry::Ahead();
    // B6-2: wall running, the end of the run is the edge (in the direction he's running).
    bool facing = s.facing_right;
    bool down = false;  // B6-3: sliding down a slide pole, the edge is its bottom (below him)
    if (!a.found && s.known && WallRunEnd(s, &a)) facing = s.vx > 0;
    else if (!a.found && s.known && SlidePoleEnd(s, &a)) down = true;
    // B5-2: an arena bound before the end of the floor is where he stops: a wall there.
    if (a.found && !down && g_area.known) {
        const float bound = facing ? g_area.max_x : g_area.min_x;
        const bool before = facing ? bound < a.end_x : bound > a.end_x;
        if (before) {
            a.end_x = bound;
            a.distance = std::max(0.f, std::fabs(bound - s.x) - kShankRadius);
            a.end = level_geometry::End();
            a.end.type = level_geometry::End::kWall;
            a.end.value = 9999;  // an invisible wall: as high as it needs to be
            a.surface = -2;      // "the boundary" in the log
        }
    }
    const bool hop = a.found && (a.end.type == level_geometry::End::kStep ||
                                 (a.end.type == level_geometry::End::kWall && a.end.value <= kTile));
    const bool touching_wall = a.found && a.end.type == level_geometry::End::kWall && a.distance <= kWallTouchPx;
    const float toward = down ? -s.vy : facing ? s.vx : -s.vx;  // his speed toward the edge
    const float close = a.found ? EdgeCloseness(a.distance, toward) : 2.f;
    if (!a.found || hop || touching_wall || close > 1.f) {
        g_edge_on = false;
        return;
    }
    if (a.surface != g_edge_surface || facing != g_edge_right) {
        g_edge_surface = a.surface;
        g_edge_right = facing;
        alog::Write("cues: edge ahead: %s at x %.0f (%.0f px, value %.0f), surface %d, heading %s", EndName(a.end),
                    a.end_x, a.distance, a.end.value, a.surface, down ? "down" : facing ? "right" : "left");
    }
    unsigned gap = kEdgeFastestMs + static_cast<unsigned>((kEdgeSlowestMs - kEdgeFastestMs) * close);
    if (g_edge_on && static_cast<int>(now_ms - g_next_edge_ms) < 0) {
        // Nearer than when the pulse was scheduled: don't wait out a slower gap.
        if (static_cast<int>(g_next_edge_ms - now_ms) > static_cast<int>(gap)) g_next_edge_ms = now_ms + gap;
        return;
    }
    const float side = down ? 0.f : facing ? kEdgePan : -kEdgePan;
    const float loud = 1.f - 0.4f * close;
    audio::Sound sound = audio::kDrop;
    if (a.end.type == level_geometry::End::kWall) sound = audio::kWall;
    else if (a.end.gap) sound = audio::kGap;  // B15-6: crossed by running (even if deadly below)
    else if (a.end.deadly) sound = audio::kDeadly;
    // B5: a wall he can run up knocks higher than one he can't.
    const float semis = sound == audio::kWall && a.end.climbable ? kClimbableWallSemitones : 0.f;
    out->plays.push_back(PlayCmd{sound, side, semis, sound == audio::kWall ? 0.8f * loud : loud});
    g_next_edge_ms = now_ms + gap;
    g_edge_on = true;
}

// Defined further down (the T key uses them too).
void NearestPoint(const level_geometry::Feature& f, float x, float y, float* nx, float* ny);
const char* FeatureName(const std::string& type);

// B5-4 jump targets. id = the feature's index, or kLandingId for the far side of a deadly drop ahead.
constexpr int kLandingId = -1;
constexpr int kPerchId = -2;  // a surface to land on while hanging/clinging (B5e)
constexpr int kWallIdBase = 100000;  // + a wall's index (walls as wall-jump targets)
constexpr int kBounceId = -4;        // B10: the pole's other side (waypoint mode)
std::map<int, unsigned> g_target_next;  // id -> next sound
std::map<int, bool> g_target_reach;     // id -> "a jump now reaches it" (for logging changes)
// B28b (mark 6, 2-c: jump-now chirps for a floor below while T said "Nothing else nearby"): what a jump reaches now, for T.
struct ReachNow {
    std::string what;
    float x, y;
    jump_model::Jump jump;
};
std::map<int, ReachNow> g_reach_now;
std::map<int, unsigned> g_target_yes_ms;       // id -> when the model last said it reaches
std::map<int, float> g_target_yes_y;           // B41e: ...and his height then
unsigned g_too_high_ms = 0;                    // B41e: "Too high" last said
bool g_wp_on = false;  // (moved up: B41e)
enum ShankMode { kModeGround, kModeAir, kModeHanging, kModeWall };
ShankMode g_shank_mode = kModeGround;
std::map<int, jump_model::Jump> g_target_jump;  // id -> which jump it was

bool AreaHas(float x, float y) { return Inside(x, y); }

// B28b: does the straight line from (ax, ay) to (bx, by) touch the box (clipped against it, Liang-Barsky)?
bool SegmentMeetsBox(float ax, float ay, float bx, float by, float x0, float y0, float x1, float y1) {
    float t0 = 0.f, t1 = 1.f;
    const float dx = bx - ax, dy = by - ay;
    const float p[4] = {-dx, dx, -dy, dy};
    const float q[4] = {ax - x0, x1 - ax, ay - y0, y1 - ay};
    for (int i = 0; i < 4; ++i) {
        if (p[i] == 0.f) {
            if (q[i] < 0.f) return false;  // parallel and outside
        } else {
            const float r = q[i] / p[i];
            if (p[i] < 0.f) t0 = std::max(t0, r);
            else t1 = std::min(t1, r);
            if (t0 > t1) return false;
        }
    }
    return true;
}

bool ToTarget(const level_geometry::Feature& f, jump_model::Target* t) {
    const auto& p = f.points;
    if (p.empty()) return false;
    const auto& q = p.size() > 1 ? p[1] : p[0];
    if (f.type == "swing_point") *t = jump_model::Target{jump_model::kSwing, p[0].first, p[0].second, 0, 0};
    else if (f.type == "pole" || f.type == "slide_pole") *t = jump_model::Target{jump_model::kPole, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "shimmy_line") *t = jump_model::Target{jump_model::kShimmy, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "wallrun_zone") *t = jump_model::Target{jump_model::kWallZone, p[0].first, p[0].second, q.first, q.second};
    else return false;
    t->slide = f.type == "slide_pole";  // B8c
    return true;
}

// B6-2: wall running: in a wall-run zone, off the ground, about level and fast along it.
bool WallRun(const position::Pos& s, jump_model::Target* zone) {
    if (std::fabs(s.vx) < kWallRunMinVx || std::fabs(s.vy) > kWallRunMaxVy) return false;
    if (level_geometry::SurfaceUnder(s.x, s.y)) return false;
    for (const level_geometry::Feature& f : level_geometry::Features()) {
        jump_model::Target t;
        if (f.type != "wallrun_zone" || !ToTarget(f, &t)) continue;
        if (s.x >= t.x1 && s.x <= t.x2 && s.y >= t.y1 - kWallRunZoneMarginPx && s.y <= t.y2 + kWallRunZoneMarginPx) {
            *zone = t;
            return true;
        }
    }
    return false;
}

// B6-2: wall running, the zone's end ahead as an edge (surface -3 in the log): where the fall off its end
// lands (a drop of that depth), or deadly (nothing below, a fatal pit zone, or below the arena's bounds).
bool WallRunEnd(const position::Pos& s, level_geometry::Ahead* a) {
    jump_model::Target z;
    if (!WallRun(s, &z)) return false;
    const bool right = s.vx > 0;
    *a = level_geometry::Ahead();
    a->found = true;
    a->end_x = right ? z.x2 : z.x1;
    a->end_y = s.y - kShankRadius;
    a->distance = std::max(0.f, right ? a->end_x - s.x : s.x - a->end_x);
    a->surface = -3;
    a->end.type = level_geometry::End::kDrop;
    float lx = 0, ly = 0;
    if (jump_model::Land(a->end_x, s.y, s.vx, 0.f, &lx, &ly) &&
        !level_geometry::PitAcross(lx, s.y, ly - kShankRadius) && (!g_area.known || ly >= g_area.min_y)) {
        a->end.value = s.y - ly;
    } else {
        a->end.deadly = true;
    }
    return true;
}

// B6-3: sliding down a slide pole (on it, moving down): its bottom as an edge below him (surface -4 in the
// log), deadly or safe by where the fall off the bottom lands; nothing if another pole or rope piece
// carries on from there (a path can be a slide pole, then a rope).
bool OnPole(const jump_model::Target& t, const position::Pos& s);  // below
bool SlidePoleEnd(const position::Pos& s, level_geometry::Ahead* a) {
    if (s.vy > -kSlideMinVy) return false;
    const auto& features = level_geometry::Features();
    for (const level_geometry::Feature& f : features) {
        jump_model::Target t;
        if (f.type != "slide_pole" || !ToTarget(f, &t) || !OnPole(t, s)) continue;
        const float bx = t.y1 < t.y2 ? t.x1 : t.x2, by = std::min(t.y1, t.y2);
        for (const level_geometry::Feature& g : features) {  // the path carries on from the bottom
            if (&g == &f || g.type == "swing_point" || g.type == "wallrun_zone") continue;
            for (const auto& p : g.points) {
                if (std::hypot(p.first - bx, p.second - by) <= kPathJoinPx) return false;
            }
        }
        *a = level_geometry::Ahead();
        a->found = true;
        a->end_x = s.x;
        a->end_y = by;
        a->distance = std::max(0.f, s.y - by);
        a->surface = -4;
        a->end.type = level_geometry::End::kDrop;
        float lx = 0, ly = 0;
        if (jump_model::Land(s.x, std::min(s.y, by), 0.f, s.vy, &lx, &ly) &&
            !level_geometry::PitAcross(lx, by, ly - kShankRadius) && (!g_area.known || ly >= g_area.min_y)) {
            a->end.value = by - ly;
        } else {
            a->end.deadly = true;
        }
        return true;
    }
    return false;
}

// The far side of a deadly drop ahead: the nearest surface starting beyond the edge (within a long jump
// and a reasonable height), as a landing target: its first stretch.
bool FarSide(const position::Pos& s, jump_model::Target* t, float* tx, float* ty) {
    const level_geometry::Ahead a = level_geometry::EdgeAhead(s.x, s.y, s.facing_right);
    if (!a.found || a.end.type != level_geometry::End::kDrop || !a.end.deadly || a.distance > kEdgeRangePx) return false;
    const level_geometry::Surface* best = nullptr;
    float best_gap = kLandingSearchPx;
    for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
        if (f.points.size() < 2) continue;
        const auto& near_end = s.facing_right ? f.points.front() : f.points.back();
        const float gap = s.facing_right ? near_end.first - a.end_x : a.end_x - near_end.first;
        const float rise = near_end.second - a.end_y;
        if (gap < 16.f || gap > best_gap || rise > kLandingMaxRisePx || rise < -kLandingMaxDropPx) continue;
        if (level_geometry::InPit(near_end.first, near_end.second)) continue;  // B6-7: a floor in a fatal pit
        if (!AreaHas(near_end.first, near_end.second + kShankRadius)) continue;
        best = &f;
        best_gap = gap;
    }
    if (!best) return false;
    const auto& p0 = s.facing_right ? best->points[0] : best->points[best->points.size() - 1];
    const auto& p1 = s.facing_right ? best->points[1] : best->points[best->points.size() - 2];
    const float len = std::fabs(p1.first - p0.first);
    const float k = len > kLandingStretchPx ? kLandingStretchPx / len : 1.f;
    const float ex = p0.first + (p1.first - p0.first) * k, ey = p0.second + (p1.second - p0.second) * k;
    *t = s.facing_right ? jump_model::Target{jump_model::kLanding, p0.first, p0.second, ex, ey}
                        : jump_model::Target{jump_model::kLanding, ex, ey, p0.first, p0.second};
    *tx = p0.first;
    *ty = p0.second + kShankRadius;
    return true;
}

void Reachable(int id, bool now, const char* what, float x, float y, jump_model::Jump j) {
    bool& was = g_target_reach[id];
    if (now != was) {
        const char* how = j == jump_model::kLong ? " (long jump)" : j == jump_model::kWallJump ? " (wall jump)"
                          : j == jump_model::kSwingJump ? " (swing jump)" : j == jump_model::kBarJump ? " (bar jump)"
                          : j == jump_model::kPoleJump ? " (pole jump)" : j == jump_model::kUpJump ? " (jump up)"
                          : j == jump_model::kRunUpJump ? " (jump off the wall while running up it)"
                          : j == jump_model::kWallRunJump ? " (wall-run jump)" : j == jump_model::kWalkOff ? " (walking off)"
                          : " (standing jump)";
        alog::Write("cues: jump %s %s at (%.0f, %.0f)%s", now ? "now reaches" : "no longer reaches", what, x, y, now ? how : "");
        was = now;
    }
    if (now) g_reach_now[id] = ReachNow{what, x, y, j};
    else g_reach_now.erase(id);
}

// Climbing a pole: in the air, about PoleClimbOffset (80 px) to one side of it, within its height.
bool OnPole(const jump_model::Target& t, const position::Pos& s) {
    const float lo = std::min(t.y1, t.y2), hi = std::max(t.y1, t.y2);
    const float px = (t.x1 + t.x2) / 2;  // poles are vertical
    const float side = std::fabs(s.x - px);
    // (B41f, the B41e log, 4-a: a jump off a shimmy line's end flew past the pole at x 69704 at ~1150 px/s and counted as on
    // it: a pole jump chirped mid-air, and following it he fell to his death twice. On a pole he isn't moving across.)
    if (std::fabs(s.vx) > kClingMaxVx) return false;
    return side >= kPoleSideMinPx && side <= kPoleSideMaxPx && s.y >= lo - kInUsePx && s.y <= hi + kInUsePx;
}

// Is Shank on this target right now (hanging from it, in the zone)? Then it's silent (the user: "any
// alerts for an object should stop when you're interacting with it").
bool InUse(const jump_model::Target& t, const position::Pos& s, bool grounded) {
    if (grounded) return false;
    auto near_segment = [&](float px, float py) {
        if (t.kind == jump_model::kSwing) return std::hypot(t.x1 - px, t.y1 - py) <= kInUsePx;
        for (int i = 0; i <= 16; ++i) {
            const float u = i / 16.f;
            if (std::hypot(t.x1 + u * (t.x2 - t.x1) - px, t.y1 + u * (t.y2 - t.y1) - py) <= kInUsePx) return true;
        }
        return false;
    };
    switch (t.kind) {
        case jump_model::kSwing: {  // hanging: he swings on a circle of kSwingRadius around it (measured)
            const float d = std::hypot(t.x1 - s.x, t.y1 - s.y);
            return std::fabs(d - jump_model::kSwingRadius) <= kSwingBandPx;
        }
        case jump_model::kPole:  // climbing it: PoleClimbOffset 1.25 tiles to one side (B5d log: x 2849.9 / 3009.9
                                 // on the pole at 2929.9), within its height
            return OnPole(t, s);
        case jump_model::kShimmy:
            return near_segment(s.x, s.y + jump_model::kHangUp);
        case jump_model::kWallZone:  // in it, or right beside it (B5b log: clinging to the wall next to 1-c's zone)
            return s.x >= t.x1 - kZoneBesidePx && s.x <= t.x2 + kZoneBesidePx && s.y >= t.y1 - kInUsePx &&
                   s.y <= t.y2 + kInUsePx;
        default:
            return false;
    }
}

// Running on the ground: how soon (seconds, up to kLeadInSeconds) a jump would reach the target if he
// keeps going, or -1. The pluck speeds up toward that moment (a countdown into the chirp).
float LeadIn(const jump_model::Target& t, const position::Pos& s) {
    if (std::fabs(s.vx) < kLeadInMinSpeed) return -1.f;
    for (float dt = kLeadInStep; dt <= kLeadInSeconds; dt += kLeadInStep) {
        const float x = s.x + s.vx * dt;
        if (!level_geometry::SurfaceUnder(x, s.y)) return -1.f;  // he'd be off the edge first
        if (jump_model::ReachLong(t, x, s.y, s.facing_right) != jump_model::kNone) return dt;  // (running: B44-2)
    }
    return -1.f;
}

// B44-4 (the user: "apply the hot/cold repeat speed ... use the speed values for the pickup sounds"): the pluck's gap by
// distance, as the pickup beacons (kPickupFastestMs + up to kPickupSpanMs over kPickupSpanPx).
unsigned PluckGap(float d) {
    return kPickupFastestMs + static_cast<unsigned>(kPickupSpanMs * Clamp(d / kPickupSpanPx, 0.f, 1.f));
}

unsigned LeadGap(float lead) {
    return kLeadInFastestMs + static_cast<unsigned>(kLeadInSpanMs * lead / kLeadInSeconds);
}

// One target's sound this tick: the chirp while a jump now reaches it (at once when the window opens), the
// countdown pluck while running toward its window, else (if it's among the nearest) the slow pluck.
void SoundTarget(int id, const char* name, float tx, float ty, bool pluck_when_idle, jump_model::Jump j, float lead,
                 unsigned now_ms, const position::Pos& s, Output* out) {
    // Hold a "reaches" for a moment: at the top of a climb he bobs and the answer flickered every few frames
    // (B5b log), which chopped the chirp up.
    unsigned& last_yes = g_target_yes_ms[id];
    if (j != jump_model::kNone) {
        last_yes = now_ms;
        g_target_jump[id] = j;
        g_target_yes_y[id] = s.y;
    } else if (g_target_reach[id] && now_ms - last_yes < kReachHoldMs) {
        j = g_target_jump[id];
    }
    const bool was = g_target_reach[id];
    Reachable(id, j != jump_model::kNone, name, tx, ty, j);
    // B41e (the user: "need to account for jumping too far above things and flying over them"; 1-c: up the wall w108 past
    // the window the jump overshot the shimmy line, off the pole from too high it flew over the wall run): in waypoint
    // mode, the window closing because he climbed past it is said.
    if (was && j == jump_model::kNone && g_wp_on && g_shank_mode == kModeWall && s.y >= g_target_yes_y[id] - 8.f && (s.y > g_target_yes_y[id] + 8.f || s.vy > -100.f) &&
        now_ms - g_too_high_ms > 2000) {
        g_too_high_ms = now_ms ? now_ms : 1;
        alog::Write("cues: too high for %s (the jump reached up to y %.0f; he's at %.0f)", name, g_target_yes_y[id], s.y);
        g_say_now = "Too high";
    }
    unsigned& next = g_target_next[id];
    if (j != jump_model::kNone && !was) next = now_ms;  // the window just opened: chirp now
    if (static_cast<int>(now_ms - next) < 0) {
        // A slower sound was scheduled: don't wait it out once the countdown or the chirp is due sooner, or (B44-4) the
        // pluck now that he's nearer.
        int soon = -1;
        if (j != jump_model::kNone) soon = static_cast<int>(kJumpNowGapMs);
        else if (lead >= 0.f) soon = static_cast<int>(LeadGap(lead));
        else if (pluck_when_idle) soon = static_cast<int>(PluckGap(std::hypot(tx - s.x, ty - s.y)));
        if (soon >= 0 && static_cast<int>(next - now_ms) > soon) next = now_ms + soon;
        return;
    }
    const float pan = Clamp((tx - s.x) / kPanRangePx, -1.f, 1.f);
    const float semis = Clamp((ty - s.y) / kPixelsPerSemitone, -8.f, 8.f);
    const float d = std::hypot(tx - s.x, ty - s.y);
    if (j != jump_model::kNone) {
        out->plays.push_back(PlayCmd{audio::kJumpNow, pan, semis, 0.9f});
        next = now_ms + kJumpNowGapMs;
    } else if (lead >= 0.f) {
        out->plays.push_back(PlayCmd{audio::kTarget, pan, semis, 0.9f});
        next = now_ms + LeadGap(lead);
    } else if (pluck_when_idle) {
        out->plays.push_back(PlayCmd{audio::kTarget, pan, semis, Clamp(1.f - d / 1600.f, 0.35f, 1.f) * 0.8f});
        next = now_ms + PluckGap(d);
    }
}

// B10 waypoint mode (see cues.h).
int g_cp_current = -1;                // the checkpoint (order) he's past; -1 = not placed yet
bool g_cp_placed = false;
float g_last_x = 0, g_last_y = 0;     // for respawn jumps
bool g_have_last = false;
std::string g_wp_node;                // his place in the graph (the last known)
std::string g_live_node;              // B27-6: his place this tick ("" in the air)
int g_wp_goal_cp = -2;                // the checkpoint the goals are for
std::set<std::string> g_wp_goals;
std::vector<pathing::Step> g_wp_path;
unsigned g_wp_path_ms = 0;
std::string g_wp_target;              // the next object on the path ("f12", "p30L", "w63"), "" = none
std::string g_wp_floor;               // the floor the next move jumps onto, "" = none
unsigned g_wp_chime_ms = 0;
std::string g_wp_logged;
std::string g_move_said, g_move_pending;  // B48: the waypoint target last spoken / waiting to hold
unsigned g_move_pending_ms = 0;
constexpr unsigned kMoveSayStableMs = 400;
const char* const kMoveAdopt = "(adopt)";  // g_move_said: take the next target without speaking it
// B20-4: Shank's situation for his gun's aims (set by TargetCues each tick, before EnemyCues).
std::string g_wp_hint;                // B11-1: the pole side the switch hint was said for
unsigned g_wp_hint_ms = 0;            // B20-3: when it was said

bool IsFloorNode(const std::string& n) { return !n.empty() && n[0] == 's'; }

// B41-5: a floor node's slide direction (+1 slides him right, -1 left, 0 not a slope he slides on).
int SlideDir(const std::string& node) {
    if (!IsFloorNode(node)) return 0;
    const int id = std::atoi(node.c_str() + 1);
    for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
        if (f.id != id) continue;
        const bool r = f.tags.find("slipperyright") != std::string::npos, l = f.tags.find("slipperyleft") != std::string::npos;
        return r == l ? 0 : r ? 1 : -1;
    }
    return 0;
}

// The feature index of an "f12" / "p30L" node, or -1.
int FeatureOf(const std::string& n) {
    if (n.size() < 2 || (n[0] != 'f' && n[0] != 'p')) return -1;
    return std::atoi(n.c_str() + 1);
}

// The floor under a spot, or (in the air) the highest floor below it; -1 if none.
int FloorBelow(float x, float y) {
    if (const level_geometry::Surface* s = level_geometry::SurfaceUnder(x, y)) return s->id;
    int best = -1;
    float best_gap = 1e9f;
    for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
        for (size_t i = 0; i + 1 < f.points.size(); ++i) {
            const auto& a = f.points[i];
            const auto& b = f.points[i + 1];
            if (x < a.first || x > b.first || b.first <= a.first) continue;
            const float fy = a.second + (x - a.first) / (b.first - a.first) * (b.second - a.second);
            const float gap = y - kShankRadius - fy;
            if (gap >= -8.f && gap < best_gap) {
                best_gap = gap;
                best = f.id;
            }
        }
    }
    return best;
}

// The places that count as reaching checkpoint c: floors passing through its trigger rectangle grown by
// kCheckpointGrowPx, holds inside it (1-c's first checkpoint is beside a swing point, mid-air), the floor at its spawn.
std::set<std::string> GoalsFor(const level_geometry::Checkpoint& c) {
    std::set<std::string> g;
    const float m = kCheckpointGrowPx;
    if (c.has_region) {
        const float x0 = c.rx - m, x1 = c.rx + c.rw + m, y0 = c.ry - m, y1 = c.ry + c.rh + m;
        // B27-3 (the user, 4-a: "telling me to walk left beyond a checkpoint boundry when the next checkpoint is clearly
        // right"): a floor counts only if Shank standing on it overlaps the rectangle vertically (feet at or under its
        // top, head at or over its bottom); s33, 205 px above "Rocketlauncher vs shimmy", had won the route (left, back
        // through the last checkpoint and over the top) against the swing points on the right.
        const float fy0 = c.ry - kShankHeightPx + kShankRadius, fy1 = c.ry + c.rh + kShankRadius;
        for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
            for (size_t i = 0; i + 1 < f.points.size(); ++i) {
                const auto& a = f.points[i];
                const auto& b = f.points[i + 1];
                if (b.first < x0 || a.first > x1 || b.first <= a.first) continue;
                const float xa = std::max(a.first, x0), xb = std::min(b.first, x1);
                for (float x : {xa, (xa + xb) / 2, xb}) {
                    const float y = a.second + (x - a.first) / (b.first - a.first) * (b.second - a.second) + kShankRadius;
                    if (y >= fy0 && y <= fy1) g.insert("s" + std::to_string(f.id));
                }
            }
        }
        const auto& features = level_geometry::Features();
        for (size_t i = 0; i < features.size(); ++i) {
            if (features[i].points.empty()) continue;
            const float x = features[i].points[0].first, y = features[i].points[0].second;
            if (x < x0 || x > x1 || y < y0 || y > y1) continue;
            const std::string n = std::to_string(i);
            g.insert("f" + n);
            g.insert("p" + n + "L");
            g.insert("p" + n + "R");
        }
    }
    const int spawn_floor = FloorBelow(c.spawn_x, c.spawn_y);
    if (spawn_floor >= 0) g.insert("s" + std::to_string(spawn_floor));
    return g;
}

// Where the checkpoint chimes from: the middle of its trigger rectangle, or its spawn.
void CheckpointSpot(const level_geometry::Checkpoint& c, float* x, float* y) {
    *x = c.has_region ? c.rx + c.rw / 2 : c.spawn_x;
    *y = c.has_region ? c.ry + c.rh / 2 : c.spawn_y;
}

// B29-6 (the user: the spots that trigger a boss scene or the next level "as checkpoints"; the Priest's chapter spawns him on
// a swing point with nothing ahead): after the current checkpoint, its story regions (a boss fight's start, a cinematic,
// the level's end) are the next goals, then the next checkpoint.
std::set<size_t> g_goals_done;             // story goals entered since the last placement (by index in Goals())
level_geometry::Checkpoint g_goal_cp;       // the pending story goal, as a checkpoint (order kGoalOrderBase + index)
int PendingGoal() {
    const auto& goals = level_geometry::Goals();
    for (size_t i = 0; i < goals.size(); ++i) {
        if (goals[i].after == g_cp_current && !g_goals_done.count(i)) return static_cast<int>(i);
    }
    return -1;
}

const level_geometry::Checkpoint* NextCheckpoint() {
    const int pending = PendingGoal();
    if (pending >= 0) {
        const level_geometry::Goal& g = level_geometry::Goals()[pending];
        g_goal_cp = level_geometry::Checkpoint();
        g_goal_cp.order = kGoalOrderBase + pending;
        g_goal_cp.has_region = true;
        g_goal_cp.rx = g.rx;
        g_goal_cp.ry = g.ry;
        g_goal_cp.rw = g.rw;
        g_goal_cp.rh = g.rh;
        g_goal_cp.spawn_x = g.rx + g.rw / 2;
        g_goal_cp.spawn_y = g.ry;
        const auto& cps = level_geometry::Checkpoints();
        std::string after = g.after >= 0 && g.after < static_cast<int>(cps.size()) ? cps[g.after].name : std::string();
        for (char& c : after) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        const bool boss = g.kind == "boss" || after.find("boss") != std::string::npos || after.find("fight") != std::string::npos ||
                          after.find("cassandra") != std::string::npos;
        g_goal_cp.name = boss ? "Boss fight" : g.after == static_cast<int>(cps.size()) - 1 ? "Level exit" : "Cutscene";
        return &g_goal_cp;
    }
    const auto& cps = level_geometry::Checkpoints();
    const int next = g_cp_current + 1;
    return next >= 0 && next < static_cast<int>(cps.size()) ? &cps[next] : nullptr;
}

// Each tick (known position): the checkpoint he's past, his place, the path, the waypoint; the chime.
void WaypointUpdate(unsigned now_ms, const position::Pos& s, const std::string& node, Output* out) {
    const auto& cps = level_geometry::Checkpoints();
    if (cps.empty()) return;
    // Placed at the checkpoint whose spawn he's at (a level start, a respawn), then along the trigger rectangles.
    const bool jumped = g_have_last && std::hypot(s.x - g_last_x, s.y - g_last_y) > kRespawnJumpPx;
    // B28b (mark 1, 2-c "stairstep swing points": its trigger is 208 px wide, and with only the pings (0.5 s apart,
    // ~385 px running) neither was inside it): the way from the last position to this one counts too.
    const float from_x = g_have_last && !jumped ? g_last_x : s.x, from_y = g_have_last && !jumped ? g_last_y : s.y;
    g_last_x = s.x;
    g_last_y = s.y;
    g_have_last = true;
    if (jumped) g_hold_up = g_hold_down = g_hold_fwd = g_hold_back = false;  // (B44f: a respawn or a warp: a new Shank)
    if (!g_cp_placed || jumped) {
        int best = -1;
        float best_d = kSpawnSnapPx;
        for (const auto& c : cps) {
            const float d = std::hypot(c.spawn_x - s.x, c.spawn_y - s.y);
            if (d < best_d) {
                best_d = d;
                best = c.order;
            }
        }
        if (best >= 0 || !g_cp_placed) {
            g_cp_current = best >= 0 ? best : 0;
            alog::Write("waypoint: at checkpoint %d (%s)", g_cp_current, cps[g_cp_current].name.c_str());
        }
        // B29-2 (the user: "Announce the level name when one finishes loading"): the chapter he starts in, once per load.
        if (!g_cp_placed && !g_chapter_said) {
            std::string name;
            for (const level_geometry::Chapter& ch : level_geometry::Chapters()) {
                if (ch.checkpoint <= g_cp_current) name = ch.name;
            }
            if (!name.empty()) {
                g_chapter = name;
                alog::Write("cues: chapter %s", name.c_str());
            }
            g_chapter_said = true;
        }
        // (B29-6: a respawn: its checkpoint's story goals are ahead again. B47c-10, B47 session 3 mark 1 "waypoint is
        // misaligned at start of level": 3-c's opening cinematic moves him, and that jump cleared the goal just reached, so
        // Q pointed back at it: only a respawn at a checkpoint's spawn clears them.)
        if (best >= 0 || !g_cp_placed) g_goals_done.clear();
        g_cp_placed = true;
    }
    for (const auto& c : cps) {
        if (c.order <= g_cp_current || !c.has_region) continue;
        if (SegmentMeetsBox(from_x, from_y, s.x, s.y, c.rx - 32, c.ry - 32, c.rx + c.rw + 32, c.ry + c.rh + 32)) {
            g_cp_current = c.order;
            alog::Write("waypoint: reached checkpoint %d (%s)", c.order, c.name.c_str());
            // B31-4 (mark 4, 3-c: "no level transition announcement"): a checkpoint that starts a chapter ("Bombs and Bells" at
            // "Bell Tower entrance") says the chapter's name, as a level start does.
            for (const level_geometry::Chapter& ch : level_geometry::Chapters()) {
                if (ch.checkpoint == c.order && ch.checkpoint > 0) {
                    g_chapter = ch.name;
                    alog::Write("cues: chapter %s", ch.name.c_str());
                }
            }
            const level_geometry::Checkpoint* next = NextCheckpoint();
            if (g_wp_on) {
                if (!g_say.empty()) g_say += ". ";
                g_say += "Checkpoint. " + (next ? "Next: " + next->name : std::string("No next checkpoint"));
            }
        }
    }
    // B29-6: the current checkpoint's story goals, entered in turn
    for (int pending = PendingGoal(); pending >= 0; pending = PendingGoal()) {
        const level_geometry::Goal& g = level_geometry::Goals()[pending];
        if (!SegmentMeetsBox(from_x, from_y, s.x, s.y, g.rx - 32, g.ry - 32, g.rx + g.rw + 32, g.ry + g.rh + 32)) break;
        g_goals_done.insert(pending);
        alog::Write("waypoint: reached the %s trigger after checkpoint %d", g.kind.c_str(), g.after);
        const level_geometry::Checkpoint* next = NextCheckpoint();
        if (g_wp_on) {
            if (!g_say.empty()) g_say += ". ";
            g_say += "Checkpoint. " + (next ? "Next: " + next->name : std::string("No next checkpoint"));
        }
    }
    if (!node.empty()) g_wp_node = node;
    const level_geometry::Checkpoint* goal = NextCheckpoint();
    if (!goal) {
        g_wp_path.clear();
        g_wp_target.clear();
        g_wp_floor.clear();
        return;
    }
    if (goal->order != g_wp_goal_cp) {
        g_wp_goal_cp = goal->order;
        g_wp_goals = GoalsFor(*goal);
        g_wp_path_ms = 0;
    }
    if (!g_wp_path_ms || now_ms - g_wp_path_ms >= kWaypointPathMs) {
        g_wp_path_ms = now_ms ? now_ms : 1;
        // (B47c-7: on a slide pole he only goes down from here)
        float from_c = -1.f;
        if (g_wp_node.size() > 1 && g_wp_node[0] == 'p') {
            const int fi = std::atoi(g_wp_node.c_str() + 1);
            const auto& fs = level_geometry::Features();
            if (fi >= 0 && fi < static_cast<int>(fs.size()) && fs[fi].type == "slide_pole") from_c = s.y;
        }
        g_wp_path = g_wp_node.empty() ? std::vector<pathing::Step>() : pathing::Path(g_wp_node, g_wp_goals, s.x, from_c);  // (B27-3: walking counts)
        g_wp_target.clear();
        g_wp_floor.clear();
        for (const pathing::Step& st : g_wp_path) {
            if (!IsFloorNode(st.to)) {
                g_wp_target = st.to;
                break;
            }
        }
        if (!g_wp_path.empty() && IsFloorNode(g_wp_path[0].to) && g_wp_path[0].move != "climb") g_wp_floor = g_wp_path[0].to;
        const std::string now = g_wp_node + " -> " + (g_wp_target.empty() ? "(none)" : g_wp_target) + " (" +
                                std::to_string(g_wp_path.size()) + " moves)";
        if (g_wp_on && now != g_wp_logged) {
            alog::Write("waypoint: %s, next checkpoint %s", now.c_str(), goal->name.c_str());
            g_wp_logged = now;
        }
    }
    // B48 (the user: "Add a mod menu option to have each move spoken when the previous one was completed. This should not
    // trigger if a number changes or shank turns around, only when waypoint mode is on and the actual interaction being
    // pointed at changes."): keyed on the waypoint's target (a pole's two sides are one), spoken once it holds for
    // kMoveSayStableMs (the path flickering between two ways says nothing).
    {
        std::string key = g_wp_target.empty() ? "goal " + goal->name : g_wp_target;
        if (key.size() > 1 && key[0] == 'p' && (key.back() == 'L' || key.back() == 'R')) key.pop_back();
        if (!g_wp_on || !announce::On(announce::kMoves) || g_move_said == kMoveAdopt) {
            g_move_said = key;  // (turned on later: nothing until the target changes)
            g_move_pending.clear();
        } else if (key == g_move_said) {
            g_move_pending.clear();
        } else if (key != g_move_pending) {
            g_move_pending = key;
            g_move_pending_ms = now_ms;
        } else if (now_ms - g_move_pending_ms >= kMoveSayStableMs) {
            g_move_said = key;
            g_move_pending.clear();
            const std::string text = NextMoveLocked(s);
            if (!g_say.empty()) g_say += ". ";
            g_say += text;
            alog::Write("waypoint: next move said (%s): \"%s\"", key.c_str(), text.c_str());
        }
    }
    // The chime at the next checkpoint.
    if (g_wp_on && static_cast<int>(now_ms - g_wp_chime_ms) >= 0) {
        float cx, cy;
        CheckpointSpot(*goal, &cx, &cy);
        const float d = std::hypot(cx - s.x, cy - s.y);
        const float c = Clamp(d / kWaypointRangePx, 0.f, 1.f);
        out->plays.push_back(PlayCmd{audio::kWaypointChime, Clamp((cx - s.x) / kPanRangePx, -1.f, 1.f),
                                     Clamp((cy - s.y) / kPixelsPerSemitone, -8.f, 8.f), 0.8f - 0.4f * c});
        g_wp_chime_ms = now_ms + kChimeFastestMs + static_cast<unsigned>(kChimeSpanMs * c);
    }
}

// Waypoint mode is guiding (on, with a path): the other traversal cues are silent.
bool Guiding() { return g_wp_on && !g_wp_path.empty(); }

// B9-2: the platform overhead (see the call in TargetCues). reach: the jump from where he stands.
int g_overhead_surface = -1;       // the platform last announced (-1 = none)
unsigned g_overhead_lost_ms = 0;   // when it went out of reach (0 = in reach)
template <typename ReachFn>
void OverheadCue(unsigned now_ms, const position::Pos& s, const ReachFn& reach, Output* out) {
    const float feet = s.y - kShankRadius;
    const level_geometry::Surface* best = nullptr;
    float best_d = 1e9f, bx = 0, by = 0;
    for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
        for (size_t i = 0; i + 1 < f.points.size(); ++i) {
            const auto& a = f.points[i];
            const auto& b = f.points[i + 1];
            // B9b: only a platform he's under (the user: the B9 chirps fired "for small ledges and steps that shank
            // traverses without user input"; those are edges beside him, the edge cue's job).
            if (s.x < a.first + kShankRadius || s.x > b.first - kShankRadius) continue;
            const float nx = s.x;
            const float ny = b.first > a.first ? a.second + (nx - a.first) / (b.first - a.first) * (b.second - a.second) : a.second;
            const float up = ny - feet, aside = 0.f;
            if (up < kOverheadMinUpPx || up > kOverheadMaxUpPx) continue;
            if (!AreaHas(nx, ny + kShankRadius) || level_geometry::InPit(nx, ny)) continue;
            const float d = std::hypot(aside, up);
            if (d >= best_d) continue;
            const jump_model::Target t{jump_model::kLanding, a.first, a.second, b.first, b.second};
            if (reach(t) == jump_model::kNone) continue;
            best = &f;
            best_d = d;
            bx = nx;
            by = ny + kShankRadius;
        }
    }
    if (!best) {
        if (g_overhead_surface >= 0 && !g_overhead_lost_ms) g_overhead_lost_ms = now_ms ? now_ms : 1;
        if (g_overhead_surface >= 0 && now_ms - g_overhead_lost_ms >= kOverheadForgetMs) g_overhead_surface = -1;
        return;
    }
    g_overhead_lost_ms = 0;
    if (best->id == g_overhead_surface) return;
    g_overhead_surface = best->id;
    alog::Write("cues: platform overhead in reach at (%.0f, %.0f), surface %d", bx, by, best->id);
    out->plays.push_back(PlayCmd{audio::kJumpNow, Clamp((bx - s.x) / kPanRangePx, -1.f, 1.f),
                                 Clamp((by - s.y) / kPixelsPerSemitone, -8.f, 8.f), 0.9f});
}

void TargetCues(unsigned now_ms, const position::Pos& s, Output* out) {
    if (!s.known) return;
    // Jumps are judged from the ground (the long or standing jump) or clinging to a climbable wall (the
    // wall jump). Clinging = in the air beside a climbable wall and not moving sideways (B5 log: mid-jump
    // near a wall counted as clinging).
    // On the ground: on a surface and not moving up or down (mid-jump past a floor's height had counted).
    // B27-4 (the user, 4-c: "no jump alert on last slide"): sliding down a steep slippery slope he falls ~900 px/s along
    // it, which counted as in the air: on a slippery floor, going down (or level) is on the ground too.
    const level_geometry::Surface* under_now = level_geometry::SurfaceUnder(s.x, s.y);
    const bool slippery_now = under_now && under_now->tags.find("slippery") != std::string::npos;
    const bool grounded = under_now != nullptr && (std::fabs(s.vy) < kGroundedMaxVy || (slippery_now && s.vy < kGroundedMaxVy));
    const level_geometry::Wall* cling =
        grounded || std::fabs(s.vx) > kClingMaxVx ? nullptr : level_geometry::WallBeside(s.x, s.y);
    const bool away_right = cling && !cling->faces_left;  // a wall met moving left is on his left
    // On a pole (B5d; the user at the top of 1-c's tall pole: "No jump chirp is playing for either"): the
    // game's pole jump (shimmy_pole_jump) is the wall jump, away from the pole.
    const jump_model::Target* pole = nullptr;
    jump_model::Target pole_t{};
    int pole_index = -1;
    if (!grounded && !cling) {
        const auto& fs = level_geometry::Features();
        for (size_t i = 0; i < fs.size(); ++i) {
            jump_model::Target t;
            if ((fs[i].type == "pole" || fs[i].type == "slide_pole") && ToTarget(fs[i], &t) && OnPole(t, s)) {
                pole_t = t;
                pole = &pole_t;
                pole_index = static_cast<int>(i);
            }
        }
    }
    const bool pole_away_right = pole && s.x > (pole_t.x1 + pole_t.x2) / 2;
    // B6-2: wall running: the wall-run jump (forward), or near the zone's end the long jump.
    jump_model::Target run_zone{};
    const bool wall_run = !grounded && !cling && !pole && WallRun(s, &run_zone);
    const bool run_right = s.vx > 0;
    const float run_left_px = run_right ? run_zone.x2 - s.x : s.x - run_zone.x1;
    // Swinging on a swing point: the jump is letting go (B5d; the user: "The second swing point does not show
    // up as a valid jump target, even though you jump directly there from the first").
    bool swinging = false, on_bar = false;
    int hold_index = -1;  // B10: the swing point / bar he's on
    if (!grounded && !cling && !pole && !wall_run) {
        const auto& fs = level_geometry::Features();
        for (size_t i = 0; i < fs.size(); ++i) {
            jump_model::Target t;
            if (!ToTarget(fs[i], &t) || !InUse(t, s, false)) continue;
            // B48e (1-b pretrain mark 3: sliding off s14's end at ~760 px/s under shimmy line f8, the cue took him as hanging
            // from it and chirped the bar's jumps at the moment the slide's long jump was due): shimmying is ~290 px/s at most.
            if (fs[i].type == "shimmy_line" && std::fabs(s.vx) > kOnBarMaxVx) continue;
            if (fs[i].type == "swing_point") swinging = true;
            if (fs[i].type == "shimmy_line") on_bar = true;  // B5e: hanging from a bar/rope
            hold_index = static_cast<int>(i);
        }
    }
    // B10: his place in the traversal graph, and the waypoint.
    std::string node;
    // B20-4: what he's doing decides which aims his gun has (InLineAim)
    g_shank_mode = grounded ? kModeGround : cling || pole ? kModeWall : hold_index >= 0 ? kModeHanging : kModeAir;
    if (grounded) {
        node = "s" + std::to_string(level_geometry::SurfaceUnder(s.x, s.y)->id);
    } else if (cling) {
        node = "w" + std::to_string(cling - &level_geometry::Walls()[0]);
    } else if (pole) {
        node = "p" + std::to_string(pole_index) + (pole_away_right ? "R" : "L");
    } else if (hold_index >= 0) {
        node = "f" + std::to_string(hold_index);
    } else if (wall_run) {
        const auto& fs = level_geometry::Features();
        for (size_t i = 0; i < fs.size(); ++i) {
            if (fs[i].type == "wallrun_zone" && !fs[i].points.empty() && fs[i].points[0].first == run_zone.x1) node = "f" + std::to_string(i);
        }
    }
    g_live_node = node;  // B27-6: what he's on right now (T)
    WaypointUpdate(now_ms, s, node, out);
    const bool guiding = Guiding();
    // The pole's other side is the next place (1-c's pole and pillar; the user: "just present it as a jump target").
    if (guiding && pole && !g_wp_path.empty() && g_wp_path[0].move == "bounce" && g_wp_path[0].from == node) {
        const float other_x = (pole_t.x1 + pole_t.x2) / 2 + (pole_away_right ? -80.f : 80.f);
        const bool at_height = std::fabs(s.y - g_wp_path[0].y) <= kBounceWindowPx;
        SoundTarget(kBounceId, "the pole's other side", other_x, s.y, false, at_height ? jump_model::kPoleJump : jump_model::kNone,
                    -1.f, now_ms, s, out);
    } else {
        Reachable(kBounceId, false, "the pole's other side", 0, 0, jump_model::kNone);
    }
    // B11-1 / B12-2: moves with their own input (switching pole sides, the jump again inside a one-way platform,
    // dropping through one): said once when it's the next move from where he is.
    // B20-3 (the user: "multiple drop through messages even though checkpoint still far away"; 56 in one session): only
    // near where the move starts (Q says it from anywhere), and the same move not again within kWaypointHintRepeatMs
    // (a fight keeps taking him off the surface and back).
    std::string hint;
    if (guiding && !g_wp_path.empty() && g_wp_path[0].from == node) {
        const pathing::Step& st = g_wp_path[0];
        const float lo = std::min(st.x_lo, st.x), hi = std::max(st.x_hi, st.x);
        const float away = s.x < lo ? lo - s.x : (s.x > hi ? s.x - hi : 0.f);
        const std::string& m = st.move;
        if (away > kWaypointHintNearPx) {
        } else if (m == "switch_sides" && pole) {
            hint = "Switch sides: hold toward the pole";
        } else if (m == "platform_up") {
            hint = "Jump up into the platform above, then jump again";
        } else if (m == "drop_through") {
            hint = "Drop through: hold down and jump";
        }
    }
    const std::string hint_key = hint.empty() ? std::string() : node + " " + g_wp_path[0].move;
    if (!hint.empty() && (g_wp_hint != hint_key || now_ms - g_wp_hint_ms >= kWaypointHintRepeatMs)) {
        if (!g_say.empty()) g_say += ". ";
        g_say += hint;
        g_wp_hint = hint_key;
        g_wp_hint_ms = now_ms;
        alog::Write("waypoint: hint \"%s\" (%s)", hint.c_str(), node.c_str());
    }
    // reach_any: any jump from where he is (the graph's view; a target it reaches is worth the pluck).
    auto reach_any = [&](const jump_model::Target& t) {
        if (grounded) {
            // B12-1: on a slippery slope he slides downhill; only the long jump that way
            const level_geometry::Surface* under = level_geometry::SurfaceUnder(s.x, s.y);
            const bool r = under && under->tags.find("slipperyright") != std::string::npos;
            const bool l = under && under->tags.find("slipperyleft") != std::string::npos;
            const int downhill = r == l ? 0 : r ? 1 : -1;  // (both ways: 3-c's roof ridge, left as a floor)
            if (downhill) return jump_model::ReachSliding(t, s.x, s.y, downhill > 0);
            return jump_model::Reach(t, s.x, s.y, s.facing_right);
        }
        if (cling) {  // running up it just after running into it: the stronger jump (B6-5)
            if (s.vy > jump_model::kRunningUpVy) return jump_model::ReachFromWallRunningUp(t, s.x, s.y, away_right);
            return jump_model::ReachFromWall(t, s.x, s.y, away_right);
        }
        if (pole) {  // B10b: away from the pole, or through it (the game moves him to the other side first)
            const jump_model::Jump j = jump_model::ReachFromPole(t, s.x, s.y, pole_away_right);
            if (j != jump_model::kNone) return j;
            const float other_x = (pole_t.x1 + pole_t.x2) / 2 + (pole_away_right ? -jump_model::kPoleSideDx : jump_model::kPoleSideDx);
            return jump_model::ReachFromPole(t, other_x, s.y, !pole_away_right);
        }
        if (wall_run) {
            const jump_model::Jump j = jump_model::ReachFromWallRun(t, s.x, s.y, run_right);
            if (j != jump_model::kNone || run_left_px > kWallRunLongWindowPx) return j;
            return jump_model::Reach(t, s.x, s.y, run_right) == jump_model::kLong ? jump_model::kLong : jump_model::kNone;
        }
        if (swinging) return jump_model::ReachFromSwing(t, s.x, s.y, s.ping_facing_right);
        if (on_bar) return jump_model::ReachFromBar(t, s.x, s.y, s.ping_facing_right);
        return jump_model::kNone;
    };
    // B44-2 (the user: "a jump alert should only sound when it is reachable by a jump given shank's current direction and
    // speed"): reach = only the jump his input and speed make now (the chirp). On the ground the standing jump until he
    // runs his facing way at kLongJumpMinVx (then the long jump); on a bar or swing point Up held = the jump up, else the
    // jump forward; Down held on a wall, pole, bar or swing point = letting go (Down + Jump).
    const bool moving = std::fabs(s.vx) >= kLongJumpMinVx && (s.vx > 0) == s.facing_right;
    // B44e (the user, 2-b: "Holding up just before last death reported false jump target": holding Up only on a bar, the jump
    // up was judged drifting 236 px onto a landing; the log: he went straight up, x unchanged, and fell): the jump up off a
    // bar or swing point drifts only while a direction is held (his facing way: holding back turns him first). (Not the
    // standing jump: "Zero input jumps do not guarantee straight up, I released all directions and jumped from the same
    // point and made it safely" - that was the bar's forward jump, the one he makes without Up.)
    const bool steer = g_hold_fwd || g_hold_back;
    auto reach = [&](const jump_model::Target& t) {
        if (grounded) {
            const level_geometry::Surface* under = level_geometry::SurfaceUnder(s.x, s.y);
            const bool r = under && under->tags.find("slipperyright") != std::string::npos;
            const bool l = under && under->tags.find("slipperyleft") != std::string::npos;
            if (r != l) return reach_any(t);  // (sliding: the slide's own jump)
            return moving ? jump_model::ReachLong(t, s.x, s.y, s.facing_right) : jump_model::ReachStanding(t, s.x, s.y, s.facing_right);  // (B44e: drifts his facing way with or without input: the user, "Zero input jumps do not guarantee straight up")
        }
        if (g_hold_down && (cling || pole || swinging || on_bar)) {
            return jump_model::ReachFalling(t, s.x, s.y, s.ping_facing_right) != jump_model::kNone ? jump_model::kWalkOff : jump_model::kNone;
        }
        if (swinging) return jump_model::ReachFromSwingAs(t, s.x, s.y, s.ping_facing_right, g_hold_up, steer);
        if (on_bar) return jump_model::ReachFromBarAs(t, s.x, s.y, s.ping_facing_right, g_hold_up, steer);
        // B48 (the user, 2026-10-02: "pole and wall jumps should always play the jump cue if the jump is in vertical range.
        // Holding toward the jump generally causes shank to slide, which can cause a jump to become out of range, especially
        // in tight windows."): off a wall or pole, every steering of the jump counts, held direction or not (B47 fix 2, the
        // unsteered jump unless a direction was held, taken back). reach_any: the wall jump (or the run-up's), the pole jump.
        return reach_any(t);
    };
    // The far side of a deadly drop: the countdown and the chirp only (the edge cue already marks the drop).
    jump_model::Target land;
    float lx = 0, ly = 0;
    if (grounded && FarSide(s, &land, &lx, &ly) &&
        (!guiding || "s" + std::to_string(FloorBelow(lx, ly)) == g_wp_floor)) {  // B10: guided, only the path's floor
        const jump_model::Jump j = reach(land);
        // (B44-3: a jump from here would reach it, not the one he'd make now (standing, a long jump would): the pluck)
        SoundTarget(kLandingId, "the far side", lx, ly, j == jump_model::kNone && reach_any(land) != jump_model::kNone, j,
                    j == jump_model::kNone ? LeadIn(land, s) : -1.f, now_ms, s, out);
    } else {
        Reachable(kLandingId, false, "the far side", lx, ly, jump_model::kNone);
    }
    // B9-2 (Phase 6, the user's goal C: "a platform overhead"): on the ground, the nearest surface above him that a
    // jump now lands on (up through a one-way platform, or onto a ledge's top); one chirp when it comes in reach, not
    // repeated while he stays (it would chirp under every ledge), again after a second out of reach or for another.
    if (grounded && !guiding) OverheadCue(now_ms, s, reach, out);  // B10: guided, the path says where to go
    int wall_sounded = -1;
    if (cling || pole || swinging || on_bar || wall_run) {
        // Other climbable walls facing him (clinging: on the jump side): the nearest a jump from here catches chirps.
        // B47b-2 (the user, 2026-10-02: "yes, climbable walls should be jump targets"; the replay: ~25 real catches of walls
        // from swing points, bars, poles and wall runs had no chirp): from every hold, not only from another wall.
        const auto& walls = level_geometry::Walls();
        int best = -1;
        float best_d = kJumpJudgeRangePx;
        for (size_t i = 0; i < walls.size(); ++i) {
            const level_geometry::Wall& w = walls[i];
            if (&w == cling || !w.climbable || w.faces_left != (w.x > s.x)) continue;
            if (cling && w.faces_left != away_right) continue;
            if (guiding && "w" + std::to_string(i) != g_wp_target) continue;  // B10: guided, only the waypoint
            const float wy = std::max(w.y1, std::min(w.y2, s.y));
            const float d = std::hypot(w.x - s.x, wy - s.y);
            // (B47b-2: from a bar, swing point, pole or wall run, not a wall within 2 tiles: the replay chirped the wall a bar
            // runs into all along the shimmy, 1-c (2624, 3904))
            const float min_dx = cling ? level_geometry::kWallClingPx : kWallFromHoldMinDxPx;
            if (std::fabs(w.x - s.x) <= min_dx || d > best_d || !AreaHas(w.x, wy)) continue;
            const jump_model::Target t{jump_model::kWall, w.x, w.y1, w.x, w.y2};
            if (reach_any(t) == jump_model::kNone) continue;
            best = static_cast<int>(i);
            best_d = d;
        }
        if (best >= 0) {
            const level_geometry::Wall& w = walls[best];
            const jump_model::Target t{jump_model::kWall, w.x, w.y1, w.x, w.y2};
            const jump_model::Jump j = reach(t);
            if (best_d <= kTargetRangePx || j != jump_model::kNone) {  // (beyond the pluck range: the chirp only)
                SoundTarget(kWallIdBase + best, "a wall", w.x, std::max(w.y1, std::min(w.y2, s.y)), best_d <= kTargetRangePx, j,
                            -1.f, now_ms, s, out);  // (B44-3)
                wall_sounded = best;
            }
        }
    }
    // B5e: hanging, clinging, on a pole or swinging, the nearest surface he'd have to jump to (at least
    // kLandingAsidePx to the side) chirps when the jump now lands on it (the user, after the fatal jump off
    // 1-c's bar: "I need to jump from that onto something, but there was no jump target ever presented").
    if (cling || pole || swinging || on_bar || wall_run) {
        const level_geometry::Surface* best = nullptr;
        jump_model::Target best_t{};
        // (B47: as far as a jump goes, not the pluck range; B47c-9, B47 session 3 mark 3 "no jump alert at floor from wall": guided,
        // the path's floor 14 tiles across and 25 down (29 tiles off) was never judged: as far as the waypoint)
        float best_d = guiding ? kWaypointRangePx : kJumpJudgeRangePx, bx = 0, by = 0;
        // B12-2: guided to a one-way platform by the jump again inside it (often right above him): that platform counts.
        const bool up_next = guiding && !g_wp_path.empty() && g_wp_path[0].move == "platform_up";
        // B43 (the user, waypoint mode off: "climbing the first wall in meat packing plays two jump targets, even though I can
        // only reach the first swing point"; the street below chirped up to ~10 tiles up the wall): the floor letting go
        // lands him on (the one he came from, the one below) is no jump target. Guided, the path decides.
        int drop_floor = -1;
        if (!guiding) {
            float dx = 0, dy = 0;
            if (jump_model::Land(s.x, s.y, 0.f, -50.f, &dx, &dy)) {
                if (const level_geometry::Surface* below = level_geometry::SurfaceUnder(dx, dy)) drop_floor = below->id;
            }
        }
        for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
            for (size_t i = 0; i + 1 < f.points.size(); ++i) {
                const auto& a = f.points[i];
                const auto& b = f.points[i + 1];
                if (!up_next && s.x >= a.first - kLandingAsidePx && s.x <= b.first + kLandingAsidePx) continue;  // under him
                // The nearest point (right above him for a platform overhead, B12-2).
                const float nx = std::max(a.first, std::min(b.first, s.x));
                const float ny = b.first > a.first ? a.second + (nx - a.first) / (b.first - a.first) * (b.second - a.second) : a.second;
                const float d = std::hypot(nx - s.x, ny + kShankRadius - s.y);
                if (d >= best_d || !AreaHas(nx, ny + kShankRadius)) continue;
                // B6-7: a floor inside a fatal pit zone (1-c's grinders) is no landing.
                if (level_geometry::InPit((a.first + b.first) / 2, (a.second + b.second) / 2)) continue;
                if (guiding && "s" + std::to_string(f.id) != g_wp_floor) continue;  // B10: guided, only the path's floor
                if (f.id == drop_floor) continue;  // (B43)
                jump_model::Target t{jump_model::kLanding, a.first, a.second, b.first, b.second};
                t.oneway = up_next && f.tags.find("skinny") != std::string::npos;
                if (reach_any(t) == jump_model::kNone) continue;  // (B44-3: the pluck if only another input reaches it)
                best = &f;
                best_t = t;
                best_d = d;
                bx = nx;
                by = ny + kShankRadius;
            }
        }
        if (best) {
            SoundTarget(kPerchId, "a landing", bx, by, true, reach(best_t), -1.f, now_ms, s, out);
        } else {
            Reachable(kPerchId, false, "a landing", 0, 0, jump_model::kNone);
        }
    }
    // Features: the nearest few within range pluck; the countdown and the chirp as above; silent while in use.
    struct Near {
        int id;
        float d, x, y;
        jump_model::Target t;
        const char* name;
    };
    std::vector<Near> cands;
    const auto& features = level_geometry::Features();
    for (size_t i = 0; i < features.size(); ++i) {
        jump_model::Target t;
        if (!ToTarget(features[i], &t)) continue;
        float nx, ny;
        NearestPoint(features[i], s.x, s.y, &nx, &ny);
        const float d = std::hypot(nx - s.x, ny - s.y);
        // Running, the countdown looks a second further ahead than the nearby range.
        // (B47: judged out to kJumpJudgeRangePx: a swing release carries ~15 tiles; the pluck stays within kTargetRangePx)
        float range = std::max(kJumpJudgeRangePx, kTargetRangePx + (grounded ? std::fabs(s.vx) * kLeadInSeconds : 0.f));
        const bool waypoint = guiding && FeatureOf(g_wp_target) == static_cast<int>(i);
        if (guiding && !waypoint) {  // B10: guided, only the next object on the path
            Reachable(static_cast<int>(i), false, FeatureName(features[i].type), nx, ny, jump_model::kNone);
            continue;
        }
        if (waypoint) range = kWaypointRangePx;  // (inside the bounds: AreaHas below)
        if (d > range || !AreaHas(nx, ny)) continue;
        // B8c: at a slide pole's foot it can only take him back to where he is: as if it weren't there.
        const bool at_foot = t.slide && s.y < std::min(t.y1, t.y2) + kSlideFootPx;
        if (at_foot || InUse(t, s, grounded)) {
            Reachable(static_cast<int>(i), false, FeatureName(features[i].type), nx, ny, jump_model::kNone);
            continue;
        }
        cands.push_back(Near{static_cast<int>(i), d, nx, ny, t, FeatureName(features[i].type)});
    }
    std::sort(cands.begin(), cands.end(), [](const Near& a, const Near& b) { return a.d < b.d; });
    // B10: a climbable wall as the waypoint: its pluck (it chirps from the wall-to-wall cue while clinging).
    if (guiding && g_wp_target.size() > 1 && g_wp_target[0] == 'w' && !cling) {
        const auto& walls = level_geometry::Walls();
        const size_t wi = static_cast<size_t>(std::atoi(g_wp_target.c_str() + 1));
        if (wi < walls.size() && static_cast<int>(wi) != wall_sounded) {  // (B47b-2: chirped from a hold above)
            const level_geometry::Wall& w = walls[wi];
            const float wy = std::max(w.y1, std::min(w.y2, s.y));
            if (std::hypot(w.x - s.x, wy - s.y) <= kWaypointRangePx && AreaHas(w.x, wy)) {
                SoundTarget(kWallIdBase + static_cast<int>(wi), "a wall", w.x, wy, true, jump_model::kNone, -1.f, now_ms, s, out);
            }
        }
    }
    for (size_t k = 0; k < cands.size(); ++k) {
        const Near& n = cands[k];
        const jump_model::Jump j = reach(n.t);
        const float lead = grounded && j == jump_model::kNone ? LeadIn(n.t, s) : -1.f;
        const bool waypoint = guiding && FeatureOf(g_wp_target) == n.id;
        if (!waypoint && n.d > kTargetRangePx && j == jump_model::kNone && lead < 0.f) continue;  // beyond range, no window
        SoundTarget(n.id, n.name, n.x, n.y, waypoint || (k < kTargetsSounded && n.d <= kTargetRangePx), j, lead, now_ms, s, out);
    }
}

}  // namespace

float EdgeCloseness(float distance, float speed_toward) {
    // The range grows with speed (the user: the range was "way to short, especially at speed").
    const float range = std::max(kEdgeRangePx, speed_toward * kEdgeRangeSeconds);
    const float c = distance / range;
    return c < 0.f ? 0.f : c;
}

std::string KindName(const std::string& kind) {
    static const struct {
        const char* kind;
        const char* name;
    } kNames[] = {{"health", "Health"},     {"grenades", "Grenades"}, {"minigun", "Minigun"},
                  {"grenadelauncher", "Grenade launcher"}, {"flamethrower", "Flamethrower"},
                  {"machete", "Machete"},   {"sword", "Katana"},      {"uzi", "Uzi"},
                  {"shotgun", "Shotgun"}};
    for (const auto& k : kNames) {
        if (kind == k.kind) return k.name;
    }
    return kind.empty() ? std::string("Pickup") : kind;
}

void TrackHazard(const std::string& kind, float x, float y, unsigned now_ms) {
    Hazard* best = nullptr;
    float best_d = kHazardMatchPx;
    for (Hazard& h : g_hazards) {
        if (h.kind != kind) continue;
        const float dt = (now_ms - h.seen_ms) / 1000.f;
        const float d = std::hypot(h.x + h.vx * dt - x, h.y + h.vy * dt - y);
        if (d < best_d) {
            best = &h;
            best_d = d;
        }
    }
    if (!best) {
        Hazard fresh;
        fresh.kind = kind;
        fresh.x = x;
        fresh.y = y;
        fresh.seen_ms = fresh.next_ms = now_ms;
        g_hazards.push_back(fresh);
        alog::Write("cues: hazard %s at (%.0f, %.0f)", kind.c_str(), x, y);
        return;
    }
    const float dt = (now_ms - best->seen_ms) / 1000.f;
    if (dt > 0.03f) {
        best->vx = (x - best->x) / dt;
        best->vy = (y - best->y) / dt;
    }
    best->x = x;
    best->y = y;
    best->seen_ms = now_ms;
}

// B7: one hazard's warning this tick (DESIGN "Hazard warnings"): how close it is to hurting him, 0 (on him)
// to 1 (the edge of its warning range), or < 0 = no warning.
// Where a hazard is now: a moving one carried on at its measured speed since its last report (B7b: rockets at
// ~1500 px/s were heard up to 0.1 s behind, "the audio cue would pan significantly slower than it").
void HazardNow(const Hazard& h, unsigned now_ms, float* x, float* y) {
    const float dt = std::min((now_ms - h.seen_ms) / 1000.f, kHazardExtrapolateSeconds);
    *x = h.x + h.vx * dt;
    *y = h.y + h.vy * dt;
}

float HazardCloseness(Hazard& h, const position::Pos& s, unsigned now_ms) {
    float hx, hy;
    HazardNow(h, now_ms, &hx, &hy);
    const float dx = hx - s.x, dy = hy - s.y;
    const float d = std::hypot(dx, dy);
    if (h.kind == "rock" || h.kind == "ceiling") {
        if (dy < -64.f || std::fabs(dx) > kFallWarnPx) return -1.f;  // below him, or well to the side
        return Clamp((std::fabs(dx) - kFallColumnPx) / (kFallWarnPx - kFallColumnPx), 0.f, 1.f);
    }
    if (h.kind == "rocket" || h.kind == "missile") {
        if (d > kProjectileWarnPx) return -1.f;
        // Fast: judged by the time until it gets to him at its speed (up to kProjectileWarnSeconds).
        const float speed = std::max(std::hypot(h.vx, h.vy), kProjectileMinSpeed);
        const bool closing = h.vx * -dx + h.vy * -dy > 0.f;  // moving toward him
        const float c = Clamp(d / speed / kProjectileWarnSeconds, 0.f, 1.f);
        if (!closing && d > kProjectileAwayPx) return -1.f;  // gone past him (B7b)
        return closing ? c : 0.5f + 0.5f * c;  // moving away: slower and softer
    }
    if (h.kind == "grenade") {
        // B15-5: in flight, heard from the throw on (following it); once it lies still, by its blast as before
        const bool flying = std::hypot(h.vx, h.vy) > kGrenadeFlyingSpeed;
        if (flying && d <= kGrenadeFlightWarnPx) {
            const float c = Clamp((d - kBlastPx) / (kGrenadeFlightWarnPx - kBlastPx), 0.f, 1.f);
            const bool closing = h.vx * -dx + h.vy * -dy > 0.f;
            return closing ? c : 0.5f + 0.5f * c;  // flying away from him: slower
        }
        if (d > kGrenadeWarnPx) return -1.f;
        return Clamp((d - kBlastPx) / (kGrenadeWarnPx - kBlastPx), 0.f, 1.f);
    }
    if (h.kind == "fire") {  // B13-3: 3-c's fire traps burn him within ~2 tiles, on their level
        if (std::fabs(dy) > kFireLevelPx || std::fabs(dx) > kFireWarnPx) return -1.f;
        return Clamp((std::fabs(dx) - kFireBurnPx) / (kFireWarnPx - kFireBurnPx), 0.f, 1.f);
    }
    if (h.kind == "barrel") {
        if (d > kBarrelWarnPx || !Inside(h.x, h.y)) return -1.f;
        if (!h.clear_ms || now_ms - h.clear_ms >= kLineCheckMs) {  // his gun (chest height) to the barrel's middle
            h.clear = level_geometry::LineClear(s.x, s.y + 48.f, h.x, h.y + 32.f);
            h.clear_ms = now_ms ? now_ms : 1;
        }
        if (!h.clear) return -1.f;
        return Clamp((d - kBlastPx) / (kBarrelWarnPx - kBlastPx), 0.f, 1.f);  // inside its blast: fastest
    }
    return -1.f;
}

void HazardCues(unsigned now_ms, const position::Pos& s, Output* out) {
    for (size_t i = 0; i < g_hazards.size();) {
        const unsigned stale = g_hazards[i].kind == "barrel" || g_hazards[i].kind == "fire" ? kBarrelStaleMs : kHazardStaleMs;
        if (now_ms - g_hazards[i].seen_ms > stale) {
            alog::Write("cues: hazard %s at (%.0f, %.0f) gone", g_hazards[i].kind.c_str(), g_hazards[i].x, g_hazards[i].y);
            g_hazards.erase(g_hazards.begin() + i);
        } else {
            ++i;
        }
    }
    if (!s.known) return;
    struct Warn {
        Hazard* h;
        float close;
    };
    std::vector<Warn> warns;
    for (Hazard& h : g_hazards) {
        const float c = HazardCloseness(h, s, now_ms);
        if (c >= 0.f) warns.push_back(Warn{&h, c});
        // B15-3 (the user: the game "highlights the explosives ... to illustrate how you can use them against enemies";
        // "translate these visual hints into spoken ones"): the first explosive in range in a level says it once.
        if (c >= 0.f && h.kind == "barrel" && !g_explosive_hint_said && announce::On(announce::kTips)) {
            g_explosive_hint_said = true;
            if (!g_say.empty()) g_say += ". ";
            g_say += "Explosives nearby. Shoot them to hurt the enemies near them";
        }
    }
    std::sort(warns.begin(), warns.end(), [](const Warn& a, const Warn& b) { return a.close < b.close; });
    for (size_t k = 0; k < warns.size() && k < kHazardsSounded; ++k) {
        Hazard& h = *warns[k].h;
        const float c = Clamp(warns[k].close, 0.f, 1.f);
        const bool projectile = h.kind == "rocket" || h.kind == "missile";
        const unsigned gap = kHazardFastestMs + static_cast<unsigned>((projectile ? kProjectileSpanMs : kHazardSpanMs) * c);
        if (static_cast<int>(now_ms - h.next_ms) < 0) {
            if (static_cast<int>(h.next_ms - now_ms) > static_cast<int>(gap)) h.next_ms = now_ms + gap;  // nearer now
            continue;
        }
        const audio::Sound sound = h.kind == "rock" || h.kind == "ceiling"  ? audio::kHazardFall
                                   : h.kind == "rocket" || h.kind == "missile" ? audio::kHazardProjectile
                                   : h.kind == "fire"                          ? audio::kHazardFire
                                                                               : audio::kHazardExplosive;
        float hx, hy;
        HazardNow(h, now_ms, &hx, &hy);
        const float pan = Clamp((hx - s.x) / kPanRangePx, -1.f, 1.f);
        const float semis = Clamp((hy - s.y) / kPixelsPerSemitone, -8.f, 8.f);
        out->plays.push_back(PlayCmd{sound, pan, semis, 1.f - 0.5f * c});
        h.next_ms = now_ms + gap;
    }
}

// Tiles, spoken the way the P summary does it.
std::string Tiles(float px) {
    const int t = static_cast<int>(std::lround(std::fabs(px) / kTile));
    return std::to_string(t) + (t == 1 ? " tile" : " tiles");
}

// B8e: an enemy cue's pan: relative to Shank (full at kEnemyPanPx), or the game's own camera pan when chosen.
float EnemyPan(float x, float dx) {
    float p;
    if (g_enemy_camera_pan && g_camera_pan && g_camera_pan(x, &p)) return Clamp(p, -1.f, 1.f);
    return Clamp(dx / kEnemyPanPx, -1.f, 1.f);
}

const enemies::Enemy* FindEnemy(const std::vector<enemies::Enemy>& list, uintptr_t item) {
    for (const enemies::Enemy& e : list) {
        if (e.item == item) return &e;
    }
    return nullptr;
}

bool OnScreen(float dx, float dy) { return std::fabs(dx) <= kScreenHalfWPx && std::fabs(dy) <= kScreenHalfHPx; }

// B29-1 / B29-4: deaths heard from the game's own sounds, the moment they happen (the enemy list drops an enemy only
// when its life record says so, up to a second later: its cue went on after the kill, the user: "Enemy audio cues,
// especially boss cues, persist for a second or so after defeat"). Each death / falling scream marks the nearest enemy;
// a marked enemy leaves the cue list at once. The target-down tone (the user: "whenever the last enemy on screen dies
// regardless of lock, and also if an enemy dies outside the enemy audio cue range ... Any enemy who falls and triggers
// the falling death scream is excluded regardless of position"); the locked one's tone as before (B23-2).
std::vector<enemies::Enemy> LiveEnemies(const std::vector<enemies::Enemy>& all, unsigned now_ms, const position::Pos& s,
                                        Output* out) {
    // Falling screams: the enemy still in the list nearest the scream is falling to its death.
    for (const DeathSound& d : g_death_sounds) {
        if (!d.fell) continue;
        const enemies::Enemy* nearest = nullptr;
        float best = kFallMatchPx;
        for (const enemies::Enemy& e : all) {
            const float de = std::hypot(e.x - d.x, e.y - d.y);
            if (de < best) {
                best = de;
                nearest = &e;
            }
        }
        if (nearest) {
            if (!g_fell.count(nearest->item)) alog::Write("cues: %s is falling to its death", nearest->name.c_str());
            g_fell[nearest->item] = d.ms;
        }
    }
    // B30-1 / B31-1: an enemy that left the list is dead (the list drops it the moment it dies; B30 also wanted its death sound,
    // but finishers and grapple kills play none: the B30 log, 3-c before the first respawn, most kills had no sound). Decided
    // kDeathDecideMs later: not when Shank died then (a respawn empties the list), not when several left at once (a despawn),
    // not one that fell to its death, not one that died within kSpawnKillMs of appearing (3-c's rockets killing fresh spawns).
    std::map<uintptr_t, bool> now_in;
    for (const enemies::Enemy& e : all) {
        now_in[e.item] = true;
        if (!g_first_seen.count(e.item)) g_first_seen[e.item] = now_ms;
    }
    size_t left_now = 0;
    for (const auto& kv : g_prev_enemies) left_now += !now_in.count(kv.first);
    for (const auto& kv : g_prev_enemies) {
        if (!now_in.count(kv.first)) g_left.push_back(Left{kv.second, now_ms, left_now >= kMassLeaveCount, g_locked == kv.first});
    }
    g_prev_enemies.clear();
    for (const enemies::Enemy& e : all) g_prev_enemies[e.item] = e;
    for (size_t i = 0; i < g_left.size();) {
        if (now_ms - g_left[i].ms < kDeathDecideMs) {
            ++i;
            continue;
        }
        const enemies::Enemy gone = g_left[i].enemy;
        const unsigned left_ms = g_left[i].ms;
        const bool mass = g_left[i].mass;
        const bool locked = g_left[i].locked;
        g_left.erase(g_left.begin() + i);
        const auto seen = g_first_seen.find(gone.item);
        const bool fresh = seen != g_first_seen.end() && left_ms - seen->second < kSpawnKillMs;
        g_first_seen.erase(gone.item);
        const bool shank_died = g_shank_died_ms && (left_ms > g_shank_died_ms ? left_ms - g_shank_died_ms : g_shank_died_ms - left_ms) <= kDeathDecideMs;
        // B36-1 (the B35 log, 2-c's final fight: three killed within 125 ms gave three tones): the ones that left after it
        // and aren't decided yet were still alive when it died, so they count as on screen too.
        bool others_on_screen = false;
        // B36b-2: in an arena, one left in it counts wherever it is (4-c: a tone while a perched rifle goon remained).
        for (const enemies::Enemy& e : all) {
            if (OnScreen(e.x - s.x, e.y - s.y) || InArena(e.x, e.y)) others_on_screen = true;
        }
        for (const Left& l : g_left) {
            if (OnScreen(l.enemy.x - s.x, l.enemy.y - s.y) || InArena(l.enemy.x, l.enemy.y)) others_on_screen = true;
        }
        // B36-1: not when the whole list was lost then (the level unloading after its end video), nor a boss leaving
        // undefeated (3-c's start: the Priest walks off; a boss's death always shows his health bar at 0 first).
        const unsigned lost_ms = enemies::ListLostMs();
        const bool unloaded = lost_ms && (left_ms > lost_ms ? left_ms - lost_ms : lost_ms - left_ms) <= kDeathDecideMs;
        const bool boss_left = gone.cls == enemies::kBoss && !g_boss_down;
        const bool fell = g_fell.count(gone.item) != 0;
        const float dist = s.known ? std::hypot(gone.x - s.x, gone.y - s.y) : 0.f;
        const bool beyond = dist > kEnemyRangePx;
        const bool skip = fell || locked || mass || shank_died || fresh || unloaded || boss_left || enemies::IsTarget(gone.name);
        const bool tone = s.known && !skip && (beyond || !others_on_screen);
        alog::Write("cues: %s died at (%.0f, %.0f), %.0f px away%s%s -> %s", gone.name.c_str(), gone.x, gone.y, dist,
                    beyond ? ", beyond the cue range" : "", others_on_screen ? "" : ", the last on screen",
                    tone ? "target down" : fell ? "no tone (fell)" : locked ? "the lock's tone" : mass ? "no tone (several at once)"
                    : shank_died ? "no tone (Shank died)" : fresh ? "no tone (just appeared)"
                    : unloaded ? "no tone (the level unloading)" : boss_left ? "no tone (a boss leaving undefeated)" : "no tone");
        if (tone) out->plays.push_back(PlayCmd{audio::kTargetDown, Clamp((gone.x - s.x) / kPanRangePx, -1.f, 1.f), 0.f, 1.f});
    }
    if (g_first_seen.size() > 256) g_first_seen.clear();
    g_death_sounds.erase(std::remove_if(g_death_sounds.begin(), g_death_sounds.end(),
                                        [now_ms](const DeathSound& d) { return d.fell || d.used || now_ms - d.ms > kDeathConfirmMs; }),
                         g_death_sounds.end());
    for (auto it = g_fell.begin(); it != g_fell.end();) it = now_ms - it->second > kDeadForgetMs ? g_fell.erase(it) : std::next(it);
    std::vector<enemies::Enemy> live;
    for (const enemies::Enemy& e : all) {
        // (B29-4: a defeated boss leaves the cues; B35-1 (the user: at 0 health from weapons or grenades "the game waits in an
        // infinite grapple now state until you initiate the qte ... the grapple now message played, the boss open cue did
        // not"): not while he's open to the finisher)
        const auto open_it = g_open_until.find(e.item);
        const bool finisher = g_open_block && static_cast<int>(g_open_block_until - now_ms) > 0;  // (a finisher running)
        const bool open_now = !finisher && (e.item == g_prompt_item ||
                                            (open_it != g_open_until.end() && static_cast<int>(open_it->second - now_ms) > 0));
        if (!(g_boss_down && e.cls == enemies::kBoss && !open_now)) live.push_back(e);
    }
    return live;
}

// The aim (degrees, relative to his facing: 0 forward, 45 diagonal up, 90 up, -45 diagonal down, -90 down, 180 back) a
// pistol shot at e would need, if one of the pistol's aims is within kAimToleranceDeg and the line is clear;
// else -99.
int InLineAim(const enemies::Enemy& e, const position::Pos& s) {
    if (e.name == "meatslab_low") return -99;  // B23-5: a lowered slab waits for the hook; shooting it does nothing
    const Gun& gun = kGuns[g_gun];
    const float gx = s.x, gy = s.y + 48.f;  // his gun, about chest height
    const float dx = e.x - gx, dy = (e.y + 48.f) - gy;
    if (std::hypot(dx, dy) > gun.range_px) return -99;
    const float fwd = s.facing_right ? dx : -dx;
    const float deg = std::atan2(dy, fwd) * 180.f / 3.14159265f;
    // B9b: the diagonals at 45 (the game's shots: 35-45 up, 37-45 down); -90 = straight down.
    // B20-4 (the user: "lock on said I could hit enemies below me, but nothing I tried could target them"; 2-b, hanging
    // from a diagonal rope with the goons 1700 px below): hanging from a rope, bar or swing point his shots go straight,
    // 45 up or 45 down (down and diagonal down both fire at -45; polehang_shoot*), and back once he turns; on a wall or
    // climbing a pole, only away from it (wall_shoot*: 180, 135, -135).
    static const int kGroundAims[] = {0, 45, 90, -45, -90, 180, -180};
    static const int kHangingAims[] = {0, 45, -45, 180, -180};
    static const int kWallAims[] = {180, -180, 135, -135};
    const int* aims = kGroundAims;
    size_t n = sizeof kGroundAims / sizeof kGroundAims[0];
    if (g_shank_mode == kModeHanging) {
        aims = kHangingAims;
        n = sizeof kHangingAims / sizeof kHangingAims[0];
    } else if (g_shank_mode == kModeWall) {
        aims = kWallAims;
        n = sizeof kWallAims / sizeof kWallAims[0];
    }
    for (size_t i = 0; i < n; ++i) {
        const int a = aims[i];
        if (std::fabs(deg - a) <= gun.tolerance_deg) {
            if (!level_geometry::LineClear(gx, gy, e.x, e.y + 48.f)) return -99;
            return a == -180 ? 180 : a;
        }
    }
    return -99;
}

// B23-5..7: the bosses lined up for an opening, from where everyone is (RE-NOTES "How the Butcher gets stunned" and
// "Boss setups"). The Butcher: a lowered slab and Shank both in front of him, in his hook's reach. The Gimp: a slave
// between him and Shank, with Shank far enough that he charges. The Priest: a fire trap between him and Shank, or right
// beside him (he burns in it).
// B25: (x, y) within `reach` of a burning fire trap (reported lately).
bool InFlames(float x, float y, unsigned now_ms, float reach = kFireClearPx) {
    for (const Hazard& h : g_hazards) {
        if (h.kind == "fire" && now_ms - h.seen_ms <= kBarrelStaleMs && std::fabs(h.x - x) < reach &&
            std::fabs(h.y - y) <= kSameLevelPx) {
            return true;
        }
    }
    return false;
}

std::set<uintptr_t> GeoSetups(const std::vector<enemies::Enemy>& list, const position::Pos& s, unsigned now_ms) {
    std::set<uintptr_t> out;
    if (!s.known) return out;
    for (const enemies::Enemy& b : list) {
        if (b.cls != enemies::kBoss) continue;
        const float sx = s.x - b.x;  // Shank from the boss
        const float dir = sx >= 0.f ? 1.f : -1.f;
        const bool level = std::fabs(s.y - b.y) <= kSameLevelPx;
        if (b.name == "boss_butcher") {
            if (!level || std::fabs(sx) < kHookShankMinPx || std::fabs(sx) > kHookShankMaxPx) continue;
            for (const enemies::Enemy& m : list) {
                const float mx = (m.x - b.x) * dir;  // the slab, in front of him (positive)
                if (m.name == "meatslab_low" && mx >= kHookSlabMinPx && mx <= kHookSlabMaxPx) out.insert(b.item);
            }
        } else if (b.name == "boss_gimp") {
            // (B23 session: 5 of 8 cuddles came with Shank clinging high on the end walls (y ~1800, 13 tiles up) and no
            // bell: his charge doesn't need Shank on his level, only far enough; the slave must be on his.)
            if (std::hypot(sx, s.y - b.y) < kGimpChargeMinPx) continue;
            for (const enemies::Enemy& v : list) {
                const float vx = (v.x - b.x) * dir;
                if (v.name == "med_gimp_slave" && vx > 0.f && vx < std::fabs(sx) && std::fabs(v.y - b.y) <= kSameLevelPx) {
                    out.insert(b.item);
                }
            }
        } else if (b.name == "boss_priest") {
            for (const Hazard& h : g_hazards) {
                if (h.kind != "fire" || now_ms - h.seen_ms > kBarrelStaleMs || std::fabs(h.y - b.y) > kSameLevelPx) continue;
                const float hx = (h.x - b.x) * dir;
                const bool between = level && hx > 0.f && hx < std::fabs(sx) && hx <= kFireLureMaxPx;
                // B24 (the Priest session: all 3 stuns were Shank's hits knocking him back into a trap behind him; the
                // traps sit at the arena's ends, by the walls, so "between" hardly happens)
                const bool behind = level && hx < 0.f && -hx <= kFireBehindMaxPx;
                if (behind || between || std::fabs(h.x - b.x) <= kFireBesidePx) out.insert(b.item);
            }
        }
    }
    return out;
}

void EnemyCues(unsigned now_ms, const position::Pos& s, Output* out) {
    // Attacks starting (B8-4), once, from where they start. Every "attack" state reports, so a combo's states (same
    // spot, within kWindupMergeMs) are one warning; none at Shank's own position. B9-1 (the user: "drop the attack cues
    // for standard attacks, and make them much more noticeable for special attacks, grapples, big boss attacks"):
    // grabs get the grab chirps; charges, and any attack by a big goon or a boss, the heavy buzz; the rest nothing.
    const std::vector<enemies::Enemy> near_attacks = s.known && !g_windups.empty() ? enemies::Current() : std::vector<enemies::Enemy>();
    for (const Windup& w : g_windups) {
        const float d = std::hypot(w.x - s.x, w.y - s.y);
        // B26 (the user: "attack warnings when he's out of range"): a charge crosses the room; a grab lunges; a punch or kick
        // doesn't reach far (the Butcher's hook, ~800 px, is the longest "std")
        const float range = w.kind == 2 ? kWindupRangePx : w.kind == 1 ? kWindupGrabRangePx : kWindupStdRangePx;
        if (!s.known || d > range || d < kWindupSelfPx || now_ms - w.ms > 300) continue;
        bool merged = false;
        for (const Windup& p : g_windups_played) {
            merged = merged || (w.ms - p.ms < kWindupMergeMs && std::hypot(w.x - p.x, w.y - p.y) < kWindupMergePx);
        }
        if (merged) continue;
        bool heavy_attacker = false;  // the enemy at the report's spot is a big goon or a boss
        float best = kAttackerMatchPx;
        for (const enemies::Enemy& e : near_attacks) {
            const float de = std::hypot(e.x - w.x, e.y - w.y);
            if (de < best) {
                best = de;
                heavy_attacker = e.cls == enemies::kLarge || e.cls == enemies::kBoss;
            }
        }
        audio::Sound snd;
        if (w.kind == 1) snd = audio::kEnemyGrab;
        else if (w.kind == 2 || heavy_attacker) snd = audio::kEnemyWindup;
        else continue;  // a standard attack: silent
        g_windups_played.push_back(w);  // only warnings that played merge later reports (a silent one doesn't)
        alog::Write("cues: %s attack from (%.0f, %.0f)", snd == audio::kEnemyGrab ? "grab" : "heavy", w.x, w.y);
        out->plays.push_back(PlayCmd{snd, EnemyPan(w.x, w.x - s.x), Clamp((w.y - s.y) / kPixelsPerSemitone, -8.f, 8.f), 1.f});
    }
    g_windups.clear();
    // B13-4 (the user: "a targeting sound any time the enemy has pulled their gun and is waiting to fire"): a thin
    // whine from each gunman aiming, repeated while he aims.
    g_aims.erase(std::remove_if(g_aims.begin(), g_aims.end(), [now_ms](const Aim& a) { return now_ms - a.last_ms > kAimHoldMs; }),
                 g_aims.end());
    for (Aim& a : g_aims) {
        const float d = std::hypot(a.x - s.x, a.y - s.y);
        if (!s.known || d > kAimRangePx || d < kWindupSelfPx || static_cast<int>(now_ms - a.next_ms) < 0) continue;
        out->plays.push_back(PlayCmd{audio::kEnemyAim, EnemyPan(a.x, a.x - s.x), Clamp((a.y - s.y) / kPixelsPerSemitone, -8.f, 8.f), 1.f});
        a.next_ms = now_ms + kAimRepeatMs;
    }
    g_windups_played.erase(std::remove_if(g_windups_played.begin(), g_windups_played.end(),
                                          [now_ms](const Windup& p) { return now_ms - p.ms > kWindupMergeMs; }),
                           g_windups_played.end());
    if (!s.known) return;
    const std::vector<enemies::Enemy> list = LiveEnemies(enemies::Current(), now_ms, s, out);  // (B29-1: the dead are out)
    g_setup_geo = GeoSetups(list, s, now_ms);  // B23-5..7
    // B25: the Priest's held grapple prompt: released once he has walked out of the flames (or after kPromptHoldMaxMs)
    if (g_prompt_hold_item) {
        const enemies::Enemy* p = FindEnemy(list, g_prompt_hold_item);
        const bool clear = p && !InFlames(p->x, p->y, now_ms);
        if (!p) {
            g_prompt_hold_item = 0;
        } else if (clear) {  // (B25b: no time limit)
            g_prompt_item = g_prompt_hold_item;
            g_prompt_hold_item = 0;
            g_setup_geo.erase(g_prompt_item);
            if (announce::On(announce::kPrompts)) g_say_now = "Grapple now";
            g_prompt_said["prompt_rt"] = now_ms ? now_ms : 1;
            alog::Write("cues: the Priest is clear of the flames after %u ms at (%.0f, %.0f) -> say \"Grapple now\"",
                        now_ms - g_prompt_hold_ms, p->x, p->y);
        } else {
            g_setup_geo.erase(g_prompt_hold_item);  // (no slow bell while he burns: "Wait")
        }
    } else if (g_prompt_item) {
        // B25b: a stunned Priest knocked back toward the fire (Shank's hits after the stun): "Wait" again, the bell stops
        const enemies::Enemy* p = FindEnemy(list, g_prompt_item);
        if (p && p->name == "boss_priest" && InFlames(p->x, p->y, now_ms, kFireDangerPx)) {
            g_prompt_hold_item = g_prompt_item;
            g_prompt_item = 0;
            if (now_ms - g_wait_said_ms >= kWaitRepeatMs && announce::On(announce::kPrompts)) {
                g_say_now = "Wait";
                g_wait_said_ms = now_ms ? now_ms : 1;
            }
            alog::Write("cues: the Priest was pushed back near the flames at (%.0f, %.0f) -> say \"Wait\"", p->x, p->y);
        }
    }
    // B8d: an enemy crossing to his other side (the user: "one of the biggest issues is knowing when an enemy goes
    // behind you"): a falling whoosh on the side it went to. And special enemies are named once when they come near.
    std::map<uintptr_t, int> sides;
    for (const enemies::Enemy& e : list) {
        const float ex = e.x - s.x, ey = e.y - s.y;
        const auto was = g_enemy_side.find(e.item);
        int side = was != g_enemy_side.end() ? was->second : 0;
        if (ex > kEnemyPassSlackPx) side = 1;
        else if (ex < -kEnemyPassSlackPx) side = -1;
        if (was != g_enemy_side.end() && was->second != 0 && side != was->second && std::hypot(ex, ey) <= kEnemyPassPx &&
            now_ms - g_enemy_pass_ms[e.item] >= kEnemyPassGapMs) {
            out->plays.push_back(PlayCmd{audio::kEnemyPass, side > 0 ? 0.8f : -0.8f, Clamp(ey / kPixelsPerSemitone, -8.f, 8.f), 1.f});
            g_enemy_pass_ms[e.item] = now_ms;
            alog::Write("cues: %s passed to his %s", e.name.c_str(), side > 0 ? "right" : "left");
        }
        sides[e.item] = side;
        if (enemies::IsSpecial(e.name) && std::hypot(ex, ey) <= kEnemyRangePx && g_special_said.insert(e.item).second &&
            announce::On(announce::kSpecialEnemies)) {
            if (!g_say.empty()) g_say += ". ";
            g_say += enemies::Describe(e.name) + (ex < 0 ? ", left" : ", right");
        }
    }
    g_enemy_side.swap(sides);
    const enemies::Enemy* target = nullptr;
    if (g_locked) {
        target = FindEnemy(list, g_locked);
        if (target) g_locked_x = target->x;
        if (!target) {  // killed, or gone
            alog::Write("cues: locked enemy %s gone", g_locked_name.c_str());
            // B23-2 (the user's sound audit: the shot-down tone does double duty): a locked enemy killed plays the same
            // falling tone where it was, instead of the "Target down" speech. (A shot-down meat or broken door played it
            // already from its own report.)
            // (B29-1: not one that fell to its death; a death heard played it already in LiveEnemies)
            if (!enemies::IsTarget(g_locked_name) && s.known && !g_fell.count(g_locked)) {
                out->plays.push_back(PlayCmd{audio::kTargetDown, Clamp((g_locked_x - s.x) / kPanRangePx, -1.f, 1.f), 0.f, 1.f});
            }
            g_locked = 0;
        }
    }
    // B21-1 (the user: "Have the meat automatically lock on and play the cue when it is targetable ... with the butcher
    // charging all over the ground he frequently is closer than the meat unless i'm locked on"): with nothing locked, a
    // shootable hanging meat (the nearest) is locked at once, silently (its lock tick and in-line ting take over). After
    // the player turns the lock off (L), not again until a meat newly becomes shootable.
    {
        std::set<uintptr_t> meats;
        for (const enemies::Enemy& e : list) {
            if (e.name == "meatslab" || e.name == "meatslab_low") meats.insert(e.item);
        }
        for (uintptr_t id : meats) {
            if (!g_meats_seen.count(id)) g_auto_lock_held = false;  // a meat newly shootable (or newly lowered)
        }
        g_meats_seen.swap(meats);
        // B23-5: a shootable slab first, else a lowered one (where the Butcher's hook must catch it); an auto lock on a
        // lowered slab moves to a shootable one when one comes back up.
        auto nearest = [&](const char* name) {
            const enemies::Enemy* best = nullptr;
            for (const enemies::Enemy& e : list) {
                if (e.name != name) continue;
                if (!best || std::hypot(e.x - s.x, e.y - s.y) < std::hypot(best->x - s.x, best->y - s.y)) best = &e;
            }
            return best;
        };
        const enemies::Enemy* shootable = nearest("meatslab");
        if (g_locked && g_auto_locked && g_locked_name == "meatslab_low" && shootable) g_locked = 0;
        if (!g_locked && !g_auto_lock_held && s.known) {
            const enemies::Enemy* best = shootable ? shootable : nearest("meatslab_low");
            if (best) {
                g_auto_locked = true;
                g_locked = best->item;
                g_locked_name = best->name;
                g_locked_x = best->x;
                g_inline_aim = -99;
                target = best;
                alog::Write("cues: auto lock on %s at (%.0f, %.0f)", best->name.c_str(), best->x, best->y);
            }
        }
    }
    // B9c: an open boss (showing the grapple prompt, or in an opening state) is cued first.
    auto open = [&](const enemies::Enemy& e) {
        if (e.cls != enemies::kBoss) return false;
        if (g_open_block && static_cast<int>(g_open_block_until - now_ms) > 0) return false;  // B29-4: a finisher runs
        if (e.item == g_prompt_item) return true;
        const auto it = g_open_until.find(e.item);
        return it != g_open_until.end() && static_cast<int>(it->second - now_ms) > 0;
    };
    // B23-4: set up for an opening (Toro's charge; lined up: B23-5..7): the slow bell.
    auto setup = [&](const enemies::Enemy& e) {
        if (e.cls != enemies::kBoss) return false;
        if (g_setup_geo.count(e.item)) return true;
        const auto it = g_setup_until.find(e.item);
        return it != g_setup_until.end() && static_cast<int>(it->second - now_ms) > 0;
    };
    // An open boss (the fast bell), else a set-up one (the slow bell), is cued over everything: B23-4, over a lock too
    // (the lock stays; its tick comes back after). (B9c had the open boss first only without a lock: an auto-locked
    // slab hid the Butcher's opening.)
    {
        const enemies::Enemy* bell = nullptr;
        for (int pass = 0; pass < 2 && !bell; ++pass) {
            float best = kEnemyRangePx * 1.5f;
            for (const enemies::Enemy& e : list) {
                const float d = std::hypot(e.x - s.x, e.y - s.y);
                if ((pass == 0 ? open(e) : setup(e)) && d < best) {
                    best = d;
                    bell = &e;
                }
            }
        }
        if (bell) target = bell;
    }
    if (!target) {
        float best = kEnemyRangePx;
        for (const enemies::Enemy& e : list) {
            const float d = std::hypot(e.x - s.x, e.y - s.y);
            if (d < best) {
                best = d;
                target = &e;
            }
        }
    }
    if (!target) {  // B36b-2: none in range, but one still in the arena: the nearest of those (at the slowest rate)
        float best = 1e18f;
        for (const enemies::Enemy& e : list) {
            const float d = std::hypot(e.x - s.x, e.y - s.y);
            if (InArena(e.x, e.y) && d < best) {
                best = d;
                target = &e;
            }
        }
    }
    if (!target) {
        if (g_enemy_cued) alog::Write("cues: no enemy near");
        g_enemy_cued = 0;
        return;
    }
    const float dx = target->x - s.x, dy = target->y - s.y;
    const float d = std::hypot(dx, dy);
    const bool behind = s.facing_right ? dx < -kEnemyBehindPx : dx > kEnemyBehindPx;
    if (target->item != g_enemy_cued) {
        alog::Write("cues: %s enemy %s (%s) at (%.0f, %.0f), %.0f px", g_locked ? "locked" : "nearest", target->name.c_str(),
                    enemies::Describe(target->name).c_str(), target->x, target->y, d);
        g_enemy_cued = target->item;
        g_enemy_next_ms = now_ms;
    }
    const bool is_open = open(*target);
    if ((is_open ? target->item : 0) != g_open_logged) {
        alog::Write(is_open ? "cues: %s is open to a grapple" : "cues: %s no longer open", target->name.c_str());
        g_open_logged = is_open ? target->item : 0;
    }
    if (is_open) {  // B9c: the energetic bell, fast, full volume, alternating a fifth up
        if (static_cast<int>(now_ms - g_enemy_next_ms) >= 0) {
            g_bell_high = !g_bell_high;
            out->plays.push_back(PlayCmd{audio::kEnemyOpening, EnemyPan(target->x, dx),
                                         Clamp(dy / kPixelsPerSemitone, -8.f, 8.f) + (g_bell_high ? 7.f : 0.f), 1.f});
            g_enemy_next_ms = now_ms + kOpeningGapMs;
        }
        return;
    }
    const bool is_setup = setup(*target);
    if ((is_setup ? target->item : 0) != g_setup_logged) {
        alog::Write(is_setup ? "cues: %s set up for an opening%s" : "cues: %s no longer set up%s", target->name.c_str(),
                    is_setup && g_setup_geo.count(target->item) ? " (lined up)" : "");
        g_setup_logged = is_setup ? target->item : 0;
    }
    if (is_setup) {  // B23-4: the slow bell (two strikes per play), full volume
        if (static_cast<int>(now_ms - g_enemy_next_ms) >= 0) {
            out->plays.push_back(PlayCmd{audio::kEnemySetup, EnemyPan(target->x, dx), Clamp(dy / kPixelsPerSemitone, -8.f, 8.f), 1.f});
            g_enemy_next_ms = now_ms + kSetupGapMs;
        }
        return;
    }
    const float c = Clamp(d / kEnemyRangePx, 0.f, 1.f);
    const unsigned gap = d <= kEnemyOnTopPx ? kEnemyOnTopMs : kEnemyFastestMs + static_cast<unsigned>(kEnemySpanMs * c);
    if (static_cast<int>(now_ms - g_enemy_next_ms) >= 0) {
        const int cls = target->cls == enemies::kOther ? enemies::kMedium : target->cls;
        // B9b: the locked enemy has its own tick (the user: it blended with the radar's).
        const audio::Sound snd = g_locked ? audio::kLockTick
                                          : static_cast<audio::Sound>((behind ? audio::kEnemyMediumBehind : audio::kEnemyMedium) + cls);
        out->plays.push_back(PlayCmd{snd, EnemyPan(target->x, dx), Clamp(dy / kPixelsPerSemitone, -8.f, 8.f),
                                     1.f - 0.3f * c});
        g_enemy_next_ms = now_ms + gap;
    } else if (static_cast<int>(g_enemy_next_ms - now_ms) > static_cast<int>(gap)) {
        g_enemy_next_ms = now_ms + gap;  // nearer now
    }
    // B8-6: locked, the "in line" ting when a pistol shot would hit it; its pitch says which aim.
    if (g_locked) {
        const int aim = InLineAim(*target, s);
        if (aim != g_inline_aim) {
            if (aim != -99) alog::Write("cues: locked enemy in line (aim %d)", aim);
            g_inline_aim = aim;
        }
        if (aim != -99 && static_cast<int>(now_ms - g_inline_next_ms) >= 0) {
            // (B20-4: from a wall, back and up -8, back and down -12)
            const float semis = aim == 0 ? 0.f : aim == 45 ? 4.f : aim == 90 ? 7.f : aim == -45 ? -4.f : aim == -90 ? -7.f
                              : aim == 135 ? -8.f : aim == -135 ? -12.f : -10.f;
            out->plays.push_back(PlayCmd{audio::kLockInLine, EnemyPan(target->x, dx), semis, 0.8f});
            g_inline_next_ms = now_ms + kInLineGapMs;
        }
    }
}

void OnCue(const std::string& name, float x, float y, unsigned now_ms) {
    AcquireSRWLockExclusive(&g_lock);
    if (name == "en_vuln" || name == "en_setup" || name == "en_setup_end" || name.compare(0, 7, "prompt_") == 0) {  // B9c
        // The enemy nearest the report (a boss's opening state, or the prompt it's showing; B23-4 its setup).
        uintptr_t item = 0;
        float best = kOpeningMatchPx;
        for (const enemies::Enemy& e : enemies::Current()) {
            if (enemies::IsTarget(e.name)) continue;  // (a prop, not the one reporting)
            const float d = std::hypot(e.x - x, e.y - y);
            if (d < best) {
                best = d;
                item = e.item;
            }
        }
        if (name == "en_vuln") {
            if (item) g_open_until[item] = now_ms + kOpeningHoldMs;
            if (item) g_setup_until.erase(item);  // (open now)
        } else if (name == "en_setup") {  // B23-4: Toro's charge started (until en_setup_end, at most kSetupMaxMs)
            if (item) g_setup_until[item] = now_ms + kSetupMaxMs;
        } else if (name == "en_setup_end") {
            if (item) g_setup_until.erase(item);
        } else if (name == "prompt_rt") {
            // B25: the Priest stunned in the flames: "Wait" now, "Grapple now" once he's out (EnemyCues)
            const enemies::Enemy* e = nullptr;
            const std::vector<enemies::Enemy> all = enemies::Current();
            for (const enemies::Enemy& c : all) {
                if (c.item == item) e = &c;
            }
            if (e && e->name == "boss_priest" && InFlames(e->x, e->y, now_ms)) {
                g_prompt_hold_item = item;
                g_prompt_hold_ms = now_ms;
                if (announce::On(announce::kPrompts)) g_say_now = "Wait";
                g_wait_said_ms = now_ms ? now_ms : 1;
                alog::Write("cues: prompt rt at (%.0f, %.0f): the Priest is in the flames -> say \"Wait\"", x, y);
                ReleaseSRWLockExclusive(&g_lock);
                return;
            }
            if (item) g_prompt_item = item;
        } else if (name == "prompt_rt_stop") {
            g_prompt_item = 0;
            g_prompt_hold_item = 0;
        }
        static const struct {
            const char* prompt;
            const char* say;
        } kSay[] = {{"prompt_rt", "Grapple now"}, {"prompt_x", "Mash attack"}, {"prompt_lt", "Parry now"},
                    {"prompt_arrow", "Press the direction"}};
        for (const auto& k : kSay) {
            if (name != k.prompt) continue;
            unsigned& last = g_prompt_said[name];
            if ((!last || now_ms - last >= kPromptRepeatMs) && announce::On(announce::kPrompts)) {
                g_say_now = k.say;
                last = now_ms ? now_ms : 1;
                alog::Write("cues: prompt %s at (%.0f, %.0f) -> say \"%s\"", name.c_str() + 7, x, y, k.say);
            }
        }
    } else if (name == "en_aim") {  // B13-4
        Aim* a = nullptr;
        for (Aim& o : g_aims) {
            if (std::hypot(o.x - x, o.y - y) < kAimMatchPx) a = &o;
        }
        if (!a) {
            g_aims.push_back(Aim{x, y, now_ms, now_ms});
            alog::Write("cues: gunman aiming at (%.0f, %.0f)", x, y);
        } else {
            a->x = x;
            a->y = y;
            a->last_ms = now_ms;
        }
    } else if (name.compare(0, 9, "en_windup") == 0) {  // B8-4; B9-1: en_windup_<grab|charge|std>
        // B13-4: an attack (the shot) from an aiming gunman ends his aim
        g_aims.erase(std::remove_if(g_aims.begin(), g_aims.end(),
                                    [x, y](const Aim& a) { return std::hypot(a.x - x, a.y - y) < kAimMatchPx; }),
                     g_aims.end());
        const std::string kind = name.size() > 10 ? name.substr(10) : "std";
        if (kind == "shot") {  // B26: a gun's shot after its aim: it ends the aim (above), no warning
            ReleaseSRWLockExclusive(&g_lock);
            return;
        }
        g_windups.push_back(Windup{x, y, now_ms, kind == "grab" ? 1 : kind == "charge" ? 2 : 0});
        if (g_windups.size() > 16) g_windups.erase(g_windups.begin());
    } else if (name == "up_on" || name == "up_off" || name == "down_on" || name == "down_off") {  // B44-1: held / let go
        (name[0] == 'u' ? g_hold_up : g_hold_down) = name.compare(name.size() - 3, 3, "_on") == 0;
    } else if (name == "fwd_on" || name == "fwd_off" || name == "back_on" || name == "back_off") {  // B44e
        (name[0] == 'f' ? g_hold_fwd : g_hold_back) = name.compare(name.size() - 3, 3, "_on") == 0;
    } else if (name == "turn_r" || name == "turn_l") {  // B19-2: Shank's facing flipped (reported once per turn)
        const int facing = name[5] == 'r' ? 1 : -1;
        if (g_turn_facing != 0 && facing != g_turn_facing) {  // (the first report after a load only sets it)
            g_pending_plays.push_back(PlayCmd{audio::kTurn, facing * kTurnPan, 0.f, kTurnVolume});
            alog::Write("cues: Shank turned %s", facing > 0 ? "right" : "left");
        }
        g_turn_facing = facing;
    } else if (name.compare(0, 10, "en_tggone_") == 0) {  // B23-5: a lowered slab taken by the hook: off the list, silently
        enemies::TargetDown(name.substr(10), x, y, now_ms);
    } else if (name.compare(0, 10, "en_tgdown_") == 0) {  // B21-2: a hanging meat shot down: off the list, the falling tone
        enemies::TargetDown(name.substr(10), x, y, now_ms);
        const float pan = g_shank_known ? Clamp((x - g_shank_x) / kPanRangePx, -1.f, 1.f) : 0.f;
        g_pending_plays.push_back(PlayCmd{audio::kTargetDown, pan, 0.f, 1.f});
    } else if (name.compare(0, 10, "en_target_") == 0) {  // B19-1: a prop to shoot (the Butcher's hanging meat)
        enemies::ReportTarget(name.substr(10), x, y, now_ms);
    } else if (name.compare(0, 3, "hz_") == 0) {
        TrackHazard(name.substr(3), x, y, now_ms);
    } else if (name.compare(0, 7, "beacon_") == 0) {
        Track(name.substr(7), x, y, now_ms);
    } else if (name.compare(0, 8, "inreach_") == 0) {
        Pickup& p = Track(name.substr(8), x, y, now_ms);
        const bool fresh = !p.reached || now_ms - p.reach_ms > kReachRepeatMs;
        p.reached = true;
        p.reach_ms = now_ms;
        if (fresh && announce::On(announce::kInReach)) {
            g_say = KindName(p.kind) + " in reach";
            p.next_ms = now_ms;  // the in-reach ping now (Tick)
        }
    }
    ReleaseSRWLockExclusive(&g_lock);
}

Output Tick(unsigned now_ms, const position::Pos& shank) {
    Output out;
    AcquireSRWLockExclusive(&g_lock);
    out.plays.swap(g_pending_plays);  // B19-2: the turn whoosh
    // B6-4: flights stop at walls, ceilings, floors (set first: the edge cue's wall-run fall uses them too).
    jump_model::SetObstacles(&level_geometry::Obstacles());
    {  // B27-5: swing points grab him in passing (a jump chirps only for what it really reaches)
        static std::vector<jump_model::Target> swings;
        static const level_geometry::Feature* swings_of = nullptr;
        static size_t swings_n = 0;
        const auto& fs = level_geometry::Features();
        if (fs.data() != swings_of || fs.size() != swings_n) {
            swings.clear();
            for (const level_geometry::Feature& f : fs) {
                jump_model::Target t;
                if ((f.type == "swing_point" || f.type == "slide_pole") && ToTarget(f, &t)) swings.push_back(t);  // (B48d: slide poles)
            }
            swings_of = fs.data();
            swings_n = fs.size();
        }
        jump_model::SetInterceptors(&swings);
    }
    EdgeCue(now_ms, shank, &out);
    TargetCues(now_ms, shank, &out);
    HazardCues(now_ms, shank, &out);  // B7
    EnemyCues(now_ms, shank, &out);   // B8
    g_shank_known = shank.known;
    g_shank_x = shank.x;
    g_shank_y = shank.y;
    // 4-4 pickups: forget the ones not reported lately; sound each, faster when nearer.
    for (size_t i = 0; i < g_pickups.size();) {
        if (now_ms - g_pickups[i].seen_ms > kPickupStaleMs) {
            alog::Write("cues: pickup %s at (%.0f, %.0f) gone", g_pickups[i].kind.c_str(), g_pickups[i].x, g_pickups[i].y);
            g_pickups.erase(g_pickups.begin() + i);
        } else {
            ++i;
        }
    }
    if (shank.known) {
        for (Pickup& p : g_pickups) {
            if (static_cast<int>(now_ms - p.next_ms) < 0) continue;
            if (!Inside(p.x, p.y)) continue;  // beyond the bounds: as if it weren't there
            const bool in_reach = p.reached && now_ms - p.reach_ms <= 400;
            // B15-4: the pickup's own sound by kind (health, grenades, weapons); in reach, the ping for all
            const audio::Sound kind_sound = p.kind == "health" ? audio::kPickup : audio::kPickupItem;  // (B23-3: grenades and weapons alike)
            out.plays.push_back(PickupSound(in_reach ? audio::kInReach : kind_sound, p, shank));
            const float dx = p.x - shank.x, dy = p.y - shank.y;
            const float dist = std::sqrt(dx * dx + dy * dy);
            p.next_ms = now_ms + kPickupFastestMs + static_cast<unsigned>(kPickupSpanMs * Clamp(dist / kPickupSpanPx, 0.f, 1.f));
        }
    }
    out.say.swap(g_say);
    out.say_now.swap(g_say_now);
    out.chapter.swap(g_chapter);
    ReleaseSRWLockExclusive(&g_lock);
    return out;
}

std::string LockNext(const position::Pos& s, bool special_only) {
    AcquireSRWLockExclusive(&g_lock);
    std::string say;
    if (!s.known) {
        say = "No position yet";
    } else {
        // The candidates within the gun's range (B8b), nearest first; the next after the one locked now.
        const Gun& gun = kGuns[g_gun];
        std::vector<enemies::Enemy> cands;
        for (const enemies::Enemy& e : enemies::Current()) {
            if (std::hypot(e.x - s.x, e.y - s.y) <= gun.range_px && (!special_only || enemies::IsSpecial(e.name))) cands.push_back(e);
        }
        std::sort(cands.begin(), cands.end(), [&s](const enemies::Enemy& a, const enemies::Enemy& b) {
            return std::hypot(a.x - s.x, a.y - s.y) < std::hypot(b.x - s.x, b.y - s.y);
        });
        size_t next = 0;
        if (g_locked) {
            size_t i = 0;
            while (i < cands.size() && cands[i].item != g_locked) ++i;
            next = i < cands.size() ? i + 1 : 0;  // after the locked one; from the nearest if it's not a candidate
        }
        if (cands.empty()) {
            g_locked = 0;
            say = std::string("No ") + (special_only ? "special " : "") + "enemies in " + gun.name + " range";
        } else if (g_locked && next >= cands.size()) {
            g_locked = 0;
            g_auto_lock_held = true;  // B21-1
            say = "Lock off";
        } else {
            const enemies::Enemy& e = cands[next];
            g_locked = e.item;
            g_locked_name = e.name;
            g_locked_x = e.x;
            g_auto_locked = false;  // B23-5: the player's own choice
            g_inline_aim = -99;
            const float dy = e.y - s.y;
            say = enemies::Describe(e.name) + ", " + Tiles(e.x - s.x) + (e.x < s.x ? " left" : " right");
            if (std::fabs(dy) >= kTile) say += ", " + Tiles(dy) + (dy > 0 ? " above" : " below");
            say += ", " + std::to_string(next + 1) + " of " + std::to_string(cands.size());
            alog::Write("cues: lock on %s (%u of %u%s)", e.name.c_str(), static_cast<unsigned>(next + 1),
                        static_cast<unsigned>(cands.size()), special_only ? ", special" : "");
        }
    }
    ReleaseSRWLockExclusive(&g_lock);
    return say;
}

void SetCameraPan(CameraPanFn camera) {
    AcquireSRWLockExclusive(&g_lock);
    g_camera_pan = camera;
    ReleaseSRWLockExclusive(&g_lock);
}

bool EnemyCameraPan() {
    AcquireSRWLockShared(&g_lock);
    const bool on = g_enemy_camera_pan;
    ReleaseSRWLockShared(&g_lock);
    return on;
}

bool ToggleEnemyCameraPan() {
    AcquireSRWLockExclusive(&g_lock);
    g_enemy_camera_pan = !g_enemy_camera_pan;
    const bool on = g_enemy_camera_pan;
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("cues: enemy pan %s", on ? "by the camera (like the game)" : "relative to Shank");
    return on;
}

void SetEnemyCameraPan(bool on) {
    AcquireSRWLockExclusive(&g_lock);
    const bool changed = g_enemy_camera_pan != on;
    g_enemy_camera_pan = on;
    ReleaseSRWLockExclusive(&g_lock);
    if (changed) alog::Write("cues: enemy pan %s", on ? "by the camera (like the game)" : "relative to Shank");
}

bool ToggleWaypoint(const position::Pos& s) {
    AcquireSRWLockExclusive(&g_lock);
    g_wp_on = !g_wp_on;
    const bool on = g_wp_on;
    g_wp_chime_ms = 0;
    g_wp_logged.clear();
    g_move_said = kMoveAdopt;  // (B48: turning it on says the move already: take the current target silently)
    g_move_pending.clear();
    g_wp_hint.clear();
    g_wp_hint_ms = 0;
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("waypoint: %s", on ? "on" : "off");
    (void)s;
    return on;
}

bool WaypointOn() {
    AcquireSRWLockShared(&g_lock);
    const bool on = g_wp_on;
    ReleaseSRWLockShared(&g_lock);
    return on;
}

// B27: how to make one move of a path from where he is ("walk 16 tiles right, then run up the wall to a floor, 4 tiles
// up"): Q's first move, and P's way to a pickup. (Under the lock.)
std::string DescribeStep(const pathing::Step& st, const position::Pos& s) {
    // B10b: where the move starts, if that's somewhere else on the same place: get there first.
    std::string first;
    float ox = s.x, oy = s.y;
    const char from = st.from.empty() ? ' ' : st.from[0];
    // The nearest spot of the range the graph found the move works from.
    const float gx = std::max(st.x_lo, std::min(st.x_hi, s.x));
    // B47c-3 (B47 session 2 mark 4, 4-a: "climb 13 tiles up, then wall jump" aimed at the window's bottom; he climbed on past
    // it to where the jump failed): up or down a wall or pole, aim 2 tiles inside a tall window, not at its edge.
    const float inset = std::min(2 * kTile, (st.y_hi - st.y_lo) / 4);
    const float gy = std::max(st.y_lo + inset, std::min(st.y_hi - inset, s.y));
    const level_geometry::Surface* on = level_geometry::SurfaceUnder(s.x, s.y);
    const bool sliding = on && on->tags.find("slippery") != std::string::npos;
    // B47c-7: a slide pole only takes him down (never "climb up" it): "as you slide down" before a jump off it
    bool slide_pole = false;
    if (from == 'p') {
        const int fi = std::atoi(st.from.c_str() + 1);
        const auto& fs = level_geometry::Features();
        slide_pole = fi >= 0 && fi < static_cast<int>(fs.size()) && fs[fi].type == "slide_pole";
    }
    if (from == 's' && std::fabs(gx - s.x) >= 2 * kTile) {
        first = (sliding ? "slide " : "walk ") + Tiles(gx - s.x) + (gx < s.x ? " left" : " right") + ", then ";
        ox = gx;
    } else if ((from == 'w' || from == 'p') && st.move != "climb_over" && std::fabs(gy - s.y) >= 2 * kTile) {
        if (!(slide_pole && gy > s.y)) {
            first = (gy > s.y ? "climb " + Tiles(gy - s.y) + " up" : (from == 'w' || slide_pole ? "slide " : "climb ") + Tiles(gy - s.y) + " down") +
                    (from == 'p' ? " the pole" : "") + ", then ";
            oy = gy;
        }
    }
    if (slide_pole && first.empty() && !pathing::OnFootMove(st.move) && st.move != "drop") first = "as you slide down, ";
    // What the move goes to, and where it is from him.
    std::string what = "a floor";
    float tx = st.x, ty = st.y;
    const int fi = FeatureOf(st.to);
    const auto& features = level_geometry::Features();
    if (fi >= 0 && fi < static_cast<int>(features.size())) {
        what = FeatureName(features[fi].type);
        if (!what.empty()) what[0] = static_cast<char>(std::tolower(static_cast<unsigned char>(what[0])));  // mid-sentence
        if (st.to[0] == 'p') what += st.to.back() == 'L' ? ", its left side" : ", its right side";
        NearestPoint(features[fi], s.x, s.y, &tx, &ty);
    } else if (st.to[0] == 'w') {
        what = "a climbable wall";
        const auto& walls = level_geometry::Walls();
        const size_t wi = static_cast<size_t>(std::atoi(st.to.c_str() + 1));
        if (wi < walls.size()) {
            tx = walls[wi].x;
            ty = std::max(walls[wi].y1, std::min(walls[wi].y2, s.y));
        }
    } else if (IsFloorNode(st.to)) {
        const int id = std::atoi(st.to.c_str() + 1);
        for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
            if (f.id != id || f.points.empty()) continue;
            // B10b: the floor's nearest point to where the move starts, at its height there (was its nearer end's
            // height: "jump up to a floor, 5 tiles down" on slopes).
            tx = std::max(f.points.front().first, std::min(f.points.back().first, ox));
            ty = f.points.front().second;
            for (size_t i = 0; i + 1 < f.points.size(); ++i) {
                const auto& a = f.points[i];
                const auto& b = f.points[i + 1];
                if (tx >= a.first && tx <= b.first && b.first > a.first) ty = a.second + (tx - a.first) / (b.first - a.first) * (b.second - a.second);
            }
            ty += kShankRadius;
        }
    }
    const float dx = tx - ox, dy = ty - oy;
    // (a jump up that lands far below: "jump up to a floor, 41 tiles down" in the B10 log)
    // B41-5 (1-c marks 2 and 3: "the last maneuver was a slide not a drop, and needs detail of jumping left since it
    // requires a quick turn while sliding"; "three back to back slides"): a slope says so; a jump against the slide says
    // to turn at once.
    const int lands_slide = SlideDir(st.to), from_slide = SlideDir(st.from);
    if (lands_slide) what = std::string("a slope, sliding ") + (lands_slide > 0 ? "right" : "left");
    std::string text = first + (st.move == "jump_up" && dy <= -2 * kTile ? std::string("jump up, then fall") : pathing::MoveName(st.move));
    // B48b (the user, B47 session 4: "a lot of swing points in this level are reachable without jumping from sprints, but not
    // from walks"): the run up to the edge is a sprint. (No "no jump": the user, "I recommend against no jump wording except
    // in specific cases where jumping will kill but not jumping is safe"; a jump there catches it too.)
    // B48d (1-b pretrain mark 2 "drop resulted in death": "drop to a floor, 2 tiles right" off a shimmy line's end; he let go
    // and fell almost straight, ~50 px across, into the pit): a drop that needs drift says which way to hold.
    if (st.move == "drop" && std::fabs(dx) >= kTile) text = first + "drop, holding " + (dx > 0 ? "right" : "left") + ",";
    // B48d (1-b pretrain mark 4 "no jump alert for first swing point": "walk 11 tiles right, then jump to swing point, 5 tiles
    // right, 8 tiles up"; he jumped running, the long jump, which doesn't go that high: no chirp, 3 deaths): the standing jump.
    if (st.move == "standing_jump" && from == 's') text = first + "stop, then jump";
    if (st.move == "run_off") {
        const std::string walk = "walk ", then = ", then ";
        if (first.compare(0, walk.size(), walk) == 0 && first.size() > walk.size() + then.size()) {
            text = "sprint " + first.substr(walk.size(), first.size() - walk.size() - then.size()) + " and off the edge";
        }
    }
    // (a turn: he's moving or facing the other way; on a slope there's no time, so "at once")
    if (from_slide && st.move != "slide_off" && st.move != "walk_off" && st.right != s.facing_right) {
        text = first + "turn " + (st.right ? "right" : "left") + " at once and " + text.substr(first.size());
    }
    // B41-2 (1-c mark 1: "let go to a floor, 5 tiles left" from a swing point; he let go at the far end of the swing and fell
    // back the other way into the meat grinder): which way to go.
    // B47b-1 (the user, 2026-10-02: "swing points still have outdated wording from when we thought shank's jump arc changed
    // based on swing angle"): the release leaves from one spot whenever he presses (B42c), 45 degrees his facing way
    // (poleswing.lua); holding back turns him (polehang_turn). So: which way to face, no timing.
    if (st.move == "swing_jump") text = first + "face " + (st.right ? "right" : "left") + " and jump off the swing point";
    if (st.move != "switch_sides" && st.move != "drop_through") {  // (those say it all)
        text += " to " + what;
        if (std::fabs(dx) >= kTile) text += ", " + Tiles(dx) + (dx < 0 ? " left" : " right");
        if (std::fabs(dy) >= kTile) text += ", " + Tiles(dy) + (dy > 0 ? " up" : " down");
    }
    // B41c (the user: "The vertical windows for those maneuvers are very narrow"): a jump off a wall, wall run, pole or bar
    // found from one spot only: wait for the jump-now chirp.
    if (from != 's' && st.move != "drop" && st.move != "swing_jump" && !pathing::OnFootMove(st.move) && st.x_hi - st.x_lo < 64.f &&
        st.y_hi - st.y_lo < 64.f) {
        text += ", at the chirp (a narrow window)";
    }
    // B46: a walk-off that works at one speed only: say which (a tap off the edge, a sprint, or in between)
    if (pathing::OneSpeedWalkOff(st)) {
        if (st.v_hi <= 224.f) text += ", stepping off slowly (one speed only)";
        else if (st.v_lo >= 704.f) text += ", at a full sprint (one speed only)";
        else text += ", at about " + std::to_string(static_cast<int>((st.v_lo + st.v_hi) / 2 / kTile + 0.5f)) + " tiles a second (one speed only)";
    }
    return text;
}

std::string NextMove(const position::Pos& s) {
    AcquireSRWLockShared(&g_lock);
    const std::string text = NextMoveLocked(s);
    ReleaseSRWLockShared(&g_lock);
    return text;
}

std::string NextMoveLocked(const position::Pos& s) {
    const level_geometry::Checkpoint* goal = level_geometry::Checkpoints().empty() ? nullptr : NextCheckpoint();
    std::string text;
    if (!s.known) {
        text = "No position yet";
    } else if (level_geometry::Checkpoints().empty()) {
        text = "No waypoints here";
    } else if (!goal) {
        text = "No next checkpoint";
    } else if (g_wp_path.empty() && g_wp_goals.count(g_wp_node)) {
        // B10b: on a floor that reaches the checkpoint, but not there yet: walk (the B10 log: "No path from here" on 1-c's
        // s15, 2 screens short of Mid Packing Warehouse).
        float cx, cy;
        CheckpointSpot(*goal, &cx, &cy);
        const float dx = cx - s.x;
        text = std::fabs(dx) < kTile ? "Almost at " + goal->name
                                     : "Walk " + Tiles(dx) + (dx < 0 ? " left" : " right") + " to " + goal->name;
    } else if (g_wp_path.empty()) {
        text = "No path from here. Next checkpoint: " + goal->name;
    } else {
        text = DescribeStep(g_wp_path[0], s);
        // B41-5: onto a slope there's no time to ask again: the moves until he's off slopes, in one go.
        // (while the move before ended on a slope, or this one starts or ends on one: 1-c's three slides with walls between)
        for (size_t i = 1; i < g_wp_path.size() && i < 5 &&
                           (SlideDir(g_wp_path[i - 1].to) || SlideDir(g_wp_path[i].from) || SlideDir(g_wp_path[i].to));
             ++i) {
            position::Pos at = s;
            at.x = g_wp_path[i].x;
            at.y = g_wp_path[i].y;
            at.facing_right = g_wp_path[i - 1].right;  // (still moving the way the move before took him)
            text += ". Then " + DescribeStep(g_wp_path[i], at);
        }
        text += ". " + std::to_string(g_wp_path.size()) + (g_wp_path.size() == 1 ? " move" : " moves") + " to " + goal->name;
    }
    return text;
}

std::vector<ReachInfo> ReachableNow() {
    AcquireSRWLockShared(&g_lock);
    std::vector<ReachInfo> out;
    for (const auto& r : g_reach_now) out.push_back(ReachInfo{r.second.what, r.second.x, r.second.y, static_cast<int>(r.second.jump)});
    ReleaseSRWLockShared(&g_lock);
    return out;
}

std::vector<pathing::Step> WaypointPath() {
    AcquireSRWLockShared(&g_lock);
    std::vector<pathing::Step> copy = g_wp_path;
    ReleaseSRWLockShared(&g_lock);
    return copy;
}

void OnPickedUp(const std::string& kind, float x, float y) {
    AcquireSRWLockExclusive(&g_lock);
    size_t best = g_pickups.size();
    float best_d = 400.f;
    for (size_t i = 0; i < g_pickups.size(); ++i) {
        const float d = std::hypot(g_pickups[i].x - x, g_pickups[i].y - y);
        if (g_pickups[i].kind == kind && d < best_d) {
            best = i;
            best_d = d;
        }
    }
    if (best < g_pickups.size()) {
        alog::Write("cues: pickup %s at (%.0f, %.0f) collected", kind.c_str(), g_pickups[best].x, g_pickups[best].y);
        g_pickups.erase(g_pickups.begin() + best);
    }
    ReleaseSRWLockExclusive(&g_lock);
}

Gun CurrentGun() {
    AcquireSRWLockShared(&g_lock);
    const Gun g = kGuns[g_gun];
    ReleaseSRWLockShared(&g_lock);
    return g;
}

void OnGameSound(const char* name, float x, float y, unsigned now_ms) {
    // B29-1: deaths and falling screams (not Shank's own)
    const bool shanks = std::strstr(name, "Voices/Shank/") != nullptr;
    if (shanks && std::strstr(name, "Shank_Death")) {  // B31-1: Shank died (a respawn empties the enemy list)
        AcquireSRWLockExclusive(&g_lock);
        g_shank_died_ms = now_ms ? now_ms : 1;
        // B44f (the B44 session, 2-b: he died holding Up; the new Shank after the respawn never reports its release, so Up
        // stayed "held" and his next jumps were judged as the jump up): what he holds is reported afresh after a death.
        g_hold_up = g_hold_down = g_hold_fwd = g_hold_back = false;
        ReleaseSRWLockExclusive(&g_lock);
        return;
    }
    const bool death = !shanks && (std::strstr(name, "enemyDeath") || std::strstr(name, "_Death"));
    const bool fell = !shanks && std::strstr(name, "_YellFalling");
    // B29-4 (the user: "the open state cue continues into the cinematic for about [a second]"): Shank's grapple (the
    // finisher starting) ends a boss's opening at once, and blocks it while the finisher runs.
    if (!shanks && (std::strstr(name, "shankGrapple") || std::strstr(name, "chainSawGrapple"))) {
        AcquireSRWLockExclusive(&g_lock);
        if (g_shank_known && std::hypot(x - g_shank_x, y - g_shank_y) <= kGrappleSoundPx && (g_prompt_item || !g_open_until.empty())) {
            alog::Write("cues: Shank grapples: the opening bell ends");
            g_prompt_item = 0;
            g_open_until.clear();
            g_open_block_until = now_ms + kFinisherBlockMs;
            g_open_block = true;
        }
        ReleaseSRWLockExclusive(&g_lock);
        return;
    }
    if (death || fell) {
        AcquireSRWLockExclusive(&g_lock);
        g_death_sounds.push_back(DeathSound{x, y, now_ms, fell, false});
        if (g_death_sounds.size() > 32) g_death_sounds.erase(g_death_sounds.begin());
        ReleaseSRWLockExclusive(&g_lock);
        return;
    }
    if (!std::strstr(name, "rm")) return;  // quick: only arm sounds ("armPistols", "..._Arm")
    int gun = -1;
    if (std::strstr(name, "armPistols")) gun = 0;
    else if (std::strstr(name, "Uzi_Arm")) gun = 1;
    else if (std::strstr(name, "Shotgun_Arm")) gun = 2;
    else if (std::strstr(name, "Minigun") && std::strstr(name, "Arm")) gun = 3;
    else if (std::strstr(name, "Flamethrower") && std::strstr(name, "Arm")) gun = 4;
    else if (std::strstr(name, "GrenadeLauncher_Arm")) gun = 5;
    if (gun < 0) return;
    AcquireSRWLockExclusive(&g_lock);
    // Shank's own (a pickup or an enemy arming far away doesn't count).
    if (g_shank_known && std::hypot(x - g_shank_x, y - g_shank_y) <= 160.f && gun != g_gun) {
        g_gun = gun;
        alog::Write("cues: ranged weapon %s (lock-on range %.0f px)", kGuns[gun].name, kGuns[gun].range_px);
    }
    ReleaseSRWLockExclusive(&g_lock);
}

// B29-4: the boss bar (HUD enemyBoss.healthBar.value): at 0 the boss is defeated (its cue stops at once; the B28 log:
// Cesar's last blow came with his bar at 0 and the cutscene 2 ms later); back above 0, a new fight.
void OnBossHealth(float value) {
    AcquireSRWLockExclusive(&g_lock);
    const bool down = value <= 0.f;
    if (down != g_boss_down && (down ? g_boss_hp > 0.f : true)) {
        alog::Write(down ? "cues: the boss is defeated: out of the cues" : "cues: a boss bar again (%.0f)", value);
        g_boss_down = down;
    }
    g_boss_hp = value;
    ReleaseSRWLockExclusive(&g_lock);
}

std::string EnemySummary(const position::Pos& s) {
    if (!s.known) return "No position yet";
    const std::vector<enemies::Enemy> list = enemies::Current();
    const enemies::Enemy* nearest = nullptr;
    float best = kScanRangePx;
    int n = 0;
    for (const enemies::Enemy& e : list) {
        const float d = std::hypot(e.x - s.x, e.y - s.y);
        if (d > kScanRangePx) continue;
        ++n;
        if (d < best) {
            best = d;
            nearest = &e;
        }
    }
    if (!n) return "No enemies nearby";
    // B8d (the user: "just say total number of enemies, name the closest one and its relative position").
    const float dx = nearest->x - s.x, dy = nearest->y - s.y;
    std::string text = std::to_string(n) + (n == 1 ? " enemy. " : " enemies. ") + (n > 1 ? "Nearest " : "") +
                       enemies::Describe(nearest->name) + ", " + Tiles(dx) + (dx < 0 ? " left" : " right");
    if (std::fabs(dy) >= kTile) text += ", " + Tiles(dy) + (dy > 0 ? " above" : " below");
    return text;
}

size_t HazardCount() {
    AcquireSRWLockShared(&g_lock);
    const size_t n = g_hazards.size();
    ReleaseSRWLockShared(&g_lock);
    return n;
}

std::string PickupSummary(unsigned now_ms, const position::Pos& shank) {
    if (!shank.known) return "No position yet";
    AcquireSRWLockShared(&g_lock);
    std::vector<const Pickup*> list;
    for (const Pickup& p : g_pickups) {
        if (now_ms - p.seen_ms <= kPickupStaleMs && Inside(p.x, p.y)) list.push_back(&p);
    }
    const float sx = shank.x, sy = shank.y;
    std::sort(list.begin(), list.end(), [sx, sy](const Pickup* a, const Pickup* b) {
        return std::hypot(a->x - sx, a->y - sy) < std::hypot(b->x - sx, b->y - sy);
    });
    std::string text;
    for (size_t i = 0; i < list.size() && i < 3; ++i) {
        const Pickup& p = *list[i];
        const long across = std::lround((p.x - sx) / kTile), up = std::lround((p.y - sy) / kTile);
        char buf[96];
        if (across == 0) _snprintf_s(buf, sizeof buf, _TRUNCATE, "here");
        else _snprintf_s(buf, sizeof buf, _TRUNCATE, "%ld tile%s %s", std::labs(across), std::labs(across) == 1 ? "" : "s", across > 0 ? "right" : "left");
        std::string where = buf;
        if (std::labs(up) >= 2) {
            _snprintf_s(buf, sizeof buf, _TRUNCATE, ", %ld %s", std::labs(up), up > 0 ? "above" : "below");
            where += buf;
        }
        text += (text.empty() ? "" : " ") + KindName(p.kind) + ", " + where + ".";
    }
    // B27 (the user's marks, 4-a: "health pickup right above me, but T says there's nothing to climb on to get up there";
    // "pathing/traversal did not pick up the path to this grenade pickup"): the nearest one, if it's on another floor,
    // with the way there (the traversal graph, worded like Q).
    if (!list.empty() && !g_wp_node.empty()) {
        const Pickup& p = *list[0];
        const level_geometry::Surface* ps = level_geometry::SurfaceUnder(p.x, p.y);
        const std::string goal = ps ? "s" + std::to_string(ps->id) : std::string();
        if (!goal.empty() && goal != g_wp_node) {
            const std::vector<pathing::Step> path = pathing::Path(g_wp_node, {goal}, shank.x);
            if (!path.empty()) {
                std::string kind = KindName(p.kind);
                if (!kind.empty()) kind[0] = static_cast<char>(std::tolower(static_cast<unsigned char>(kind[0])));
                text += " To the " + kind + ": " + DescribeStep(path[0], shank) + ". " + std::to_string(path.size()) +
                        (path.size() == 1 ? " move." : " moves.");
            }
        }
    }
    ReleaseSRWLockShared(&g_lock);
    return text.empty() ? "No pickups nearby" : text;
}

namespace {

// The point of a feature nearest to (x, y): its point, the nearest point on its line, or inside its box.
void NearestPoint(const level_geometry::Feature& f, float x, float y, float* nx, float* ny) {
    const auto& p = f.points;
    if (f.type == "wallrun_zone" && p.size() >= 2) {
        *nx = Clamp(x, p[0].first, p[1].first);
        *ny = Clamp(y, p[0].second, p[1].second);
        return;
    }
    if (p.size() >= 2) {
        const float ax = p[0].first, ay = p[0].second, bx = p[1].first, by = p[1].second;
        const float dx = bx - ax, dy = by - ay, len2 = dx * dx + dy * dy;
        const float t = len2 > 0 ? Clamp(((x - ax) * dx + (y - ay) * dy) / len2, 0.f, 1.f) : 0.f;
        *nx = ax + t * dx;
        *ny = ay + t * dy;
        return;
    }
    *nx = p.empty() ? x : p[0].first;
    *ny = p.empty() ? y : p[0].second;
}

const char* FeatureName(const std::string& type) {
    if (type == "swing_point") return "Swing point";
    if (type == "pole") return "Pole";
    if (type == "slide_pole") return "Slide pole";
    if (type == "shimmy_line") return "Shimmy line";
    if (type == "wallrun_zone") return "Wall run";
    return "Feature";
}

std::string Where(float dx, float dy) {
    const long across = std::lround(dx / kTile), up = std::lround(dy / kTile);
    char buf[96];
    if (across == 0) _snprintf_s(buf, sizeof buf, _TRUNCATE, "here");
    else _snprintf_s(buf, sizeof buf, _TRUNCATE, "%ld tile%s %s", std::labs(across), std::labs(across) == 1 ? "" : "s", across > 0 ? "right" : "left");
    std::string where = buf;
    if (std::labs(up) >= 2) {
        _snprintf_s(buf, sizeof buf, _TRUNCATE, ", %ld %s", std::labs(up), up > 0 ? "above" : "below");
        where += buf;
    }
    return where;
}

}  // namespace

std::string TraversalSummary(const position::Pos& shank) {
    if (!shank.known) return "No position yet";
    struct Near {
        float d, dx, dy;
        const char* name;
    };
    std::vector<Near> list;
    AcquireSRWLockShared(&g_lock);
    const Area area = g_area;
    const std::string on = g_live_node;
    std::vector<ReachNow> floors;  // B28b: floors a jump reaches now (the chirp), which the feature list doesn't name
    for (const auto& r : g_reach_now) {
        if (r.second.what == "a landing" || r.second.what == "a wall") floors.push_back(r.second);  // (B47b-2: walls too)
    }
    ReleaseSRWLockShared(&g_lock);
    // B27-6 (the user: "If shank is hanginf from a swing point, climbing a wall, etc, it should say that rather than giving
    // an odd announcement like saying the swing point is 3 tiles above"): what he's on first, and not again in the list.
    std::string holding;
    int held = -1;
    const auto& features = level_geometry::Features();
    if (!on.empty() && (on[0] == 'f' || on[0] == 'p')) {
        held = std::atoi(on.c_str() + 1);
        if (held >= 0 && held < static_cast<int>(features.size())) {
            const std::string& type = features[held].type;
            if (type == "swing_point") holding = "Hanging from a swing point.";
            else if (type == "shimmy_line") holding = "Hanging from a shimmy line.";
            else if (type == "wallrun_zone") holding = "Wall running.";
            else if (type == "slide_pole") holding = "On a slide pole.";
            else if (type == "pole") holding = std::string("On a pole, its ") + (on.back() == 'L' ? "left" : "right") + " side.";
        }
    } else if (!on.empty() && on[0] == 'w') {
        holding = "Clinging to a climbable wall.";
    }
    for (size_t fi = 0; fi < features.size(); ++fi) {
        if (static_cast<int>(fi) == held) continue;
        const level_geometry::Feature& f = features[fi];
        float nx, ny;
        NearestPoint(f, shank.x, shank.y, &nx, &ny);
        if (area.known && (nx < area.min_x - kAreaMarginPx || nx > area.max_x + kAreaMarginPx ||
                           ny < area.min_y - kAreaMarginPx || ny > area.max_y + kAreaMarginPx)) {
            continue;  // beyond the bounds
        }
        const float dx = nx - shank.x, dy = ny - shank.y, d = std::hypot(dx, dy);
        if (d <= kTraversalRangePx) list.push_back(Near{d, dx, dy, FeatureName(f.type)});
    }
    std::sort(list.begin(), list.end(), [](const Near& a, const Near& b) { return a.d < b.d; });
    std::string text;
    for (size_t i = 0; i < list.size() && i < 3; ++i) {
        text += (text.empty() ? "" : " ") + std::string(list[i].name) + ", " + Where(list[i].dx, list[i].dy) + ".";
    }
    for (size_t i = 0; i < floors.size() && i < 2; ++i) {
        const ReachNow& r = floors[i];
        const char* how = r.jump == jump_model::kLong ? "long jump" : r.jump == jump_model::kBarJump ? "jump off the bar"
                          : r.jump == jump_model::kSwingJump ? "jump off the swing point" : r.jump == jump_model::kPoleJump ? "jump off the pole"
                          : r.jump == jump_model::kWallJump ? "wall jump"
                          : r.jump == jump_model::kUpJump ? (holding.find("shimmy") != std::string::npos ? "jump up off the bar" : "jump up")
                          : r.jump == jump_model::kWallRunJump ? "jump off the wall run" : "jump";
        text += (text.empty() ? "" : " ") + std::string(r.what == "a wall" ? "A climbable wall, " : "A floor, ") + Where(r.x - shank.x, r.y - shank.y) + ": " + how + " now.";
    }
    if (text.empty()) text = holding.empty() ? "Nothing to climb or swing on nearby" : "Nothing else nearby.";
    return holding.empty() ? text : holding + " " + text;
}

void SetArea(const Area& area) {
    AcquireSRWLockExclusive(&g_lock);
    g_area = area;
    ReleaseSRWLockExclusive(&g_lock);
}

void Reset() {
    AcquireSRWLockExclusive(&g_lock);
    g_meats_seen.clear();       // B21-1
    g_setup_until.clear();      // B23-4
    g_setup_geo.clear();
    g_setup_logged = 0;
    g_auto_lock_held = false;
    g_next_edge_ms = 0;
    g_edge_on = false;
    g_edge_surface = -1;
    g_pickups.clear();
    g_hazards.clear();
    g_aims.clear();
    g_turn_facing = 0;
    g_hold_up = g_hold_down = false;  // (B44-1)
    g_hold_fwd = g_hold_back = false;  // (B44e)
    g_pending_plays.clear();
    g_explosive_hint_said = false;
    g_enemy_cued = 0;
    g_locked = 0;
    g_windups.clear();
    g_death_sounds.clear();  // B29-1
    g_chapter.clear();  // B29-2
    g_open_block = false;  // B29-4
    g_boss_hp = -1.f;
    g_boss_down = false;
    g_chapter_said = false;
    g_left.clear();  // B30-1
    g_first_seen.clear();  // B31-1
    g_shank_died_ms = 0;
    g_prev_enemies.clear();
    g_fell.clear();
    g_windups_played.clear();
    g_enemy_side.clear();
    g_overhead_surface = -1;
    g_cp_current = -1;
    g_cp_placed = false;
    g_goals_done.clear();  // B29-6
    g_have_last = false;
    g_wp_node.clear();
    g_live_node.clear();  // B27-6
    g_wp_goal_cp = -2;
    g_wp_goals.clear();
    g_wp_path.clear();
    g_wp_path_ms = 0;
    g_wp_target.clear();
    g_wp_floor.clear();
    g_wp_chime_ms = 0;
    g_wp_logged.clear();
    g_move_said.clear();
    g_move_pending.clear();
    g_overhead_lost_ms = 0;
    g_inline_next_ms = 0;
    g_enemy_next_ms = 0;
    g_enemy_pass_ms.clear();
    g_special_said.clear();
    g_open_until.clear();
    g_prompt_item = 0;
    g_prompt_hold_item = 0;  // B25
    g_prompt_said.clear();
    g_say_now.clear();
    g_open_logged = 0;
    g_inline_aim = -99;
    g_say.clear();
    g_area = Area();
    g_target_next.clear();
    g_target_reach.clear();
    g_reach_now.clear();
    g_target_yes_ms.clear();
    g_target_jump.clear();
    ReleaseSRWLockExclusive(&g_lock);
}

}  // namespace cues
