"""Syntax-check every Lua file the mod would deploy, using the real Lua 5.0 compiler.

Checks mod/files/**/*.lua directly, and each mod/patches/**/*.lua.patch.json by
rendering the patched file (pristine game file + ops) and compiling the result.
Run before every deploy; a Lua error at level load kills the game.

Usage (repo root):
  .venv/Scripts/python tools/luacheck50.py [--game-dir DIR] [extra.lua ...]
Build luac50 first:
  cmake -S tools/lua50 -B build/lua50 -G "Visual Studio 17 2022" -A Win32
  cmake --build build/lua50 --config Release
"""
import argparse
import os
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import deploy  # noqa: E402

LUAC = os.path.join(deploy.REPO, "build", "lua50", "Release", "luac50.exe")


def check(path, label=None):
    r = subprocess.run([LUAC, "-p", path], capture_output=True, text=True)
    if r.returncode != 0:
        msg = (r.stderr or r.stdout).strip().replace(path, label or path)
        print("FAIL", msg)
        return False
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*")
    ap.add_argument("--game-dir", default=deploy.DEFAULT_GAME_DIR)
    ap.add_argument("--state-dir", default=deploy.DEFAULT_STATE_DIR)
    args = ap.parse_args()
    if not os.path.exists(LUAC):
        print("luac50 not built; see docstring", file=sys.stderr)
        return 2

    ok, n = True, 0
    d = deploy.Deployer(args.game_dir, args.state_dir)
    try:
        built = d.build(d.load_state())
    except deploy.DeployError as e:
        print("ERROR building mod:", e, file=sys.stderr)
        return 2
    with tempfile.TemporaryDirectory() as tmp:
        for rel, kind, _original, new in built:
            if not rel.lower().endswith(".lua"):
                continue
            p = os.path.join(tmp, "check.lua")
            with open(p, "wb") as f:
                f.write(new)
            n += 1
            ok &= check(p, "%s (%s)" % (rel, kind))
    for f in args.files:
        n += 1
        ok &= check(f)
    print("%d Lua file(s) checked: %s" % (n, "OK" if ok else "ERRORS"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
