# Area, character and cutscene descriptions: feasibility (2026-10-03)

The user (2026-10-03): a key "similar to T, that would give you a more detailed description of the area you're in ...
more of a narrative description of your surroundings in the current level, and could potentially even extend to enemy
and boss physical descriptions. How much can be gotten directly from level files, assets, using image recognition to
fill in details, etc? I'm thinking this might be easier than full audio description for cutscenes because we already
have a lot of detail from the game files, but you tell me." Discussion only; nothing built, no decision yet.

## What the game files give (checked 2026-10-03)
- **Level scripts** (`data-pc/levels/<level>/<level>.lua`, plain Lua): every prop and enemy by Klei's name, e.g.
  1-c: 30 meatgrinder, 21 barrier, 12 rat, 12 light, crates, windows, meat slabs, health pickups; enemies
  med_security_grappler, med_thug_pistol, large_security_fists, dog_black_teeth ... Checkpoint names ("Before 1st
  Wallrun") and chapter names. Already extracted by extract_levels.py.
- **Collision** (.slev, decoded): floors, walls, pits, poles, swing points: the layout (already behind T / P / E).
- **Background art:** `tiles.zip` per level = positioned DDS tiles (`layer<N>_<x>_<y>.dds`; 2,561 for 1-c, 28 MB);
  `.vlev` = the visual layers (placement / parallax: not decoded yet). Stitching a section's tiles gives a picture of
  what the player sees there (minus characters and effects).
- **Characters:** 576 `.canim` animations + textures (format not decoded). Enemy display names from the HUD
  ("Wallace", "Franco"); character names from attributes.
- **Cutscenes:** 60 `.usm` movies (CRI Sofdec, 1.1 GB) in data/movies, each started by an `<id>_animatic.lua`
  (StartFullScreenMovie / WaitUntilMovieEnd). No subtitles or script text in the files. Our DLL already sees movie
  starts (the movie helpers, RE-NOTES).

## Image recognition
- **Offline, at development time (recommended):** Claude views stitched images / extracted frames directly and writes
  the descriptions; they ship as our own text (bin/ file). No API key, cost or lag for players. Images stay in build/
  (Klei art, never committed). Risk: the user can't check visual accuracy; a sighted spot-check would help.
- **Live (a screenshot sent to a vision API on a key press):** possible, but needs internet, an API key per player,
  2-5 s per press and a cost: not for the public mod.

## Effort
1. **Area key, facts only (small-medium):** the current section's name, what's around (props in plain words,
   hazards, enemy kinds), the layout (floor, drops, walls, ceilings) from data we already load.
2. **Visual narrative per section (medium per few levels):** decode .vlev placement (small RE), stitch per
   checkpoint section, write one short description each (roughly 10-20 sections per level).
3. **Enemy / boss descriptions (small-medium):** about 30 kinds; images from the stitched/captured frames, the
   cutscenes, or a .canim decoder; spoken from the L / K lock-on or the N scan.
4. **Cutscene audio description (medium-large):** demux USM (format documented; tools exist), frames every ~1 s and
   the audio track, write timed lines into dialogue gaps, speak them from the movie-start hook. Hard part: fitting
   lines between dialogue and music, and the movie can't be paused (as far as known).

## Assessment
The area key's facts are the easiest (the data is already loaded). The visual part needs the same pipeline as the
cutscenes (images → descriptions written offline); cutscenes are fixed and linear, so authoring is easier in one way,
and timing against dialogue is the hard part. Suggested order: the facts-only key; the image pipeline with one level's
sections; characters; then cutscenes reusing the pipeline.
