#include "announce.h"

#include <windows.h>

namespace announce {
namespace {

volatile LONG g_on[kCount] = {1, 1, 1, 1, 1, 1, 1, 1, 0};

const struct {
    const char* label;
    const char* key;
} kInfo[kCount] = {
    {"Health warnings", "health"},
    {"Pickup announcements", "pickups"},
    {"In reach announcements", "in_reach"},
    {"Combo announcements", "combo"},
    {"Boss names and health", "boss"},
    {"Special enemy arrivals", "special_enemies"},
    {"Button prompts", "prompts"},
    {"Loading tips and tutorial hints", "tips"},
    {"Speak each move", "moves"},
};

}  // namespace

bool On(Kind k) { return k >= 0 && k < kCount && InterlockedCompareExchange(&g_on[k], 0, 0) != 0; }

void Set(Kind k, bool on) {
    if (k >= 0 && k < kCount) InterlockedExchange(&g_on[k], on ? 1 : 0);
}

const char* Label(Kind k) { return k >= 0 && k < kCount ? kInfo[k].label : ""; }

const char* IniKey(Kind k) { return k >= 0 && k < kCount ? kInfo[k].key : ""; }

}  // namespace announce
