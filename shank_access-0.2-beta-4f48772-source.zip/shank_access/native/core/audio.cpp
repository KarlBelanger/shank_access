// XAudio2 2.9 needs the Windows 10 headers; it's loaded at run time (LoadLibrary), so the mod still
// loads without it (older Windows): the cues are then silent and the log says why.
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#include "audio.h"

#include <windows.h>
#include <xaudio2.h>

#include <cmath>
#include <vector>

#include "log.h"

namespace audio {
namespace {

constexpr float kPi = 3.14159265f;
constexpr int kVoices = 16;

std::vector<float> g_samples[kSoundCount];
bool g_built = false;

SRWLOCK g_lock = SRWLOCK_INIT;
IXAudio2* g_xa = nullptr;
IXAudio2MasteringVoice* g_master = nullptr;
unsigned g_out_channels = 2;
IXAudio2SourceVoice* g_voices[kVoices] = {};
int g_next = 0;
float g_master_volume = 0.8f;

// A tone gliding from f0 to f1 Hz over `ms`, with a short attack and an exponential decay.
// `second` adds that much of the second harmonic (a slightly woodier sound).
void Tone(std::vector<float>& out, float f0, float f1, float ms, float amp, float second = 0.f) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    const unsigned attack = kSampleRate / 500;  // 2 ms: no click
    float phase = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / n;
        const float f = f0 + (f1 - f0) * t;
        phase += 2.f * kPi * f / kSampleRate;
        const float env = (i < attack ? static_cast<float>(i) / attack : 1.f) * std::exp(-4.f * t);
        out.push_back(amp * env * (std::sin(phase) + second * std::sin(2.f * phase)) / (1.f + second));
    }
}

void Silence(std::vector<float>& out, float ms) {
    out.insert(out.end(), static_cast<size_t>(kSampleRate * ms / 1000.f), 0.f);
}

// Low-passed noise with a fast decay: a knock.
void Knock(std::vector<float>& out, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    unsigned seed = 12345;  // fixed: the same sound every run
    float lp = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        seed = seed * 1103515245u + 12345u;
        const float white = static_cast<float>((seed >> 9) & 0x7fff) / 16384.f - 1.f;
        lp += 0.12f * (white - lp);
        const float t = static_cast<float>(i) / n;
        const float env = (i < 44 ? i / 44.f : 1.f) * std::exp(-6.f * t);
        out.push_back(amp * 3.f * lp * env);
    }
}

// Two detuned square-ish tones (odd harmonics) gliding down: a rough buzz that can't be mistaken for the tock.
void Buzz(std::vector<float>& out, float f0, float f1, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    const unsigned attack = kSampleRate / 250;  // 4 ms
    float a = 0.f, b = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / n;
        const float f = f0 + (f1 - f0) * t;
        a += 2.f * kPi * f / kSampleRate;
        b += 2.f * kPi * f * 1.06f / kSampleRate;
        auto sq = [](float ph) { return std::sin(ph) + std::sin(3.f * ph) / 3.f + std::sin(5.f * ph) / 5.f; };
        const float env = (i < attack ? static_cast<float>(i) / attack : 1.f) * std::exp(-2.5f * t);
        out.push_back(amp * env * 0.5f * (sq(a) + sq(b)) / 1.53f);
    }
}

// A tone whose pitch wobbles around fc (depth Hz, rate Hz): a siren-like warble.
void Warble(std::vector<float>& out, float fc, float depth, float rate, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    const unsigned attack = kSampleRate / 250;  // 4 ms
    float phase = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / n;
        const float f = fc + depth * std::sin(2.f * kPi * rate * i / kSampleRate);
        phase += 2.f * kPi * f / kSampleRate;
        const float env = (i < attack ? static_cast<float>(i) / attack : 1.f) * (t > 0.8f ? (1.f - t) / 0.2f : 1.f);
        out.push_back(amp * env * std::sin(phase));
    }
}

// A short square-ish beep (odd harmonics), flat then a quick fade: harsher than the sine tones.
void Beep(std::vector<float>& out, float freq, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    const unsigned edge = kSampleRate / 500;  // 2 ms in and out: no click
    float phase = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        phase += 2.f * kPi * freq / kSampleRate;
        const float env = i < edge ? static_cast<float>(i) / edge : (i > n - edge ? static_cast<float>(n - i) / edge : 1.f);
        out.push_back(amp * env * (std::sin(phase) + std::sin(3.f * phase) / 3.f + std::sin(5.f * phase) / 5.f) / 1.53f);
    }
}

// B15-8: rocks clacking: per hit, a 2 ms noise burst ringing two short resonances (stone-like, ~2.9 and 4.3 kHz,
// ~10 ms decay); two hits `gap_ms` apart, the second a little softer and higher. Sharp attack, no tone after.
void Clack(std::vector<float>& out, float gap_ms, float amp) {
    const unsigned gap = static_cast<unsigned>(kSampleRate * gap_ms / 1000.f);
    const unsigned n = gap + static_cast<unsigned>(kSampleRate * 0.05f);
    std::vector<float> buf(n, 0.f);
    unsigned seed = 9001;
    for (int hit = 0; hit < 2; ++hit) {
        const unsigned start = hit ? gap : 0;
        const float f1 = hit ? 3100.f : 2900.f, f2 = hit ? 4500.f : 4300.f, a = hit ? 0.75f : 1.f;
        // Two resonators (two-pole filters) excited by the burst.
        float y1a = 0, y1b = 0, y2a = 0, y2b = 0;
        const float r = std::exp(-1.f / (0.010f * kSampleRate));
        const float c1 = 2.f * r * std::cos(2.f * kPi * f1 / kSampleRate), c2 = 2.f * r * std::cos(2.f * kPi * f2 / kSampleRate);
        for (unsigned i = start; i < n; ++i) {
            float x = 0.f;
            if (i - start < kSampleRate / 500) {  // the 2 ms burst
                seed = seed * 1103515245u + 12345u;
                x = static_cast<float>((seed >> 9) & 0x7fff) / 16384.f - 1.f;
            }
            const float o1 = x + c1 * y1a - r * r * y1b, o2 = x + c2 * y2a - r * r * y2b;
            y1b = y1a;
            y1a = o1;
            y2b = y2a;
            y2a = o2;
            buf[i] += a * 0.18f * (o1 + 0.7f * o2) + (i - start < 44 ? a * 0.5f * x : 0.f);
        }
    }
    float peak = 0.f;
    for (float v : buf) peak = std::fmax(peak, std::fabs(v));
    for (unsigned i = 0; i < n; ++i) {
        const float edge = i < 11 ? i / 11.f : 1.f;  // 0.5 ms: no click at the very start
        out.push_back(amp * edge * buf[i] / (peak > 0.f ? peak : 1.f));
    }
}

// B13-3: a fire's crackle: a soft low hiss with random sharp pops (fixed seed: the same sound every run).
void Crackle(std::vector<float>& out, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    unsigned seed = 4242;
    float lp = 0.f, pop = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        seed = seed * 1103515245u + 12345u;
        const float white = static_cast<float>((seed >> 9) & 0x7fff) / 16384.f - 1.f;
        lp += 0.05f * (white - lp);  // the hiss: low-passed
        if (((seed >> 3) & 0x3ff) < 3) pop = 1.f;  // ~130 pops a second
        pop *= 0.985f;
        const float t = static_cast<float>(i) / n;
        const float env = (i < 88 ? i / 88.f : 1.f) * (t > 0.7f ? (1.f - t) / 0.3f : 1.f);
        out.push_back(amp * env * (2.f * lp + pop * white));
    }
}

// B13-4: an aiming whine: a thin sine rising f0 -> f1 with an amplitude flutter (rate Hz).
void Whine(std::vector<float>& out, float f0, float f1, float rate, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    float phase = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / n;
        phase += 2.f * kPi * (f0 + (f1 - f0) * t) / kSampleRate;
        const float flutter = 0.6f + 0.4f * std::sin(2.f * kPi * rate * i / kSampleRate);
        const float env = (i < 88 ? i / 88.f : 1.f) * (t > 0.85f ? (1.f - t) / 0.15f : 1.f);
        out.push_back(amp * env * flutter * std::sin(phase));
    }
}

// Two-operator FM with a decaying index: a short metallic "bonk" (B8 enemies).
void Fm(std::vector<float>& out, float fc, float ratio, float index, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    const unsigned attack = kSampleRate / 1000;  // 1 ms
    float pc = 0.f, pm = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / n;
        const float env = (i < attack ? static_cast<float>(i) / attack : 1.f) * std::exp(-5.f * t);
        pm += 2.f * kPi * fc * ratio / kSampleRate;
        pc += 2.f * kPi * fc / kSampleRate;
        out.push_back(amp * env * std::sin(pc + index * env * std::sin(pm)));
    }
}

// Band-passed noise whose centre rises, getting louder: a "whoosh" (B8-4 wind-ups).
void Whoosh(std::vector<float>& out, float f0, float f1, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    unsigned seed = 9090;
    float lo = 0.f, band = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        seed = seed * 1103515245u + 12345u;
        const float white = static_cast<float>((seed >> 9) & 0x7fff) / 16384.f - 1.f;
        const float t = static_cast<float>(i) / n;
        const float f = f0 + (f1 - f0) * t;
        const float k = 2.f * kPi * f / kSampleRate;  // a crude state-variable band-pass
        lo += k * band;
        band += k * (white - lo - 0.5f * band);
        const float env = t < 0.85f ? t / 0.85f : (1.f - t) / 0.15f;
        out.push_back(amp * env * band * 2.f);
    }
}

// A square-ish tone gliding f0 -> f1 with an amplitude tremolo (trem Hz; 0 = none): harsh, attention-getting (B9-1).
void Alarm(std::vector<float>& out, float f0, float f1, float trem, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    const unsigned edge = kSampleRate / 500;  // 2 ms
    float phase = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / n;
        phase += 2.f * kPi * (f0 + (f1 - f0) * t) / kSampleRate;
        const float sq = (std::sin(phase) + std::sin(3.f * phase) / 3.f + std::sin(5.f * phase) / 5.f) / 1.53f;
        const float tr = trem > 0.f ? 0.6f + 0.4f * std::sin(2.f * kPi * trem * i / kSampleRate) : 1.f;
        const float env = i < edge ? static_cast<float>(i) / edge : (i > n - edge ? static_cast<float>(n - i) / edge : 1.f);
        out.push_back(amp * env * tr * sq);
    }
}

// A muffled copy (one-pole low-pass), for "behind him".
void Muffled(const std::vector<float>& in, std::vector<float>& out, float amount, float gain) {
    float lp = 0.f;
    out.clear();
    for (float v : in) {
        lp += amount * (v - lp);
        out.push_back(gain * lp);
    }
}

// A plucked string (Karplus-Strong): a noise burst through a short averaging delay line.
void Pluck(std::vector<float>& out, float freq, float ms, float amp) {
    const unsigned n = static_cast<unsigned>(kSampleRate * ms / 1000.f);
    const unsigned period = static_cast<unsigned>(kSampleRate / freq);
    std::vector<float> line(period);
    unsigned seed = 4242;  // fixed: the same sound every run
    for (float& v : line) {
        seed = seed * 1103515245u + 12345u;
        v = static_cast<float>((seed >> 9) & 0x7fff) / 16384.f - 1.f;
    }
    float prev = 0.f;
    for (unsigned i = 0; i < n; ++i) {
        const unsigned k = i % period;
        const float cur = line[k];
        line[k] = 0.996f * 0.5f * (cur + prev);
        prev = cur;
        const float fade = i < 88 ? i / 88.f : 1.f;           // 2 ms: no click
        const float tail = i > n - 441 ? (n - i) / 441.f : 1.f;  // 10 ms fade out
        out.push_back(amp * fade * tail * cur);
    }
}

void Build() {
    if (g_built) return;
    Tone(g_samples[kDrop], 420.f, 200.f, 80.f, 0.7f, 0.3f);
    Knock(g_samples[kWall], 50.f, 0.6f);
    Tone(g_samples[kPickup], 880.f, 880.f, 80.f, 0.45f);
    Silence(g_samples[kPickup], 10.f);
    Tone(g_samples[kPickup], 1320.f, 1320.f, 110.f, 0.45f);
    Tone(g_samples[kInReach], 1760.f, 1760.f, 140.f, 0.4f, 0.2f);
    Buzz(g_samples[kDeadly], 190.f, 150.f, 150.f, 0.75f);
    Pluck(g_samples[kTarget], 392.f, 260.f, 0.6f);
    Tone(g_samples[kJumpNow], 700.f, 1500.f, 90.f, 0.45f);  // B5d: back to the original chirp at 0.45 (the user: the sweep was too loud or harsh)
    // B7 hazards: their own timbres (DESIGN "Hazard warnings").
    // B15-8 (the user: the rock fall sound "is no good. should be a sharp abrupt sound, something similar to rocks
    // clacking toghether or an electrical snap"): two stone clacks (B8-0 had a noise crack + tonal tick "snap").
    Clack(g_samples[kHazardFall], 28.f, 0.6f);
    Warble(g_samples[kHazardProjectile], 1000.f, 250.f, 8.f, 180.f, 0.35f);
    Beep(g_samples[kHazardExplosive], 1600.f, 35.f, 0.35f);
    Silence(g_samples[kHazardExplosive], 30.f);
    Beep(g_samples[kHazardExplosive], 1600.f, 35.f, 0.35f);
    // B8 enemies (DESIGN "Enemy cues").
    // B8d: louder (the user: "a little quiet in the middle of combat").
    Fm(g_samples[kEnemyMedium], 600.f, 1.4f, 3.f, 70.f, 0.7f);
    Fm(g_samples[kEnemyLarge], 250.f, 1.4f, 4.f, 110.f, 0.8f);
    Fm(g_samples[kEnemyGirl], 1100.f, 1.4f, 2.5f, 60.f, 0.65f);
    Fm(g_samples[kEnemyDog], 800.f, 1.4f, 3.f, 30.f, 0.7f);
    Silence(g_samples[kEnemyDog], 25.f);
    Fm(g_samples[kEnemyDog], 800.f, 1.4f, 3.f, 30.f, 0.7f);
    Fm(g_samples[kEnemyBoss], 180.f, 2.01f, 5.f, 160.f, 0.8f);
    for (int k = 0; k < 5; ++k) Muffled(g_samples[kEnemyMedium + k], g_samples[kEnemyMediumBehind + k], 0.08f, 1.4f);
    Alarm(g_samples[kEnemyWindup], 700.f, 250.f, 25.f, 250.f, 0.6f);  // B9-1: heavy attacks only (was a whoosh for all)
    Fm(g_samples[kEnemyOpening], 1320.f, 3.5f, 4.f, 220.f, 0.7f);  // B9c: a boss's opening: a bell
    // B23-4 (the user: "use a slow opening bell for all situations which lead to the open state"): the same bell, slow
    // (two strikes 330 ms apart in one sample (sounds stay under 0.5 s); played every 660 ms: a strike every 330 ms,
    // where the open bell strikes every 140 ms and alternates a fifth up)
    Fm(g_samples[kEnemySetup], 1320.f, 3.5f, 4.f, 150.f, 0.7f);
    Silence(g_samples[kEnemySetup], 180.f);
    Fm(g_samples[kEnemySetup], 1320.f, 3.5f, 4.f, 150.f, 0.7f);
    Fm(g_samples[kWaypointChime], 1047.f, 2.f, 2.f, 450.f, 0.5f);  // B10: the next checkpoint
    Tone(g_samples[kLockTick], 1300.f, 1300.f, 30.f, 0.6f);  // B9b: the locked enemy's own tick
    Silence(g_samples[kLockTick], 15.f);
    Tone(g_samples[kLockTick], 1300.f, 1300.f, 30.f, 0.25f);
    Alarm(g_samples[kEnemyGrab], 400.f, 1200.f, 0.f, 80.f, 0.55f);
    Silence(g_samples[kEnemyGrab], 40.f);
    Alarm(g_samples[kEnemyGrab], 400.f, 1200.f, 0.f, 80.f, 0.55f);
    Whoosh(g_samples[kEnemyPass], 2500.f, 400.f, 130.f, 0.35f);
    Crackle(g_samples[kHazardFire], 160.f, 0.5f);          // B13-3
    Whoosh(g_samples[kTurn], 3200.f, 1400.f, 90.f, 0.35f);  // B19-2: Shank turned (B20-1: louder, the user)
    // B21-2: a hanging meat shot down. B22-2 (the user: "could be a bit more noticeable over gun sounds"): square-ish
    // (its harmonics cut through the gunfire), higher, longer, louder; no tremolo (unlike the heavy-attack buzz).
    Alarm(g_samples[kTargetDown], 1500.f, 450.f, 0.f, 240.f, 0.7f);
    // B15-4 (the user: "should have different pickup sounds for different items"): the same rising two-note motif.
    // B23-3: grenades and weapons share it (the user's sound audit: "especially sounds that are only used occasionally").
    Beep(g_samples[kPickupItem], 700.f, 70.f, 0.35f);
    Silence(g_samples[kPickupItem], 20.f);
    Beep(g_samples[kPickupItem], 1050.f, 90.f, 0.35f);
    // B15-6 (the user: narrow gaps "should have a slightly different sound ... to make it clear they can be crossed"):
    Tone(g_samples[kGap], 520.f, 330.f, 45.f, 0.7f, 0.3f);
    Silence(g_samples[kGap], 35.f);
    Tone(g_samples[kGap], 520.f, 330.f, 45.f, 0.7f, 0.3f);
    Whine(g_samples[kEnemyAim], 1800.f, 2600.f, 40.f, 150.f, 0.3f);  // B13-4
    Tone(g_samples[kLockInLine], 2000.f, 2000.f, 60.f, 0.25f);
    {
        std::vector<float> high;
        Tone(high, 3000.f, 3000.f, 60.f, 0.15f);
        for (size_t i = 0; i < high.size() && i < g_samples[kLockInLine].size(); ++i) g_samples[kLockInLine][i] += high[i];
    }
    g_built = true;
}

using XAudio2CreateFn = HRESULT(WINAPI*)(IXAudio2**, UINT32, XAUDIO2_PROCESSOR);

}  // namespace

const std::vector<LearnItem>& LearnOrder() {
    // B17-3 (the user: "make sure all sounds are grouped by category, some newer sounds got dropped at the end of the
    // menu and should be moved with their related sounds").
    static const std::vector<LearnItem> kOrder = {
        {kDrop, "Edges and jumps"},     {kGap, "Edges and jumps"},       {kDeadly, "Edges and jumps"},
        {kWall, "Edges and jumps"},     {kTarget, "Edges and jumps"},    {kJumpNow, "Edges and jumps"},
        {kTurn, "Edges and jumps"},
        {kPickup, "Pickups"},           {kPickupItem, "Pickups"},
        {kInReach, "Pickups"},          {kHazardFall, "Hazards"},        {kHazardProjectile, "Hazards"},
        {kHazardExplosive, "Hazards"},  {kHazardFire, "Hazards"},        {kEnemyMedium, "Enemies"},
        {kEnemyLarge, "Enemies"},       {kEnemyGirl, "Enemies"},         {kEnemyDog, "Enemies"},
        // B23-1: one entry for "behind" (every class sound muffled the same way; the goon's stands for all five)
        {kEnemyBoss, "Enemies"},        {kEnemyMediumBehind, "Enemies"},
        {kEnemyPass, "Enemies"},        {kEnemyAim, "Enemies"},          {kEnemyGrab, "Enemies"},
        {kEnemyWindup, "Enemies"},      {kEnemySetup, "Enemies"},        {kEnemyOpening, "Enemies"},
        {kLockTick, "Lock-on"},
        {kLockInLine, "Lock-on"},       {kTargetDown, "Lock-on"},       {kWaypointChime, "Waypoint"},
    };
    return kOrder;
}

const char* Describe(Sound sound) {
    static const char* const kText[kSoundCount] = {
        "Drop ahead. Pulses faster as you get closer; lower means deeper",
        "Wall ahead",
        "Health nearby",
        "Pickup in reach",
        "Deadly drop ahead",
        "Jump target nearby",
        "Jump now: a jump from here reaches the target",
        "Falling rocks or ceiling above you",
        "Rocket or missile coming",
        "Explosive: an enemy grenade, or a barrel you can shoot",
        "Enemy: goon",
        "Enemy: big goon",
        "Enemy: girl",
        "Enemy: dog",
        "Enemy: boss",
        "Enemy behind you: any enemy's sound, muffled like this",
        "Big goon behind you",
        "Girl behind you",
        "Dog behind you",
        "Boss behind you",
        "Heavy attack coming: a charge, or a big goon's or boss's attack",
        "Locked enemy in your line of fire",
        "An enemy passed you",
        "Waypoint: the next checkpoint",
        "Boss open to a grapple",
        "Locked enemy",
        "Grab attack coming",
        "Fire trap nearby",
        "Gunman aiming at you",
        "Grenades or a weapon nearby",
        "Narrow gap ahead: running carries you across",
        "Shank turned: panned a little to the way he now faces",
        "Target down: a locked enemy killed, a hanging meat shot down, or a door broken",
        "Boss set up for an opening: a charge to dodge, or a trap lined up",
    };
    return sound >= 0 && sound < kSoundCount ? kText[sound] : "";
}

const float* Samples(Sound sound, unsigned* count) {
    AcquireSRWLockExclusive(&g_lock);
    Build();
    ReleaseSRWLockExclusive(&g_lock);
    *count = static_cast<unsigned>(g_samples[sound].size());
    return g_samples[sound].data();
}

bool Start() {
    AcquireSRWLockExclusive(&g_lock);
    Build();
    ReleaseSRWLockExclusive(&g_lock);
    HMODULE dll = LoadLibraryW(L"xaudio2_9.dll");
    auto create = dll ? reinterpret_cast<XAudio2CreateFn>(GetProcAddress(dll, "XAudio2Create")) : nullptr;
    if (!create) {
        alog::Write("audio: xaudio2_9.dll not available (%lu): cues are silent", GetLastError());
        return false;
    }
    IXAudio2* xa = nullptr;
    HRESULT hr = create(&xa, 0, XAUDIO2_DEFAULT_PROCESSOR);
    if (FAILED(hr)) {
        alog::Write("audio: XAudio2Create failed 0x%08lx", static_cast<unsigned long>(hr));
        return false;
    }
    IXAudio2MasteringVoice* master = nullptr;
    hr = xa->CreateMasteringVoice(&master);
    if (FAILED(hr)) {
        alog::Write("audio: CreateMasteringVoice failed 0x%08lx", static_cast<unsigned long>(hr));
        xa->Release();
        return false;
    }
    XAUDIO2_VOICE_DETAILS details = {};
    master->GetVoiceDetails(&details);
    WAVEFORMATEX fmt = {};
    fmt.wFormatTag = WAVE_FORMAT_IEEE_FLOAT;
    fmt.nChannels = 1;
    fmt.nSamplesPerSec = kSampleRate;
    fmt.wBitsPerSample = 32;
    fmt.nBlockAlign = 4;
    fmt.nAvgBytesPerSec = kSampleRate * 4;
    int made = 0;
    for (int i = 0; i < kVoices; ++i) {
        if (SUCCEEDED(xa->CreateSourceVoice(&g_voices[i], &fmt, 0, 4.0f))) ++made;
        else g_voices[i] = nullptr;
    }
    AcquireSRWLockExclusive(&g_lock);
    g_xa = xa;
    g_master = master;
    g_out_channels = details.InputChannels ? details.InputChannels : 2;
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("audio: XAudio2 started (%u output channels, %u Hz, %d voices)", details.InputChannels,
                details.InputSampleRate, made);
    return made > 0;
}

namespace {
bool g_engine_on = true;  // (test mode F4)
}  // namespace

bool Enabled() { return g_engine_on; }

void StopForExit() {
    AcquireSRWLockExclusive(&g_lock);
    if (g_xa) g_xa->StopEngine();
    g_engine_on = false;
    ReleaseSRWLockExclusive(&g_lock);
}

bool ToggleEnabled() {
    AcquireSRWLockExclusive(&g_lock);
    const bool enabled = g_engine_on = !g_engine_on;
    if (g_xa) {
        if (enabled) g_xa->StartEngine();
        else g_xa->StopEngine();
    }
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("audio: engine %s", enabled ? "started" : "stopped");
    return enabled;
}

void SetMasterVolume(float volume) {
    AcquireSRWLockExclusive(&g_lock);
    g_master_volume = volume < 0.f ? 0.f : (volume > 1.f ? 1.f : volume);
    ReleaseSRWLockExclusive(&g_lock);
}

void Play(Sound sound, float pan, float semitones, float volume) {
    if (sound < 0 || sound >= kSoundCount) return;
    AcquireSRWLockExclusive(&g_lock);
    if (!g_xa) {
        ReleaseSRWLockExclusive(&g_lock);
        return;
    }
    // A free voice, else the oldest one (round robin) is cut off.
    IXAudio2SourceVoice* voice = nullptr;
    for (int k = 0; k < kVoices && !voice; ++k) {
        IXAudio2SourceVoice* v = g_voices[(g_next + k) % kVoices];
        if (!v) continue;
        XAUDIO2_VOICE_STATE state = {};
        v->GetState(&state, XAUDIO2_VOICE_NOSAMPLESPLAYED);
        if (state.BuffersQueued == 0) {
            voice = v;
            g_next = (g_next + k + 1) % kVoices;
        }
    }
    if (!voice) {
        voice = g_voices[g_next];
        g_next = (g_next + 1) % kVoices;
        if (voice) {
            voice->Stop();
            voice->FlushSourceBuffers();
        }
    }
    if (!voice) {
        ReleaseSRWLockExclusive(&g_lock);
        return;
    }
    // Equal-power pan onto the front left/right speakers.
    if (pan < -1.f) pan = -1.f;
    if (pan > 1.f) pan = 1.f;
    const float angle = (pan + 1.f) * kPi / 4.f;
    float levels[8] = {};
    levels[0] = std::cos(angle);
    if (g_out_channels > 1) levels[1] = std::sin(angle);
    else levels[0] = 1.f;
    const unsigned out = g_out_channels > 8 ? 8 : g_out_channels;
    voice->SetOutputMatrix(g_master, 1, out, levels);
    if (semitones < -12.f) semitones = -12.f;
    if (semitones > 12.f) semitones = 12.f;
    voice->SetFrequencyRatio(std::pow(2.f, semitones / 12.f));
    voice->SetVolume(volume * g_master_volume);
    XAUDIO2_BUFFER buf = {};
    buf.AudioBytes = static_cast<UINT32>(g_samples[sound].size() * sizeof(float));
    buf.pAudioData = reinterpret_cast<const BYTE*>(g_samples[sound].data());
    buf.Flags = XAUDIO2_END_OF_STREAM;
    voice->SubmitSourceBuffer(&buf);
    voice->Start();
    ReleaseSRWLockExclusive(&g_lock);
}

}  // namespace audio
