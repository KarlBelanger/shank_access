"""Copy the game's log files into build/logs/<timestamp>/ after a test session (read-only on the game).

The game rewrites its logs on every launch, so collect them before starting it again.

Usage (repo root):
  .venv/Scripts/python tools/collect_logs.py [--game-dir DIR] [--label short-name]
Prints the destination folder and, for sound.log, the a11y cue lines ("Could not play a11y/...").
"""
import argparse
import datetime
import glob
import os
import shutil
import sys

DEFAULT_GAME_DIR = os.environ.get("SHANK_GAME_DIR", r"C:/Program Files (x86)/Steam/steamapps/common/Shank")
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--game-dir", default=DEFAULT_GAME_DIR)
    ap.add_argument("--label", default="")
    args = ap.parse_args()
    logs = sorted(glob.glob(os.path.join(args.game_dir, "*.log")) +
                  glob.glob(os.path.join(args.game_dir, "log", "*.log")))
    if not logs:
        print("No logs found in", args.game_dir, file=sys.stderr)
        return 1
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = os.path.join(REPO, "build", "logs", stamp + ("-" + args.label if args.label else ""))
    os.makedirs(dest, exist_ok=True)
    for path in logs:
        rel = os.path.relpath(path, args.game_dir)
        out = os.path.join(dest, rel)
        os.makedirs(os.path.dirname(out), exist_ok=True)
        shutil.copy2(path, out)
    print("Copied %d log(s) to %s" % (len(logs), dest))
    sound = os.path.join(dest, "sound.log")
    if os.path.exists(sound):
        with open(sound, encoding="latin-1") as f:
            cues = [line.rstrip() for line in f if "a11y" in line]
        print("%d a11y cue line(s) in sound.log" % len(cues))
        for line in cues[:20]:
            print("  " + line)
    return 0


if __name__ == "__main__":
    sys.exit(main())
