# Reverse-engineering notes — Shank (PC, Steam)

Technical facts about the game, with the evidence behind them. Add to this whenever
something is learned. Label anything unconfirmed as **(hypothesis)**, and change it to
**(confirmed YYYY-MM-DD, how)** once it's verified.

## Binary fingerprint

| File | SHA-256 | Notes |
|---|---|---|
| `bin/Shank.exe` | `a3b58dde9e4e3588664389bc6a36422d3f6110e6cf0869c493f0cb91fce79e2a` | PE32 i386, 4,952,576 bytes, linked 2012-09-20 |
| `bin/fmodex.dll` | `4f23a613939642e30f6a6ea06bba3fd80d236a49bb320f4e41efc57afa556c6f` | FMOD Ex |
| `bin/fmod_event.dll` | `e491f25030dfed06a920a41cd81b26444c425879cb2edf969695c09948be977d` | FMOD Designer event API |

**Every address in this file is only valid for this Shank.exe hash.** The DLL must check the hash, or a signature, at startup.

- Image base `0x400000`. DllCharacteristics `0x8000`: **no ASLR, no DEP flag**. Addresses are fixed. **(confirmed at runtime 2026-09-24:** shank_access logged module base 00400000.)
- The dinput8 proxy's loader thread runs about 2 s before the game logs `### SHANK started ###`. Hooks can be installed before any game systems start.
- Sections: `.text` (VA 0x1000), `PSFD00`, `.rdata`, `.data` (VA 0x484000, virtual size ≈3.4 MB), `.tls`, `.rsrc`.
- Rich MSVC RTTI (`.?AV…@@`): ~684 class names. Useful for vtables. Examples:
  - Sim: `cGameItemManager@Sim`, `cShankGameItem@Sim`, `cCollisionWorld@Sim`, `cCollisionSegment@Sim`, `cSimEventManager@Sim`.
  - Events: `cDamageEvent`, `cHealEvent`, `cInventoryChangeEvent`, `cSelectedWeaponChangeEvent`, `cCharacterKilledEvent`, `cComboCountChangedEvent`, `cSpawnEvent`.
  - AI: `cPathfinder@AI`, `sPathTransition@AI`, `sPlatformID@AI`.
  - UI: `SwfButton@UI`, `SwfSpinner@UI`, `SwfSlider@UI`, `SwfCheckBox@UI`, `SwfLabel@UI`, `SwfTextListBox@UI`, `SwfExternalInterface@?A…`, `KleiGFxTranslator`.
- Serialisation field names are present as strings (`mHealth`, `mComboCount`, `mIsDead`, `mLastAttackerHitGUID`, …). They can help find struct offsets.
- Debug event formatter strings: `" health change "`, `" has died"`, `" has spawned"`, `" inventory change: "`, `" at location "`, `" damage and is now at health level "`.

## Imports and injection points

- `DINPUT8.dll!DirectInput8Create`: **proxy target** (a `dinput8.dll` in `bin/`).
- `XINPUT1_3.dll` by ordinals (#2 GetState, #3 SetState, #4 GetCapabilities, #5 Enable, #8). An alternative proxy.
- `d3d9.dll!Direct3DCreate9`, `d3dx9_43.dll`. Rendering (fullscreen DX9).
- `fmod_event.dll`: only `Event::start/stop/setPaused/release/getParameter`, `EventParameter::setValue`, `FMOD_EventSystem_Create`. EventSystem methods are called through a vtable.
- `fmodex.dll`: 42 functions, including `Channel::setPan/setVolume`, `System::createSound/playSound` (probably Scaleform sound and movies).
- Input: `RegisterRawInputDevices`/`GetRawInputData` (keyboard), DirectInput, XInput.
- Import thunks: `0x7158b0` Event::start, `0x7158b6` Event::release, `0x7158bc` Event::getParameter, `0x7158c2` EventParameter::setValue, `0x7158c8` Event::stop, `0x7158ce` Event::setPaused.

## Logging

- Logger calls look like `push fmt; push 0; push CHANNEL; call 0x401070; push eax; call 0x43c640`.
- Channel IDs are FourCC. `0x5f444e53` = `"SND_"`, which goes to `sound.log`.
- Log files are written to the game root: `game.log`, `sound.log`, `lua.log`, `loading.log`, `rendering.log`, `aggregate.log`, `ai.log`, `memory.log`, `crash.log`.
- **Each launch overwrites the logs (confirmed 2026-09-24).** The June logs were entirely replaced by the user's September session. Collect logs (`tools/collect_logs.py`) before the game is started again.
- **Focus loss pauses the game (confirmed 2026-09-24, user).** Alt-tabbing freezes the simulation; logs stay readable (no file lock) and appear flushed promptly.
- Lua `Print()` (load-time only) goes to `lua.log`. Example: `Print("Current Level: "..LEVEL)` in `data/commonpresentation.lua`.

## Sound system (confirmed statically 2026-09-24)

- The event system pointer is at `[0xadfdf0]`. `getEvent(name, mode, &event)` = vtable `+0x4c` (mode 2 in play functions).
- **`0x55ab10` PlaySound(name)**: `esi` = name (char*). Calls getEvent, then `Event::start`, then `Event::release(0,1)`. Not positional. Called from 0x553529 and 0x553544.
- **`0x55ab90` PlaySoundAt(name, pos)**: `esi` = name, `[esp+4]` = pointer to a position whose `.x` float is at +0.
  - It computes `pan = (pos.x − [0xae6868]) / [0xae6860]`, but only when `[0xae6860] > 0`; otherwise pan = 0.
  - Then `getParameter("pan")` (string at 0x8478f4), `setValue(pan)`, start, release.
  - On failure it logs `"Could not play %s"` (string 0x8478e0) to SND_.
  - **(confirmed 2026-09-24, 1b-2 hook log)** `[0xae6868]/[0xae686c]` = camera centre; `[0xae6860]/[0xae6864]` = camera half-extents, **(1600, 900) during gameplay**. In menus, pos/listener/half are all 0 (pan 0).
- The only caller of 0x55ab90 is `0x5219a5`, inside a sim-sound-event consumer (a switch around 0x521930–0x521a40).
  - The event object is in `esi`: **position at `esi+4`**, name built from `esi+0x3c` via `0x402680` (string c_str).
  - Flags `[0xae6533]`/`[0xae6534]` gate playback (probably mute/paused states).
- `0x55ade0` plays a looping sound into the single global slot `[0xadfdf4]` (stop/release the previous one first). Not positional. Called from 0x521a20. `0x55ada0`/`0x55ad50` stop it.
- **Panning investigation (static, 2026-09-24), after the user reported the pickup beacon isn't panned even in arenas:**
  - **(1b-2)** In a whole play session, **no** call reached `0x55ab10`. Even menu clicks (`Shank/GUI/onclick`) go through `0x55ab90` with pos (0,0).
- The non-positional `0x55ab10` is only called from `0x5534d0`. That's a (cmd, args, argc) handler that matches the string `"playsound"`, most likely the **Scaleform UI** ExternalInterface/FSCommand callback (menu sounds). So script sounds do **not** use 0x55ab10. **(confirmed statically)**
  - The listener and range are set together at `0x55b157`: `[0xae6860]/[0xae6864]` = half-extents from `esi` (a vec2), `[0xae6868]/[0xae686c]` = centre from `edi` (a vec2). Almost certainly the **camera view centre and half-size**, so pan = offset from the screen centre ÷ half the screen width. **(confirmed statically; the camera identity is inferred)**
  - Pan calculations: `0x55a320` (x only, arg pointer = pos), `0x55a360` (x and y; also divides by `[0xae6864]`, then calls 0x40dee0), `0x55b550` (x, pos in `ecx`), plus 0x55ab90's inline one. Other references to the range and centre are at 0x7e0281/0x7e0fb1 (not examined).
  - The `playsound` action **parser** is `0x4e4490`. It reads `param`, `action`, `sound`; for action `playsound` it prefixes the name via `0x796690()`→vfunc+0x34 (`Shank/Character/`). Nearby parsers exist for `playmusic` 0x4e511d, `startcue` 0x4e51af, `stopallsounds` 0x4e5218, `startlooping` 0x4e523b, `stoplooping` 0x4e52a8.
  - **Not yet known:** what the action does at run time: does it queue a positional sim sound event with the emitter's position, or something else? The vtable-by-RTTI walk was inconclusive: it landed on `cSpawnEffectAction`'s vtable at 0x83eef8, likely a misread.
  - **Decision:** stop the static dig here (the user prefers no rabbit holes). The Phase 1b hook on 0x55ab90 answers it directly by logging name, position, listener and range per call.
- **Engine panning works for script sounds (confirmed 2026-09-24, user):** the Uzi_Arm beacon, played by `PlaySound` in a pickup's stategraph, pans properly. So stategraph sounds are positional; it's the camera-relative pan formula above.
- **Why pointOfInterest didn't pan (checked 2026-09-24 with `tools/re/sounds.py`):** it's **not** mono vs stereo. Both samples are stereo 44.1 kHz:
  - `pointOfInterest` → sound definition `/Effects/GUI/pointOfInterest` → `effects/Stat Screen Slam.ogg` (1.25 s; the kill-stats screen slam).
  - `Uzi_Arm` → `/Effects/Shank/Uzi/Uzi_Arm` → `effects/attack/uzi/Uzi_Arm.wav` (0.78 s).
  - The likely difference: pointOfInterest is a **GUI** sound. Its event has a `pan` parameter, but probably no pan effect authored against it. It also has a baked-in stereo slam. Whether an event responds to `pan` is decided per event in FMOD Designer, not by the sample format. **(hypothesis; the FEV effect envelopes aren't parsed)**
  - Bank stats: effects.fsb has 434 samples (415 mono, 19 stereo); streaming_bank.fsb has 203 (113 mono, 90 stereo).
- **Every engine pan reads the same four globals (static RE 2026-09-26, for the Shank-centred panning question):** half-width `[0xae6860]`, half-height `[0xae6864]`, centre x `[0xae6868]`, centre y `[0xae686c]`. Readers: 0x55ab90 (one-shot positional sounds), 0x55a320 (x pan; used at 0x55b4ef when a **tracked** sound starts: loops and sounds attached to objects, stored in a map), 0x55a360 (x and y) and **0x55b550** (updates a tracked sound's pan as its emitter moves; called from the sim at 0x52236f, 0x5223ed, 0x52246c). The only writer is **0x55b157-0x55b172**, inside **0x55b0d0** (the per-frame sound update: takes dt on the stack, **half-size in esi, centre in edi** (a custom convention), both from the camera; called once, from 0x521009). The only other references (0x7e0280, 0x7e02a0, 0x7e0fb0, 0x7e0fc0) are the globals' start-up constructors / atexit registrations. **So overriding the centre right after 0x55b0d0 returns would make every positional game sound pan around whatever point we choose**, with nothing else in the game affected. Shank's own sounds are emitted at his position (the B8 log: armPistols/pistolShoot at his tracked (x, y)), so they'd pan to 0 (centre).
- `0x55ae70`: another event path (vtable +0x24 on the event system). Called from 0x796dac. Not investigated yet.
- `0x55a920(name, volume)`: sets category volume ("game", "music"). Globals `0x8899f8` (game volume), `0x8899fc` (music volume).
- **FEV** `data-pc/bootstrap/sound/shank.fev`: about **314 events have a `pan` parameter**. That covers most in-world sounds: all goon/boss voices, weapons, impacts, footsteps (`step`, `Dog_Step`, `Movement_*`), props, ambiences, plus `pointOfInterest` and `test`.
  - Only 3 events have `distance` (Gimp_Moan, Bodyguard_HeavyBreath, MeatGrinderRunning).
- A Lua `PlaySound("x")` action inside an object's stategraph becomes a positional sim sound event carrying that object's position. **(confirmed 2026-09-24:** the 1b-2 hook log shows `a11y/edge_far` at Shank's position and `a11y/pickup_beacon`/`Uzi_Arm` at the pickup's.)
  - **Evidence against it, 2026-09-24:** the pickup beacon (`PlaySound("pointOfInterest")` from a pickup's idle state) was heard but **not panned at all**, according to the user. Two remaining explanations:
    - (a) stategraph `playsound` actions use the non-positional path 0x55ab10;
    - (b) they are positional, but in follow-camera sections the pan range `[0xae6860]` is so large (or the listener tracks Shank so closely) that pan ≈ 0.

    The user notes that in fixed-camera arenas panning is tight and accurate, which fits (b) for the game's own sounds. The 1b hook will settle it: log which function is called, plus name, position, listener x and range.
- **0x55ab90 ends in a plain `ret`** (at 0x55ac55/0x55ac74/0x55ad44); its only caller (0x5219a5) cleans the position argument (`add esp, 4`) and doesn't use eax. So a hook can return without calling it. (confirmed statically 2026-09-26.) Since B3 our hook does this for `a11y/` names: they go to a native cue listener and never reach FMOD.
- **Pickup stategraphs (`stategraphs/props/*pickup_stategraph.lua`, 9 files; read 2026-09-26):**
  - health and grenade: `Event("collected", {Transition("consumed")})`; the `consumed` state's on_enter gives the item (`HealthDelta{aspercent=true, time=.5, amount=.3}` = +30% over 0.5 s; `AddInventory("grenades", 3)`) and GenEvents `shankpickuphealth` / `shankpickupgrenades`.
  - weapons (minigun, grenadelauncher, flamethrower, machete, sword = Katana, uzi, shotgun): actions on the `collected` event: `GenEvent("pickupWeapon")` (not shotgun) and `SendEventToCollector("collect<weapon>")` or `DoActionsToCollector{GoToState("<weapon>_pickup")}`.
  - The stategraph file is the pickup's kind, whether placed in the level or dropped. Placed pickups in the campaign: health_pickup, grenadepickup, itemmachete/minigun/shotgun/sword/uzi (build/levels); the grenade launcher and flamethrower only drop.
  - `Event(name, transitions, actions)` builds `{event=, transitions=, actions=}` (stategraphutil.lua).
- An unknown event name is non-fatal and logs `Could not play <name>`. This lets us check Lua-only cue triggers through `sound.log`.
- **Script sound names get the prefix `Shank/Character/` (confirmed 2026-09-24).**
  - Evidence: a June `sound.log` showed `Could not play Shank/Character/Voices/MediumGoon/MediumGoon_JumpIn` for Lua `PlaySound("Voices/MediumGoon/MediumGoon_JumpIn")`, and `Shank/Character/enemyDeath` for `PlaySound("enemyDeath")`.
  - The prefix comes from `0x41ca00`, a getter that returns the string at 0x837f84. `0x41ca10` returns `"Shank/Music/"` (0x837f98) for music.
  - UI sounds use full names (`Shank/GUI/onfocus`, in `data/bootstrap/uisounds.lua`).
  - **Consequences:**
    - Lua `PlaySound("a11y/x")` reaches FMOD and our hook as `Shank/Character/a11y/x`. Match on the substring `/a11y/`.
    - `PlaySound("pointOfInterest")` targets `Shank/Character/pointOfInterest`, which sits alongside other generic Character events like `enemyDeath` and `pistolShoot`, so it should resolve.

## Lua (5.0, embedded)

- The version banner `$Lua: Lua 5.0 Copyright (C) 1994-2003`. No `loadlib`. Has `require`, `loadstring`, `dofile`, `io` (used by attributeutil), `debug`.
- **The Lua is declarative and runs at load time only.** Scripts build tables that the C++ engine interprets. There's no per-frame Lua callback.
- **Lua 5.0 dialect:**
  - No `#` operator: use `table.getn`.
  - Varargs use `arg`, not `...` in expressions.
  - No `%` operator: use `math.mod`.
  - No `string.gmatch`: use `string.gfind`.
  - No long-string nesting levels `[==[`.
- Engine-registered Lua functions (debug only): `Print`, `LoadFile`, `SpawnCharacterAtMouse`, `NextCheckPoint`, `PrevCheckPoint`, `SingleStep`, `TogglePause`, `ToggleDebugRender`, `DebugRenderOn`, `Advance`, `Rewind`, `Reload`, `KillAllEnemies`, `DebugNextGameItem`, `DebugPrevGameItem`, `LoadToLastCheckpoint`, `KillDebugCharacter`, `ToggleHUD`, `ToggleGodMode`, `ToggleSuperSpeed`, `TabPressed`, `KillShank`, `SetGameOver`, `LoadDebugFile`, `SaveProfiles`.
  - `data/autoexec.lua` binds some of these to keys (Ctrl+K/D/N/M/U/J/L/W/F/S). **Whether they work in retail is untested.**
- `LoadFile(path)` includes another script. Paths are case-insensitive.
- Loading `stategraphs/shank/shank_stategraph.lua` pulls in 65 files. **Vanilla** reads 14 never-defined globals, which are nil in the game (confirmed 2026-09-24 with `tools/loadtest50.py`):
  - `BUTCHER_CHAIN_GRAPPLE_DAMAGE`, `COOP_CATCH_SLAM_KNOCKBACK_DAMAGE`, `GRAPPLE_STANDING_ATTACH_DMG`
  - `GUNS_TO_MACHETE_STANDING1_DMG`, `GUNS_TO_MACHETE_STANDING2_DMG`
  - `GuardEvents`, `ScriptEvents`, `ShankStates`, `ZOOM_STANDARD`
  - five `SWORD_TO_*_DMG` constants

  A patch must not add to this list.
- **`data/autoexec.lua` is never loaded by the retail game (confirmed 2026-09-24).**
  - Its first line, `Print("loading autoexec.lua")`, never appears in `lua.log`.
  - The user tried Ctrl+U, Ctrl+J and Ctrl+N in 1-a, and nothing happened.
  - The debug functions are still compiled in and registered. The registration code is at 0x781ad0–0x781cf0; each entry is `push name; push impl; mov ecx,[ebp+8]; call 0x437660; push eax; call <binder>`.
  - Binder types: 0x780730 = no arguments, 0x780780 = (cSimulation*), 0x780890 = (number), 0x780840 = (sim, int).
  - Implementations:
    - NextCheckPoint 0x780d30, PrevCheckPoint 0x780c60
    - SingleStep 0x7812f0, TogglePause 0x781210
    - ToggleDebugRender 0x781090, DebugRenderOn 0x781010
    - Advance 0x780be0, Rewind 0x780b60, Reload 0x781370
    - KillAllEnemies 0x7814d0, LoadToLastCheckpoint 0x781580
    - DebugNextGameItem 0x781190, DebugPrevGameItem 0x781110, KillDebugCharacter 0x780e10
    - ToggleHUD 0x780f10, **ToggleGodMode 0x780650**, **ToggleSuperSpeed 0x780680**
    - TabPressed 0x780f90, KillShank 0x780ac0, SetGameOver 0x780a20
    - LoadDebugFile 0x780e90, SaveProfiles 0x7814b0, SpawnCharacterAtMouse 0x7816c0
  - **The retail game honours god mode (+9) and super speed (+0xA)** (confirmed 2026-09-25: the user tested the F5/F6 test-mode toggles in 1-a and both "work perfectly"). **Correction (2026-09-26, B7 log + every earlier log):** with god mode on, Shank still takes damage (health drops, down to 0 and below). The byte 0xae6539 is read in one place only, 0x4c6f44 (a team comparison inside what looks like damage handling). What it actually prevents is unknown (hypothesis: death, or some damage between teams).
  - **The debug-settings block is a fixed global at `0xae6530`** (confirmed statically 2026-09-25: `0x529ec0` is just `mov eax, 0xae6530; ret`).
    - god mode = byte `0xae6539` (+9)
    - super speed = `0xae653a` (+0xA)
    - skip-intro = `0xae65a0` (+0x70)
    - `[0xae6533]`/`[0xae6534]` (+3/+4) are the flags that gate sound playback in the sim sound consumer (meaning unknown).
  - ToggleGodMode and ToggleSuperSpeed take no real arguments. They call `0x529ec0()`, which returns a global debug-settings struct, and toggle **byte +9 (god mode)** / **byte +0xA (super speed)**. Retail code still honours these flags **(confirmed 2026-09-25, see above: the user's F5 / F6 test)**.
  - NextCheckPoint/PrevCheckPoint use their `cSimulation*` argument (`[ebp+8]`), so the DLL needs the sim pointer to call them.

### Stategraphs (`data/stategraphs/`)

- `State{ name, anim, tags, events = {Event(...)}, on_enter/on_new_enter = {actions}, at_time = {AtTime(t, action)}, transitions = {...}, end_transitions = {...} }`
- Transitions:
  - `Transition(dest, cond, actions)`.
  - **`NullTransition(cond, actions)`** runs the actions with **no state change**.
  - `CompoundTransition(cond, actions, children)`.
- Shank's shared lists are in `stategraphs/shank/shank_transitions.lua`: `REACTIONS` (used by most grounded states), `AIR_REACTIONS`, `PICKUPS`, `RUNNING_MOVEMENT_TRANSITIONS`, …
- **The built-in anti-fall system** is the last entry of `REACTIONS`:
  `NullTransition(And(GroundHasTag("noFall"), CountdownExpired("noFallDelay"), CheckBool("facingedge")), { SetCountdown("noFallDelay", 6*FRAMES) })`
  - It works together with `Event("onfall", { Transition("backtoledge", CountdownExpired("noFallDelay", false)) })` in `shank/events.lua`.
- Pickups use `Probe{offset={0,0}, size={PICKUP_RADIUS,64}, props=true, …, condition=HasAttributeTag("healthpickup"|"grenadepickup"|"weaponpickup"|"pickup")}`.
- **Valsources** usable in `ValCmp`/`CheckBool` (with usage counts, from grep):
  - Edges: `disttoendofplatform`(19), `disttoendofplatformbehind`(11), `disttoclosestendofplatform`(11), `facingedge`(30), `backtoedge`(21).
  - Walls/ledges: `distancetoledgewall`, `lookingatledgewall`, `lookingatledgewallheight`, `wallhasledgeattop`, `distfromtopofwall`, `onwall`, `canshimmyforward`, `isshimmying`, `isonpole`.
  - Movement: `onground`, `inair`, `airspeedy`, `ononewayplatform`, `facing`.
  - Enemies: `distancetoclosestenemy`(39), `facingclosestenemy`, `backturnedonenemies`, `isonlythreatontargetside`, `distancetotarget`, `hdistancetotarget`, `angletotarget`, `facingtarget`.
  - Status: `healthpercent`, `inv:grenades`, `timer:<name>`, `cnt:<name>`.
- **Valsource behaviour on Shank (confirmed 2026-09-24, 1a-1 test in 1-a):**
  - `disttoendofplatform` is measured in pixels, in the facing direction. It drops below 4 tiles and then 1.5 tiles as Shank approaches a drop, whether walking or running.
  - It **also** drops at walls, because a wall ends the platform too.
  - `facingedge` is effectively true together with `disttoendofplatform` < ~1.5 tiles, so it's redundant for our purposes.
  - `onground` gates correctly: nothing fires during jumps.
- **`facing` true = right (confirmed in use since B3: the position ping's facing drives the edge cue's pan and B19's turn whoosh, and no wrong side has ever been reported):** Klei's own comment in the pickup `death_train` state: "Turn around if we're facing left:" `IfAction(CheckBool("facing", false), { Toggle("facing") })`. Our position ping reports `pos_r` when `CheckBool("facing")`; (the planned B3 log check is moot, see the heading).
- **Edge valsources are local (confirmed 2026-09-26, B3c log):** `disttoendofplatform` ends at the end of the current collision piece, including a seam where the next piece continues at the same height (x 5704, y 224, level 1-a), and probably at arena bounds. `lookingatledgewall` is only for ledge (climbable) walls. Shank runs at about 770 px/s.
- **Other valsources in the exe's name table** (strings near "disttoendofplatform", 2026-09-26): `facingwall` (bool; AI: `Or(CheckBool("facingedge"), CheckBool("facingwall"))` → turn), `at_platform_edge` (bool; AI scared shuffle stop), `heightofwall`, `lastrunintowallheight`, `hitcavewall`, `inbounds`, `onbounceoffbounds`, `isontargetplatform`, `segid`, `backedupagainstwall`, `approachingwallinair`, `touchingoneway`. None is a long-range distance.
- **Collision classes (RTTI, 2026-09-26):** `Sim::cCollisionWorld`, `Sim::cCollisionSegment`, `Sim::MapCollision`, `Sim::sCollisionSegmentIdentifier`, `AI::sPlatformID`, `Sim::cMovingPlatform(Manager/Path/PathSegment)`, `Segment2d`, an anonymous `FindFirstSegmentIntersection`. Nearby strings: "segments", "neighbours", "platform", "segid", "pathtransition", "pathingcaps": a platform/segment graph exists. The "disttoendofplatform" string (VA 0x8411fc) has no direct code reference (probably a name table).
- **The sim sound event doesn't point at its emitter's position** (B3c probe, negative): dwords at event+0x18 (0x11169100), +0x28 (0x10586770), +0x40 (varies) point at memory without the (x, y) floats in their first 0x800 bytes.
- **Picking up (read 2026-09-26, `PICKUPS` in shank_transitions.lua):** Block + Down (`ControlHasBeenPressed(CONTROL_BLOCK)`, `ControlIsDown(CONTROL_DOWN)`) with the pickup inside `Probe{size={PICKUP_RADIUS, 64}}`: health → `health_slam`, grenades → `activepickup`, weapons → a NullTransition (the pickup's own `collected` event does the rest).
- **A firing transition (NullTransition included) makes the stategraph re-check its list, up to about 10 times a frame** (confirmed 2026-09-26, B3b log: `cue: wall_3` 10 times in the same ms, every frame, when a report didn't disarm itself). So every NullTransition must disarm itself **in its own actions** (its countdown or counter), and ours in Shank's lists must fire rarely: firing 10+ times a second there hampered his movement ("getting stuck on level geometry"; frame rate stayed 59.8 fps).
- **A CompoundTransition whose condition is true but fires no child Transition doesn't stop the list** (inferred 2026-09-26: REACTIONS starts with `CompoundTransition(LacksTag("noReactions"), nil, {...})`, true almost always, and Klei's noFall NullTransition after it works). `CompoundTransition(cond, actions, children)` builds `{condition, actions, transitions=children, type="compound"}`. We use it as a gate so expensive conditions (valsources, Probes) are evaluated only when a countdown has expired.
- **Unknown:** whether `And(...)` short-circuits. Don't rely on putting CountdownExpired first; gate instead.
- **A firing NullTransition doesn't stop the list** (inferred from 1a-1: `edge_far` and `edge_near`, separate NullTransitions in sequence, fired in the same seconds). Ours still go at the **end** of each list (after the game's own), as Klei did with noFall, so that even if this were wrong they could only delay our reports, never the game's transitions.
- **Pickup stategraphs share `pickup_common_actions.lua`** (LoadFile'd by each, after it sets `UI_INDICATOR_OFFSET`/`UI_PICKUP_OFFSET`). The shared list is built at that LoadFile, so a global set just before it (our `A11Y_PICKUP_KIND`) is baked into that pickup's transitions.
- **NullTransitions appended to `REACTIONS` don't affect movement** (confirmed 2026-09-24: the user reported normal movement after many runs and jumps, with the probes firing about once a second).
- **Deaths in `game.log`:** `cApp::RestartGame` followed by `Checkpoint::Activate -- Activated checkpoint '<name>'` (confirmed 2026-09-24). Checkpoint progress, `Trigger::TryTrigger -- triggered '<name>'` and `cEnemyGenerator::ActivateWaveNumber` are logged too.
- `Probe{offset, size, delay, ownteam, otherteam, props, characters, condition, facingme, collects, …}` tests for **game items** (not terrain) in a box relative to the owner.
- Goon attack wind-ups consistently use `*_pre` state names (atk_pre, charge_pre, shoot_pre, grab_pre, kick_pre, jump_pre, punch1_pre, smash_pre, dropkick_pre, …).
- Weapon-select sounds (GenEvents in `data/commonpresentation.lua`, around line 383): `selectedPistols` plays `armPistols`, `selectedShotgun` plays `Sounds/Attacks/Shotgun/Shotgun_Arm`, `selectedUzi` plays `Sounds/Attacks/Uzi/Uzi_Arm`, `selectedChains` plays `ChainFist_Swipe`, `selectedSword` plays `Sword_Swipe`. Also `Minigun_Arm`, `GrenadeLauncher_Arm`, `RocketLauncher_Arm`. Successful plays are **not** logged, so a weapon switch leaves no trace in sound.log.
- `GenericEvents` in `data/commonpresentation.lua` map event names to actions (`DoGenEvent(name, {PlaySound(...), ...})`).

### Attributes (`data/attributes/`)

- `characters/*.lua` and `props/*.lua` use `inherit(base){ Tags={...}, Viz, Physics, Combat, StateGraph={StateFile=...} }`.
- Shank: `MaxHealth = SHANK_HEALTH`; `InventoryMax` has `{item="grenades", maxcount=5}`.
- Pickup tags: `pickup`, `healthpickup`, `grenadepickup`, `weaponpickup`.
- `props/proxy.lua` is an invisible fixed prop with no animation. **Template for our marker props.**

## Startup: intro logo movie (2026-09-24)
- **Correction, 2026-09-24:** the unskippable first logo (with its own music) is **`data-pc/bootstrap/movies/introscee.usm`** (10.9 MB).
  - It's played by the intro screen's **activation** routine `0x792c10`: hide B (`0x54d000(0)` on this+0x20), then **unless debug-settings byte `[0x529ec0()+0x70]` is set**, `mov edx, "introscee.usm"; call 0x54d410` at 0x792c37/0x792c3c.
  - `introscea.usm` (13.0 MB) sits next to it and isn't referenced by name in the exe (a regional variant).
  - The input handler `0x792b90` only lets you skip (`stopVideo`) when state == 1 **or** the debug byte +0x70 is set. That's why the first movie is unskippable. Byte +0x70 is a Klei developer "skip intro" flag in the same block as god mode (+9) and super speed (+0xA).
  - Patch: NOP the call at 0x792c3c (checked bytes at 0x792c37: `BA B8 44 83 00 E8 CF A7 DB FF`). **(Confirmed 2026-09-24, user:** with both skips, the game goes "straight to menu with only a few seconds of load".)
- The second, skippable sequence is the movie `data/bootstrap/movies/introtomain.usm` (13 MB, CRI USM), shown by the intro screen. The screen's gfx is `data/bootstrap/ui/introscreen.gfx`.
- The intro screen update is at `0x792c50` (thiscall, ecx = screen):
  - `[this+0x10]` = state.
  - `this+0x14` = video player A; `this+0x20` = element B.
  - State 0: `mov edx, "introtomain.usm"; call 0x54d410` (play), then state = 1.
  - While A isn't playing and state == 1: `0x54d000(0)` on A and `0x54d000(1)` on B (virtual +0x1c on the widget; likely show/hide).
  - Once A isn't playing, if `0x428f60(app)` == 2 (booting done), it moves to the next screen (`0x51f1d0`, id 0x39).
- Movie helpers wrap Scaleform methods on the player widget `[eax+8]`: `0x54d410` play (→0x555bf0), `0x54d440` "isPlaying", `0x54d420` "stopVideo". They're safe on a never-started video.
- **Skip patch (shank_access):** NOP the 5-byte call at `0x792cf2` (checked bytes at 0x792ced: `BA C8 44 83 00 E8 19 A7 DB FF`).
  - **Tested 2026-09-24:** it skipped the **wrong** movie. `introtomain.usm` is the **second** startup sequence, which was already skippable. **Something plays before it, with its own music track**; that's the unskippable one the user wants skipped. **Found later on 2026-09-24:** `introscee.usm`, played by the intro-screen routine 0x792c10; skipped by `SkipLogoMovie` (native/core/patches.cpp; test mode only since B18). The candidates considered before that: Candidates: `cSplashScreen` (RTTI), a boot-time movie or screen, a music cue. Expect the screen to advance once booting finishes: in the 1b-1 session boot finished about 9 s after start (`LOAD TIMES TOTALS` at 23:10:20 vs start 23:10:11). If the movie overlaps loading, the saving may be small.

## Levels (`data-pc/levels/<name>/`)

- `<name>.lua` is autogenerated by the "Shanker" tool and says "DO NOT HAND EDIT". It defines the globals `Actions = {...}` and `Checkpoints = {...}`.
  - Action `Type`s:
    - Spawning: `spawnprop` (`type` = prop attribute name), `spawncharacter` (`Attributes` = character), `spawnregiontrigger`, `spawntrigger`.
    - Scripting: `timedseq`, `genevent`, `setbounds`, `selectcontext`, `enemygeneratoraction`, `gauntletaction`, `tutorial`.
    - Camera and cinematics: `Push*Camera`, `PopCamera`, `playcinematic`.
    - Other: `addareaeffect`, `teleport`, `setgameover`, …
  - **Deadly pits:** `{Type="addareaeffect", lower={x,y}, upper={x,y}, fatal=true, killevent="ondeathfall", healthrate=0, ...}`.
    - Counts from the extractor, which walks nested checkpoint and trigger actions:
      - 1a: 3
      - 1b-pre: 2
      - 1b-train: 4
      - 1c: 17
      - 2a: 0
      - 2b: 4
      - 2c: 11
      - 3c: 8
      - 4a: 9
      - 4c: 1
    - The earlier grep counts were different because they included the paxdemo and missed nesting.
  - Many spawns (enemies, props, pits) sit **inside** `Checkpoints.Checkpoints[i].Actions` / `Checkpoints.Initial.Actions`, trigger `EnterActions` and `enemygeneratoraction` waves, not just in the top-level `Actions`.
  - Props use `proptype` + `offset` (not `type`/`Position`). Characters use `Attributes` + `Position` + `InitState`.
  - Checkpoints have `Name`, `Next` (the name of the next checkpoint, making a linked chain), `SpawnLocation0`, `FaceRight`, `Region`, `MusicCue`, `Actions`. Names are descriptive ("Before 1st Wallrun"), so they're usable as spoken waypoint names.
  - y grows upward **(confirmed 2026-09-26, B4: the .slev floors and Shank's tracked position)**. In 1b_pretrain the pit is at y 454–654 below spawns at y ≈1100.
  - Level files are pure Lua tables. They load fine in lupa (Lua 5.5) for offline extraction.
  - `ondeathmeatgrinder` = grinder deaths.
  - Damage zones: `addareaeffect` with `healthrate ≠ 0`.
  - Regions: `Region = {Type=2, Position={x,y}, Size={w,h}}`.
- Campaign levels:
  - `campaign_1a_wrestlingring`, `1b_pretrain`, `1b_train`, `1c_meatpacking`
  - `2a_brothel`, `2b_lovehotel`, `2c_redlight`
  - `3c_church`
  - `4a_winecellar`, `4c_thevilla`
  - The coop levels: `coop_*`.
- **`.slev`: level collision, fully decoded (2026-09-26, B4 G1; decoder `tools/levels/slev.py`, every level parses to the exact end of its file).** Loader: `LevelData::LoadSimData` 0x495e30 (the address hooked since B4 and confirmed working; an earlier note here said 0x495e40) (error strings "Unexpected level header", "Wrong level version '%u'"; the "LVEL" compare at 0x495e86; a second loader with the same check at 0x4966aa, not examined).
  - Header: "LVEL", u32 version (7; the game accepts ≤ 7), u32 → level+0x6c, u32 → level+0x70 (meaning unknown).
  - **Segments:** u32 n; each f32 x1, y1, x2, y2; u8 flag (0 in every file); u32 ntags; u32 tag hashes. Built by 0x563f10 and added to the collision world by 0x503e70 (world = level+0x68); 0x503fb0 then links them.
    - **Solid is on the right of the direction** (y up): floors run left→right, ceilings right→left, a wall going up faces left, going down faces right (checked in 1-a: the floor slab y 64–192 is top L→R, bottom R→L).
    - **Shank's reported y = floor + 32** (1-a: floor y 192, Shank 224; the step at x 2816 up to y 320, Shank 352).
    - **Tags are sdbm hashes of lowercase names:** noclimb (851 uses in 17 levels), skinny (650), nosplat (646), throwfg (126), throwbg (73), slipperyright (59), slipperyleft (6), bg (2), nofall (2), mg (1). `slide` (0x582732f1) and 0 appear on paths. `skinny` = thin one-sided pieces (1-a's climb after "1st Swing Point" is a staircase of skinny walls and floors; Shank's `skinnyledgeattach` state hangs from them when `heightofwall` < 3 tiles). **(hypothesis)** skinny floors are the one-way platforms (`ononewayplatform`; Down + Jump drops through, `JumpDown()`).
  - **Movie:** a length-prefixed string (one length byte, e.g. "1a-02_animatic.lua"; read by 0x43dd40/0x43dc30) + 4 floats → level+0xe8…0xf4 (0x496290; "movies/" prefix).
  - **Points:** u32 n; each f32 x, y → a 32-byte list at world+0x68 (0x5058d0). **Swing poles** (strong evidence 2026-09-26, B4 G3: in 1-a they hang over the bridge gap (pit zone x 18019–19923) and the last pit (x 31442–35202), where the floor ends deadly on both sides; 6 in 1-a, 13 in 1-c). Confirm in game with Shank's position while on a pole.
  - **Boxes:** u32 n; each two corners (f32 ×4, min/max) → world+0x58. **Wall-run zones** (strong evidence 2026-09-26: 1-a's one, x 26428–27612, y 2286–2600, spans the pit after the "Wall Run" checkpoint, x 26049–28557, whose floors end deadly on both sides). All ~1100–1500 px wide, 300–500 tall.
  - **Paths:** u32 n; each u32 count, (count − 1) × (f32 x, y; u32 ntags; tags), then f32 end x, y (0x503a90 → 0x51ab80; 92-byte nodes at world+0x78; each piece built like a segment). Mostly single lines. **(hypothesis)** vertical = poles to climb, tagged `slide` = poles to slide down; horizontal/diagonal = bars/ropes to shimmy along. A path can mix pieces (1-c: a slide pole then a diagonal rope). Campaign totals: 16 poles, 18 slide poles, 39 shimmy lines.
  - **Property regions** ×2 containers (0x5669b0): u32 version 1, then batches [u32 count, regions] until count 0. Region (0x566410 *peeks* the type, so it's part of the base): u32 type (0 `PropertyRegion::LerpRegion`, 1 `ConstantRegion`, 2 `LerpGroupRegion`), i32 rect ×4; then 4 / 1 property sets, or u32 n + n child regions. Property set: u32 n; (u32 key hash, u32 value type 1 bool u8 / 2 f32 / 3 u32 / 4 string). Camera/lighting-style settings by area; not traversal.
  - **Moving platforms:** u32 count (0x497240: animation "animations/<name>.canim", type "Bar"/"One Way", mode "Ping-Pong"/"Once"/"Loop"). **0 in every level file**, so the record layout isn't decoded.
  - **The B3c "false edge" at x 5704 isn't in the geometry:** 1-a's floor at y 192 is one segment from x 3200 to 7296. `disttoendofplatform` ended there because of something dynamic (a prop such as a barrier/table, or arena bounds).
- `.vlev`: visual layers (`levels/<name>/layer-N_x_y.dds`). `.tlev`: tutorial gfx list. `data.zip`/`tiles.zip`: vertex buffers / tiles.
- Units: `PIXELS_PER_TILE` (see `data/attributes/units.lua`); positions are in pixels.

## UI (Scaleform GFx 3.x, CLIK)

### 1c-1 static findings (2026-09-25)

**Flash → game (the ExternalInterface callback)**
- **Every** Flash → game call goes through `SwfExternalInterface::Callback`, vtable `0x8450c4`: slot 0 = `0x5536a0` (dtor), **slot 1 = `0x5534d0`**.
  - It's `__thiscall(this, GFxMovieView* movie, const char* method, const GFxValue* args, UInt argc)`, `ret 0x10`.
  - `method == "playsound"`: plays args[0] (a string) via 0x55ab10.
  - Otherwise it gets the movie's owner through movie vtable `+0xb8` (with an out param) and calls `0x553b40(owner; method, args, argc)`. That's the screen-level dispatch.
- **GFxValue (GFx 3.x), 16 bytes:**
  - `+0` interface pointer;
  - `+4` type (0 undefined, 1 null, 2 bool, 3 number, 4 string, 5 wide string, 6 object, 7 array, 8 display object; **bit 0x40 = managed**);
  - `+8` value. A number is a double. A string is a `const char*`, or `const char**` when managed.
- **Per-widget event handler `0x556160`:** called directly, not a virtual. It loops over a widget list. Events:
  - an unknown event with 2 args (args[1] a number) fires the delegate at `+0x38`;
  - **`itemClick`** with 2 args (args[1] = item index, a number) fires the delegate at `+0x40`;
  - **`focusIn`** with 1 arg fires `+0x48`;
  - **`focusOut`** with 1 arg fires `+0x50`.
- So focus changes reach C++ as ExternalInterface calls. **(settled by the 1c-2 log, below: `focusIn` / `navigate` / `click` / `change` with the widget path)**

**Game → Flash (setting text and values)**
- Widget wrappers: `0x54d120` SetText and `0x54d1d0` SetLabel. The wrapper's impl is at `[wrapper+8]`.
  - Both call **`0x5552c0`**: `esi` = impl, `edi` = member name (`"text"` / `"label"`), `[ebp+8]` = pointer to a `const char*` value.
  - `0x5552c0` builds a string GFxValue and calls **`0x559a50`**, the general "set member" on the Flash object (6 callers). **Confirmed 2026-09-25 (static):** `0x559a50` is `SwfSymbol::SetVariableInternal` (named in its own error string). Inputs: `esi` = SwfSymbol*, `edi` = member name (char*), `[esp+4]` = `const GFxValue*`; it returns `al` (success) and does `ret 4` (callee pops). It calls `0x5c6c20` with `ecx=[esi+0x28]` (movie), `[esi+0x30]`, the name and the value. **The widget's name is a `std::string` at SwfSymbol `+0xc`** (MSVC layout: capacity at +0x18; if >= 16 the heap pointer is at +4, else the inline buffer is at +4). `0x402680`/`0x402d50` are its `c_str()`. Callers: 0x555309 (SetText/SetLabel path), 0x55539a, 0x555d0a, 0x555f39, 0x556069, 0x559cd4. Neighbours: `0x559ab0` PlayAnimation(name), a SwfSymbol method (thiscall).
  - Video helpers use `0x555d50` (invoke a method: `isPlaying`) and `0x559920` (`stopVideo`).
- **HUD binding:** e.g. at `0x78d840`, the game builds paths with `sprintf("%s.healthBar" / "%s.grenadeTxt" / "%s.comboanim", player)`. It binds each to a C++ widget wrapper in the player HUD object (`+0x88`, `+0x94`, `+0xe8`) via `0x54ccf0(ecx = screen, edi = wrapper; path)`. So HUD values also flow through the wrappers, i.e. through 0x5552c0 / 0x559a50.

### 1c-2 runtime findings (2026-09-25, log `build/logs/20260925-073537-1c-2-ui-logging`)
**Flash → game events** (216 `ui call` lines):
- `focusIn("<full widget path>", undefined)` fires when a widget gains focus. **Paths name the widget**, e.g. main menu `_level0.controls.spBtn` → `mpBtn` → `achievementsBtn` → `leaderboardsBtn` → `helpBtn` → `quitBtn`; Help & Options `howToPlayBtn`, `controlsBtn`, `settingsBtn`; difficulty `normalBtn`; dialog `_level0.secondBtn`.
- `navigate("<path>")` fires on each direction press, repeating when pushed against the end (no wrap-around). `click("<path>", 0)` on activation. `change("<path>")` on slider/spinner changes: `_level0.musicSlider`, `ratioSpinner`, `modeSpinner`, `rumbleSpinner`, `adapterSpinner`. `stopped("_level0.gameMovie1")` when a video ends.
- **Gaps:**
  - In the **Settings** dialog, moving between controls only gives `navigate(undefined)`: no focusIn with a path.
  - **Level select** chapter scrolling produced **no events** at all.

  Focus there must be tracked some other way. → 1c-3/Phase 2
- **Main-menu button labels are not set by the game.** They're baked into the SWFs, so labels must be read from Flash (GetVariable on `<path>.label`) or taken from a table extracted from the SWFs.

**Game → Flash values** (336 `ui set` lines, change-only):
- HUD:
  - `_level0.HUD.player1.healthBar.value` (a number, percent: 100 → 97.5 → 95 → 90);
  - `_level0.HUD.player1.grenadeTxt.text` ("3" → "2" after the user threw exactly one grenade);
  - `_level0.HUD.player1.comboanim.combo.comboNum.text`. **(confirmed 2026-09-26 from the 1c-3 log)** Written on every hit: "1", "2", … "12". A new combo starts again at "1" (seen right after Shank was hit: health write at 38.931, "1" at 38.964). There's no explicit reset or hide write; hits 1.15 s apart still continued a combo. The listener gets every write (the log shows changes only, so repeated "1"s don't appear there).
  - enemies: `_level0.HUD.enemy0..2.nameTxt.text` (e.g. "Wallace", "Franco") and `.healthBar/.smallHealthBar/.largeHealthBar.value`;
  - bosses: `_level0.HUD.enemyBoss.nameTxt`, `_level0.HUD.enemyBosses.boss1/boss2.nameTxt`. **(confirmed 2026-09-26 from the 1c-3 log)** A fight starts with name, `profileImg.image`, `healthBar.visible = true` and `healthBar.value = 100` in the same ms; the value falls in percent and **goes negative on overkill** (-750, -2500, -2.4375). `nameTxt = ""` (all three bars) at level loads. The two-boss bars' `healthBar` writes haven't been seen yet (**hypothesis:** `enemyBosses.bossN.healthBar.value`).
  - `profileImg.image`.
- Dialogs: `_level0.headerTxt.text`, `_level0.bodyTxt.text`, `_level0.secondBtn.label`/`thirdBtn.label` (e.g. "Unsaved Changes" / "Are you sure you want to close?" / "Yes" / "No"; "Writing Game Results" / "Please wait...").
- Settings: `_level0.musicVolumeTxt.text` (the number at every slider step), `soundVolumeTxt`, `soundSlider.value/maximum`, `ratioSpinner.disabled`.
- Tutorial hints: `_level0.tutorial.help.helpText.text`.
- Level select / stats: `_level0.CampaignName.text` ("Story Mode"), `_level0.Stats.*` (longestCombo, totalEnemyKills, weaponName0..8 / weaponKills0..8, …).
- Other: `<widget>.visible`, `.focused`, `._y`, `.image`.
- **Consequence:** Phase 3 status readouts (health %, grenades, combo, enemy/boss names and health) and the dialog/tutorial text can all come from this one hook.

### 1c-3 static notes (2026-09-25)
- **A SwfSymbol holds a GFxValue display-object handle at `+0x28`:** iface at +0x28, type at +0x2c (8 = display object), pData at +0x30. **(hypothesis, strong)**
- ObjectInterface methods (thiscall, ecx = iface; they resolve pData to a display object via `0x6225c0`):
  - `0x5c6c20` = **SetMember(pData, name, const GFxValue* value, bool isDObj)**. Its only caller is SetVariableInternal 0x559a6f.
  - `0x5c6cf0` = GetDisplayInfo(pData, out). Used by `0x5598f0`, which returns the visible byte (SwfSymbol::IsVisible).
  - `0x5c6e00` = SetDisplayInfo. Used by `0x5598c0` (SwfSymbol::SetVisible).
  - `0x5c68c0` = used by PlayAnimation (0x559ab0/0x559b00); probably GotoAndPlay-like.
  - `0x5c6a50` = a GFxValue → internal value conversion (a switch on type & 0x8f), used by SetMember.
  - `0x5c6930` (callers 0x5c7fe2, 0x60d2ad, 0x60d3cf, …) was the GetMember candidate. **Checked 2026-09-25: it's an internal helper, not the public ObjectInterface::GetMember.**
    - thiscall(ecx = AS object; `[esp+4]` = context/env, `[esp+8]` = C-string name, `[esp+0xc]` = internal value out), `ret 0xc`.
    - It builds an engine string with `0x61a310(strmgr+0x24c, name, len, 0)` (strmgr = `[[env]+8]`), then calls the object's **vtable `+0x2c`** (a GetMember on an internal GASObject), and returns `al`.
    - The output is an internal GASValue, **not** a GFxValue.
- **Found (confirmed static 2026-09-25):**
  - `0x5c8500` = **ObjectInterface::GetMember(pData, name, GFxValue* out, bool isDObj)**, thiscall ecx = iface, returns al. Callers: `0x5599f0` **SwfSymbol::GetPropertyInternal** (named in its error string; esi = symbol, edi = member, `[esp+4]` = GFxValue* out, `ret 4`), and 0x55564b (reads `image`), 0x555750 (reads `clickSound`).
  - `0x5c7620` = **ObjectInterface::ObjectRelease(GFxValue* v, void* data)**, `ret 8`. The game calls it with `ecx = [v+0]`, `push [v+8]`, `push &v` whenever type bit 0x40 (managed) is set. For a managed string it decrements the node refcount at `[data+8]`.
  - **GFxMovie vtable (the movie object at SwfScreen `+0x38`):**
    - `+0x28` = IsAvailable(path), used by SwfScreen::CreateWidget 0x554020 ("path does not evaluate to an object").
    - **`+0x44` = GetVariable(GFxValue* out, const char* path)**. The SwfSymbol constructor `0x559480` calls it to fill the symbol's handle at `+0x28` from the widget path (`_level0.<name>`).
    - `+0x5c` = Invoke(path, result, args, argc), used by SwfSymbol::InvokeMethodInternal 0x559920 (path built as `"<widget>.<method>"`).
  - The `movie` passed to SwfExternalInterface::Callback is the same kind of object, so `movie->vtable[+0x44](&out, "<focus path>.label")` reads a button label **(confirmed by 1c-3, below)**.

### 1c-3 runtime findings (2026-09-25, deployed ef881c0, log `build/logs/20260925-195726-1c-3-focus-labels`)
- **Confirmed:** the `movie` passed to SwfExternalInterface::Callback supports GetVariable at vtable `+0x44`. `GetVariable(&v, "<focus path>.label")` returned a string for **all 41** focusIn events. There were no crashes (crash.log empty) and no rate-limit drops. The user played through level 1 and its boss afterwards with no problems.
  - The `textField.text` fallback was never needed. Whether `.label` goes through the CLIK getter or a plain member doesn't matter: it works.
- **Label values seen:**
  - **Main menu** (`_level0.controls.*`): `spBtn` = "IDS_CAMPAIGN", `mpBtn` = "IDS_MULTIPLAYER", `achievementsBtn` = "IDS_ACHIEVEMENTS", `leaderboardsBtn` = "About Us" (plain), `helpBtn` = "IDS_HELPANDOPTIONS", `quitBtn` = "Exit Game"; difficulty `normalBtn` = "IDS_DIFFICULTY_NORMAL".
    - **Labels can be localization keys.** All 19 `IDS_*` keys are in `data/bootstrap/localization/localization_en.xml` (IDS_ACHIEVEMENTS, IDS_CAMPAIGN, IDS_CAMPAIGN_LOADSAVE/NEW/SELECT, IDS_DIFFICULTY_HARD/MADNESS/NORMAL, IDS_HELPANDOPTIONS, IDS_LEADERBOARDS, IDS_MULTIPLAYER, IDS_MULTIPLAYER_LOCAL/SL_HOST/SL_JOIN/XBL, IDS_PRESS_START, IDS_RETURN, IDS_TEST, IDS_UNLOCK). The displayed text is translated later (KleiGFxTranslator). **(hypothesis)** `<path>.textField.text` holds the translated display text.
  - **Help & Options:** "How to Play", "Controls", "Settings".
  - **Pause menu** (`_level0.*`): resumeBtn "Resume Game", lastCheckpointBtn "Load Last Checkpoint", unlocksBtn "View Unlocks", weaponsBtn "View Weapons", helpOptionsBtn "Help and Options", quitBtn "Exit Game".
  - **Dialogs:** `_level0.secondBtn` "Yes"/"OK", `_level0.thirdBtn` "Cancel".
- **Settings dialog (again):** only `change("_level0.musicSlider" / soundSlider / rumbleSpinner / ratioSpinner / modeSpinner)`, `stepperChange("_level0.rumbleSpinner")` and `navigate(undefined)`. No focusIn, so no label read. → Phase 2.
- **2-1 runtime (confirmed 2026-09-25, log `build/logs/20260925-201526-2-1-menu-labels`):**
  - The stray pause-menu focus (`_level0.controls.howToPlayBtn`) comes from a **different movie** (135BA000) than the pause menu (149E3000).
  - Unlabelled widgets (GetVariable found no `.label` or `.textField.text`):
    - Weapons screen icon buttons `sawBtn`, `gunsBtn`, `macheteBtn`, `swordBtn`, `uziBtn`, `shotgunBtn` (`chainsBtn` exists too). The same screen has `meleeTitleTxt`/`meleeBodyTxt`/`gunTitleTxt`/`gunBodyTxt` text.
    - The Controls screen's `_level0.listBox` (the binding list; the device name is in `controlTxt.text`).
- **2-2 runtime (confirmed 2026-09-25, log `build/logs/20260925-203206-2-2-settings`):**
  - **Settings dialog events:**
    - Each move sends `navigate("<new widget path>")` (no focusIn for sliders, spinners or checkboxes; buttons also get focusIn in the same ms). `navigate(undefined)` = leaving the dialog.
    - The first focus is set by the game writing `_level0.musicSlider.focused = true`, **before** it writes `musicSlider.value` and `musicVolumeTxt.text`.
    - Spinner changes send `change` + `stepperChange` in the same ms.
    - Checkbox toggles send **`select("<path>")`**. The game writes `cbBloom/cbBlur/cbDisplacements/cbFullscreen.selected` only when the dialog opens.
  - **Readable by GetVariable:** spinner values at `<spinner>.textField.text` ("ON"/"OFF", "1920x1080 (16:9)", "16:9", "(1) AMD Radeon Graphics"); slider numbers at `_level0.musicVolumeTxt.text`/`soundVolumeTxt.text`.
  - **Checkbox state (confirmed 2-2b, log `build/logs/20260925-203839-2-2b-settings-fixes`):**
    - `<checkbox>._selected` (the CLIK backing field) always gives the bool.
    - `<checkbox>.selected` gives nothing until the user has toggled the box, then gives the correct bool.
    - **(hypothesis)** GetVariable returns plain members and doesn't run AS2 getters. A toggle, or the game's write, creates a plain `selected` member. `.label` works because button labels are plain members.
    - Prefer the CLIK backing fields (`_selected`, `_value`, `_disabled`) when a public property reads as nothing.
  - SwfSymbol `+8` → SwfScreen, SwfScreen `+0x38` → the same movie object the callbacks get (the focused-set events carried movie 1539C000, the same as the dialog's navigate events). **(confirmed, same pointer in the log)**
- **Level select (static, 2026-09-25, for 2-3):**
  - The screen is `levelselectscreen.gfx`, class `LevelSelectScreen` (RTTI `.?AVLevelSelectScreen@@`). Its widgets are `FilmStrip.LevelSelector` (wrapper at screen `+0x3c`), `CampaignName` ("Story Mode") and `backBtn`. The activation log tag is "levelselectscreen::onactivate".
  - **It's driven from native code, not Flash events,** which is why 1c-2 saw nothing while scrolling. The native input handler `0x791f60` (thiscall, `ret 4`, float dt arg) polls `IsLoadingImage`/`IsSelected` every frame and calls `SelectNext` (0x79211f) / `SelectPrev` (0x792171) when the stick/keys pass a threshold (`[screen+0x88]` accumulates).
  - The cell list is built in `0x7924d0` (on activation):
    - `Clear`;
    - per level, `AddCell` with format `"%s, %s, %s, %d, %f"`. The strings come from a level record (`0x411d30` lookup) at `+4`, `+0x58` and `+0x74`; the int is a flag at `[ebp-0x139]`; the double is progress (`[ebp-0x150]` / const, or a const);
    - then `SelectCell("%d, %d", index, 1)`.
    - A debug branch instead lists every `levels/` folder (`campaign_`/`coop_` prefixes).
  - `GetSelectedIndex` is called at 0x791bd4 / 0x791cfd (returns a string). `TriggerLoad`, `CancelImageLoads`.
  - **Runtime (confirmed 2026-09-25, log `build/logs/20260925-205356-2-3-level-select`):**
    - AddCell args = (chapter name, small image `levels/small_00NN_x.dds`, large image `levels/_00NN_x.dds`, int flag, float).
      - The name is plain English, e.g. "Return Home"; 20 chapters.
      - **The flag is 1 for a locked chapter** (confirmed 2026-09-25 on a fresh save: 1 from the first unreached chapter on, 0 before; all 0 on a complete save).
      - On opening, SelectCell selects the first unfinished chapter (fresh save: index 2).
      - The float is the **best completion time in seconds**: ms / 1000.0 (const 0x847e80) when the save has a time, else **-1.0** (const 0x847f38). Confirmed static 2026-09-25; the values (45.5 … 2522.8) fit, and the user's save has every chapter completed.
    - Keyboard scrolling makes **no** calls either way (no SelectNext/SelectPrev); the Flash strip scrolls itself.
    - **`GetSelectedIndex` (asked by us through the original InvokeV) returns the current index as text immediately** (confirmed 2-3b, log `build/logs/20260925-210548-2-3b-level-poll`).
    - The game polls `IsSelected()` → "false" every frame while the screen is up.
- **Native → Flash method calls (static, confirmed):**
  - `0x54d080` = widget-wrapper invoke helper: cdecl, `eax` = wrapper; `[esp+4]` method, `[esp+8]` printf-style format, varargs. It calls `[wrapper+4]` (the SwfSymbol) vtable `+0x40`.
  - **`0x559b50` = SwfSymbol::InvokeV(const char* method, const char* fmt, va_list args)**: thiscall, `ret 0xc`, returns `const char*` (the result as text, e.g. "true", or an index). It builds `"<widget>.<method>"` and calls `0x5d1790` (ecx = movie = `[[sym+8]+0x38]`; path, fmt, va_list) = GFxMovie::InvokeArgs.
    - First bytes: `81 EC 04 01 00 00 A1 70 46 88 00`.
    - It's the vtable `+0x40` entry of every SwfSymbol subclass (14 vtables, 0x84516c … 0x8458dc).
- **Erase Save Data flow (confirmed 2026-09-25, log `build/logs/20260925-212958-2-3c-fresh-save`):**
  1. The confirm dialog (headerTxt "Erase Save Data", bodyTxt "You are about to erase all your saved data. Are you sure you want to do this?", secondBtn "OK", thirdBtn "Cancel", initial focus Cancel).
  2. OK → 4× `SaveSaveData` of 12 bytes. It then opens a **second, single-button dialog in another movie**: headerTxt "Save Data Erased", bodyTxt "Your saved data was successfully erased.", secondBtn hidden, thirdBtn "OK".
  3. Arrow keys on it send `navigate("_level0.thirdBtn")` repeatedly.
- **SwfSymbol::InvokeMethodInternal 0x559920 (static, 2026-09-26):** ecx = symbol, **edi = method name**, `[esp+4]` = result GFxValue*, `[esp+8]` = args GFxValue*, `[esp+0xc]` = argc; returns al; `ret 0xc`; first bytes `81 EC 0C 01 00 00 A1 70 46 88 00`.
  - It builds `"<widget>.<method>"` and calls movie vtable `+0x5c` Invoke.
  - 12 callers; the method names passed in edi are addItem, clearItems, getItem, getUserData, setSelectedIndex, playVideo, pauseVideo, stopVideo.
  - List boxes: `clearItems` 0x54d660; `addItem` at 0x555baf (a text list: args = (string label, number)) and 0x556333 (a custom list: an args array built in a loop, 0x30-byte source items); `setSelectedIndex` 0x55592f; `getItem` 0x5559d4; `getUserData` 0x555ab4.
- **Controls screen runtime (confirmed 2026-09-26, log `build/logs/20260926-055945-morning-overnight`):**
  - Rows arrive as `listBox.addItem(icon, action, binding)` via InvokeMethodInternal, e.g. ("controls/JUMP.png", "Jump", "Space"); Previous/Next Gun/Weapon have an empty icon. clearItems first; the list is rebuilt when switching controllers ("360 Controller [1]" gives "Button X", "Left Thumb Left"…).
  - **Keyboard bindings:** arrows, Left Control, Left Shift, Left Alt, Space, Enter (grenade), Right Shift (pounce), Caps Lock (block), Right Control (grapple), 1–4. H and G are unused.
  - **The list is keyboard-navigable:** focusIn("_level0.listBox") then `change("_level0.listBox", <row>)` per arrow press, plus `ui set listBox.selectedIndex`. focusOut sets it to -1.
  - Like the difficulty screen, it sends focusIn before navigate.
- **Weapons screen choose (confirmed 2026-09-26):** choosing any weapon rewrites **both** slots' titles and bodies (melee and gun) in the same ms before the click event.
- **Level load / respawn (confirmed 2026-09-26):** `HUD.player1.healthBar.value = 100` and `grenadeTxt.text = "3"` are written in the same ms.
- **Wall-run zones latch anywhere inside (corrected 2026-10-01, B41f; B41e's "near the end he enters" was a misread):** the B41e log, 4-a, a wall jump came down into the zone (69326..70646) ~257 px inside its end and ran; the B41d pole jump from 2286 caught 1-c's f16 and ran to its end. **A wall jump while sliding back after a run-up's top barely rises** (one flight: w108 at 2838, leaving at ~580 px/s across and ~800 px/s falling; hypothesis).
- **Co-op and AI (2026-10-01, static + the co-op log):** goon AI is engine code (data/strategizers/defaultstrategizer.lua is "--currently empty"; data/strategy.lua: AttackPeriod, HitPeriod, ShotPeriod, GrappleBlankout timings only); goons' attributes give only a StateGraph file. Co-op players are Shank characters (attributes shank.lua, shank2.lua, shank_mp.lua) on two teams (24 / 25 in coop_1_bikersinabrothel), each with its own HUD block (HUD.player1, HUD.player2). Co-op levels: coop_* (not in our extracted geometry). **Co-op rules (confirmed 2026-10-01 by the user, from play):** the two players can't be more than a screen apart (the leader is held while the other is at the screen's far left edge); a player killed by enemies stays down until the other revives them with Down + Grapple (the pickup command). Pit deaths in co-op: not seen. The lobby has a join button per player (player0.readyBtn ...); the device that presses one plays that player (P1 = Shank, P2 = his partner) (the user, 2026-10-01).
- **Off a slope's end he crosses at ~750-790 px/s (B41c, measured 2026-10-01 from the B41b log, 1-c s51 and s60, sliding off and jumping alike), not the slide's 13 MPS.** Falls catch ledges close above (s61's, 56 px up); the wider reach was only seen in a jump (B41-4).
- **Walking off an edge always carries speed (B41-6, 2026-10-01, from the B41 log):** walking off s42's left end he went into the grinder 0-40 px past the edge: the model now gives walk-offs at least air-control speed (384 px/s); letting go of poles, walls and bars still drops straight.
- **Bar / shimmy jumps start with a pull-up (confirmed 2026-10-01 from two logs, B41-4):** hanging still, Jump first lifts him ~50 px in place over ~160 ms (1-c f19: 2534 -> 2585; the B5 log's bar end: 3996 -> 4044), then the flight (+170 px to the top, ~1150 px/s across). **Ledge grabs reach ~190 px above our position** (one grab, 1-c s29's ledge (16384, 2944) from below its 64 px lip; hypothesis: LedgeHangDist 2.5 tiles counted from the body's middle, feet + 80, and needs no contact with the wall under the ledge).
- **The game's controller bindings in memory (static RE 2026-09-30, B40-4; the layout a hypothesis until a log shows it):** class `Input::XInputController` (vtable 0x843fdc; slot 7 = 0x535400, the binding's name for an action). Its bindings are a **std::list** at +0x64 (the head node pointer; corrected 2026-09-30 from the B40 log, "couldn't be read" as a tree: the find 0x52ec60 walks from [head] along +0 until the head; a node: +0 next, +4 prev, +8 the action key (0x14 bytes, compared by 0x52d590)); a node's binding at +0x1c: +0 type (0 axis, 1 trigger, 2 button), +4 axis (0 LX, 1 LY, 2 RX, 3 RY), +8 byte positive (Right / Up), +0xc trigger (0 left, 1 right), +0x10 button (an XInput wButtons bit, e.g. 0x1000 Button A). The name function 0x536620 (axes 0x536900: "Left Thumb %s" / "Right Thumb %s"). Start pauses outside the action table; the right stick's left / right roll / dodge (the user, 2026-09-30, from play: hard bound). **The game's menus read the pad through XInputGetKeystroke** (import #8; hypothesis from the user's report that the pad still moved the game's menus with only XInputGetState hidden).
- **The game's default controller map (confirmed 2026-09-30 from the Controls screen rows logged when the user switched it to "360 Controller [1]", 2026-09-26 logs):** Move Left / Right / Look Up / Crouch = Left Thumb Left / Right / Up / Down; Quick Attack Button X; Heavy Attack Button Y; Gun Attack Button B; Jump Button A; Grenade Left Bumper; Pounce Right Bumper; Block Left Trigger; Grapple Right Trigger; Previous / Next Gun DPad Up / Down; Previous / Next Weapon DPad Left / Right. The 16-action table has no entry for the right stick, the stick clicks or Back (Start pauses); they're free by default, but the Controls screen can rebind any action to them. (autoexec.lua's JKEY_RStick / JKEY_LStick debug combos: that file is never loaded.)
- **Controls screen (controllerconfig.gfx, static 2026-09-26):**
  - Widgets: listBox, controlTxt (device, e.g. "Keyboard"), btnPrevious, btnNext, btnReset, btnSave, btnLoad, backBtn.
  - The rows are built at 0x788d60 from pairs (icon `controls/<ACTION>.png`, name): Move Left, Move Right, Look Up, Crouch, Quick Attack, Heavy Attack, Gun Attack, Jump, Grenade, Pounce, Block, Grapple, Previous Gun, Next Gun, Previous Weapon, Next Weapon.
  - "-Select New Input-" (0x8331c8) is shown while rebinding (0x789db1).
  - **How the rows reach Flash, and whether the list is keyboard-navigable, is unknown** (in 2-1 the game moved focus from listBox to btnPrevious at once).
- **Weapons and Unlocks screens (static + logs, 2026-09-25):**
  - `weaponunlocksdialog.gfx`: the native binding at 0x77ede7 (strings 0x831ca0…).
    - Widgets: backBtn, meleeTitleTxt, meleeBodyTxt, meleeArt, area1, gunTitleTxt, gunBodyTxt, gunArt, area2, and per weapon `%sBtn`/`%sBg`: saw, chains, machete, sword, guns, uzi, shotgun.
    - Static SWF text: "HEAVY WEAPONS" plus placeholder body text.
    - The game writes each `<weapon>Btn.disabled` and the equipped weapons' titles/bodies on open ("Chainsaw"/"Default heavy weapon.", "Chain Fists"/"Powerful chains to mangle and choke your enemies.", "Pistols"/"Default gun weapons."). It rewrites them when a weapon is chosen (a "Uzi" gun title was seen).
  - `unlocksdialog.gfx` = outfits.
    - Static title "SELECT AN OUTFIT"; `unlockBtn0..10` with `.portrait`; the game writes `unlockBtnN.visible` and `.disabled` (true = locked).
    - The index order matches `OUTFITS` in data/unlocks.lua (Shank 0, Wildman 1, Spartan 2, KungFu 3, Horror 4, Dance 5, NinjaRed 6, NinjaWhite 7, Droid 8, Gimp/teddy 9, DeathSpank 10).
  - `pausedialog.gfx` static text includes the stats labels ("GRENADE KILLS:", "Shank Kills:", "Total Enemy Kills:", "Total Creature Kills:", "longest combo:").
- **Gameplay text fields (logs + static, 2026-09-25):**
  - `_level0.hintText.text` = the loading tip, written as the loading screen appears (e.g. "Hold guard to throw dogs aside").
  - `_level0.tutorial.help.helpText.text` = a tutorial hint, written when the tutorial prompt appears (1-a, about 12 s in).
  - gamescreen.gfx also has TutorialOverlay0..3, an `unlockTxt` banner ("You unlocked a new weapon!"), and the enemy/boss `nameTxt`.
  - `newweapondialog.gfx`: continueBtn, unlockTxt (static "You unlocked a new weapon!"), a placeholder movie (the weapon picture).
  - `newcostumedialog.gfx`: buyBtn, continueBtn, costumeName, costumeChangeText ("Change your costume under the Unlocks option in the Pause Menu."), buyText, costumeImage.
- **Drawn text in the UI files (confirmed 2026-09-26):** some screens draw their text as SWF **DefineText** glyph runs (tags 11/33), which GetVariable can't read.
  - They decode with the DefineFont2/3 (tags 48/75) code tables (glyph index → character).
  - How to Play: each page is its own screen (howtoplayscreencombos/grapples/coop.gfx, separate movies). The editable `nameTxt` has the page title ("Combos", "Grapples", "Coop Play"); the explanations are DefineText (e.g. "Juggle enemies by holding down and pressing attack").
  - 30 of the UI files have drawn text (settings labels and others too); see `tools/ui_text/extract_ui_text.py`.
- **Dialog text fields (static scan of `data*/ui/*.gfx`, 2026-09-25):**
  - `headerTxt` + `bodyTxt`: modaldialog, newconceptartdialog, busydialog.
  - `bodyTxt` only: quitdialog (the main menu's Exit Game). Its text is static in the SWF, "Are you sure you want to exit the game?"; buttons `quitBtn` (labelID "Quit"), `cancelBtn` ("Cancel"); the game never writes the text.
  - `titleTxt`: creditsscreen.
  - Modal dialogs get their text written by the game (headerTxt/bodyTxt), then the first button focus, in the same ms (confirmed in all logs to date).
- **SwfScreen vtable (static, 2026-09-25):** the vtable is around 0x845078 (entries 0x5536c0 …).
  - `0x553cd0` = IsActive (`[this+0x3c] != 0`).
  - `0x553ce0` = Open: state 0/3 → 1 (opening), then posts an event (0x554ed0).
  - **`0x553d50` = Update(float dt)**: thiscall, `ret 4`; first bytes `D9 44 24 04 56 8B F1 8B 4E 38`. It calls movie vtable `+0x8c` (Advance(dt, 2)), then movie `+0x1c` (a "finished" check) moves state 1 → 2 and 3 → 0.
  - `0x553db0` = Render: draws via movie `+0x90` only if byte `[this+0xc]` is set (visible).
  - **State `[screen+0x3c]`:** 0 closed, 1 opening, 2 open, 3 closing. The movie is at `+0x38`.
- **Screen lifetimes (confirmed 2026-09-25, log `build/logs/20260925-222733-2-5b-3-crash`):**
  - SwfScreen::Update runs every frame for every existing screen, closed ones included (state 0 transitions were seen).
  - The main menu screen stays "shown" (state 1/2) underneath its submenus; a submenu goes shown → hidden on back-out.
  - **Screens are destroyed without passing through "hidden"** (the main menu's when a level loads): their Update simply stops. Liveness = "Update ran recently", and **a stored movie pointer must never be used unless alive** (reading through a freed movie crashed the game).
  - The in-level Help & Options is a separate movie from the main menu's.
- **Asking a movie for its focus (confirmed 2026-09-25, 2-5b-6 log):** `ui_hooks::QueryFocus` answered `_level0.controls.howToPlayBtn` for the in-level Help & Options on first entry. It tries movie vtable `+0x5c` Invoke("Selection.getFocus") first, then GetVariable `_global.gfx.managers.FocusHandler._instance.currentFocus._target`. (The log line doesn't say which one answered.)
- **Pause menu and exit behaviour (confirmed 2026-09-25):**
  - Escape in the in-level Help & Options is handled natively (no `navigate(undefined)`): Help hides, then the pause screen hides 83–216 ms later and the game resumes. Escape in Weapons/Unlocks sends `navigate(undefined)` and returns to the pause menu.
  - The in-level first entry to Help & Options sends no focus event.
  - Quit in the main menu's Exit Game dialog: `click("_level0.quitBtn")` → the quit dialog hides at once → `ExitProcess(3)` about 1.7 s later. Both "Quitting the game NOW!" paths (0x56e6a8 main loop, 0x44ba4e window proc) end in CRT exit → kernel32 ExitProcess (imported at 0x7e4098).
- **Backing out / re-entering menus (2-5b-2 log):** backing out sends only `navigate(undefined)`; re-entering an already-built submenu (click helpBtn the second time) sends only the click. **CLIK restores the screen's previous focus with no event**, so the next event is the user's first arrow press.
- **Focus event order differs by screen (confirmed 2026-09-25, 2-5b log):**
  - Main menu and Help & Options: `navigate` then `focusIn`.
  - **The difficulty screen: `focusIn` then `navigate`** on every arrow press.
  - Backing out to a previous screen (main menu, Help & Options) arrives as `navigate("<path>")` in that screen's movie, with no focused-set.
  - Screen movies persist and are reused: the difficulty screen keeps movie 1536D000 across visits.
- **The quit dialog's static `bodyTxt` text ends with a line break** (so the text read back ends after the question mark with a line break; confirmed by the extra period in 2-5b).
- **Note:** a focusIn can fire for a widget of a screen that is closing (e.g. `howToPlayBtn` logged 5 ms after `resumeBtn` when the pause menu opened). Phase 2 speech should debounce or prefer the last focus.

**Plan for 1c-2 (logging), done:**
- hook `0x5534d0` (a standard thiscall; log method plus decoded args);
- hook `0x559a50` or `0x5552c0` (log member name and value);
- where possible, log the widget identity too.


- The `.gfx` files in `data/ui` and `data-pc/ui` have a `CFX` header: zlib-compressed SWF after 8 bytes. JPEXS FFDec can open them once the header is changed to `FWS`/`CWS`.
- CLIK AS2 components: `gfx.core.UIComponent`, `gfx.managers.FocusHandler`, `gfx.controls.Button`. Focus events go to C++ through `ExternalInterface` (`dispatchEventToGame`); event names include `focusIn`, `focusOut`, `itemClick`.
- Button labels are mostly **baked into the SWFs**. For example, the pause dialog has `resumeBtn` "Resume Game", `lastCheckpointBtn` "Load Last Checkpoint", `helpOptionsBtn`, `unlocksBtn`, `weaponsBtn`, `quitBtn` "Exit Game".
- `localization_en.xml` has only 19 strings (IDS_*). `KleiGFxTranslator` is the translation hook.
- HUD (`gamescreen.gfx`): `player1`/`player2` PlayerUI with `healthBar`, `grenadeTxt`, `comboanim.combo.comboNum`, `meleeSlot`, `gunSlot`, `specialSlot`; `enemy0..2`/`enemyBoss` EnemyUI with `nameTxt`, `healthBar`; `TutorialOverlay0..3`; `hintText`.
  - The C++ side sets these through format strings `"%s.healthBar"`, `"%s.grenadeTxt"`, `"%s.comboanim.combo.comboNum"`, `"%s.meleeSlot"`, `"%s.gunSlot"`, `"%s.nameTxt"`, …
- Other hard-coded English UI strings are in the exe: settings dialog names (`musicSlider`, `adapterSpinner`, `cbFullscreen`, …), tutorial hint sentences, upsell and save dialogs.

## Save data (confirmed 2026-09-25)
- Shank saves through **Steam Cloud** (`SteamRemoteStorage`, exe string 0x87edd0) into `C:\Program Files (x86)\Steam\userdata\<account>\6120\remote\` (Shank's app id is 6120):
  - `savedata.dat`: progress, 484 bytes;
  - `settings.dat`: 16 bytes.
- The game log only shows the bare names (`ProfileManagerInterface::LoadSaveData -- loading data from 'savedata.dat'`; the format strings are at 0x8436a0…0x8436f8).
- Level completion times are stored in ms (`ProfileQuery::UpdateLevelCompletionTime -- update level time for %s/%s to %u ms`).
- Backups and the fresh-save procedure: `saves/README.md`.

## Position tracker: a wrong address that passes the ping check (confirmed 2026-09-29, B27play log)
- The tracker (native/core/position.cpp) keeps a memory address whose float pair matched the Lua ping and moved with him over 2 pings, re-checked only **at each ping** (within 64 px + 0.08 s of his speed); between pings `Current()` accepts the live read if it's within 1200 px of the last ping.
- In the B27play session (4-a) it locked onto 0x001AF6E0 at 06:36:04 and kept it to the end with no "lost" line. Climbing the pillar's right face (x 42496, y 6592-9088) at 06:51:42-06:52:10, the game's own Shank sounds (`sound at: Shank/Character/step|wallClimb ...`) put him at x 42528, y 6795 → 8929, while our live read said x 42326 at a lagging y (up to ~600 px off); our pan centre (the `listener=` value) flipped between the two. So that address holds Shank's position at ping time but something else in between (hypothesis: a scratch or camera-side copy that the ping itself refreshes).
- Measure (tools: the log's `traj:` lines vs `sound at: Shank/Character/(step|wallClimb|land|ledgeClimb|skidStop)` within 40 ms): off by > 150 px in 94% of pairs in B27play; 4% (B25), 12% (B27), 34-46% (B13b, B19play, B23). Old behaviour, luck of which address gets picked.
- Effect: while wrong, everything that uses his position is wrong: clinging not seen (the wall is 200 px from the read), the waypoint node stays on the last place (Q "let go to a climbable wall" with no distance), edge and jump cues from the wrong spot.
- The scan itself (~500 MB, ~140 ms) runs in `position::Work` on the cue thread, so every rescan freezes all cues for that long.
- **Why this session (the user: "I've never seen anything that bad in any previous session"):** every session since B4 tracked an address ending in `...518` (Shank's own object; e.g. 111BB518 held all through the previous 4-a session, re-found after each loss). Here:
  1. 06:35:20, x 5825: a grappler goon grabbed Shank ("Mash attack"): the grab moves him by its animation, the `...518` address left the ping and was dropped (normal; losses happen every session).
  2. The rescan ran while he was held still: **78 candidates** (usual 11-28): with him still, other things held his exact floats too.
  3. Candidates are confirmed in address order, so the lowest one that followed 2 pings wins: **0x001AF6E0** (06:36:04), seen once before (B19 session, reading (0, 0) when picked).
  4. It then stayed x-frozen for minutes at a time (x 5652 at 06:36-06:38 with Shank at x 5811-6944; 16995; 21547; 42326 at the pillar), y offset or lagging, and at times held his exact position (06:52:06: 43134.7 = the turn report's x).
  5. **What it was (B28, 2026-09-29; hypothesis, strong):** a slot on one of **our own threads' stacks**: 0x001AF6E0 is in the low range where 32-bit thread stacks live, the scan read every private RW region including stacks, and our locals (the cue thread's `pos`, flight samples starting at his position) hold copies of our own estimate: exact at ping time (the estimate is the ping when not live), anything in between, and once tracked partly its own read fed back (the frozen x). Host check: the real scan over the test process found a pair planted once on the heap **5 times** (stack copies of the arguments); with stacks left out, once. The first guess, the camera locked on fight arenas, didn't fit the bounds (no consistent offset).
  6. It was never dropped because the ping-time check can't see it: at ping time it matched.
- Correction (B28): `Shank/Character/step` is mostly other characters' steps (the B27 logs: 106 of 107 steps near a known position of his were > 150 px away), so the first measure was wrong. With only his own sounds (blockEnter, skidStop, wallClimb, shimmy, ledgeClimb): tracker off by > 150 px in 0 of 57 / 50 / 113 pairs (B19play, B23, B25), 8 of 349 (B13b), 4 of 560 (B27), **16 of 17 (B27play)**. Those own sounds are within 160 px of a correct tracker in the good sessions.
- **Fixed in B28:** stacks left out of the scan; between pings a read farther from the last ping than he can move (3000 px/s + 96 px) or jumping faster than that from the previous read is not used, and 3 such within 1 s drop the address; his own game sounds (list above) more than 224 px from the read twice within 3 s drop it; a dropped address is never picked again in that level; candidates are checked against his sounds and the reach before one is trusted; the ping-time allowance's speed is capped at 3000 px/s; the scan runs on its own thread.

## Deaths, cutscene videos, boss bars, chapters, story triggers (B29, 2026-09-29)
- **Deaths (confirmed from the logs; corrected 2026-09-30, B30-1):** an enemy's death plays `Shank/Character/enemyDeath` and/or `Voices/<Kind>/<Kind>_Death` at its position; the enemy list drops it (its life record flagged) **in the same ms, first** (the B29 log: `enemies: med_thug_knife gone` then `enemyDeath` 0-12 ms later, every kill). B29's "the list lags ~1 s" was wrong.
- **Kills without a death sound (the user, 2026-09-30):** "I favor the shotgun, which blows enemies back and uses a different scream sound, and does not play a special sound on death when an enemy dies that way." And: "The fall scream is actually different from the knockback scream. There were a bunch of falls back to back in the last fight before the end of the log as I blew enemies off a platform, and almost none prior to that." So `*_YellFalling` = a fall off (confirmed by the user: the B30 log's four at 3-c 13:15:34-44, the goon leaving the list ~0.5 s after the scream, still near the platform's height); the knock-back scream is another event (hypothesis: `MediumGoon_PainLong`, 44 plays in that log). A B31-5 change that required a drop after the scream was wrong and reverted.
- **Checkpoint jump (static RE 2026-09-30, B34; confirmed in game the same day, see below):** the debug `NextCheckPoint(cSimulation*)` 0x780d30 doesn't move Shank: it reads the simulation's restart checkpoint name (`0x4049d0` = sim+0x38, a std::string), finds that checkpoint in sim+0x14's list (+0x94; `0x475ca0` = its next, `0x475c90` the first), and calls **`0x406b80`** (thiscall sim, `const char* name`, `const vec2* pos`; ret 8): name → sim+0x38, pos → sim+0x54/+0x58 (NextCheckPoint passes the global 0xae10e0). **`LoadToLastCheckpoint(cSimulation*)` 0x781580** (cdecl, plain `ret`): copies the app's load request (app = [0xae699c], request at app+0xdc; copy-ctor 0x4070f0), sets its checkpoint string (request+0x4c) from sim+0x38 and its position (request+0x68) from 0x432400, stores it back (`0x42b270`: app+0xdc), then pushes screen 0x18 (loading) via 0x51f1d0: a real reload of the current level at that checkpoint. The request's strings (the B34 log, confirmed 2026-09-30): +0x14 the campaign ("Story Mode"), +0x30 the level ("campaign_3c_church"), +0x4c the checkpoint. **Confirmed in game 2026-09-30** (two jumps in 3-c). On Hard the restart checkpoint stays the level's start (hypothesis). Warping past a chapter's last checkpoint skips that chapter's completion (confirmed 2026-09-30, the user: on Hard, the level select appeared only once 1-a's last checkpoint was cleared by playing). A boss brought to 0 health by weapons / grenades waits in its grapple-now state until the finisher is started (the user, 2026-09-30, 1-a's fake Butcher). The load request's +0x158 is **not** the difficulty (1 on Normal and Hard, the B34c log). The difficulty screen's buttons are `_level0.controls.normalBtn` / `hardBtn` (game.log `MainMenuScreen::OnSelectDifficulty`); Hard with no Hard progress goes straight to 1-a (no level select). The simulation object: `cShankSimulation`, vtable 0x837d80 at +0 and 0x837db0 at +4 (RTTI COLs 0x849a2c / 0x849a18; cSimulation's own: 0x83a59c / 0x83a5cc); 1-b pre-train runs no bounds action at its start, so the bounds hook can't supply it there. Campaign chapters: `0x7a3f74` reads each sublevel's name / startcp / image / movie / RichPresenceContext.
- **Music volume (static RE 2026-09-30, B32):** `0x55a920(name, volume)` = EventSystem vtable +0x38 getCategory("master"), then that category's vtable +4 getCategory(name), then vtable +0x20 setVolume(volume × [0x889a00]). Callers: `0x55a980` SetGameVolume (stores [0x8899f8], applies "game"), `0x55a9b0` SetMusicVolume (stores [0x8899fc], applies "music"), and around 0x55aa00 one that sets the scale [0x889a00] (after a call to 0x41c3c0) and re-applies both. fmod_event.dll exports `EventSystemI::getCategory`, `EventCategoryI::getCategory / getVolume / setVolume / getMute / getPaused`, `MusicSystemI::get/setVolume` (virtual, __stdcall, this first).
- **Music volume in play (confirmed 2026-09-30, B32 logs music1-5):** FMOD's "music" category volume = the Settings value / 100, linear, from the first UI frame (~3.4 s after launch) on, through levels and the menus; master 1.0, scale [0x889a00] 1.0. The menu and level music are not ordinary events started by `Event::start` (none among the first 40 starts: only GUI sounds): probably FMOD's music system (the level parsers `playmusic` 0x4e511d / `startcue` 0x4e51af). The Settings slider, held, steps in runs of exactly 15 (~0.48 s) then stops until pressed again (music5; no mod input handling at the time): the game's own slider (hypothesis).
- **Startup audio (B33 log music6, 2026-09-30):** our init at launch +0; FMOD's EventSystem pointer [0xadfdf0] null until +4.4 s (the game's music setting global still its default 1.0 until then), then the music category = the saved setting at once. The FMOD music system's own volume 1.0, unmuted, never changed by the game. With test mode off the startup movies play through `_level0.introMovie` (Scaleform video): `introscee.usm` (~16 s) then `introtomain.usm`; their sound doesn't go through FMOD's event categories (hypothesis: not scaled by the music setting).
- **Videos (B30-2, the B29 log):** `_level0.gameMovie1` = the cutscenes (the game's time stops); `_level0.gameMovie0` = short videos over play (1-a `1a_03` / `1a_04` flashbacks, 2-a `2a_02`, 4-c `toro_intro_scene1`): `perf` game time 1.00 s per s during them, fights go on.
- **FMOD (B30-3):** fmod_event.dll / fmodex.dll 4.30.2; the game calls exported non-virtual `FMOD::Event` methods (`?start@Event@FMOD@@QAG?AW4FMOD_RESULT@@XZ`, getParameter, setValue, release); `?getVolume@Event@FMOD@@QAG?AW4FMOD_RESULT@@PAM@Z` and `?setVolume@Event@FMOD@@QAG?AW4FMOD_RESULT@@M@Z` are exported too (__stdcall, event first). PlaySoundAt calls start inside itself on the game thread.
- **1-a's grenade tutorial (B30-4):** the event trigger "Grenade tutorial" (TriggerEvent -932495990): `genevent pointOfInterest`, a `proxy` prop tagged `tutorialgrenade` at (24387, 2601), and `tutorial` tutorialgrenades.gfx with `track = true`: a marker at the proxy, no screen of its own (never a `screen shown` for it in any log). The campaign's only tracked tutorial without a screen (the others, tutorialhint etc., show one). Falling to its death: `Voices/<Kind>/<Kind>_YellFalling` (Medium, Large, Girl; Shank has `Shank_YellFalling`). Shank's own: `Voices/Shank/...`.
- **Cutscene videos:** the game's video player widget `_level0.gameMovie1`: `playVideo()` when a cutscene starts (4-a's intro 1.3 s after LoadSimData; Cesar's finale 2 ms after his last blow), `stopVideo()` + callback `stopped("_level0.gameMovie1")` when it ends or is skipped. The end credits use `_level0.creditsMovie` on creditsscreen.gfx (credits_1.usm), the same screen as the Credits menu item.
- **The single boss bar:** `_level0.HUD.enemyBoss.healthBar.value` goes to 0 (after a negative value) at the boss's defeat.
- **Grapple:** Shank's grapple plays `Shank/Character/shankGrapple` (chainsaw: `chainSawGrapple`) at the finisher's start; hits on an open boss (e.g. ChainFist_Swipe / _Hit) are not a finisher.
- **Chapters:** campaigns.lua's Story Mode `levels` → `sublevels` (name, startcp = a checkpoint name; "" = the level start); 1-b pre-train has none (the level's own `name`).
- **Story triggers:** a level's end is a `spawnregiontrigger` whose EnterActions `playcinematic` (the end cinematic), then a `spawntrigger` (condition type 18, the cinematic done) with `setgameover`; boss fights start from a region trigger with `PushBossCamera` (4-c Toro) or an intro `playcinematic` (the Priest's at (70734, 11860), left of his chapter's spawn (71417, 11972)). A checkpoint's own Actions run when he spawns there (hypothesis, from the Priest and 1-a's Boss checkpoint regions lying behind their spawns).

## Arena bounds (static RE 2026-09-26, B5)
- `Sim::cSetBoundsAction` (level Lua `Type = "setbounds"`, fields `min_bounds`, `max_bounds`, `reset`, `boundstag`): vtable 0x83f6a4 = [dtor 0x4eb800, **Execute 0x4eb940**]; the factory/parser is 0x4eb840 (reads "reset" + two vec2 into +8 (bool), +0xc (min), +0x14 (max)).
- Execute: thiscall(action; ctx) ret 4; target = `*ctx` (the simulation). reset → 0x46c470 (default bounds, flag +0xc0 = 1); else 0x46c390 (eax = target, edi = &max, [esp+4] = &min).
- **The current bounds are floats in the simulation object: +0xb0 min x, +0xb4 min y, +0xb8 max x, +0xbc max y; byte +0xc0 = default bounds in force.** Getter 0x46c430. Game items reach the simulation through item+0x20 (0x41a310).
- Other bounds strings: mMinBounds / mMaxBounds / mDefaultBounds, mInXBounds / mInYBounds, IgnoreBounds, onbounceoffbounds, inbounds.

## Shank's movement constants (stategraph Lua, 2026-09-26)
- Units: 30 frames/s; METER = 96 px; MPS = 96 px/s.
- `JUMP_SPEED` = 12.5 MPS (1200 px/s) (`stategraphs/shank/constants.lua`; also DOUBLE_JUMP_SPEED 12.5, WALL_JUMP_SPEED 13.5).
- `jump` (standing): Jump(90°, JUMP_SPEED × 1.15) = 1380 px/s up. `jumplong` (running, `ControlIsDown(CONTROL_FORWARD)`): Jump(60°, × 1.2) = 1440 px/s (720 across, 1247 up); air control from 4 frames.
- **Walls (onwall.lua):** `walljump` = Jump(WALL_JUMP_ANGLE 65°, WALL_JUMP_SPEED 13.5 MPS) away from the wall (548 px/s across, 1175 up); `wallclimb` climbs at `wallspeed` 3.5 MPS (336 px/s) while holding forward/up; `vaultwallledge` when `wallhasledgeattop` and `distfromtopofwall` < 1.5 tiles. Walls tagged `noclimb` can't be run up (1-c: the street's end wall is climbable from y 384 to 1600, `noclimb` above).
- Releasing jump early: `JUMP_HEIGHT_TRANSITIONS` sets the rise to 8 MPS (768 px/s) if it's still above that.
- **Measured from logged arcs (2026-09-26, B5 run, 10 running long jumps, `traj:` lines at ~30 ms):** gravity **3200 px/s²** (median; middle half 3154..3239); horizontal **720 px/s** held all the way (holding forward); rise **205 px** every time, so the launch is ~1145 px/s up (92% of the scripted 1247; why is unknown). Climbing a wall (1-c, x 5344): ~358 px/s up (scripted `wallspeed` 3.5 MPS = 336), then sliding down ~230 px/s.
- **Swing-point catches, measured (2026-09-26, B5 run: 27 catches in 1-a and 1-c):** hanging, Shank swings on a circle of **~178 px** around the point (he snaps on at (115 ahead, 137 below)). Approaching from below and behind, the catch comes about a frame after the point enters the scripted grab spot (2 tiles ahead, 3 up, radius 1 tile). But wall jumps in 1-c also caught it with the point level with or slightly below him, ~180 px to the side, while falling at ~1400-1550 px/s. Model since B5b: catch if within the grab spot **or within 190 px of him**, **only while falling slower than 1600 px/s** (the user: climbing too high in 1-c means a miss).
- **Wall jump and swing release, measured (2026-09-26, B5c log, 1-c):** the wall jump that caught the first swing point went ~600 px/s across with a 203 px rise (~1140 up; scripted 548 / 1175). Letting go of a swing point (`poleswing_jump`, Jump(45°, 17 MPS) = 1632 px/s): ~1100-1240 across and ~1100 up just after release, launched ~0.2 s after the press (the swing carries on for the AtTime 6 frames).
- **Climbing a pole (2026-09-26, B5c/B5d logs):** Shank's x is the pole's x ± 80 (PoleClimbOffset 1.25 tiles): 2849.9 / 3009.9 on 1-c's pole at 2929.9, which runs y 1481-3557. The pole jump (`shimmy_pole_jump`, poleclimb.lua) is Jump(WALL_JUMP_ANGLE, WALL_JUMP_SPEED), the wall jump. In B5b he dropped from the pole top (x 2849.9) left into the wall-climb zone at x 1478-2546.
- **Swing points grab in passing (confirmed 2026-09-29, the B27 log, 4-c 03:15:43):** letting go of swing point f6 toward pole p20 (20 tiles left), Shank caught swing point f7 on the way (49912, 2774); the jump model had modelled each target alone (f6 → the pole looked reachable). B27-5: jump_model::SetInterceptors (the level's swing points; the one he launches from, within 300 px, excluded) ends a flight at the first one it would grab.
- **Sliding on a steep slippery slope (confirmed 2026-09-29, 4-c s18, 45°):** he moves ~880 px/s down it (vy ~-880), which the cue thread's "on the ground" test (|vy| < 150) had read as in the air, so no slide-jump targets were judged; a slide jump near its low end caught swing point f0 (38080, 1216).
- **4-a "Rocketlauncher vs shimmy" (2026-09-29):** the way on is the swing points f7 (35716, 6110) and f8 (36554, 6202) over the 26-tile gap after s30 (x 35456), then the one-way platforms s34-s39. s33 (y 6720) passes 205 px above the checkpoint's trigger box (x 42177-42377, y 5435-6515) and had counted as reaching it.
- **Wall-run zone near its bottom edge (confirmed 2026-09-28, the Priest session, mark 1):** walking off 3-c's s43 (end x 70912, y 7552) at running speed crosses zone f10 (x 71020-72206, y 7578-7960) ~20 px under its bottom: he fell to his death; a long jump from the same floor entered ~250 px higher and ran. The model had counted entries down to 32 px under the bottom; since B24 only 32 px inside (above the bottom) counts, and the path there is the long jump. Walking off itself can start a wall run (`fall`, `rundrop` carry `canstartwallrun`).
- **Wall-run zone entry (2026-09-26, B5b vs B5c, 1-c's zone x 1478-2546, y 2939-3343):** two near-identical jumps off the pole top (peak ~3670, entering the box at ~(2530, 3190) falling ~1900 px/s): in B5b he latched near the zone's bottom (y ~2957) and ran left along the wall, descending gently; in B5c he fell straight through. The trajectories match to the frame, so the difference is probably input (unknown which). The box is where the wall run can start.
- **1-c's pole and pillar (2026-09-26, B5d log):** jumping right from the pole's right side at the top (3009.9, 3557), Shank peaks at x ~3125, bounces off the narrow pillar (walls x 3200/3264, y 1856-3840, `noclimb`) and comes back onto the same pole's **left** side (2849.9); from there the jump left reaches the wall-run zone. The user described this as jumping "from the poll to whatever I was on just before the wall run segment" (back and forth several times).
- **Superseded (B10b, below): ~~The pole jump is weaker than the wall jump~~ (2026-09-26, B5b/B5c logs, 1-c pole top at y 3553):** ~590 px/s across and a 120-131 px rise (~915 up), peaking ~3674; a wall-jump launch (203 px rise) would have hit the platform's underside at y 3840, which the real jump clears.
- **The pole jump is the wall jump, and it starts on the side it heads to (confirmed 2026-09-26, B10 log 21:53:24 and B5 logs 11:44:06, 12:26:11):** mid-pole jumps rise ~197 px at ~585 px/s across (vy ~1130). Jumping left from the right side, the game first moves him to the left side (x - 160: 21914.7 → 21754.7; 3009.9 → 2849.9) in the same frame, then jumps; `jumpFromWall` plays. The B5b pole-top jump had the same first steps (+35, +31, +27, +24 px per 31 ms) and then turned down (-14) at once: its head met the platform above (y 3840), a ceiling bump; after it he fell on at ~-450 px/s, still moving across.
- **Pit zones with `applytoplayer` false don't kill Shank (2026-09-26, B10b):** 2-b's pit at x 49560-51272, y 1372-1572 (`ondeathfall`, applytoplayer false) contains the "After Buildings" checkpoint trigger; 1-c has two more (x 22652.., x 10032..). geometry.py now writes only player pits.
- **1-c grinder slides (confirmed 2026-09-26, B10 log):** 6 of the 8 grinder deaths came off slippery surfaces; off surface 31's right end (x 20224, y 3648) he slid on to die at x 20532 in the pit starting at x 20245. An edge's fall carries him out several tiles; geometry.py checks for pits over that drift.
- **Jumping off a bar (2026-09-26, B5d log):** from 1-c's bar end (2601, 3996; the bar at y 4181) facing right: ~1140 px/s across, a 168 px rise (~1040 up); `shimmy_jump_out` = small hops then Jump(45°, 16 MPS) at 7.5 frames. That jump flew over the platform (x 2624-3328 at y 3904) and fell short of the wall-run zone at x 3500: the fatal jump.
- **Swing catches need the point level or above (2026-09-26, B5d log):** releasing swing point 2 toward swing point 1 passed ~163-170 px from it but ~150-180 px *above* it, and never caught it (three tries).
- **Base gravity not found statically (2026-09-26):** `mGravityMult` is +0xc of the physics settings (reflection at 0x511fab; the attribute parser at 0x5197e9), but a scan for multiplies of a `+0xc` operand next to a float constant found nothing gravity-like. Calibrate from logged jump arcs instead (B5 trajectory logger).
- `attributes/characters/shank.lua`: GravityMultiplier 3.5 (the base gravity is in the engine: not found statically; **measured 3200 px/s² in total**, see above; 9.8 m/s² would give 3293 px/s² and a 4.5-tile standing jump), AirControlSpeed 4 MPS (384 px/s), Radius 0.5 tile, CollisionHeight 2.5 tiles, LedgeHangDist 2.5 tiles, ShimmyOffset (0, 3 tiles), PoleClimbOffset (1.25 tiles, 0), **PoleGrabOffset (2 tiles, 3 tiles), PoleGrabRadius 1 tile** (a swing point is caught within 1 tile of a spot 2 tiles ahead of and 3 above Shank's position).

## The movement corpus (B42-1, measured 2026-10-01: `tools/movements.py` over the 36 collected sessions with `traj:` lines)
Every launch fitted in game time (the time scale from each arc's curvature; clean = normal game speed, no warp, 200+
ms, 6+ samples; "across" from flights he didn't steer). Medians, with the 10%-90% range; regenerate with
`movements.py` (build/movements/summary.txt). **Measured; applied to the model in B42b (2026-10-01): the wall / pole / run-up jumps, the ledge-hang
wall jump, the swing catch's fall limit (2000); the rest not applied** (the user picks):
- **Gravity** (real time, 1454 flights of 350+ ms): 3261 (3035..3485). The model's 3200 holds.
- **Long jump** (n 349): 1114 up (model 1145), 712 across (720). **Standing jump** (n 155): 1129 up (model 1270, never
  measured before). **Jump off a slope** (n 109): 1104 up, 711 across.
- **Wall jump, pole jump and the jump while running up a wall all launch the same:** ~1045 up, ~541 across unsteered
  (wall n 229, pole n 146, run-up n 9). Model: wall 1140 up, 450..700 across; pole 1140 / 500..650; **run-up 1410 up,
  550..715 across** (the B6-5 scripted guess: ~35% too strong). The run-up jump counts only while he's still moving up
  faster than 450 px/s; most jumps "during" a run up come after it slows (the wallClimb sound, ~360 px/s).
- **About one wall jump in five leaves the wall already falling** (49 of 225: launch vy -350..-880, median -620, across
  ~540 as usual). **Where (measured 2026-10-01, B42b):** hanging 120..200 px under the wall's top (the wall's pieces
  stacked at the same x joined): 49 of 56 jumps there fell, every one lower down rose (0 of 173). That's the ledge hang
  (LedgeHangDist 2.5 tiles = 160); why the game's ledge states (onwall.lua: ON_LEDGE_TRANSITIONS, Jump = climbwallledge)
  send him down and away is not worked out (hypothesis). (B41e's "post-peak wall jump" at 2838 was one: w108's top 3008.)
  Modelled since B42b (kLedgeJumpVy -620).
- **Bar jump** (n 80): ~912 up (model 1040), ~1069 across (1140); its parabola at the press sits ~25 px above the hang
  (model pull-up 51; a rough measure: the lift happens before the flight). **Swing release** (n 4 clean): ~1030 up, ~1146
  across (model 1100 / 1240). **Wall-run jump** (sound jumpFromAir, n 25): 946 up (model 940), 1009 across (940).
- **Sliding off a slope's end** (n 12): 860 across (822..881); model 700..860. **Running off a wall run's end** (n 53):
  762 across (705..855; no model). **Walking off a floor's end:** only 5 clean flights (most walk-offs start in a
  tracker gap); not measured yet.
- **Calibration jumps (2026-10-01, the user in 1-a, the B44b log):** the standing jump with Jump held fully rises ~231-252
  px (vy ~1220-1270: the model's 1270 holds; the corpus's 1129 median mixed in short presses, which cap the rise:
  JUMP_HEIGHT_TRANSITIONS); the long jump ~710-714 across, ~1090-1130 up (rise ~186-200) both ways. Down + Jump on the floor
  does jump (the user; the five presses in the log had no traj samples: untracked, not "no jump").
- **Walking off a floor's end, recovered from mid-fall (2026-10-02, a one-off analysis; hypothesis, small sample):** the
  tracker usually picks him up already falling; fitting the fall's parabola (g 3200) back to where his vertical speed was
  0 puts him at a floor's end, ~0.27 s earlier (median). Built into tools/movements.py (B45-1, 2026-10-02): 11 recovered;
  with the direct ones, 8 clean walk-offs off flat floors crossed at 318..567 px/s (median 378: two groups, ~320-380 and
  ~567); slide-offs (any fall starting on a slope) 829..891 (median 862). The model: walk-off 384..720 (kWalkOffMinVx /
  MaxVx), slide-off 700..860. Raising the slide-off loses real moves. **But his run speeds (constants.lua: TOP_RUN_SPEED
  8 MPS = 768; START_RUN 0.25x, RUN_SPEED 0.75x = 576, SPRINT_SPEED 1x = 768; WALK_SPEED 2 MPS) and his footsteps (1,505
  step pairs, the last 25 sessions: ~550-600 px/s 363 times, ~700-800 1,088 times) say most running is a sprint (~750):
  the clean walk-offs (318..567) are the slow ones the tracker happened to catch.** The ~380 ones left 0.1-0.4 s after
  a landing (the jump's air-control drift, 384); the ~567 after steps (a run). No jump sound near any of them (checked
  2026-10-02, the user's question); slide-offs (~860) likewise, so they're plain slides off the end. Not dodge rolls (the
  user asked): counting only steady runs (4+ steps in a row, same height, one way) with no dekeBehind / landRoll / skidStop /
  blockEnter within 0.6 s (9 pairs left out), still ~840 step pairs at 700-800 px/s vs 159 at 550-600: the sprint.
- **Letting go (confirmed 2026-10-01, B44d, the Lua + the user's death in 2-b):** `walldrop` (onwall.lua: Jump(180°, 1 MPS),
  air control from 3 frames), `shimmy_fall` (shimmy.lua: Jump(0, 1 MPS), tagged aircontrol) and `poleswing_fall`
  (poleswing.lua: Jump(0°, 1 MPS)) push him ~96 px/s at most; after that only air control (384 px/s) moves him sideways.
  The jump up off a bar with Up only goes straight up (2-b, x unchanged); with no input the bar's jump is shimmy_jump_out
  (forward).
- **Our Lua counters belong to the Shank entity (B44f, 2026-10-01):** after a death the new Shank's counters start at 0, so a
  key held at the death never gets its "released" report (Up stayed held in the DLL); the DLL clears what's held at his
  death voice and at a respawn jump.
- **What a catch needs (B44g, measured 2026-10-01 from the corpus and movement_check's false catches):** a wall-run zone
  latches only well inside its ends (real latches 52+ px from the nearer end, 90%; flights within 32 px of an end fell
  through, e.g. the B44b long jump into 1-c's f18 6 px inside its left end, ~70 above its bottom) and not in a very fast
  fall; a pole is caught only along its length (all 226 real pole catches: his position between its bottom and 26+ px
  under its top, within ~118 px across); flights ~50 px over a pole's top or under its bottom went on.
- **The swing jump goes his facing way (confirmed 2026-10-02, poleswing.lua):** `poleswing_jump` is Jump(45°, 17 MPS) in his
  facing; holding back on a swing point turns him (`polehang_turn`, Toggle("facing"), from ON_POLE_TRANSITIONS on
  CONTROL_BACK). With B42c (one release spot whenever he presses) only the facing matters, not the timing.
- **The air warp also carries him onto a swing point and into a climbable wall (confirmed 2026-10-02, B47 sessions 1-2, the
  user: "successfully walked into swing point without jumping"):** running off a floor's end (over deadly drops) he rises
  ~50-150 px and goes ~1100 px/s across onto a swing point ahead and above, no jump sound: 1-c s39 -> (24192, 1600), 384
  across / 320 up; 4-a s30 -> (35716, 6110), 260 / 286; 4-a s49 -> (50276, 10040), 356 / 227. Not the grab rule
  (PoleGrabOffset 2 tiles ahead and 3 up, radius 1 tile: a plain fall only catches points below that spot, as the corpus's
  walk-off catches all were). And off 4-a s58's end (70720, 6464) into the climbable wall at 70848 (bottom 6528): runUpWall
  at (70814, 6513), no drop. The limits are the engine's (mAirWarp*); the graph allows what was seen with a margin.
- **No dropping through a one-way floor (confirmed 2026-10-02, 1-b train mark 7):** Down + Jump on a skinny floor is a plain
  jump (three tries at (31104, 1696), each landing back on it); no stategraph transition for it. (B11-3 assumed it.)
- **A slide pole in the way catches him (confirmed 2026-10-02, the villa, 2 deaths + marks 2-3):** a bar jump from (41722,
  ~1800) caught slide pole p16 (x 42241, 1366..2645) at ~2000, coming down, and slid him off its bottom; a swing release in
  1-c crossed the slide pole at 14012 rising, ~210 under its top, and went on to the wall 132 px behind it (session 1).
- **The air warp onto a swing point needs speed (confirmed 2026-10-02, all collected logs, B48b; the user: "reachable without
  jumping from sprints, but not from walks"):** no-jump catches off floor ends at 556..769 px/s (a run, 576, to a sprint, 768),
  up to 476 across and 366 up; slow walk-offs (~400, just started moving) off 1-a s36 fell. Off a wall run's end too (1-a f6
  -> f3, 422 across, 212 above the zone's bottom, mark 1); a timed jump works there as well (the user).
- **A ceiling at a climbable wall's top cuts the wall jump (confirmed 2026-10-02, B47 session 2, 4-a w120):** from 8877 the
  jump rose only ~50 px (head against the ceiling x 42496..42560, y 9088, 158 px above his position) and fell at once
  (~-600 px/s), coming down at the upper line's very end (x 42655 vs the end 42654) and past it; from 8742..8851 (older
  logs) he caught the line. Shimmy catches (93 in the corpus) all came falling (vy -512..-3638 at the catch).
- **The wall jump near a wall's top leaves falling (confirmed again 2026-10-02, 4-a w14, top 2624):** jumps from 2429..2468
  (156..195 below the top) left at vy -500..-720 and landed on the floor below; the B42b ledge band (120..200) holds.
- **A slide pole is caught low and only slid down (confirmed 2026-10-02, B47 session 3, 3-c p20, 7 deaths):** sliding off
  s28's end (55056, 3808) he caught slide pole p20 (x 55456, 3325..5007) at ~3570 (x fixed at 55376 from there) and slid
  down at ~400-600 px/s to its bottom and off into the pit (y ~3300, then falling); nothing above the catch is reachable.
- **Rockets (3-c, B47 session 3):** 640 RocketLauncher_Explode and 90 RocketLauncher_Gibs in 33 minutes; a direct hit plays
  Gibs at his position (not Explode); 9 of 24 deaths. One dived from up-right at ~1150 px/s ((51620, 5780) -> (51061, 5200)
  in 0.7 s) onto him blocking SWAT goons.
- **A cinematic's move reads as a respawn jump (confirmed 2026-10-02, B47 session 3, 3-c's start):** no position during the
  cinematic, then a far one: WaypointUpdate's `jumped` (kRespawnJumpPx); it used to clear the story goals reached.
- **A wall run ends when forward is released (confirmed 2026-10-02, B47 session 2, 4-a f17):** fwd_off at 77893 mid-run and
  he dropped off ~1500 px before the zone's end (wallrun.lua: `wallrun` only while holding forward).
- **A jump just after running off an edge (hypothesis, 2026-10-02, B47 session 1; superseded 2026-10-02 by the air warp
  onto swing points above):** `rundrop` (running.lua) has
  TimeTag("canjump", 0, 9 frames) and Transition("jumplong", ... ControlHasBeenPressed(CONTROL_JUMP)): the long jump works for
  ~0.15 s after he leaves the edge. Session 1 at 1-c s39's right end (23808, 1280): he rose ~150 px at ~1000 px/s just past
  the edge and caught the swing point (24192, 1600), the user calling it a walk-off; no jumpFromGround was logged.
- **The arena boundary after Enter Packing Warehouse (confirmed 2026-10-02, the session 1 log):** the fight's bounds (x
  5840..7074) and then the next section's (x 5834..13221) start at the spawn: no going back left; the edge cue marks it as a
  wall (bounds).
- **Swing releases (confirmed 2026-10-01, B42c, 341 releases):** the `poleSwing` sound plays as he passes the bottom of
  the swing (2 px ahead, 172 below the point), and the flight starts ~176 ms later (140..200) from one spot: **~74 px
  ahead of the point (the way he faces) and ~70 below it**, at ~1043 up and ~1135 across (10%-90%: 970..1146),
  wherever he pressed. The jump up (holding up) leaves from the bottom, rises ~390 px (~1580 up) and falls back onto the
  same point (the B42b session, 1-c's second street point). Modelled since B42c.
- **Swing-point catches** (n 199): ~180 px from the point (model disc 190) while falling at up to ~2000 px/s (median 1077,
  90% 2023); the model's 1600 px/s limit missed real catches; **B42b: 2000** (movement_check: 2000 / 2200 / 2400 / 2800
  gained 37 / 43 / 45 / 47 real moves, lost 8 / 10 / 10 / 10). **The point is above him:** 280 of 289 catches had it
  80+ px above his position (B42c: kSwingCatchAbovePx; the old rule allowed it up to 40 below, which let the release
  from 1-c's second street point catch the first as it fell past it, ~175 px over it at the crossing).
- **Wall-run latches** (n 157): ~88 px inside the nearer end, ~290 above the bottom, falling at up to ~2170 px/s.
  **Pole catches** (n 146): 80 px aside (the hang offset).
- **Ledge grabs** (n 48; the labelling is rough): the ledge was at most ~136 px above his position when rising and ~216
  when falling at the grab; model 208 rising / 160 falling (B41-4 / B41c). Unclear: re-check with more grabs.
- **Runs up walls** (n 682): ~809 px/s over the first 250 ms (model "running up" > 450); from the floor, sliding back,
  the highest point varied 326..1053 (median 564; model's top 1088). **Wall runs:** ~734 px/s. **Shimmying:** ~286 px/s.
  **Slope slides:** ~780 px/s along (model 1248; includes the slow motion near some ends: unclear).
- **The sounds** (Shank/Character/... events, shared with goons: his are the ones at his position): jumpFromGround (ground
  and slope jumps), jumpFromWall (wall, pole, run-up jumps), jumpFromAir (the wall-run jump; also hops), poleSwing (the
  swing release and the bar jump; also plays while swinging), runUpWall (each stride up a wall, ~285 ms), wallClimb
  (climbing / sliding on a wall), wallAttach (catching a wall, pole or bar), shimmy, Movement_WallRunStep, land /
  landRoll, ledgeClimb (a ledge grab, and the vault at a run's top), skidStop, step. A swing point's catch has no sound.

## Shank's traversal launches (B6-1, 2026-09-26; `tools/re/shank_moves.py` lists every state with a Jump())
- **Hazard props (B6-7, confirmed 2026-09-26 from the level JSON and prop/stategraph Lua):** `meatgrinder` does nothing itself (idle loop, a `meatgrinder_running` sound event); every grinder in 1-c lies inside a fatal `pit` zone, and 1-b's grinder deaths are pit zones with `killevent` `ondeathmeatgrinder`. `firetrap` (2, 3-c "Priest Boss Fight") spawns fire damage regions (192×128 knockback bursts; a 150×250 region for 70 frames), damage not death. `train_meat` is Fixed, not invincible (carcasses on 1-b's train). 7 floor pieces lie inside pit zones (1-c 4, 2-c, 3-c, 4-a one each).
- **Modelled (B6-5, hypothesis: scripted values × 0.92, not measured):** jump up 1500 px/s up with ±250 steer; runtowalljump 550–715 across, 1410 up; wallrunjump 700–940 across, 940 up (lands ~550 px ahead at the same height). **Measured 2026-10-01 (B42 corpus, above):** the wall-run jump holds (946 up, 1009 across); the run-up jump doesn't: it launches like the wall jump (~1045 up, ~541 across; n 9 while still running up). Applied in B42b (the run-up jump = the wall jump's numbers).
Speeds in MPS (96 px/s); JUMP_SPEED 12.5, WALL_JUMP_SPEED 13.5, WALL_JUMP_ANGLE 65°. "Measured" = from `traj:` logs (launches come out ~92% of scripted vertically where measured).
- **Ground:** `jump` 90° × JUMP_SPEED·1.15 (standing); `jumplong` 60° × 1.2 (holding forward; measured 720 across, 205 px rise); `hop`/`hop2`/`hop3` automatic over walls ≤ 1/2/3 tiles (90° 10/13/15 then 45° 7); `platformup` in the air touching a one-way platform + Jump: 90° 14 (up through it); `dbl_jump` needs a co-op partner (`doublejumpassist`): not single player.
- **Walls:** `runtowall` (running into a wall: runs up at 10 then 6 MPS; `wallclimb` at 3.5 while holding up/forward, else `wallslide`); `walljump` 65° 13.5 away (measured ~600 across, 1140 up); `runtowalljump` (jump early in `runtowall`) 65° 13.5·1.25 = 16.9, facing toggled; `wallbounce` 65° 13.5 at 0.15 s (hitting a wall in the air: the 1-c pillar bounce); `walldrop` (down + jump); at the top: `vaultwallledge` (95° 13 then 30° 7) when `wallhasledgeattop` and < 1.5 tiles from the top; `mountledge`, `climbwallledge` (95° 15 then 30° 7) from a ledge hang; `ledge_low_jump` 90° 16.
- **Slide poles in play (2026-09-26, B8 live log, 2-b x 14779, y 1397..4290):** jumping onto one from the ledge by its top, Shank catches it (80 px aside) and slides down at once; it can't be climbed.
- **Poles:** climbing (PoleClimbOffset 80 px aside); `shimmy_pole_jump` = the wall jump (65° 13.5) away from the pole; `pole_slide_*` slide down at 2 / 8 / 14 MPS (slow with up, fast with down) on `slide` poles.
- **Swing points:** `poleswing_jump` / `polehang_jump` 45° 17 (measured 1100-1240 across, ~1100 up); `poleswing_jump_up` 90° 17 (holding up); `poleswing_fall` (down).
- **Bars/ropes (shimmy):** `shimmy_jump_out` hops then 45° 16 at 7.5 frames (measured ~1140 across, ~1040 up); `shimmy_jump_up` 90° 17 (holding up); `shimmy_fall` (down).
- **Wall runs (wallrun.lua):** `OnStartWallRun` (engine) → `startwallrun` (−10°, 5 MPS) → `wallrun` level at 8 MPS (768 px/s) while holding forward; `OnLeaveWallRun` (leaving the zone) → `wallruntofall` (7 frames in which Jump gives `jumplong`) → `wallrunfall`. Jump during the run: `wallrunjump` 45° × JUMP_SPEED·1.2 (1440). States tagged `canstartwallrun` (jump, jumplong, walljump, pole jump, bar jumps, slide falls...) can start one.
- **Slides (sliding.lua):** landing on `slipperyLeft/Right` ground → `slide` at 13 MPS (1248 px/s) down the slope, facing set by the slope; running off the end → `slide_fall` (Jump then gives `jumplong`).

## Cutscene skip prompt (static RE 2026-09-27, B15-1)
- `SkipCinematicDialog` (RTTI `.?AVSkipCinematicDialog@@`): constructor 0x784560 builds a small screen-handle object (base 0x54cac0, vtable 0x844ad0, then 0x83870c) that opens `skipcinematic.gfx` through 0x54ce60. **That object is not the SwfScreen:** every screen seen in SwfScreen::Update has vtable 0x845088 (confirmed 2026-09-27, override log: 45 screens), so the B15-1 vtable check never matched. The SWF has no text fields or named widgets; its text is drawn: "ESC" "to Pause", "Space" "to Skip". **Recognised by its movie's `_url`** instead (confirmed 2026-09-27: `menu: screen shown (movie ...) is skipcinematic.gfx` twice in the override log).

## Tutorial pop-ups and "point of interest" (2026-09-27, B15-3)
- **pointOfInterest plays whenever a buttonless UI screen opens during play** (confirmed from the B13b log: every `pointOfInterest` sound has a `ui screen ... shown` in the same ms, e.g. 1-a 06:42:00 / 06:42:10 before the wall run). Those screens are the level's `tutorial` actions (level JSON `tutorials`: movieclip, helptext, index, track, show), e.g. tutorialwallrun.gfx, tutorialclimb.gfx, tutorialmovement.gfx, tutorialbasicattacks.gfx; the game pauses briefly. Their text is drawn (DefineText) with the button as an icon: "jump and hold forward to wall run" + "Wall Run"; "just hold [icon] to climb a wall". tutorialhint.gfx writes its text to `_level0.tutorial.help.helpText.text`.
- The mod names a screen's SWF from `_level0._url` (**confirmed 2026-09-27**, override log: tutorialbasicattacks.gfx, tutorialchangecontrols.gfx, skipcinematic.gfx). 1-a opens two tutorials in the same ms.
- 1-b pre-train's "highlighted explosives" (mark 6): no action for it in the level script (only spawnprop explosive_barrel / propane_tank, genevent ambience, PushPositionalCamera arena framing) and nothing in the props' stategraphs (idle / explode): probably drawn in the props' animation (hypothesis).
- Grenade reports (hz_grenade) do follow the flight every 0.1 s (B13b log 07:03:09); the warning only started within 500 px (the cause of mark 7).

## CompoundTransition actions and the carried weapons (confirmed 2026-09-27, B15-4)
- **A CompoundTransition runs its own actions whenever any child transition fires, NullTransitions included.** Carrying the minigun / flamethrower, `MINIGUN_REACTIONS` / `FLAMETHROWER_REACTIONS` wrap `CatTables(REACTIONS, ...)` in `CompoundTransition(nil, { DROP_MINIGUN }, ...)`; DROP_MINIGUN = `SpawnGameObject props/itemminigun` (a pickup). Our position ping (a NullTransition in REACTIONS, every 0.5 s) therefore spawned a new minigun pickup every ping while carrying (B13b log: minigun beacons multiplying along his path from 06:56:36, up to 30 reports a second; the user picked one up again). Fix: those two lists use `A11Y_NoPing(REACTIONS)` and carry the ping beside the wrapper. No other action-bearing compound wraps a list with our ping (grep of stategraphs/shank).
- The game's own anti-fall rule (a NullTransition in REACTIONS) is inside the same wrapper: at a noFall edge while carrying, vanilla spawns minigun copies too; safe edges (E) makes that rule fire at every guarded edge (open risk, PLAN).

## Narrow gaps: the air warp (2026-09-27, B15-6)
- **B28b (confirmed 2026-09-29, the B28 log, 2-c x 68736 → 68992, 21:05:09):** it also carries him to a floor **3 tiles higher** 4 tiles across: steps, then `ledgeClimb` at (68960, 2656) and `landRoll` at (69096, 2848), no input (the user). geometry.py's gap rule now allows up to 3 tiles up.
- Running off an edge with a floor close across, the engine carries Shank over without a jump (B13b log, 1-b train x 2432 → 2624, a 192 px gap between cars at the same height: y 1057 → 1075 → 1057 over 0.28 s, both ways; no collision bridges it). Shank.exe has `mAirWarpTarget`, `mAirWarpOffset`, `mAirWarpDuration`, `mAirWarpTargetDeadline`, `mAirWarpValid`; running.lua's rundrop only allows a late jump with `CheckBool("airwarping", false)`. The limits (width, height) are the engine's; geometry.py assumes up to 4 tiles across and 1 tile up or down (hypothesis).

## 1-b train, mark 9 (2026-09-27, B15-7)
- The path sent Shank from the climbable wall w27 (x 30592, y 832..1600) up into the one-way floor s29 (y 1664) by the platformup jump; the graph found that only from the top 32 px of the wall (the one sample at y 1568), and in the game it didn't work for the user. What worked (B13b log 07:25:31-51): a wall jump left onto s28 (y 1152), walk left, up to s25, a long jump right onto s29, then across the gap to s31. Cause in the graph: from the wall, the plain wall jump's Fly already tried the platformup pass before the running-up wall jump was tried, and one move per (from, to) is kept. Fixed: all plain launches first, platformup only when none reaches; a platformup that works from one sampled spot costs 3 jumps in the path.

## Moves the game does for him (2026-09-27, B15-10; the user: "several times where pathing told me to long jump to something but Shank handled it by pulling himself up, hopping down, etc.")
- **Running into a climbable wall with a ledge on top:** runUpWall, then (climbing, holding forward or up, `wallhasledgeattop` and within 1.5 tiles of the top) `vaultwallledge`: ledgeClimb onto the ledge, no jump (B13b log: 1-a x 7712, a 4-tile wall; 1-b train x 6944, 4 tiles; both said "long jump ... 4 tiles up"). The graph had run_up_wall + climb_over (0.5 + 0.5) tie with the jump; now one on-foot move `climb_up`.
- **Walking off an edge** onto a lower floor needs no jump; the graph found the long jump first (ground origins before walk-off origins) and kept it. walk_off / slide_off are now on-foot moves and replace jumps between the same floors.
- Also automatic (already modelled): hop / hop2 / hop3 up walls of 1 / 2 / 3 tiles when running into them (`climb`), the air warp over narrow gaps (`run_across`, B15-6), ledge grabs in the air (B11-2). `hopupjump` (running at a 2-3 tile ledge 1-2 tiles away: an automatic 60 degree jump) is covered by `climb` when the ledge is at the floor's end (hypothesis: not for ledges 1-2 tiles beyond a gap).

## File system search order and Steam's file check (static RE 2026-09-27)
- The game reads its data through **PhysFS** (PHYSFS_* strings in Shank.exe). At 0x41d062 it mounts `../data`, then `../data-pc`, each with 0x5701d0(dir, mount point 0x8380a8, 0): PHYSFS_mount's appendToPath = 0 = **prepend**, so `data-pc` is searched **before** `data` (**confirmed 2026-09-27** by the data-pc deploy check: every patched script was read from data-pc; also consistent with the 4 files present in both folders, all ui/*.dds, whose data-pc copies differ). Texture zips (`../data/textures/*.zip`) are mounted after.
- So a patched copy placed at `data-pc/<same path>` overrides `data/<path>` without changing any of the game's own files. deploy.py does this since 2026-09-27. **Confirmed 2026-09-27** (override log `build/logs/20260927-083436-override`: 267 pickup beacons, 46 enemy reports, pickup messages and Q's moves, all from the data-pc copies; the game's data/ files vanilla).
- Steam's "Verify integrity of game files" and updates only compare and restore the files in the game's depot manifest; they don't delete extra files. Our 10 added files (bin/dinput8.dll, our DLLs, ini, data txt files) are extra; our 23 patched Lua files under data/ are depot files and would be reverted to vanilla. Shank has no Steam Workshop, and Steam has no other mod registration.
- The Madness difficulty ("Charles Norris", IDS_DIFFICULTY_MADNESS) has no button on PC: difficultymenuscreen.gfx has only normalBtn and hardBtn (descriptions "Play the Game, Enjoy the story" / "Tougher Enemies and no checkpoints!"). campaigns.lua: finishing 4-c grants unlock 1 on difficulty 2 and unlock 2 on difficulty 3 ("Complete Single Player Campaign on Hard Mode", the Wildman outfit).

## Speech engines: Tolk and SAPI (2026-09-27, investigation)
- **Tolk** (third_party/tolk/src): API = Load, IsLoaded, Unload, TrySAPI, PreferSAPI, DetectScreenReader, HasSpeech, HasBraille, Output, Speak, Braille, IsSpeaking, Silence. No voice, rate or volume. `Tolk_DetectScreenReader` runs on every Output: with TrySAPI on, PreferSAPI chooses SAPI or the running screen reader, so switching per message works. Its SAPI driver is a plain `CoCreateInstance(CLSID_SpVoice)` with `SPF_ASYNC | SPF_IS_NOT_XML` (+ `SPF_PURGEBEFORESPEAK` to interrupt), the default voice and rate.
- **SAPI voices a 32-bit program sees on the user's machine** (HKLM\SOFTWARE\WOW6432Node\Microsoft\Speech\Voices\Tokens, 2026-09-27): Blastbay Libby, Blastbay Richard, DECtalk Betty / Dennis / Frank / Harry / Kit / Paul / Rita / Ursula / Wendy, IVONA 2 Kendra, Microsoft David Desktop, Microsoft Zira Desktop. The OneCore voices (Microsoft David, Mark, Zira under Speech_OneCore) aren't classic SAPI voices. **Correction (confirmed 2026-09-27, B16-1 settings_test and a 32-bit SAPI.SpVoice.GetVoices()):** SAPI's voice category lists **31** voices for a 32-bit program: those 14 plus 17 "Microsoft ... Online (Natural) - English (United States)" voices (Ana, Andrew, AndrewMultilingual, Aria, Ava, AvaMultilingual, Brian, BrianMultilingual, Christopher, Emma, EmmaMultilingual, Eric, Guy, Jenny, Michelle, Roger, Steffan), provided by a token enumerator rather than the registry keys (hypothesis: a natural-voice SAPI adapter; they need the internet).

## Focus loss
- **Pausing (static RE 2026-09-30, B38-2; partly hypothesis):** the window procedure is 0x44b9f0 (RegisterClassA at 0x44dae0 stores it at [0xadfa38]); WM_ACTIVATEAPP (0x1c) posts two game events with (wParam == 0), i.e. true when deactivated: 0x22 and 0x47 (event object built by 0x4068a0(this, id, value), destroyed by 0x4075f0, posted by 0x40adf0 on [0x796690()] + 0x44). 0x51f340 is a setter that stores a byte at this+0xad and posts 0x22; the handler 0x51f1f0 stores event 0x22's value at [0x406aa0()] + 0x3c. The debug Lua `TogglePause` (0x781210) posts event 0x3f (built by 0x40e0b0, sent through 0x407b40() and 0x51f1d0), then 0x64 with a Lua argument. The handlers that actually stop the simulation / open the pause dialog weren't found (a byte search for `cmp , 0x3f` found only unrelated switches). **The focus-loss pause opens the game's pause menu** (confirmed 2026-09-30 from the B29 / B30 logs: every F2 mark was followed ~1.6 s later by `pausedialog.gfx` shown). B38-2 therefore pauses with a focused window of ours (the user's fallback).
- **The game pauses when its window loses the focus** (confirmed 2026-09-27 by the user, from play). It runs fullscreen (`ResetWindowSize(FullScreen)` in game.log; `cbFullscreen` selected), so another window taking the focus (the F2 mark window) minimises it until it gets the focus back.

## Gunmen aiming (static RE 2026-09-26, B13-4)
- Only the medium gun goons tag their aiming states: `attacks_gun.lua` (pistol: gun_idle, gun_up_idle, gun_up_extreme_idle, gun_down_idle, gun_down_extreme_idle; tags "branch aiming ...") and `attacks_ak47.lua` (gun_idle, gun_idle_up, gun_idle_down; "aiming branch"), 34-42 frames each. Other guns go through a `_pre` state before the shot: girl `attacks_uzi.lua` shoot_pre (untagged), large `minigun_pre` / `minigun_up_pre` / `minigun_down_pre` (rev-up), `grenadelauncher_shoot_pre`, shield shotgun `open_shoot_pre` (+ up / down), fat biker `shoot_pre` / `shotgun_atk_pre`, the priest's `shoot_up_pre`.
- loadtest50 entries for goons must be the `_1/_2/_3` variant files (they set SKILL_LEVEL before loading the stategraph); the plain `*_stategraph.lua` fails at med_TRANSITIONS.lua:23 in the harness (vanilla too).

## Mod settings in the game's menus (static RE 2026-09-26, B13-2)
- **Controls screen rebinding:** the screen object (`[ebp-0x2b0]` in the row builder 0x788d60..0x789ea0) keeps the row being rebound at +0x78 and a "waiting for input" flag at +0x7c; that row shows "-Select New Input-" (0x789db1). The rebind is native (Enter on a row sends no Flash callback: B1 log, only clearItems/addItem rebuilds). Rows = a fixed 16-action table (Move Left ... Next Weapon), so an injected 17th row would make the game rebind action 16: past its table (hypothesis: memory corruption). Not used.
- **Settings dialog:** its widgets are fixed in settingsdialog.gfx; new sliders/checkboxes would need SWF changes (Klei assets). Not used.
- **Keyboard input:** the game reads the keyboard only through raw input (`GetRawInputData`, loaded once at 0x52af8a); `GetAsyncKeyState` (0x52e6cf) is only asked for Shift/Ctrl/Alt (0x10/0x11/0x12) as Scaleform key modifiers. So hooking `GetRawInputData` hides keys from gameplay and menus alike; our own hotkeys poll GetAsyncKeyState and still see them.
- No achievements screen file exists (the main menu's Achievements probably opens Steam's overlay).

## Pathing audit B12 (static RE 2026-09-26: the Shank stategraphs and the level data)
- **Slippery slopes** (`sliding.lua`, events.lua 25-26): landing on a `slipperyLeft/Right` floor starts `slide` facing downhill; `SetGroundSpeed(13 MPS)` (1248 px/s), friction off; he can't stop, turn or walk uphill. SLIDING_TRANSITIONS: Jump = `slide_jump` (MultiplySpeed(0), then `jumplong`: the long jump, downhill); Gun = slide shoot. Off the low end: `slide_fall` (air control; `jumplong` still allowed for 5 frames), keeping the slide's speed (B10 log: ~1000 px/s off 1-c's surface 31). Down + Jump is not a drop-through on a slope. 3-c's surface 58 has both tags (a ridge; the artifact has no per-segment tags, so it stays a floor).
- **`platformup`** (inair.lua; IN_AIR_MOVEMENT_TRANSITIONS): in the air with `touchingoneway` (his body in a one-way platform), Jump → speed 0, then Jump(90°, 14 MPS = 1344 px/s) after 4 frames: a second jump up through the platform. `dbl_jump` needs a co-op partner (`doublejumpassist`): not for us.
- **Letting go of a pole:** POLE_CLIMB_TRANSITIONS and POLE_SLIDE_TRANSITIONS include ON_WALL_REACTIONS: Down + Jump = `walldrop`, Jump = `walljump` (the pole jump). At a pole's bottom he falls off (`ATBOTTOMOFVERTICALSHIMMY`).
- **Joined path pieces:** a `.slev` path can run pole → rope; `onverticalshimmy` switches pole climbing and shimmying as he moves along. Joined ends in the campaign: 1-c slide pole 28 ↔ bar 29 (at x 10551, y 2959), 3-c bars 17 ↔ 18, the villa's bars 18 ↔ 19.
- **Not traversal problems:** `barrier` props (21 in 1-c, 8 in 2-c: breakable, invincible, `burst` when any character is within a 200 × 100 probe; never block); `wallbounce` (onwall.lua) has no transition into it; ledges: `ledgeattach` → climb up (Up / Forward / Jump) or `walldrop` (Down); `OnAttachToLedgeHigh` while running/jumping → `landrunning` (auto mantle).
- **Closed 2026-09-27 (the user: "Played that level a few times and haven't noticed anything"); kept as a note:** 1-b's "Engine Car" wind zone (x 46664-47606, y 582-1726; `windspeed` 1920, angle π = leftward) isn't in the jump model; its effect on Shank is unmeasured. `teleports` (1-a 3, 1-c 1, 2-a 1, 2-b 4, 2-c 1, 3-c 3, the villa 6) are scripted moves (PlaceOnGround targets); all checkpoint legs have paths without them.

## Moves not modelled before B11 (static RE 2026-09-26)
- **Switching sides of a pole:** climbing a pole (`POLE_CLIMB_TRANSITIONS`, branch states), **holding forward** (toward the pole: he faces it while climbing) enters `pole_climb_switch` (poleclimb.lua): `Toggle("facing")`, anim `pole_slide_switch`, 22 frames, then `pole_climb_switch_wallslide` → `pole_climb_idle` on the other side. (Slide poles: `pole_slide_switch` too.) This answers the user's "wrong side of the pole".
- **Ledge grabs:** an engine event `OnAttachToLedge` (in the air, a ledge within reach; shank.lua `LedgeHangDist = 2.5 tiles`) → events.lua: `skinnyledgeattach` if `heightofwall` < 3 tiles (a skinny ledge, `platform_hang`), `ledge_low` if holding forward (then `ledge_low_jump` 90° 16 MPS with forward/up), else `ledgeattach` → `ledgehang` (loops). From a ledge (`ON_LEDGE_IDLE_TRANSITIONS`): up, forward or jump → `climbwallledge` (95° 15 then 30° 7: onto the top); down → `walldrop`. `OnAttachToLedgeHigh` → `ledgevaulthigh` (straight onto the top, then running). `mountledge` (onwall.lua; 100° 12 then 65° 7) climbs up from a wall.
- **Dropping through a one-way platform:** REACTIONS: Jump pressed with Down held and `ononewayplatform` → `fall` with `JumpDown()`.
- `platformup`: in the air touching a one-way platform, Jump → 90° 14 MPS up through it.
- Automatic: `hop`/`hop2`/`hop3` (walls ≤ 1/2/3 tiles), `hopupjump` (running at a 2-3 tile ledge wall 1-2 tiles away: 60°), `vaultwallledge`. `targetedjump` / `sword_leap` are grapple (combat) moves. `wallbounce` (hitting a wall in the air: 65° 13.5 away) is only modelled as the pole bounce.

## Tag conditions and the anti-fall rule (static RE 2026-09-26, B7-1)
- Stategraph conditions are Lua tables (`luahelpers/conditionutil.lua`): `GroundHasTag(t)` = `{type="hastag", source="ground", tag=t}`, `GroundLacksTag` adds `nott=true`; `HasTag` = source "state", `LastHitHasTag` = source "lasthit".
- They are parsed into `HasTag_ParseNode` (RTTI `.?AVHasTag_ParseNode@?A0x6da2068a@@`, vtable 0x8417d8): parse 0x4f91b0 stores the tag hash at node+0x20, `nott` (byte) at +0x24, the source hash at +0x28. **Evaluate 0x4f92c0** (thiscall(node, ctx), ret 4, returns 0/1 in eax): `ctx+4` = the owner object; calls its vfunc 1 (vtable+4) as (source hash, tag hash, bool* out), then returns `out != nott`.
- Names are hashed by 0x43d060: sdbm of the lowercased string (h × 0x1003f + c), the same hash as the `.slev` tags: "nofall" 0xb476217c, "ground" 0x919d2307 (computed; to confirm at run time).
- Segment tags live in a `TagSet` (vtable 0x837cac, RTTI `.?AVTagSet@@`): a vector of u32 hashes at +4 (element array pointer at +8), filled by 0x43ed30 from the `.slev`; 0x503e70 copies it into the world's segment. Adding a tag to a live segment would need an allocation inside the game (not attempted).
- **The anti-fall rule** (last in REACTIONS): `NullTransition(And(GroundHasTag("noFall"), CountdownExpired("noFallDelay"), CheckBool("facingedge")), {SetCountdown("noFallDelay", 6 FRAMES)})`; `Event("onfall", {Transition("backtoledge", CountdownExpired("noFallDelay", false))})` (events.lua); RUNNING_TRANSITIONS' `rundrop` also waits for the countdown. `backtoledge` (running.lua; Klei: "a major hack to prevent Shank from running off the side of a platform") = Jump(170°, 1 MPS), back on the ground at 4 frames, then the running transitions. Only Shank's stategraph uses `GroundHasTag("noFall")` (2 segments in the campaign carry the tag).
- **B7 plan:** hook Evaluate; when the node asks (ground, nofall) and our safe-edges guard is active, answer true. The game's own rule then stops him.

## Game items and the enemy list (static RE 2026-09-26, B8-1)
- **Mello (`boss_mello`) is a non-combatant** (confirmed 2026-09-30, data/stategraphs/goon/boss_mello/mello_states.lua: only idle, walk_start/loop/talk/stop, phone_start/loop/pause; no attack, hit or death state; the only goon stategraph without attacks). He is listed on a hostile team at 2-b's bar before the Denny fight and leaves the list without dying. **A simulation pointer can go stale after a checkpoint load with no bounds action** (4-a "Exit the level", hard2 log: +0x38 read "" afterwards; hypothesis: the load replaced the simulation).
- **The game's own closest-enemy filter** `sClosestEnemyCharacterEligibilityFunctor` (vtable 0x83d998; check = vfunc 1, 0x4cae90, (item, float* dist²) ret 8): the item's attributes type (via 0x4804e0) must be 0 or 1; `[item+0x64]` → if non-null its byte +0x24 must be 0 (hypothesis: dead / disabled); team (0x40e280 = `[item+0x24]`) must differ from the asker's; `[item+0x30]` (0x438ba0) must differ from the asker's; position = `[[item+0x5c]+0xc]` (x, y floats; 0x42c9e0 = `[item+0x5c]`, the physics component; 0x41c280 = component+0xc).
- **Item fields:** vtable at +0 (`cShankGameItem` 0x837e88, `cGameItem` 0x83b174; secondary vtables at +4 and +0x1c); `[+0x20]` = the simulation/world; team `+0x24`; `+0x30` an id; attributes: **`mCurrentAttributesHash` at +0x40** (reflection at 0x47e395 registers sub-object+0x24, the sub-object being item+0x1c); the attributes pointer cached at +0x50 (0x4804e0 looks the hash up in cAttributesManager, entries keyed by the hash at their +0x24, type at +4); physics component at +0x5c.
- **The item manager** `cGameItemManager` (primary vtable **0x83ae44**, secondary 0x83ae88 at +4) = `[[item+0x20]+8]`. **Its items: a vector of cGameItem pointers, first at manager+0x24, last at +0x28** (0x47a0f0 = find-best(functor): iterates `manager+0x20` with begin `[+4]`, end `[+8]`, 4-byte steps).
- Attribute files: `attributes/characters/%s.lua` (210 in the install; the level JSON's enemy `attributes` are their names, e.g. `med_thug_knifepistol`), props `attributes/props/%s.lua`. **(confirmed, next line)** the hash is sdbm of the lowercased name (like every other name hash, 0x43d060).
- **Confirmed in game (2026-09-26, B8 live log):** the scan finds the manager (4 candidates, one usable), `mCurrentAttributesHash` = sdbm of the lowercased character name (every goon named: med_thug_knife, med_thug_machette (sic), large_thug_grappler, med_thug_pistol, med_thug_knifepistol). The value at item+0x24 differs per enemy (38, 39, 53...): not a team number but it differs from Shank's, so "other team" still works. A checkpoint restart replaces the manager (the old vtable goes).
- Shank's gun from its arm sounds (B8b): `Shank/Character/armPistols`, `.../Attacks/Uzi/Uzi_Arm`, `.../Attacks/Shotgun/Shotgun_Arm`, `.../Attacks/GrenadeLauncher/GrenadeLauncher_Arm` (also `RocketLauncher_Arm`, not mapped).
- Plan (B8): find the manager by scanning memory for its vtable, then read every item each tick (SEH-guarded): team, hash → name → class, position.

## Boss openings and button prompts (static RE 2026-09-26, B9c)
- **Vulnerable states** are tagged `canbegrappled`: butcher `stunned`/`stunned_loop` (tags "stunned canbegrappled nocombo"), `hook_throw_stunned(_loop)`; toro `dazed_loop(_pre)`, `wall_hit_pre/_loop`, `shoulder_smash_loop` ("dazed idle canbegrappled"); swat `taser_stunned(_loop)`; bodyguard `bg_grapple_sword_bk/_loop`; gimp `cuddle`. The biker bosses' `dazed_loop` is tagged "dazed" only; the priest's `stunned_pre` / `impact_flame` "stunned ... press_rt".
- **Button prompts are world-space icons, not text:** the stategraphs `GenEvent("fx_press_<button>_start", {x, y})` / `_stop`; `commonpresentation.lua` maps them to `SpawnFollowingEffect("press_<button>...")` / `KillFollowingFX`. Buttons: `rt` (bosses' openings: biker bosses, bodyguard, cesar, priest, swat, toro, butcher), `x` (the Butcher's `grapple_chain*` states: Shank choked, mash attack), `lt` (cesar and swat pre-taser, medium goons' grapple: parry timing; `fx_press_lt_fail` plays Sounds/Impact/Parry_Break), `arrow` (masked butcher climb, co-op), `b` (meat slabs; commented out for Cassandra). Pickups use `press_rt_slow_loop` + `arrow_down` (separate `fx_pickup_UI_*` events).
- **Prompts shown by a boss's own event, not fx_press_* (confirmed 2026-09-27, static + the B19 log):** `cassandra_grapple_start` (Cassandra's `cas_grapple_pre`, 20 frames; 1 frame on Hard) spawns `press_lt_slow` (the parry prompt) with `speedSlowDown`; `cassandra_grapple_stop` kills it. Parry = hold CONTROL_BLOCK2 (LT) when her `cas_grapple_lunge` hits → `parried` (Parry_Enter plays), then any attack → `cas_grapple_parried_atked`. In the B19 session the prompt showed ~110 times and the mod said nothing (only fx_press_lt was patched). `butcher_dazed_start` / `_stop` (Masked Butcher, `maskedbutcher_attacks.lua` 173) does the same with `press_rt_slow`. B19-3 patches all four. **Invisible prompts (no presentation handler, so nothing for sighted players):** `fx_press_y_start` (Cassandra's `parried`), `fx_press_b_start` (the meat slabs' hint).
- **rt = CONTROL_BLOCK:** Shank's grapple (`air_grapple_lunge`, `airgrapplepredive` on BLOCK or TAUNT), pounce and pickup (PICKUPS: BLOCK + DOWN) all use it.

## Shooting while hanging or on a wall (static RE 2026-09-28, B20-4; `attacks_parkour.lua`, `shank_transitions.lua`)
- **Hanging** (a rope / bar: SHIMMY_ATTACKS; a pole hang / swing point: ON_POLE_ATTACKS): every shot goes through `polehang_shoot*`: straight 0° (`Shot({100,-10}, "hed", 0°)`), up **45°** (`{90,70}`; UP and DIAG_UP both), down **−45°** (`{90,-80}`; DOWN and DIAG_DOWN both). No straight up or straight down. `ALLOW_FACING_SWITCH_AIMING` in the shoot states turns him to shoot back. (The `shimmy_shoot_*_pre` states are commented out.)
- **On a wall, and climbing a pole** (ON_WALL_ATTACKS; ON_POLE_CLIMB_ATTACKS = ON_WALL_ATTACKS): `wall_shoot` 180° (away from the wall), `wall_shoot_up` 135°, `wall_shoot_dwn` −135°, relative to his facing.
- **Standing** has a straight-down shot too (`pistol_pre_dwn` / `pistol_attack_dwn`, −90°, `canhitground`); the floor he stands on is in its way.
- 2-b's diagonal rope (shimmy_line (37397, 2961) → (38165, 3279)) hangs ~1700 px above floors with goons (surface 32, y 1088): the B19 lock-on offered −90° there (mark 3).

## Guns and boss bars (B7b, 2026-09-26)
- `stategraphs/shank/constants.lua`: PISTOL_RANGE = 40 tiles (2560 px), PISTOL_ATTACK_ARC 15°; UZI_RANGE 30 tiles; SHOTGUN_RANGE 8 tiles. Pistol shots are `Shot({0,0}, "hed", angle, arc, range, ...)`.
- Boss bars (B7 log): the HUD writes `enemyBoss.nameTxt.text = ""` only when it's first built; later level loads don't clear it, and hiding the bar is no write we see. 1-a's scripted fake Butcher sets its bar to -650 / -750 / -2500, then 0.

## Hazard props that threaten Shank (static RE 2026-09-26, B7-3; stategraphs in `data/stategraphs/props/`)
- **Falling rock** `rockfall` (`rockFall_stategraph.lua`): spawned by dynamite / dynamiterock (`SpawnProp("rockfall", ..., Velocity(15-20 MPS, 90°))`: thrown up, then falls) and by level scripts. State `idle` = in flight: plays `GameItems/rubbleBreakLong`, a damage region 300×300 (offset 0,50) that follows it for 30 frames (re-entered each 30); ends on `onland` / `onbounceoffground` / `onhitother` → `die` (retire at 30 frames).
- **Breaking ceiling** `breaking_ceiling`: `idle` waits for level events `ceiling_break_1..3` or a rocket hit → `explode` = falls (Jump −90° at 6, 9, 18, 36 MPS over 6 frames), damage region 320×60 following it; `onland` → `land` (dust, retire).
- **Rocket** `rocket` (from `rocketspawner`, every ROCKET_SPAWN_RATE, and bosses): `idle` = flying (`rotatetospeed`), a 60×60 contact region; explodes on hitting anything, a wall, the ground: `explode` = a 240×240 blast for 3 frames.
- **Guided missile** `guidedmissile`: launched up (`idle`, 85° at 16 MPS), `respawndown`, then `attackDown` etc. (260-265° at GUIDED_MISSILE_SPEED); explodes on contact / ground / bounds / when shot: a 350×350 blast.
- **Enemy grenade** `grenade_timed` (large goons' `attacks_grenade.lua`, medium AK goons: `SpawnProp("grenade_timed", ..., Velocity(8 MPS, 30°))`): `idle` for GRENADE_TIMED_LIFETIME (stops on landing), then `explode` = a 350×350 blast (can hit its own team too). Shank's own `grenade` hits only the other team (not him).
- **Explosive barrel / propane tank** (`explosive_barrel`, `propane_tank`): `idle` until `OnHit` / `OnShot` / `blowme` → `explode` = a 350×350 blast (both teams). Static.
- `dynamite`: explodes when hit (350×350) and throws a rock up; `dynamiterock`: on `triggerExplode` throws a rock up. `firetrap`: see "Hazard props (B6-7)".

## Interactive props survey (static RE 2026-09-27, B19-1 / B19-5; the level JSONs' placed props + every SpawnProp / SpawnGameObject)
- **Meat slabs** `meatslab` (1-c Butcher fight, (36940, 850) and (36300, 850), ~630 px above the floor at y 224): `idle` = hanging, the only state without ranged invulnerability (shoot it: `OnShot` / `OnHit` → `fall` → `idle_dwn`, lowered on its chain); the Butcher's `meat_hook` hitting a lowered slab → `hide` (240 ± 60 frames) → `drop` → `idle`. Its `fx_press_b` hint has no presentation handler (invisible). Wired: `a11y/en_target_meat` every 0.5 s in `idle`.
- **How the Butcher gets stunned (confirmed 2026-09-28, static + the B21 log):** only his `hook_throw` stuns him: at frame 4 it spawns a high region (offset (350, 480), 500×240: 100-600 px ahead, 360-600 px up) tagged `meat_hook`; if it hits a **lowered** slab (`idle_dwn`, after being shot), he goes to `hook_throw_stunned` (`canbegrappled`) and the slab hides (240 ± 60 frames), then drops back to `idle`. He only starts `hook_throw_pre` when the hook countdown has expired (`SetCountdown("hookattack", 10, 3)`: every 7-13 s) and a probe finds Shank 200-800 px in front of him (offset 500, 600×240); otherwise he punches, charges or jump-grabs. So a slab shot down stays lowered, and no opening follows, until he throws the hook with the lowered slab in its path. The game's own tutorial there: "Shoot the Meatslabs to lure the Butcher." (B21 log: 5 slabs shot down, 2 openings straight after; the others waited.)
- **Boss setups: what leads to each boss's opening (static RE 2026-09-28, B23):**
  - **The fake Butcher (1-a) runs Toro's stategraph** (`boss_fakebutcher/*.lua` load `boss_toro/*`; chunk names are Toro's files): `charge_start_pre` (roar, `special_attack_flash_start`) → `charge_pre` → `charge` (loop, 8.5 MPS, until `OnRunIntoWall`) → Toro `shoulder_smash*` → `shoulder_smash_loop`, the fake Butcher `wall_hit_pre` → both `canbegrappled`. Dodged, he hits a wall and is open. **Height (checked 2026-09-28, the user's question):** the mod's bell for him comes from his own charge states (Lua reports), so Shank's height can't make it miss. The charge is one step of his attack cycle (`attackPhase`: kick → throw / grapple charge → charge → ground punch), taken only with `distancetoclosestenemy` within CHARGE_ATTACK_RANGE (12 tiles), so high up a wall he may skip it; with Shank on a wall and himself at the platform edge facing it, the anti-wall `kick_pre` → `kickoffwall`; a charge into the wall knocks everyone off it (`KnockEveryoneOffWalls`).
  - **The Gimp (2-b, after Cassandra):** his `charge_pre` / `charge` (after the grab cooldown, facing Shank, Shank farther than GRAB_ATTACK_RANGE 4 tiles) grabs the first character in a 200×128 box 200 px ahead (own or other team), or a thrown one (300×300); `GIMP_GRAPPLE_TRANSITIONS`: a `med_gimp_slave` grabbed → `cuddle` (`canbegrappled cuddle`, `fx_press_rt_start`). So a slave between him and Shank when he charges, or a slave thrown at him. **Shank's height doesn't matter (confirmed 2026-09-28, B23 log):** 5 of the 8 cuddles in the session came with Shank clinging 11-13 tiles up the arena's end walls (x 87200 / 89376, y ~1720-1830); he charged at the wall and grabbed the slave at its foot. Slaves spawn in the cage at (88683, 1382) and drop to the floor (y 992).
  - **The Priest (3-c):** a `firetrap` in `alwayson` probes 192×128 (offset 0, 50) and sends `infire` to a character with the `priest` attribute tag → `impact_flame` (unless `ignorefire`) → `stunned_pre` / `stunned` (`press_rt`, open). Our `hz_fire` report sits beside that probe (burning traps only). **In play (confirmed 2026-09-28, the Priest session log):** the two traps are at the arena's ends, beside the end walls ((70825, 14275) and (72928, 14269); the fight floor y 14304, walls at ~70784 / ~72960); all 3 stuns came from Shank's melee hits (from ~6 tiles, on the arena side) knocking him back into a trap behind him (stunned ~90-130 px from it). **The stun sequence (confirmed 2026-09-28, static + the log):** `impact_flame` (55 frames; `fx_press_rt_start` at frame 0, so the grapple prompt comes at once; grappling is accepted from the start) moves him forward (his facing, toward Shank) at 6 MPS for 10 frames then 4 MPS for 15: ~6 tiles, out of the flames, in ~0.8 s; then `stunned_pre` (47 frames) → `stunned` (50 frames looping until `stunnedtime`, `press_rt`) → `stunned_pst`: roughly 3 s more. The session's 2 missed stuns (20:19:53, 20:26:39): stunned at x 72836, at the flames' edge (trap 72928 ± 96); Shank kept swinging, then grappled at once; his lunge ended in the flames (hitWall / punchHit at 72865-72928, thrown back 135°), and the window passed. Fire damage to Shank here: 2.5% ticks plus a knockback. **The B25 session (2026-09-28, 10 stuns, 1 finisher):** B25's "Grapple now" came 80-125 ms after "Wait" with him only ~70 px out: the trap's burn region is off-centre (`alwayson`: 192×128 at offset (-64, 0), plus the 192×128 probe at (0, 50)), reaching ~160 px from the trap on the arena side; Shank's hits after the stun (he kept swinging) knocked the stunned Priest back toward the fire, and the grapple lunge (`shankGrapple`, ~300 px) then ended in the flames (hurt 2.5%, thrown back). He comes to rest ~380-480 px from the trap if left alone. Two stuns came with Shank on the wall right behind the trap (x ~72915, y ~14440, inside the flames' height: burned there) shooting him; he then walked away from Shank, so reaching him meant crossing the fire. **His block counter:** `block` → a hit on it → `block_hit` → after more than 3 blocked hits, or 75% of the time, `block_counter_pre` (20 frames; 6 on Hard; `special_attack_flash_start`, tags `blocking ...`, no `attack`) → `block_counter` (frame 5: a 250×200 kick ahead, knockback 135°); `close_kick_pre` → `block_counter` too. Most of the session's unwarned hits were this: Shank's swing, `swordOnSword` (blocked), `Angelo_Grunt` + `toroSwipe`, hit.
  - **Wind-up reports that came to nothing (static + the B25 log, 2026-09-28; the user: "attack warnings when he's out of range or otherwise doesn't seem to do anything"):** the Priest fight had ~1100 wind-up reports (after merging), ~10% followed by a hit; every boss "std" report plays the heavy buzz (B9-1). Causes, from `tools/re/windup_states.py` (the patch's rules applied offline): (1) grab words matched inside tags ("nograpple": the Priest's slide kick and flip kick were grabs); (2) "_pst" recovery states tagged `attack` reported; (3) one attack reported up to three times (X_pre, X, X_pst: different kinds don't merge), e.g. the Priest's `shoot1_pre` (aim) + `shoot1` (the shot, a boss "std" = heavy buzz), `cata_pre` + `cata1` + `cata2`; (4) states acting on an already-held Shank (the Butcher's `grapple_butcher*` finishers, Toro's climb / saw / piledriver / throw, Cesar's parry and anti-pounce sequences, SWAT's taser hold, the Gimp's headbutt / bite: actions of Type `hitgrapplepartner` / `endgrapple` / `stealgrapple` / `grapplelastattacker` or `selectcontext` 8 / 9); (5) "attack" matched inside `cassattack` (Cassandra being parried); (6) intros (`intro_idle` tagged attack: Toro, the bodyguard); (7) every report heard within 1400 px, punches too. B26 fixes all seven (see make_windup_patch.py): per boss the reporting states drop to their attacks' first telegraphs (the Priest 21 → 9, the Butcher 41 → 6, Toro 39 → 9, Cesar 24 → ~13).
- **Flash telegraphs without the attack tag (static grep 2026-09-28):** states that start `special_attack_flash_start` but aren't tagged `attack`: the Priest's `block_counter_pre` / `close_kick_pre`, Cassandra's `block_counter_pre`, Cesar's `block_atk_pre`, the bodyguard's `jump_pre` / `grab_pre`, SWAT's `swat_grapple_anti_pounce_pre(_bk)`, the Masked Butcher's `barrel_throw_pre`, the jeep passenger's `grenade_shoot_pre` / `missile_shoot_pre` (the last three were already reported by name). B24: the State() patch warns for all of them (grab words → grab, else heavy).
  - **Cesar (4-c):** three phases by health (`PHASE_ACTIONS` on hit/shot): phase 2 below 75% (cinematic `4c-05_animatic.lua`), phase 3 below 27% (`4c-06`). Phase 1: `knife_atk1` (close), `sword_dash` (300-600 px ahead); phase 2 adds `moon_kick` (Shank in the air above, in front) and `ces_grapple_lunge_pre` → `ces_grapple_lunge` (a grab); phase 3 adds `run` and `jump_pre` (600-1200 px ahead). `DEFENSE_TRANSITIONS`: he blocks (`block1` / `block2`, BLOCK_PERCENT 1.0, then 0.5 s ± 0.25 without) a telegraphed attack or a ranged one aimed at him; a hit he blocks (`OnBlockedHit`) becomes `ces_grapple_parry` 25% of the time (he grabs Shank, `fx_press_lt_start`: "Parry now"); Block 2 within PARRY_TIME (25 / 20 / 20 frames) → `ces_grapple_parry_reverse` (Shank's headbutt: HEADBUTT_DAMAGE) → phases 1-2 `butt_hit`, phase 3 `butt` → `butt_daze` (`qte`, `fx_press_rt_start`: open). Too late → `ces_grapple_parry_atk`. Pouncing him while he faces Shank → `ces_grapple_pounce_rev_pre` (his reversal); `IN_AIR_ATTACKS`: `ces_grapple_pounce` at Shank in the air (300, -300 box). No `canbegrappled` state: his openings are the prompts.
- **Slow motion stretches game-time reports (confirmed 2026-09-28, B21 log):** the Butcher's special attacks slow the game (`speedSlowDown` / `butcher_special_attack_start`); a report on a 0.5 s countdown then came up to ~1.1 s apart in real time, past the target list's 0.9 s timeout: 11 "no longer shootable" / "can be shot again" blips in one fight, each at a `speedSlowDown` (and one during the fight's opening yell). B22-1: the target timeout is 3 s and shot down / broken is reported at once.
- **Breakable doors** `doorbreakopen` (4-a, 2): tag `blocking`, attribute tag `obstacle`, Fixed; `idle` until its health reaches 0 (`onhit` / `OnShot`) → `hit` (CrateBreak) → `destroyed`. Wired: `a11y/en_target_door` in `idle`.
- **Thrown barrels** `itembarrel` (Masked Butcher, `maskedbutcher_attacks.lua` 41, 137, 140; `barrel_stategraph.lua`): `thrown` / `thrown_loop` fly with a 100×100 region and explode (350×350, both teams) on landing, a wall, bounds, or when shot. Wired: `a11y/hz_grenade` every 0.1 s in both.
- **Flashbang** `flashbang` (the SWAT boss, `swat_attacks.lua` 204): `init` = in flight (FLASHBANG_LIFETIME), `idle` = landed; `explode` sends `flashbanghit` to Shank (no damage). Wired: `a11y/hz_grenade` in both.
- **Not interactive / not meaningful:** `door_bar` (opens by itself when a character comes near), `french_door_breaking`, `window*`, `window_breaking_*` (shatter when anyone passes or hits them), `train_meat` (sways when hit), `statue_gargoyle`, `statue_pillar`, `rubble_breaking` (rockets or level scripts only), `statue_break` (3-c, decorative), `gimp_cage` (spawns gimp slaves; not attackable), tables, vases, candles, crates, `barrel_break`, `diablo_crate` (generic breakables; the user excluded them), `barrier` (never blocks), ambient animals and lights, `rope` (spawned by tied-up goons, decoration).
- **Unused:** `dynamite`, `dynamiterock`, `mine`, `livewire`, `livewireground`, `trainhazard`, `fall_hazard`, `trash_compactor`, `barrelflaming`, `barrel` (placed): no level places them and no script spawns them (grep 2026-09-27).

## Process exit (B20-6, 2026-09-28; the user: the process sometimes hangs after Alt+F4 until killed in Task Manager)
- **What the logs show (every session through B19play):** a11y.log ends with `ExitProcess(3)`, `say (final): Exiting`, `speech: final message handed over`; game.log with `Quitting the game NOW!`; crash.log empty; no Application Hang / Error events for Shank in the Windows event log. So both the game and our hook finish their part; a hang would be later, in Windows' process teardown (after ExitProcess kills every other thread, each DLL's PROCESS_DETACH runs under the loader lock, and our static CRT's global destructors run there).
- **Cause (hypothesis, not reproduced):** since B16 our SAPI voice lived in a global `std::unique_ptr<SapiSpeech>`; its destructor Released the `ISpVoice` and voice tokens in PROCESS_DETACH, after the speech thread and SAPI's own threads were gone: COM teardown there can wait forever. Consistent with "a couple times now" (intermittent, recent). The user (2026-09-28): "I never noticed this playing the game before the mod, nore did I see it during the early parts of development" (the hangs began after B16's SAPI voice). Fixed B20-6: the speech objects are never destroyed, and the XAudio2 engine is stopped inside the ExitProcess hook (still normal code, threads alive). Tolk keeps raw pointers (no teardown unless Tolk_Unload).
- **Result:** no hang since B20-6 (the user 2026-09-28: "The game closed properly this time"; every session collected since, B21 to B27, ends with the exit line). The cause stays a hypothesis; the fix works.
- **Check:** after B20-6, a11y.log's last line on exit is `exit: handing over to the game's ExitProcess`; if a hang comes back, that line shows our hook got through, and the next suspect is another DLL's detach.

## Our audio output (XAudio2; confirmed 2026-09-26 on the user's PC with `cues_test --start`)
- `xaudio2_9.dll` (Windows 10/11) is loaded at run time; `XAudio2Create` from it.
- **COM must be initialised on the calling thread:** without `CoInitializeEx`, `CreateMasteringVoice` fails with 0x800401f0 (CO_E_NOTINITIALIZED). The mod starts XAudio2 on its own cue thread with `COINIT_MULTITHREADED`, away from the game's threads.
- The default device here: 8 output channels, 48 kHz. Our mono sources (44.1 kHz) are panned onto front left/right (channels 0 and 1) with an equal-power law.

## Tools used

- `tools/re/pe.py` (pefile + capstone): import map, string xrefs, call-site search, linear disassembly. Run with `.venv/Scripts/python`.
