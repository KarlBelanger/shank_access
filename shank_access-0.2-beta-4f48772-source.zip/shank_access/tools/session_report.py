"""B42-3: one session's trouble report (instead of reading 20,000 log lines).

Reads build/logs/<session>/ (a11y.log, a11y_marks.log) and lists, per level played:
  - the session's F2 marks with their comments;
  - every death of Shank with the 6 s before it: the jump-now claims, his launches and catches, the keys he held (the Lua
    reports), the last Q;
  - the flights the jump model gets wrong (tools/movements.py + movement_check for this session: a real move the model
    can't do, his real speeds ending elsewhere in the model, a false catch, a chirp he followed that didn't get him there);
  - "Too high" warnings; time and deaths per waypoint target.
Written to build/logs/<session>/report.txt and printed.

Usage: session_report.py [<session folder or name part> | --latest]   (default: --latest)
Run it first after collect_logs.py.
"""
import glob
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import movements  # noqa: E402

LOGS = os.path.join(ROOT, "build", "logs")
RX_T = re.compile(r"^\[(\d\d):(\d\d):(\d\d)\.(\d\d\d)\] (.*)$")
RX_POS = re.compile(r"pos=\((-?\d+), (-?\d+)\)")
KEEP_BEFORE_DEATH = re.compile(r"jump now reaches|no longer reaches|cue: (up|down|fwd|back)_(on|off)|too high|"
                               r"Character/(jumpFrom\w+|poleSwing|land|landRoll|ledgeClimb|ledgeGrab|wallAttach|shimmy|"
                               r"runUpWall|Sounds/Movement/Movement_WallRunStep)\b")


def clock(ms):
    ms %= 24 * 3600 * 1000
    return "%02d:%02d:%02d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60)


def read_lines(path):
    """[(t ms, body)] with the day rollover handled as movements.parse_log does."""
    out, day, last = [], 0, -1
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = RX_T.match(line.rstrip("\n"))
            if not m:
                continue
            t = ((int(m.group(1)) * 60 + int(m.group(2))) * 60 + int(m.group(3))) * 1000 + int(m.group(4))
            if last >= 0 and t + 12 * 3600 * 1000 < last:
                day += 24 * 3600 * 1000
            last = t
            out.append((t + day, m.group(5)))
    return out


def session_marks(folder, first_ms, last_ms):
    """The marks file's entries inside this log's time span (the file is appended across sessions)."""
    path = os.path.join(folder, "a11y_marks.log")
    if not os.path.exists(path):
        return []
    date = os.path.basename(folder)[:8]  # 20261001-...
    want = "%s-%s-%s" % (date[:4], date[4:6], date[6:8])
    marks, on = [], False
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.rstrip("\n")
        if line.startswith("=== Session "):
            parts = line.split()
            on = len(parts) >= 4 and parts[2] == want
            if on:
                hh, mm, ss = (int(v) for v in parts[3].split(":"))
                t = ((hh * 60 + mm) * 60 + ss) * 1000
                on = first_ms - 60000 <= t <= last_ms + 60000
            continue
        if on and line.startswith("MARK "):
            marks.append(line)
    return marks


def flagged_flights(folder):
    """movements.py for this session, then movement_check on it: the flights with a problem."""
    name = os.path.basename(folder)
    subprocess.run([sys.executable, os.path.join(ROOT, "tools", "movements.py"), "--session", name, "--quiet"], check=True,
                   cwd=ROOT)
    out_dir = os.path.join(ROOT, "build", "movements", "only_" + name)
    check = os.path.join(out_dir, "check.txt")
    exe = os.path.join(ROOT, "build", "native", "out", "movement_check.exe")
    geo = os.path.join(ROOT, "build", "levels", "shank_access_geometry.txt")
    if not os.path.exists(exe):
        return ["(movement_check.exe not built)"]
    subprocess.run([exe, geo, os.path.join(out_dir, "movements.txt"), check], check=True, cwd=ROOT, stdout=subprocess.DEVNULL)
    rows = []
    starts = {}
    for line in open(os.path.join(out_dir, "movements.txt"), encoding="utf-8"):
        f = line.split()
        if f and f[0] == "m":
            starts[f[1]] = (f[3], f[4], f[5], f[6])
    for line in open(check, encoding="utf-8"):
        if not line.startswith("mv "):
            continue
        head, _, detail = line.rstrip("\n").partition(" | ")
        f = head.split()
        key, level, kind, reach, replay, claim = f[1], f[2], f[3], f[4], f[5], f[6]
        phantom = f[7] if len(f) > 7 else "-"
        problems = [p for p, bad in (("the model can't do this real move", reach == "MISS"),
                                     ("his real speeds end elsewhere in the model", replay == "WRONG"),
                                     ("a false catch", phantom == "FALSE"),
                                     ("a chirp he followed didn't get him there", claim == "broken")) if bad]
        if not problems:
            continue
        t = int(key.rsplit(":", 1)[1])
        k, x0, y0, d = starts.get(key, (kind, "?", "?", "?"))
        rows.append((level, t, "%s %s from (%s, %s) facing %s: %s%s" % (clock(t), kind, x0, y0, "right" if d == "R" else "left",
                                                                       "; ".join(problems), (" (" + detail + ")") if detail else "")))
    return rows


def report(folder, check=True):
    log = os.path.join(folder, "a11y.log")
    lines = read_lines(log)
    if not lines:
        return "no a11y.log lines in %s" % folder
    first, last = lines[0][0], lines[-1][0]
    out = ["Session report: %s (%s to %s)" % (os.path.basename(folder), clock(first), clock(last))]
    # levels in order, with their time spans
    spans = []
    for t, body in lines:
        if body.startswith("level: LoadSimData") and "name " in body:
            spans.append([t, body.split("name ")[1].strip()])
    out.append("Levels: " + (", ".join("%s at %s" % (lv, clock(t)) for t, lv in spans) or "none"))

    def level_at(t):
        name = None
        for ts, lv in spans:
            if ts <= t:
                name = lv
        return name or "-"

    marks = session_marks(folder, first, last)
    out.append("")
    out.append("Marks (%d):" % len(marks))
    out.extend("  " + m for m in marks)

    # deaths, each with the 6 s before
    deaths = []
    for i, (t, body) in enumerate(lines):
        if "Voices/Shank/Shank_Death" in body and (not deaths or t - deaths[-1][0] > 3000):
            deaths.append((t, i, body))
    out.append("")
    out.append("Deaths (%d):" % len(deaths))
    last_q = ""
    q_at = {}
    for i, (t, body) in enumerate(lines):
        if body.startswith("hotkey: Q") and i + 1 < len(lines) and lines[i + 1][1].startswith("say (stats): "):
            last_q = lines[i + 1][1][len("say (stats): "):]
        q_at[i] = last_q
    for t, i, body in deaths:
        m = RX_POS.search(body)
        out.append("  %s %s at (%s, %s)%s" % (clock(t), level_at(t), m.group(1) if m else "?", m.group(2) if m else "?",
                                              ("; last Q: " + q_at[i]) if q_at.get(i) else ""))
        for t2, b2 in lines[max(0, i - 600):i]:
            if t - t2 <= 6000 and KEEP_BEFORE_DEATH.search(b2):
                b2 = re.sub(r" listener=.*", "", b2).replace("sound at: Shank/Character/", "").replace("Sounds/Movement/", "")
                out.append("      -%4.1f s  %s" % ((t - t2) / 1000.0, b2))

    flagged = flagged_flights(folder) if check else []
    out.append("")
    out.append("Flights the jump model gets wrong (%d):" % len(flagged))
    for row in flagged:
        if isinstance(row, str):
            out.append("  " + row)
    by_level = {}
    for row in flagged:
        if not isinstance(row, str):
            by_level.setdefault(row[0], []).append(row)
    for lv in sorted(by_level):
        out.append("  " + lv + ":")
        out.extend("    " + r[2] for r in sorted(by_level[lv], key=lambda r: r[1]))

    too_high = [(t, b) for t, b in lines if b.startswith("cues: too high")]
    out.append("")
    out.append("Too high (%d):" % len(too_high))
    out.extend("  %s %s %s" % (clock(t), level_at(t), b[len("cues: "):]) for t, b in too_high)

    # waypoint targets: how long each was the next object, and the deaths meanwhile
    steps = []
    for t, body in lines:
        if body.startswith("waypoint: ") and " -> " in body:
            target = body.split(" -> ")[1].split(" ")[0]
            if not steps or steps[-1][1] != target:
                steps.append([t, target, body[len("waypoint: "):]])
    out.append("")
    out.append("Waypoint targets (longest first; deaths while each was next):")
    rows = []
    for k, (t, target, text) in enumerate(steps):
        end = steps[k + 1][0] if k + 1 < len(steps) else last
        n = sum(1 for td, _, _ in deaths if t <= td < end)
        rows.append((end - t, n, t, text))
    for dur, n, t, text in sorted(rows, reverse=True)[:15]:
        out.append("  %5.0f s  %d death(s)  from %s  %s %s" % (dur / 1000.0, n, clock(t), level_at(t), text))
    if not rows:
        out.append("  (waypoint mode not used)")
    return "\n".join(out)


def find_folder(arg):
    folders = sorted(d for d in glob.glob(os.path.join(LOGS, "*")) if os.path.exists(os.path.join(d, "a11y.log")))
    if not arg or arg == "--latest":
        return folders[-1] if folders else None
    if os.path.isdir(arg):
        return arg
    hits = [d for d in folders if arg in os.path.basename(d)]
    return hits[-1] if hits else None


def main(argv):
    folder = find_folder(argv[0] if argv else None)
    if not folder:
        print("no such session in %s" % LOGS)
        return 1
    text = report(folder)
    with open(os.path.join(folder, "report.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
