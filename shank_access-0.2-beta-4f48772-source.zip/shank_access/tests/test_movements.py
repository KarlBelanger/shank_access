"""Tests for tools/movements.py (B42-1): flights cut out of a synthetic log, their fitted speeds and ends.

Run: .venv/Scripts/python -m unittest discover -s tests -v
"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
import movements  # noqa: E402

G = movements.G


def stamp(ms):
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return "[%02d:%02d:%02d.%03d]" % (h, m, s, ms)


def long_jump_log(t0=36000000, x0=1000.0, y0=224.0, vx=720.0, vy=1145.0, scale=1.0, jitter=True):
    """A level load, steps, a jump sound, traj samples every ~31 ms along a parabola (as the cue thread reads them: a
    frame stale at times), and the landing's sound when he's back at y0."""
    lines = ["%s level: LoadSimData(1234) -> 1, name campaign_test_nogeometry" % stamp(t0 - 5000)]
    lines.append("%s sound at: Shank/Character/step pos=(%d, %d) listener=(%d, %d) half=(1600, 900) pan=0.00"
                 % (stamp(t0 - 300), x0 - 200, y0, x0 - 200, y0))
    lines.append("%s sound at: Shank/Character/jumpFromGround pos=(%d, %d) listener=(%d, %d) half=(1600, 900) pan=0.00"
                 % (stamp(t0), x0, y0, x0, y0))
    tick0 = 900000
    t = 16
    k = 0
    while True:
        frame = t - (8 if jitter and k % 3 == 1 else 0)  # some samples show the previous frame
        g = frame / 1000.0 * scale  # game time
        x, y = x0 + vx * g, y0 + vy * g - G / 2 * g * g
        if y < y0:
            break
        lines.append("%s traj: %d %.1f %.1f" % (stamp(t0 + t), tick0 + t, x, y))
        t += 31
        k += 1
    lines.append("%s sound at: Shank/Character/land pos=(%d, %d) listener=(%d, %d) half=(1600, 900) pan=0.00"
                 % (stamp(t0 + t), x, y0, x, y0))
    return "\n".join(lines) + "\n"


class FitTest(unittest.TestCase):
    def test_parabola(self):
        pts = [(t / 100.0, 5 + 3 * t / 100.0 - 7 * (t / 100.0) ** 2) for t in range(10)]
        a, b, c = movements.fit_parabola(pts)
        self.assertAlmostEqual(a, 5, places=6)
        self.assertAlmostEqual(b, 3, places=6)
        self.assertAlmostEqual(c, -7, places=6)

    def test_ballistic_stops_at_a_catch(self):
        # a fall, then hanging still (a catch): the flight ends at the last falling sample
        samples = [(1000 + 31 * k, 0.0, 500 - 1600 * (0.031 * k) ** 2) for k in range(12)]
        samples += [(samples[-1][0] + 31 * k, 0.0, samples[-1][2]) for k in range(1, 6)]
        used, fit, deviated = movements.ballistic(samples, 1000)
        self.assertTrue(deviated)
        self.assertEqual(used, 12)
        self.assertAlmostEqual(-2 * fit[2], G, delta=40)


class CorpusTest(unittest.TestCase):
    def run_log(self, text):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "a11y.log")
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            events, traj = movements.parse_log(path)
        sess = movements.Session("test", events, traj)
        return movements.session_movements(sess, {})

    def test_long_jump(self):
        moves = [m for m in self.run_log(long_jump_log()) if m.get("launch") == "jumpFromGround"]
        self.assertEqual(len(moves), 1)
        m = moves[0]
        self.assertEqual(m["kind"], "ground")
        self.assertEqual(m["dir"], "R")
        self.assertEqual(m["end"]["how"], "land")
        self.assertAlmostEqual(m["fit"]["vy"], 1145, delta=40)
        self.assertAlmostEqual(m["fit"]["vx"], 720, delta=25)
        self.assertAlmostEqual(m["fit"]["scale"], 1.0, delta=0.05)
        self.assertEqual(m["flags"], [])

    def test_slow_motion_scale(self):
        # the same jump at half game speed: the fit finds the time scale and the game-time speeds
        m = [m for m in self.run_log(long_jump_log(scale=0.5)) if m.get("launch") == "jumpFromGround"][0]
        self.assertAlmostEqual(m["fit"]["scale"], 0.5, delta=0.05)
        self.assertAlmostEqual(m["fit"]["vy"], 1145, delta=60)
        self.assertIn("timescale", m["flags"])

    def test_someone_elses_jump_sound(self):
        # a goon's jump far from him (goons share the Character sounds) isn't his
        text = long_jump_log().replace("jumpFromGround pos=(1000, 224) listener=(1000, 224)",
                                       "jumpFromGround pos=(5000, 224) listener=(1000, 224)")
        self.assertEqual([m for m in self.run_log(text) if m.get("launch") == "jumpFromGround"], [])

    def test_flat_line(self):
        m = [m for m in self.run_log(long_jump_log()) if m.get("launch") == "jumpFromGround"][0]
        fields = movements.flat_line(m).split()
        self.assertEqual(fields[0], "m")
        self.assertEqual(fields[1], "test:36000000")
        self.assertEqual(fields[3], "ground")
        self.assertEqual(len(fields), 24)

    def test_model_constants(self):
        k = movements.model_constants()
        self.assertEqual(k["kGravity"], 3200.0)
        self.assertEqual(k["kLedgeHangPx"], 160.0)
        self.assertIn("kSlideOffMaxVx", k)


if __name__ == "__main__":
    unittest.main()
