#pragma once
// Phase 2 (menu reading): decides what to say for each UI event from ui_hooks.
//   2-1: speak the focused item's label (IDS_* keys translated).
//   2-2: Settings dialog: focus also comes from navigate("<path>") and <path>.focused = true;
//        sliders, spinners and checkboxes get a name, a role and their value; value changes on the
//        focused control are spoken.
#include <functional>
#include <vector>
#include <string>

#include "ui_hooks.h"

namespace menu_reader {

// A focus from a *different movie* this soon after the previous spoken focus is ignored. Opening
// the pause menu for the first time focuses "Resume Game" and then, 5 ms later, "How to Play" on a
// hidden screen (another movie; 1c-2, 1c-3 and 2-1 logs). The first focus is the real one.
constexpr unsigned kIgnoreOtherMovieWithinMs = 50;
// focusIn / focused-set for the path that is already focused, this soon after it was spoken, is the
// same move reported twice (e.g. navigate + focusIn, or focused = true + focusIn).
constexpr unsigned kSameFocusWithinMs = 100;

// 2-5a: dialog text (<parent>.headerTxt.text / .bodyTxt.text) written this soon before a focus
// in the same movie, on a widget under the same parent (the dialog's own button), is spoken first:
// "<header>. <body> <button>". The game writes the text and sets the button focus in the same ms.
constexpr unsigned kDialogTextWithinMs = 500;

// 2-5b: a screen title is spoken with a focus the game sets (not an arrow press) when the screen
// differs from the last title spoken, or when the previous focus was at least this long ago
// (reopening the pause menu after playing).
constexpr unsigned kTitleAgainAfterMs = 1500;

// The screen a focused widget belongs to ("Main menu", "Settings", …; our own names), or "" when
// unknown or shared between screens (backBtn, dialog buttons).
std::string ScreenTitle(const std::string& path);

// navigate("<path>") for the path that is already focused means a key press that didn't move the
// focus: the focus is spoken again, unless it was spoken less than this long ago.
constexpr unsigned kRepeatNavigateAfterMs = 50;

// Reads a Flash value by full path (ui_hooks::ReadValue in the game; a fake in tests).
using Reader = std::function<ui_hooks::FlashValue(void* movie, const std::string& path)>;

// A value written to the focused slider's value source this soon after the focus was spoken
// re-announces the focus with that value (Settings opens with focus on the music slider and only
// then writes its number; 2-2 test: "Music volume, slider, 00").
constexpr unsigned kLateValueWithinMs = 500;
// The same value for the same widget this soon after it was spoken is not repeated (spinners send
// change and stepperChange for one press).
constexpr unsigned kSameValueWithinMs = 20;

// Returns the text to speak for an event ("" = stay silent) and logs the decision.
// now_ms is a millisecond clock (GetTickCount). new_value: the value being written (kValueSet only).
std::string OnEvent(ui_hooks::UiEvent::Type type, void* movie, const std::string& path, unsigned now_ms,
                    const Reader& read, const ui_hooks::FlashValue* new_value = nullptr);

// 2-3: native -> Flash method calls (ui_hooks kInvoke). Keeps each widget's cell list (Clear /
// AddCell) and speaks the selected cell on SelectCell / SelectNext / SelectPrev (the level select's
// film strip): "<name>, <n> of <total>". `ask` calls a no-argument method on the widget (for
// "GetSelectedIndex"); it may be empty in tests.
// Keyboard scrolling moves the strip inside Flash with no call to the game (2-3 test), so the
// selection is also polled: on the game's own per-frame calls (IsSelected, IsLoadingImage), at most
// every kPollEveryMs, GetSelectedIndex is asked and a change is spoken.
using Asker = std::function<std::string(const std::string& method)>;
constexpr unsigned kPollEveryMs = 100;
// movie: the widget's movie (identity only). When a cell is spoken, that movie becomes the focused
// screen, so screens hiding underneath (the difficulty screen as level select opens) aren't taken
// for the focused screen closing (2-5b-4 test: "Main menu. Play the Story" over "Level select").
std::string OnInvoke(const std::string& widget, const std::string& method, const std::vector<std::string>& args,
                     const std::string& result, unsigned now_ms, const Asker& ask, void* movie = nullptr);

// The readable name of a cell from its AddCell arguments (heuristic until the log shows which
// argument is the name): the first string that isn't a path, file or identifier.
std::string CellName(const std::vector<std::string>& args);

// Extra details spoken after a cell's name (2-3c): for level select, "locked" (flag args[3] = 1),
// else the completion time ("completion time 4 minutes 46 seconds", or "no completion time" when
// the game sends -1).
std::string CellDetails(const std::vector<std::string>& args);

// 2-5b-3: a screen was shown or hidden (ui_hooks kScreenShown / kScreenHidden). CLIK restores a
// screen's previous focus silently when the user backs out to it or re-enters it, so:
//   - shown: if the focus isn't already in that movie, re-announce the widget last focused there
//     (with the screen title);
//   - hidden: if it was the focused screen, re-announce the most recent other screen that is
//     still shown and has a focus history.
// Returns the text to speak ("" = nothing).
std::string OnScreen(bool shown, void* movie, unsigned now_ms, const Reader& read);
// 2-5b-6: a screen that opened with no focus event and no focus history (the in-level Help &
// Options on first entry) is asked for its focus on the frames after it appears
// (ui_hooks kScreenTick), for up to kFocusProbeMs. `query` returns the focused path or "".
constexpr unsigned kFocusProbeMs = 1000;
std::string OnScreenTick(void* movie, unsigned now_ms, const Reader& read,
                         const std::function<std::string(void*)>& query);

// 2-5b-7: announcing the screen the user returned to (after the focused screen hides) waits this
// long, and is dropped if that screen closes meanwhile (Escape from the in-level Help & Options
// closes the pause menu 0.2 s later: only "Resumed" should be heard). OnFrame speaks it when due.
constexpr unsigned kRestoreDelayMs = 300;
std::string OnFrame(unsigned now_ms, const Reader& read);

// 2-5b-7: the Exit Game dialog's Quit button (a click on "_level0.quitBtn" in a movie where
// "_level0.cancelBtn" had the focus) makes OnEvent return "Exiting"; from then on nothing else is
// spoken. Exiting() tells the caller to speak it as the final message.
bool Exiting();

// N2: gameplay text spoken when written (the loading tip "Loading. Tip: …", tutorial hints
// "Tutorial: …", unlock banners). The same text on the same field is not repeated until the field
// has gone this long without a write.
constexpr unsigned kAnnouncedRepeatMs = 30000;

// N3: the read-screen key (any thread) asks for everything readable on the focused screen; the
// next OnFrame (game thread) builds it: title, text fields, descriptions, pause stats, the focus.
void RequestReadScreen();

// B5b: a menu has the focus right now (the pause menu, a dialog, the main menu, level select): its
// focused screen is shown and alive. The positioned cues stay silent then (the user: "the new sounds
// do not stop when pausing or leaving a level").
bool MenuActive();

// B1e (the user, 2026-09-26): F8 repeats "the last screen, tutorial message, etc that was spoken.
// It should not capture short text like menu items or status readouts." The last message that
// carried dialog/page/pop-up text, a tutorial hint, loading tip, unlock banner or chosen weapon's
// description; "" if none yet. Safe from any thread.
std::string LastLongMessage();
// B30-4: when the last tutorial pop-up screen was shown (0 = never).
unsigned LastTutorialScreenMs();

// B13-1: the Credits (Help & Options > Credits plays a scrolling movie built from the game's own
// data-pc/credits.xml). CreditsFromXml turns that file's rows into speech ("Executive Producer: Jamie
// Cheng. ..."); SetCredits keeps it; clicking creditsBtn speaks it (and F8 repeats it).
std::string CreditsFromXml(const std::string& xml);
void SetCredits(const std::string& text);
// B16: whether the text just returned by OnEvent / OnScreen was an automatic announcement (loading tips, tutorial
// hints and pop-ups, unlock banners) rather than menu reading; clears it. For the speech channels.
bool TakeAutomatic();

// B13-2: the settings menu's key name; Help & Options' title mentions it once per session.
void SetSettingsKeyName(const std::string& name);

// B1f: a list box rebuilt while it has the focus (a rebind shows "-Select New Input-", then the new
// key) re-reads its selected row this long after clearItems, once addItem calls are done.
constexpr unsigned kListRefreshMs = 100;
// N3: How to Play Next/Prev: the page's name (nameTxt) is read this long after the click, once the
// new frame shows, and spoken if it changed.
constexpr unsigned kPageReadDelayMs = 150;

// N1: description text (…TitleTxt / …BodyTxt) written this soon before a click, in the same movie
// and beside the clicked widget, is spoken as "<title>. <body>" (choosing a weapon).
constexpr unsigned kDescWithClickMs = 200;

// Stored movie pointers are only read through if this says the movie is still alive
// (ui_hooks::MovieAlive in the game; unset = always alive, for tests).
void SetMovieAliveCheck(std::function<bool(void*)> alive);
// A shown screen is not re-announced within this long of a focus the game reported in another screen.
constexpr unsigned kScreenRestoreQuietMs = 250;

// Forget the current focus and cell lists (tests).
void Reset();

}  // namespace menu_reader
