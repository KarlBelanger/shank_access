#pragma once
#include <string>

// Every hard-coded address in this mod is only valid for one Shank.exe build (docs/RE-NOTES.md).
inline constexpr char kExpectedExeSha256[] = "a3b58dde9e4e3588664389bc6a36422d3f6110e6cf0869c493f0cb91fce79e2a";

// Lower-case hex SHA-256 of the file, or an empty string on failure.
std::string Sha256File(const wchar_t* path);
