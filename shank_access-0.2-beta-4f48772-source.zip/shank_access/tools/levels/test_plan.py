"""B47-4: the manual test plan from the evidence (tools/levels/evidence.py), grouped by the user's rule (CLAUDE.md "Test
session size"): a level with many gaps is one session (a playthrough with waypoint mode on, following Q, plus its key
spots tried on purpose); levels with only a few spots are strung together, 10-15 spots a session.

A gap is a route move that is untested (no real attempt from there), contradicted (attempts, none made it), model-doubt
(made, but the model can't or the replayed chirp was false / missing), mixed (made and died there) or extremely risky. Key
spots (tried on purpose, with directions from the checkpoint before them): every contradicted, model-doubt, mixed or
extremely risky move. Untested moves are covered by the playthrough. B48c (the user's one-safe-path rule, 2026-10-02): key
spots are only contradicted moves and one-speed walk-offs at other than a full sprint.

Writes build/levels/test_plan.txt and prints it. Usage: test_plan.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
LEVELS = os.path.join(ROOT, "build", "levels")
FULL_LEVEL_GAPS = 10   # this many gap moves or more: the whole level is a session
SPOTS_PER_SESSION = (10, 15)

WHY = {
    "contradicted": "Real attempts from here never made this move. Do exactly what Q says from here (a few tries); mark (F2) whether it works and what happened instead.",
    "model-doubt": "You've made this move before, but today's model or its jump alert disagrees. Listen for the jump alert before you jump; mark if it's missing, early or late, or if it sounds and the jump fails.",
    "mixed": "You've made this move and also died here. Try it a few times as Q says; mark what goes wrong when it fails.",
    "extreme": "It works at one speed only. Try it at that speed and once a little off it; mark what happens.",
}


def key_spots(legs):
    """[(leg, move, kind)] the moves to try on purpose, each once per level (its first leg)."""
    out, seen = [], set()
    for leg in legs:
        for mv in leg["moves"]:
            kind = None
            # (B48c, the user's rule: "As long as we have at least one valid path that doesn't require pixel perfect jumps or
            # speed perfect drops, we're fine": a spot is worth a test only where the route may have no such path: moves real
            # attempts never made, and one-speed walk-offs at a speed other than a full sprint (his normal running). Moves he
            # has made where only the model or the alert disagreed (model-doubt, mixed) are left to the playthrough.)
            if any("EXTREMELY" in r and "full sprint" not in r for r in mv["risks"]):
                kind = "extreme"
            elif mv["status"] == "contradicted":
                kind = mv["status"]
            k = (mv["from"], mv["to"], mv["move"])
            if kind and k not in seen:
                seen.add(k)
                out.append((leg, mv, kind))
    return out


def gaps(legs):
    seen, n = set(), 0
    for leg in legs:
        for mv in leg["moves"]:
            k = (mv["from"], mv["to"], mv["move"])
            if k in seen or mv["status"] in ("on foot", "proven"):
                continue
            seen.add(k)
            n += 1
    return n


def spot_text(leg, mv, kind, number):
    lines = ["  Spot %d: %s, checkpoint \"%s\" (Go to checkpoint), move %d of %d on the way to \"%s\"." % (
        number, leg["chapter"], leg["checkpoint"], mv["n"], len(leg["moves"]), leg["to"])]
    for prior in leg["moves"][:mv["n"]]:
        lines.append("    %d. %s" % (prior["n"], prior["text"]))
    lines.append("    Why: " + WHY[kind])
    if mv["move"] in ("wall_jump", "pole_jump", "run_up_jump") and kind in ("contradicted", "model-doubt"):
        # (B47 fix 2: the routes allow a wall / pole jump steered away (up to 700 px/s); unsteered ones go ~541)
        # (B48: the jump alert sounds for any steering now; holding toward the jump can slide him out of a tight window)
        lines.append("    Try it a few ways: holding the jump's direction as you jump, and with no direction held. Mark which "
                     "worked.")
    e = mv["evidence"]
    if e["tried"]:
        lines.append("    (The logs: %d attempt(s) from here, %d made it, %d died, %d went elsewhere.)" % (e["tried"], e["made"], e["died"], e["elsewhere"]))
    return lines


def main(argv):
    ev = json.load(open(os.path.join(LEVELS, "evidence.json"), encoding="utf-8"))
    levels = []
    for level, legs in ev.items():
        if not legs:
            continue
        spots = key_spots(legs)
        g = gaps(legs)
        if not g and not spots:
            continue  # (nothing to test: 2-a's routes have no jumps)
        score = sum({"contradicted": 3, "extreme": 3, "model-doubt": 2, "mixed": 1}[k] for _, _, k in spots)
        chapters = []
        for leg in legs:
            if leg["chapter"] and leg["chapter"] not in chapters:
                chapters.append(leg["chapter"])
        levels.append({"level": level, "chapters": chapters, "spots": spots, "gaps": g, "score": score})
    levels.sort(key=lambda l: -l["score"])
    out = ["B47 manual test plan (tools/levels/test_plan.py; from build/levels/evidence.json)",
           "Before each session: waypoint mode on; collect the logs before relaunching. Mark (F2) anything wrong.", ""]
    session = 0
    small = []
    for l in levels:
        if l["gaps"] >= FULL_LEVEL_GAPS:
            session += 1
            out.append("Session %d: %s (a playthrough: %d route moves with no or doubtful evidence)" % (session, " / ".join(l["chapters"]), l["gaps"]))
            out.append("  Play it from the level's start to its end with waypoint mode on, following Q. Then the key spots:")
            for i, (leg, mv, kind) in enumerate(l["spots"], 1):
                out.extend(spot_text(leg, mv, kind, i))
            out.append("")
        else:
            small.append(l)
    batch, count = [], 0
    for l in small:
        batch.append(l)
        count += len(l["spots"])
        if count >= SPOTS_PER_SESSION[0]:
            session += 1
            out.append("Session %d: spots in %s" % (session, ", ".join(" / ".join(b["chapters"]) for b in batch)))
            n = 0
            for b in batch:
                for leg, mv, kind in b["spots"]:
                    n += 1
                    out.extend(spot_text(leg, mv, kind, n))
            out.append("")
            batch, count = [], 0
    if batch:
        session += 1
        out.append("Session %d: spots in %s" % (session, ", ".join(" / ".join(b["chapters"]) for b in batch)))
        n = 0
        for b in batch:
            for leg, mv, kind in b["spots"]:
                n += 1
                out.extend(spot_text(leg, mv, kind, n))
    path = os.path.join(LEVELS, "test_plan.txt")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")
    print("%d sessions -> %s" % (session, path))
    for l in levels:
        print("  %-45s gaps %3d, key spots %2d (score %d)" % (" / ".join(l["chapters"]), l["gaps"], len(l["spots"]), l["score"]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
