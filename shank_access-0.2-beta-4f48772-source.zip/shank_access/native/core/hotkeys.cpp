#include "hotkeys.h"

#include <windows.h>

#include <cwchar>

#include "log.h"
#include "mod_state.h"
#include "speech.h"

namespace hotkeys {

bool GameIsForeground() {
    HWND w = GetForegroundWindow();
    DWORD pid = 0;
    if (w) GetWindowThreadProcessId(w, &pid);
    if (pid != GetCurrentProcessId()) return false;
    // B14b: our own windows live in the game's process too; the F2 mark window isn't the game (the user: "I'm
    // getting status announcements as I type").
    wchar_t cls[64] = {};
    GetClassNameW(w, cls, 64);
    return wcscmp(cls, L"ShankAccessMark") != 0;
}

namespace {

struct Key {
    int vk;
    std::string name;
    void (*action)();
    bool was_down;
    std::string id;     // B13-2: bindable keys only
    std::string label;
    int default_vk;
    unsigned pad = 0;          // B39
    bool pad_was_down = false;
};

SRWLOCK g_lock = SRWLOCK_INIT;
std::vector<Key> g_keys = {
    {VK_F9, "F9 (repeat last message)", [] { speech::RepeatLast(); }, false, "", "", VK_F9},
};
void (*g_menu)(int) = nullptr;  // B13-2 menu mode
bool g_all_down[256] = {};       // every key's last state (menu mode)
void (*g_pad_capture)(unsigned) = nullptr;  // B39
unsigned g_pad_peak = 0;                    // (capture: the most buttons held at once)
bool g_pad_wait_release = false;            // B40c: capture starts once every button is up (the A that chose it isn't it)

// B39: XInput, loaded at run time (the game's own xinput1_3, or a later one).
struct PadState {
    DWORD packet;
    WORD buttons;
    BYTE left_trigger, right_trigger;
    SHORT lx, ly, rx, ry;
};
using GetStateFn = DWORD(WINAPI*)(DWORD, PadState*);
GetStateFn LoadXInput() {
    for (const wchar_t* dll : {L"xinput1_3.dll", L"xinput1_4.dll", L"xinput9_1_0.dll"}) {
        if (HMODULE h = LoadLibraryW(dll)) {
            if (auto f = reinterpret_cast<GetStateFn>(GetProcAddress(h, "XInputGetState"))) {
                alog::Write("hotkeys: controller input through %ls", dll);
                return f;
            }
        }
    }
    alog::Write("hotkeys: no XInput: controller bindings unavailable");
    return nullptr;
}

GetStateFn g_real_xinput = nullptr;  // B40-2: the trampoline past input_block's hook

unsigned ReadPad(GetStateFn loaded) {
    const GetStateFn get = g_real_xinput ? g_real_xinput : loaded;
    if (!get) return 0;
    for (DWORD i = 0; i < 4; ++i) {  // the first connected pad
        PadState st = {};
        if (get(i, &st) != ERROR_SUCCESS) continue;
        unsigned b = st.buttons & 0xf3ff;
        if (st.left_trigger > 128) b |= kPadLeftTrigger;
        if (st.right_trigger > 128) b |= kPadRightTrigger;
        if (st.ly > kStickThreshold) b |= kPadLStickUp;  // B40-1
        if (st.ly < -kStickThreshold) b |= kPadLStickDown;
        if (st.lx < -kStickThreshold) b |= kPadLStickLeft;
        if (st.lx > kStickThreshold) b |= kPadLStickRight;
        if (st.ry > kStickThreshold) b |= kPadRStickUp;
        if (st.ry < -kStickThreshold) b |= kPadRStickDown;
        if (st.rx < -kStickThreshold) b |= kPadRStickLeft;
        if (st.rx > kStickThreshold) b |= kPadRStickRight;
        return b;
    }
    return 0;
}

unsigned g_pad_prev = 0;  // B40-3: the last state (menu navigation fires on presses)

// The controller step (poll thread, lock not held): returns the actions to run.
std::vector<void (*)()> PadStep(unsigned buttons, bool active) {
    std::vector<void (*)()> fire;
    void (*capture)(unsigned) = nullptr;
    unsigned captured = 0;
    std::vector<int> menu_keys;
    void (*menu)(int) = nullptr;
    AcquireSRWLockExclusive(&g_lock);
    const unsigned pressed = buttons & ~g_pad_prev;
    if (g_menu && !g_pad_capture && active && pressed) {  // B40-3
        unsigned menu_pad = 0;
        int menu_vk = 0;
        for (const Key& k : g_keys) {
            if (k.id == "settings") {
                menu_pad = k.pad;
                menu_vk = k.vk;
            }
        }
        menu = g_menu;
        menu_keys = MenuKeysFor(pressed, buttons, menu_pad, menu_vk);
    }
    g_pad_prev = buttons;
    if (g_pad_capture && g_pad_wait_release) {
        if (!buttons) g_pad_wait_release = false;
    } else if (g_pad_capture) {
        g_pad_peak = buttons ? (g_pad_peak | buttons) : g_pad_peak;
        if (!buttons && g_pad_peak) {
            capture = g_pad_capture;
            captured = g_pad_peak;
            g_pad_peak = 0;
        }
    }
    for (Key& k : g_keys) {
        const bool down = k.pad && (buttons & k.pad) == k.pad;
        if (down && !k.pad_was_down && active && !g_menu && !g_pad_capture) {
            alog::Write("hotkey: %s (controller %s)", k.name.c_str(), PadName(k.pad).c_str());
            fire.push_back(k.action);
        }
        k.pad_was_down = down;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (capture) capture(captured);
    for (int vk : menu_keys) menu(vk);
    return fire;
}

DWORD WINAPI PollThread(LPVOID) {
    const GetStateFn get_pad = LoadXInput();
    for (;;) {
        Sleep(30);
        const bool fg = GameIsForeground();
        const bool active = mod_state::Active();  // B38-3: off, only F11 (the on / off key) is listened for
        std::vector<void (*)()> fire;
        std::vector<int> menu_keys;
        AcquireSRWLockExclusive(&g_lock);
        void (*menu)(int) = g_menu;
        for (int vk = 8; vk < 256; ++vk) {
            const bool down = fg && (GetAsyncKeyState(vk) & 0x8000) != 0;
            // (the generic Shift/Ctrl/Alt codes double the left/right ones: only those are passed on)
            const bool generic = vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU;
            if (menu && active && down && !g_all_down[vk] && !generic) menu_keys.push_back(vk);
            g_all_down[vk] = down;
        }
        for (Key& k : g_keys) {
            const bool down = fg && (GetAsyncKeyState(k.vk) & 0x8000) != 0;
            if (down && !k.was_down && (!menu || !active || k.vk == VK_F11) && (active || k.vk == VK_F11)) {
                alog::Write("hotkey: %s", k.name.c_str());
                fire.push_back(k.action);
            }
            k.was_down = down;
        }
        ReleaseSRWLockExclusive(&g_lock);
        for (auto action : PadStep(fg ? ReadPad(get_pad) : 0, active)) fire.push_back(action);  // B39
        for (auto action : fire) action();  // outside the lock, so actions may call Add()
        for (int vk : menu_keys) menu(vk);
    }
}

}  // namespace

void Start() {
    if (HANDLE t = CreateThread(nullptr, 0, PollThread, nullptr, 0, nullptr)) CloseHandle(t);
}

void Add(int vk, const char* name, void (*action)()) {
    AcquireSRWLockExclusive(&g_lock);
    g_keys.push_back({vk, name, action, false, "", "", vk});
    ReleaseSRWLockExclusive(&g_lock);
}

void AddBindable(const char* id, int default_vk, int vk, const char* label, void (*action)()) {
    AcquireSRWLockExclusive(&g_lock);
    g_keys.push_back({vk, KeyName(vk) + " (" + label + ")", action, false, id, label, default_vk});
    ReleaseSRWLockExclusive(&g_lock);
}

std::vector<Binding> Bindings() {
    std::vector<Binding> out;
    AcquireSRWLockShared(&g_lock);
    for (const Key& k : g_keys) {
        if (!k.id.empty()) out.push_back(Binding{k.id, k.label, k.vk, k.default_vk, k.pad});
    }
    ReleaseSRWLockShared(&g_lock);
    return out;
}

bool SetKey(const std::string& id, int vk) {
    bool found = false;
    AcquireSRWLockExclusive(&g_lock);
    for (Key& k : g_keys) {
        if (k.id != id) continue;
        k.vk = vk;
        k.name = KeyName(vk) + " (" + k.label + ")";
        k.was_down = true;  // (it's down right now: don't fire as the menu closes)
        found = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (found) alog::Write("hotkeys: %s is now %s", id.c_str(), KeyName(vk).c_str());
    return found;
}

bool SetPad(const std::string& id, unsigned buttons) {
    bool found = false;
    AcquireSRWLockExclusive(&g_lock);
    for (Key& k : g_keys) {
        if (k.id != id) continue;
        k.pad = buttons & kPadAll;
        k.pad_was_down = true;  // (held right now, maybe: don't fire at once)
        found = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (found) alog::Write("hotkeys: %s controller binding %s", id.c_str(), buttons ? PadName(buttons).c_str() : "cleared");
    return found;
}

std::string PadName(unsigned buttons) {
    static const struct {
        unsigned bit;
        const char* name;
    } kNames[] = {  // (modifier-like buttons first, as a chord reads: "Back + Button A")
        {kPadBack, "Back"}, {kPadStart, "Start"}, {kPadLeftBumper, "Left Bumper"}, {kPadRightBumper, "Right Bumper"},
        {kPadLeftTrigger, "Left Trigger"}, {kPadRightTrigger, "Right Trigger"}, {kPadLeftStick, "Left Stick"},
        {kPadRightStick, "Right Stick"}, {kPadDpadUp, "DPad Up"}, {kPadDpadDown, "DPad Down"}, {kPadDpadLeft, "DPad Left"},
        {kPadDpadRight, "DPad Right"}, {kPadA, "Button A"}, {kPadB, "Button B"}, {kPadX, "Button X"}, {kPadY, "Button Y"},
        // B40-1 (the game's own names: "Left Thumb Left", ...)
        {kPadLStickUp, "Left Thumb Up"}, {kPadLStickDown, "Left Thumb Down"}, {kPadLStickLeft, "Left Thumb Left"},
        {kPadLStickRight, "Left Thumb Right"}, {kPadRStickUp, "Right Thumb Up"}, {kPadRStickDown, "Right Thumb Down"},
        {kPadRStickLeft, "Right Thumb Left"}, {kPadRStickRight, "Right Thumb Right"},
    };
    std::string out;
    for (const auto& n : kNames) {
        if (!(buttons & n.bit)) continue;
        if (!out.empty()) out += " + ";
        out += n.name;
    }
    return out;
}

void SetPadCaptureHandler(void (*on_buttons)(unsigned buttons)) {
    AcquireSRWLockExclusive(&g_lock);
    g_pad_capture = on_buttons;
    g_pad_peak = 0;
    g_pad_wait_release = on_buttons != nullptr;
    ReleaseSRWLockExclusive(&g_lock);
}

std::vector<int> MenuKeysFor(unsigned pressed, unsigned now_down, unsigned menu_pad, int menu_vk) {
    std::vector<int> keys;
    // The menu's own binding (a chord: all down, one of them just pressed) closes it, like its key; except Back alone
    // (B40b: the default), which stays Escape in the menu (back out, closing at the top).
    if (menu_pad && menu_pad != kPadBack && (now_down & menu_pad) == menu_pad && (pressed & menu_pad)) {
        keys.push_back(menu_vk);
        return keys;
    }
    if (pressed & (kPadDpadUp | kPadLStickUp)) keys.push_back(VK_UP);
    if (pressed & (kPadDpadDown | kPadLStickDown)) keys.push_back(VK_DOWN);
    if (pressed & (kPadDpadLeft | kPadLStickLeft)) keys.push_back(VK_LEFT);
    if (pressed & (kPadDpadRight | kPadLStickRight)) keys.push_back(VK_RIGHT);
    if (pressed & kPadA) keys.push_back(VK_RETURN);
    // (the user: "make back work as the escape equivalent"; B40c: "B should also work as a back button in all
    // circumstances except waiting for a button map")
    if (pressed & (kPadBack | kPadB)) keys.push_back(VK_ESCAPE);
    return keys;
}

void SetRealXInput(XInputGetStateFn fn) { g_real_xinput = reinterpret_cast<GetStateFn>(fn); }

void PadStepForTests(unsigned buttons) {
    for (auto action : PadStep(buttons, mod_state::Active())) action();
}

std::string KeyName(int vk) {
    if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9')) return std::string(1, static_cast<char>(vk));
    if (vk >= VK_F1 && vk <= VK_F24) return "F" + std::to_string(vk - VK_F1 + 1);
    UINT scan = MapVirtualKeyA(static_cast<UINT>(vk), MAPVK_VK_TO_VSC);
    switch (vk) {  // extended keys: their names need the extended bit
        case VK_LEFT: case VK_RIGHT: case VK_UP: case VK_DOWN: case VK_PRIOR: case VK_NEXT: case VK_END: case VK_HOME:
        case VK_INSERT: case VK_DELETE: case VK_DIVIDE: case VK_NUMLOCK: case VK_RCONTROL: case VK_RMENU:
            scan |= 0x100;
            break;
        default:
            break;
    }
    char name[64] = {};
    if (scan && GetKeyNameTextA(static_cast<LONG>(scan << 16), name, sizeof(name)) > 0) return name;
    return "key " + std::to_string(vk);
}

void SetMenuHandler(void (*on_key)(int vk)) {
    AcquireSRWLockExclusive(&g_lock);
    g_menu = on_key;
    if (!on_key) {
        for (Key& k : g_keys) k.was_down = (GetAsyncKeyState(k.vk) & 0x8000) != 0;  // (no key fires on the way out)
    }
    ReleaseSRWLockExclusive(&g_lock);
}

}  // namespace hotkeys
