#pragma once
// Keyboard hotkeys, polled on a small background thread and only acted on while Shank's window
// is in the foreground. Registry of keys: docs/DESIGN.md "Hotkeys".
#include <string>
#include <vector>

namespace hotkeys {

// Starts polling. F9 (repeat last message) is always registered.
void Start();

// Registers a fixed key (F9, the test-mode keys); safe to call before or after Start(). The action runs on
// the poll thread.
void Add(int vk, const char* name, void (*action)());

// B13-2: a key the player can rebind in the settings menu. id = its [keys] name in shank_access_user.ini
// ("health"); label = its spoken name ("Health"). vk = the key to use now (the saved one, or the default).
void AddBindable(const char* id, int default_vk, int vk, const char* label, void (*action)());

struct Binding {
    std::string id, label;
    int vk = 0, default_vk = 0;
    unsigned pad = 0;  // B39: its controller buttons (a PadButton mask; 0 = not set)
};
std::vector<Binding> Bindings();                 // in registration order
bool SetKey(const std::string& id, int vk);      // false if no such id
std::string KeyName(int vk);                     // "H", "F7", "Page Up"

// B13-2 menu mode: while a handler is set, no hotkey fires; every key that goes down is passed to it
// (on the poll thread). nullptr = back to normal.
void SetMenuHandler(void (*on_key)(int vk));

// B39 (the user: "Add controller bindings for each key in the mod menu. Leave them undefined at this point"): a bindable
// key's controller binding, read from XInput (the first connected pad) on the poll thread. A binding is one button or
// several held together; it fires when all of them are down (the game uses every button, so chords are the useful kind).
enum PadButton : unsigned {  // XInput's wButtons bits, plus the triggers
    kPadDpadUp = 0x1, kPadDpadDown = 0x2, kPadDpadLeft = 0x4, kPadDpadRight = 0x8, kPadStart = 0x10, kPadBack = 0x20,
    kPadLeftStick = 0x40, kPadRightStick = 0x80, kPadLeftBumper = 0x100, kPadRightBumper = 0x200, kPadA = 0x1000,
    kPadB = 0x2000, kPadX = 0x4000, kPadY = 0x8000, kPadLeftTrigger = 0x10000, kPadRightTrigger = 0x20000,
    // B40-1: the sticks pushed past half way (the right stick is free in the game's default map)
    kPadLStickUp = 0x40000, kPadLStickDown = 0x80000, kPadLStickLeft = 0x100000, kPadLStickRight = 0x200000,
    kPadRStickUp = 0x400000, kPadRStickDown = 0x800000, kPadRStickLeft = 0x1000000, kPadRStickRight = 0x2000000,
};
constexpr unsigned kPadAll = 0x3fff3ff;
constexpr short kStickThreshold = 16384;  // (of 32767)
bool SetPad(const std::string& id, unsigned buttons);  // 0 clears; false if no such id
// The game's own names (its Controls screen): "Back + Button A"; "" for 0.
std::string PadName(unsigned buttons);
// B39 capture mode: while set, the buttons pressed together (the most held at once) are passed to it when all are let
// go (on the poll thread), and no controller binding fires. nullptr = back to normal.
void SetPadCaptureHandler(void (*on_buttons)(unsigned buttons));
// For tests: the poll thread's controller step, with a given button state.
void PadStepForTests(unsigned buttons);
// B40-3: in menu mode the pad drives the menu: DPad / left stick = the arrows, Button A = Enter, Back = Escape, and the
// mod menu's own controller binding = its key. Returns the keys for a newly pressed state (for tests too).
std::vector<int> MenuKeysFor(unsigned pressed, unsigned now_down, unsigned menu_pad, int menu_vk);
// B40-2: the real XInputGetState (input_block's hook passes the game an empty pad while blocking); nullptr = unhooked.
using XInputGetStateFn = unsigned long(__stdcall*)(unsigned long user, void* state);
void SetRealXInput(XInputGetStateFn fn);

// True if Shank's window is the foreground window (any thread).
bool GameIsForeground();

}  // namespace hotkeys
