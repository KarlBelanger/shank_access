#include "exe_check.h"

#include <windows.h>
#include <bcrypt.h>

#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>

std::string Sha256File(const wchar_t* path) {
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (file == INVALID_HANDLE_VALUE) return {};

    std::string result;
    BCRYPT_ALG_HANDLE alg = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    if (BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0)) &&
        BCRYPT_SUCCESS(BCryptCreateHash(alg, &hash, nullptr, 0, nullptr, 0, 0))) {
        std::vector<unsigned char> buf(1 << 16);
        DWORD read = 0;
        bool ok = true;
        while (ReadFile(file, buf.data(), static_cast<DWORD>(buf.size()), &read, nullptr) && read > 0) {
            if (!BCRYPT_SUCCESS(BCryptHashData(hash, buf.data(), read, 0))) { ok = false; break; }
        }
        unsigned char digest[32];
        if (ok && BCRYPT_SUCCESS(BCryptFinishHash(hash, digest, sizeof digest, 0))) {
            static const char hex[] = "0123456789abcdef";
            for (unsigned char b : digest) {
                result += hex[b >> 4];
                result += hex[b & 15];
            }
        }
    }
    if (hash) BCryptDestroyHash(hash);
    if (alg) BCryptCloseAlgorithmProvider(alg, 0);
    CloseHandle(file);
    return result;
}

namespace {

std::string FirstLine(const std::wstring& path) {
    std::ifstream f(path, std::ios::binary);
    std::string s;
    if (f) std::getline(f, s);
    while (!s.empty() && (s.back() == '\r' || s.back() == ' ' || s.back() == '\n')) s.pop_back();
    return s;
}

bool IsBuild(const std::string& s) { return s == "steam" || s == "classic"; }

}  // namespace

// B54-7: which game build the installed mod files were made for: "steam", "classic", or "" (can't tell). Setup and
// deploy.py write bin/shank_access_build.txt; without it, the patched scripts tell: only the Steam set patches Shank's
// shank_transitions.lua, only the classic set's stategraphutil.lua has A11Y_ClassicState.
std::string InstalledFilesBuild(const std::wstring& root) {
    const std::string b = FirstLine(root + L"\\bin\\shank_access_build.txt");
    if (IsBuild(b)) return b;
    if (GetFileAttributesW((root + L"\\data-pc\\stategraphs\\shank\\shank_transitions.lua").c_str()) != INVALID_FILE_ATTRIBUTES) {
        return "steam";
    }
    std::ifstream u(root + L"\\data-pc\\stategraphs\\stategraphutil.lua", std::ios::binary);
    if (u) {
        std::stringstream ss;
        ss << u.rdbuf();
        if (ss.str().find("A11Y_ClassicState") != std::string::npos) return "classic";
    }
    return std::string();
}

std::string InstalledModVersion(const std::wstring& root) { return FirstLine(root + L"\\bin\\shank_access_version.txt"); }

// ---- B55-2 / B56-1: one store of the mod's build-specific files per game build ---------------------------------------
namespace {

const wchar_t kStores[] = L"\\shank_access_builds";
const wchar_t kOldAside[] = L"\\shank_access_set_aside";  // (B55-2's single folder)
const char kMarker[] = "shank-access";  // every patch of ours writes this into its file (a comment)
// The build-specific files in bin (the DLLs, settings and UI text are the same for both builds).
const wchar_t* const kBinFiles[] = {L"\\bin\\shank_access_geometry.txt", L"\\bin\\shank_access_paths.txt",
                                    L"\\bin\\shank_access_paths.key", L"\\bin\\shank_access_build.txt"};

bool IsOurs(const std::wstring& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str().find(kMarker) != std::string::npos;
}

bool Exists(const std::wstring& path) { return GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES; }

// Every file under base + rel (rel with backslashes), recursively; lua_only: .lua files only.
void Files(const std::wstring& base, const std::wstring& rel, bool lua_only, std::vector<std::wstring>* out) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((base + rel + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        const std::wstring name = fd.cFileName;
        if (name == L"." || name == L"..") continue;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            Files(base, rel + L"\\" + name, lua_only, out);
        } else if (!lua_only || (name.size() > 4 && _wcsicmp(name.c_str() + name.size() - 4, L".lua") == 0)) {
            out->push_back(rel + L"\\" + name);
        }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

void MakeDirs(const std::wstring& path) {  // every folder of path's parent
    for (size_t i = 3; i < path.size(); ++i) {
        if (path[i] == L'\\') CreateDirectoryW(path.substr(0, i).c_str(), nullptr);
    }
}

// Removes dir's empty folders (deepest first), then dir itself if it's empty.
void RemoveEmptyTree(const std::wstring& dir) {
    std::vector<std::wstring> dirs = {dir};
    for (size_t i = 0; i < dirs.size(); ++i) {
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((dirs[i] + L"\\*").c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) continue;
        do {
            const std::wstring name = fd.cFileName;
            if (name != L"." && name != L".." && (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) dirs.push_back(dirs[i] + L"\\" + name);
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    for (size_t i = dirs.size(); i-- > 0;) RemoveDirectoryW(dirs[i].c_str());
}

void RemoveTree(const std::wstring& dir) {
    std::vector<std::wstring> files;
    Files(dir, L"", false, &files);
    for (const std::wstring& rel : files) DeleteFileW((dir + rel).c_str());
    RemoveEmptyTree(dir);
}

bool Move(const std::wstring& from, const std::wstring& to) {
    MakeDirs(to);
    return MoveFileExW(from.c_str(), to.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_COPY_ALLOWED) != 0;
}

}  // namespace

std::wstring StoreDir(const std::wstring& root, const std::string& build) {
    return root + kStores + L"\\" + std::wstring(build.begin(), build.end());
}

void MigrateOldSetAside(const std::wstring& root) {
    const std::wstring old = root + kOldAside;
    if (!Exists(old)) return;
    const std::string b = FirstLine(old + L"\\build.txt");
    if (IsBuild(b) && !Exists(StoreDir(root, b))) {
        MakeDirs(StoreDir(root, b) + L"\\");
        if (MoveFileExW(old.c_str(), StoreDir(root, b).c_str(), 0)) return;  // (made_by unknown: not used, setup replaces it)
    }
    RemoveTree(old);
}

size_t StashBuildFiles(const std::wstring& root, const std::string& files_for, const std::string& made_by) {
    const std::wstring store = StoreDir(root, files_for);
    RemoveTree(store);  // (an older store of the same build: replaced as a whole)
    size_t moved = 0;
    std::vector<std::wstring> rels;
    Files(root, L"\\data-pc", true, &rels);
    for (const std::wstring& rel : rels) {
        if (!IsOurs(root + rel)) continue;  // (the game's own data-pc scripts stay)
        if (Move(root + rel, store + rel)) ++moved;
    }
    RemoveEmptyTree(root + L"\\data-pc\\stategraphs");  // (only the folders our patches made; the game's own have files)
    for (const wchar_t* rel : kBinFiles) {
        if (Exists(root + rel) && Move(root + rel, store + rel)) ++moved;
    }
    MakeDirs(store + L"\\");
    std::ofstream m(store + L"\\made_by.txt", std::ios::binary | std::ios::trunc);
    m << made_by << "\n";
    std::ofstream b(store + L"\\build.txt", std::ios::binary | std::ios::trunc);
    b << files_for << "\n";
    return moved;
}

bool StoreUsable(const std::wstring& root, const std::string& build, const std::string& made_by) {
    const std::wstring store = StoreDir(root, build);
    return FirstLine(store + L"\\build.txt") == build && Exists(store + L"\\made_by.txt") &&
           FirstLine(store + L"\\made_by.txt") == made_by && Exists(store + L"\\bin\\shank_access_paths.txt");
}

bool SetupRunning(const std::wstring& root) {
    const std::wstring lock = root + L"\\shank_access_setup.lock";
    WIN32_FILE_ATTRIBUTE_DATA a;
    if (!GetFileAttributesExW(lock.c_str(), GetFileExInfoStandard, &a)) return false;
    FILETIME now_ft;
    GetSystemTimeAsFileTime(&now_ft);
    ULARGE_INTEGER now, written;
    now.LowPart = now_ft.dwLowDateTime;
    now.HighPart = now_ft.dwHighDateTime;
    written.LowPart = a.ftLastWriteTime.dwLowDateTime;
    written.HighPart = a.ftLastWriteTime.dwHighDateTime;
    const unsigned long long kMaxAge = 60ull * 60 * 10000000;  // 60 minutes in 100 ns units (an older lock is stale)
    if (now.QuadPart > written.QuadPart && now.QuadPart - written.QuadPart > kMaxAge) return false;
    const unsigned long pid = std::strtoul(FirstLine(lock).c_str(), nullptr, 10);
    if (pid == 0) return false;
    HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!p) return false;  // (setup ended without removing it: stale)
    DWORD code = 0;
    const bool alive = GetExitCodeProcess(p, &code) && code == STILL_ACTIVE;
    CloseHandle(p);
    return alive;
}

size_t UnstashBuildFiles(const std::wstring& root, const std::string& build) {
    const std::wstring store = StoreDir(root, build);
    std::vector<std::wstring> rels;
    Files(store, L"", false, &rels);
    size_t moved = 0;
    for (const std::wstring& rel : rels) {
        if (_wcsicmp(rel.c_str(), L"\\made_by.txt") == 0 || _wcsicmp(rel.c_str(), L"\\build.txt") == 0) continue;
        if (Move(store + rel, root + rel)) ++moved;
    }
    RemoveTree(store);
    RemoveEmptyTree(root + kStores);
    return moved;
}
