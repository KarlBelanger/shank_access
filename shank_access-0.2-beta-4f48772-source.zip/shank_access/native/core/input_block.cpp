#include "input_block.h"

#include "MinHook.h"
#include "hotkeys.h"
#include "log.h"

namespace input_block {
namespace {

using GetRawInputDataFn = UINT(WINAPI*)(HRAWINPUT, UINT, LPVOID, PUINT, UINT);
GetRawInputDataFn g_orig = nullptr;
volatile LONG g_blocking = 0;
bool g_down[256] = {};  // (only touched on the game's window thread)

UINT WINAPI HookGetRawInputData(HRAWINPUT input, UINT command, LPVOID data, PUINT size, UINT header_size) {
    const UINT r = g_orig(input, command, data, size, header_size);
    if (command == RID_INPUT && data && r != static_cast<UINT>(-1) && r >= sizeof(RAWINPUTHEADER) + sizeof(RAWKEYBOARD)) {
        RAWINPUT* raw = static_cast<RAWINPUT*>(data);
        if (raw->header.dwType == RIM_TYPEKEYBOARD) Filter(&raw->data.keyboard, InterlockedCompareExchange(&g_blocking, 0, 0) != 0, g_down);
    }
    return r;
}

// B40-2: the pad too. While blocking, the game's XInputGetState reads an empty pad; after it, a button still held from
// the menu (Button A choosing a checkpoint) stays hidden until let go, so it isn't a jump.
using XInputGetStateFn = DWORD(WINAPI*)(DWORD, void*);
XInputGetStateFn g_orig_xinput = nullptr;
volatile LONG g_pad_hidden = 0;  // buttons held when blocking ended (still hidden)
volatile LONG g_was_blocking = 0;

DWORD WINAPI HookXInputGetState(DWORD user, void* state) {
    const DWORD r = g_orig_xinput(user, state);
    if (r != ERROR_SUCCESS || !state) return r;
    const bool blocking = InterlockedCompareExchange(&g_blocking, 0, 0) != 0;
    WORD* buttons = reinterpret_cast<WORD*>(static_cast<unsigned char*>(state) + 4);  // XINPUT_STATE.Gamepad.wButtons
    const WORD held = PadFilter(buttons, blocking, InterlockedCompareExchange(&g_was_blocking, 0, 0) != 0,
                                static_cast<WORD>(InterlockedCompareExchange(&g_pad_hidden, 0, 0)));
    InterlockedExchange(&g_pad_hidden, held);
    InterlockedExchange(&g_was_blocking, blocking ? 1 : 0);
    if (blocking) memset(static_cast<unsigned char*>(state) + 4, 0, 12);  // (buttons, triggers, sticks)
    return r;
}

// B40d (the user: "the controller still moves through the active menu if the mod menu is opened outside of a level"):
// the game's menus read XInputGetKeystroke (its import #8); while blocking, the keystrokes are taken and dropped.
using XInputGetKeystrokeFn = DWORD(WINAPI*)(DWORD, DWORD, void*);
XInputGetKeystrokeFn g_orig_keystroke = nullptr;
constexpr DWORD kErrorEmpty = 0x10D4;  // ERROR_EMPTY: no keystroke waiting

DWORD WINAPI HookXInputGetKeystroke(DWORD user, DWORD reserved, void* keystroke) {
    const DWORD r = g_orig_keystroke(user, reserved, keystroke);
    if (r == ERROR_SUCCESS && InterlockedCompareExchange(&g_blocking, 0, 0) != 0) return kErrorEmpty;
    return r;
}

}  // namespace

WORD PadFilter(WORD* buttons, bool blocking, bool was_blocking, WORD hidden) {
    if (blocking) return *buttons;  // (all hidden; these stay hidden after it until let go)
    (void)was_blocking;
    hidden = static_cast<WORD>(hidden & *buttons);  // (a released button is the game's again)
    *buttons = static_cast<WORD>(*buttons & ~hidden);
    return hidden;
}

void Filter(RAWKEYBOARD* k, bool blocking, bool down[256]) {
    const USHORT vk = k->VKey;
    const bool release = (k->Flags & RI_KEY_BREAK) != 0;
    if (!blocking) {
        if (vk >= 256) return;
        if (release && !down[vk]) {  // the release of a key pressed while blocking (Escape closing our menu): hidden too
            k->VKey = 0xFF;
            k->MakeCode = 0;
            return;
        }
        down[vk] = !release;
        return;
    }
    if (vk < 256 && down[vk]) {
        down[vk] = false;  // the game gets this key's release now (it was held when the menu opened)
    } else {
        k->VKey = 0xFF;     // (reserved: no binding uses it)
        k->MakeCode = 0;
    }
    k->Flags |= RI_KEY_BREAK;
    k->Message = WM_KEYUP;
}

bool Install() {
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) return false;
    void* target = nullptr;
    st = MH_CreateHookApiEx(L"user32", "GetRawInputData", reinterpret_cast<void*>(&HookGetRawInputData),
                            reinterpret_cast<void**>(&g_orig), &target);
    if (st == MH_OK) st = MH_EnableHook(target);
    alog::Write("hook GetRawInputData: %s", st == MH_OK ? "installed" : MH_StatusToString(st));
    const bool keys = st == MH_OK;
    // B40-2: the game's XInput (a static import: already loaded).
    void* pad_target = nullptr;
    MH_STATUS ps = MH_CreateHookApiEx(L"xinput1_3", "XInputGetState", reinterpret_cast<void*>(&HookXInputGetState),
                                      reinterpret_cast<void**>(&g_orig_xinput), &pad_target);
    if (ps == MH_OK) ps = MH_EnableHook(pad_target);
    alog::Write("hook XInputGetState: %s", ps == MH_OK ? "installed" : MH_StatusToString(ps));
    if (ps == MH_OK) hotkeys::SetRealXInput(reinterpret_cast<hotkeys::XInputGetStateFn>(g_orig_xinput));
    void* key_target = nullptr;  // B40d
    MH_STATUS ks = MH_CreateHookApiEx(L"xinput1_3", "XInputGetKeystroke", reinterpret_cast<void*>(&HookXInputGetKeystroke),
                                      reinterpret_cast<void**>(&g_orig_keystroke), &key_target);
    if (ks == MH_OK) ks = MH_EnableHook(key_target);
    alog::Write("hook XInputGetKeystroke: %s", ks == MH_OK ? "installed" : MH_StatusToString(ks));
    return keys;
}

void SetBlocking(bool on) {
    InterlockedExchange(&g_blocking, on ? 1 : 0);
    alog::Write("input block: %s", on ? "on (the game gets no keys)" : "off");
}

}  // namespace input_block
