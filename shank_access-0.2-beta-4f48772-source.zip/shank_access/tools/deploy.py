"""Deploy / uninstall shank-access into a Shank install, safely and reversibly.

The ONLY tool that writes to the game folder. Nothing Klei-owned is stored in the repo:
we ship our own files plus patches that are applied to the pristine originals.

Mod sources (repo):
  mod/files/<game-relative path>                   copied verbatim (our own files)
  mod/patches/<game-relative path>.patch.json      text ops applied to the pristine original. A patch of a
                                                   data/ file is written to the same path under data-pc/
                                                   (a NEW file: the game's PhysFS searches data-pc before
                                                   data), so no file of the game's own is changed and
                                                   Steam's "verify integrity" has nothing to undo
                                                   (2026-09-27; RE-NOTES "File system search order")
  mod/pristine.json                                SHA-256 of every Klei file we patch/replace
  mod/artifacts.json                               {"game/relative/path": "build/... output"} for built files
                                                   (DLLs); deploy fails if an artifact has not been built

Patch file format:
  {"ops": [
     {"op": "replace", "find": "...", "with": "...", "count": 1},
     {"op": "insert_after",  "anchor": "...", "text": "..."},
     {"op": "insert_before", "anchor": "...", "text": "..."},
     {"op": "append", "text": "..."}
  ]}
  Matching is done on LF-normalised text; the original line endings are restored on write.
  "count" (default 1) is the exact number of occurrences required; anchors must be unique.

State and backups live OUTSIDE the repo and the game folder:
  %LOCALAPPDATA%/shank-access/deploy/state.json
  %LOCALAPPDATA%/shank-access/deploy/originals/<game-relative path>

Commands:
  plan        show what deploy would do (no writes)
  deploy      apply the mod (asks for confirmation unless --yes)
  status      show deployed files and whether they're still intact
  verify      exit 1 if any deployed file was changed (e.g. by Steam "verify integrity")
  uninstall   restore originals and remove added files
  record-pristine PATH... | -   store SHA-256 of pristine game files in mod/pristine.json
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_GAME_DIR = os.environ.get("SHANK_GAME_DIR", r"C:/Program Files (x86)/Steam/steamapps/common/Shank")
DEFAULT_STATE_DIR = os.environ.get(
    "SHANK_ACCESS_STATE_DIR",
    os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "shank-access", "deploy"))


class DeployError(Exception):
    pass


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def read_bytes(path):
    with open(path, "rb") as f:
        return f.read()


def sha256_file(path):
    with open(path, "rb") as f:
        return sha256_bytes(f.read())


def norm(rel):
    return rel.replace("\\", "/").strip("/")


def override_path(rel):
    """Where a patched copy of the game file `rel` is written: data/x -> data-pc/x (a new file that the game's
    PhysFS finds first); anything else in place."""
    return "data-pc/" + rel[len("data/"):] if rel.startswith("data/") else rel


def apply_ops(original: bytes, ops, label):
    text = original.decode("latin-1")
    crlf = "\r\n" in text
    text = text.replace("\r\n", "\n")
    for i, op in enumerate(ops):
        kind = op["op"]
        where = "%s op #%d (%s)" % (label, i, kind)
        if kind == "replace":
            find, repl = op["find"], op["with"]
            want = op.get("count", 1)
            got = text.count(find)
            if got != want:
                raise DeployError("%s: expected %d match(es) of find text, found %d" % (where, want, got))
            text = text.replace(find, repl)
        elif kind in ("insert_after", "insert_before"):
            anchor = op["anchor"]
            got = text.count(anchor)
            if got != 1:
                raise DeployError("%s: anchor must match exactly once, found %d" % (where, got))
            idx = text.index(anchor)
            if kind == "insert_after":
                idx += len(anchor)
            text = text[:idx] + op["text"] + text[idx:]
        elif kind == "append":
            if not text.endswith("\n"):
                text += "\n"
            text += op["text"]
        else:
            raise DeployError("%s: unknown op" % where)
    if crlf:
        text = text.replace("\n", "\r\n")
    return text.encode("latin-1")


class Deployer:
    def __init__(self, game_dir, state_dir, mod_dir=None, pristine_path=None):
        self.game = os.path.abspath(game_dir)
        self.state_dir = os.path.abspath(state_dir)
        self.mod = mod_dir or os.path.join(REPO, "mod")
        self.repo = os.path.dirname(os.path.abspath(self.mod))  # artifact paths are relative to this
        self.pristine_path = pristine_path or os.path.join(self.mod, "pristine.json")
        self.orig_dir = os.path.join(self.state_dir, "originals")
        self.state_path = os.path.join(self.state_dir, "state.json")

    # ---- persistence -------------------------------------------------
    def load_state(self):
        if os.path.exists(self.state_path):
            with open(self.state_path, encoding="utf-8") as f:
                return json.load(f)
        return {"game_dir": self.game, "files": {}}

    def save_state(self, state):
        os.makedirs(self.state_dir, exist_ok=True)
        tmp = self.state_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=1, sort_keys=True)
        os.replace(tmp, self.state_path)

    def load_pristine(self):
        if os.path.exists(self.pristine_path):
            with open(self.pristine_path, encoding="utf-8") as f:
                return json.load(f)
        return {}

    # ---- helpers ------------------------------------------------------
    def gpath(self, rel):
        return os.path.join(self.game, *rel.split("/"))

    def opath(self, rel):
        return os.path.join(self.orig_dir, *rel.split("/"))

    def check_game_dir(self):
        if not os.path.isfile(os.path.join(self.game, "bin", "Shank.exe")):
            raise DeployError("Not a Shank install (bin/Shank.exe missing): %s" % self.game)

    def mod_entries(self):
        """Yield (rel, kind, source_path) for everything the mod provides."""
        files_root = os.path.join(self.mod, "files")
        for root, _, names in os.walk(files_root):
            for n in names:
                if n == ".gitkeep":
                    continue
                src = os.path.join(root, n)
                yield norm(os.path.relpath(src, files_root)), "file", src
        patch_root = os.path.join(self.mod, "patches")
        for root, _, names in os.walk(patch_root):
            for n in names:
                if n.endswith(".patch.json"):
                    src = os.path.join(root, n)
                    yield norm(os.path.relpath(src, patch_root))[:-len(".patch.json")], "patch", src
        artifacts = os.path.join(self.mod, "artifacts.json")
        if os.path.exists(artifacts):  # built outputs (e.g. DLLs) that must not be committed
            with open(artifacts, encoding="utf-8") as f:
                for rel, src in json.load(f).items():
                    src = src if os.path.isabs(src) else os.path.join(self.repo, src)
                    yield norm(rel), "artifact", src

    def pristine_bytes(self, rel, state, pristine):
        """Return the original bytes for rel (None if the file doesn't exist in vanilla)."""
        entry = state["files"].get(rel)
        if entry is not None:  # already deployed once: the backup is the source of truth
            if entry["original_sha256"] is None:
                return None
            with open(self.opath(rel), "rb") as f:
                return f.read()
        gp = self.gpath(rel)
        if not os.path.exists(gp):
            return None
        data = read_bytes(gp)
        want = pristine.get(rel)
        if want is None:
            raise DeployError("%s exists in the game but has no pristine hash; run "
                              "'deploy.py record-pristine %s' while the game is vanilla" % (rel, rel))
        if sha256_bytes(data) != want:
            raise DeployError("%s does not match its pristine hash (modified or game updated). "
                              "Restore it (Steam > Verify integrity) before deploying." % rel)
        return data

    def build(self, state):
        """Compute the desired final bytes for every mod entry: [(rel, kind, original, new)].
        rel = where it goes in the game folder; original = what's there now in vanilla (None = a new file)."""
        pristine = self.load_pristine()
        out = []
        for rel, kind, src in sorted(self.mod_entries()):
            if kind == "artifact" and not os.path.isfile(src):
                raise DeployError("build artifact missing for %s: %s (build it first)" % (rel, src))
            if kind in ("file", "artifact"):
                out.append((rel, kind, self.pristine_bytes(rel, state, pristine), read_bytes(src)))
                continue
            source = self.pristine_bytes(rel, state, pristine)  # the game's own file the patch applies to
            if source is None:
                raise DeployError("patch target does not exist in the game: %s" % rel)
            with open(src, encoding="utf-8") as f:
                spec = json.load(f)
            new = apply_ops(source, spec["ops"], rel)
            target = override_path(rel)
            out.append((target, kind, source if target == rel else self.pristine_bytes(target, state, pristine), new))
        return out

    # ---- commands -----------------------------------------------------
    def plan(self):
        self.check_game_dir()
        state = self.load_state()
        actions = []
        for rel, kind, original, new in self.build(state):
            cur = self.gpath(rel)
            cur_sha = sha256_file(cur) if os.path.exists(cur) else None
            if cur_sha == sha256_bytes(new):
                verb = "unchanged"
            elif original is None:
                verb = "update" if cur_sha is not None else "add"
            else:
                verb = "patch" if kind == "patch" else "replace"
            actions.append((verb, rel))
        wanted = {a[1] for a in actions}
        for rel in sorted(state["files"]):
            if rel not in wanted:
                restores = state["files"][rel]["original_sha256"] is not None
                actions.append(("restore original" if restores else "remove (no longer in mod)", rel))
        return actions

    def deploy(self):
        self.check_game_dir()
        ensure_game_not_running()
        state = self.load_state()
        state["game_dir"] = self.game
        built = self.build(state)  # everything validated before any write
        wanted = set()
        for rel, kind, original, new in built:
            wanted.add(rel)
            entry = state["files"].get(rel)
            if entry is None:
                entry = {"kind": kind, "original_sha256": None}
                if original is not None:
                    os.makedirs(os.path.dirname(self.opath(rel)), exist_ok=True)
                    with open(self.opath(rel), "wb") as f:
                        f.write(original)
                    entry["original_sha256"] = sha256_bytes(original)
                state["files"][rel] = entry
                self.save_state(state)  # record the backup before touching the game file
            gp = self.gpath(rel)
            os.makedirs(os.path.dirname(gp), exist_ok=True)
            with open(gp, "wb") as f:
                f.write(new)
            entry["kind"] = kind
            entry["deployed_sha256"] = sha256_bytes(new)
            self.save_state(state)
        for rel in sorted(set(state["files"]) - wanted):  # entries dropped from the mod
            self.restore(rel, state)
        return sorted(wanted)

    def restore(self, rel, state):
        entry = state["files"][rel]
        gp = self.gpath(rel)
        if entry["original_sha256"] is None:
            if os.path.exists(gp):
                os.remove(gp)
                try:  # (the folders we made for it, if now empty; stops at the first non-empty one)
                    os.removedirs(os.path.dirname(gp))
                except OSError:
                    pass
        else:
            os.makedirs(os.path.dirname(gp), exist_ok=True)
            shutil.copyfile(self.opath(rel), gp)
            os.remove(self.opath(rel))
        del state["files"][rel]
        self.save_state(state)

    def uninstall(self):
        self.check_game_dir()
        ensure_game_not_running()
        state = self.load_state()
        done = []
        for rel in sorted(state["files"]):
            self.restore(rel, state)
            done.append(rel)
        return done

    def status(self):
        state = self.load_state()
        rows = []
        for rel, entry in sorted(state["files"].items()):
            gp = self.gpath(rel)
            cur = sha256_file(gp) if os.path.exists(gp) else None
            if cur == entry.get("deployed_sha256"):
                s = "ok"
            elif cur == entry.get("original_sha256"):
                s = "REVERTED (original is back, e.g. Steam verify)"
            elif cur is None:
                s = "MISSING"
            else:
                s = "CHANGED since deploy"
            rows.append((rel, entry["kind"], "added" if entry["original_sha256"] is None else "backed up", s))
        return rows

    def record_pristine(self, rels):
        self.check_game_dir()
        state = self.load_state()
        pristine = self.load_pristine()
        for rel in map(norm, rels):
            if rel in state["files"]:
                raise DeployError("%s is currently deployed; uninstall first" % rel)
            pristine[rel] = sha256_file(self.gpath(rel))
        os.makedirs(os.path.dirname(self.pristine_path), exist_ok=True)
        with open(self.pristine_path, "w", encoding="utf-8") as f:
            json.dump(pristine, f, indent=1, sort_keys=True)
            f.write("\n")
        return pristine


def ensure_game_not_running():
    if os.name != "nt" or os.environ.get("SHANK_ACCESS_SKIP_PROCESS_CHECK"):
        return
    out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Shank.exe", "/NH"],
                         capture_output=True, text=True).stdout
    if "Shank.exe" in out:
        raise DeployError("Shank.exe is running; quit the game first")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["plan", "deploy", "status", "verify", "uninstall", "record-pristine"])
    ap.add_argument("paths", nargs="*")
    ap.add_argument("--game-dir", default=DEFAULT_GAME_DIR)
    ap.add_argument("--state-dir", default=DEFAULT_STATE_DIR)
    ap.add_argument("--yes", action="store_true", help="don't ask for confirmation")
    args = ap.parse_args(argv)
    d = Deployer(args.game_dir, args.state_dir)
    try:
        if args.command == "plan":
            for verb, rel in d.plan():
                print("%-26s %s" % (verb, rel))
        elif args.command == "deploy":
            actions = [a for a in d.plan() if a[0] != "unchanged"]
            if not actions:
                print("Nothing to do.")
                return 0
            for verb, rel in actions:
                print("%-26s %s" % (verb, rel))
            if not args.yes and input("Write these changes to %s? [y/N] " % d.game).strip().lower() != "y":
                print("Aborted.")
                return 1
            d.deploy()
            print("Deployed. Backups in", d.orig_dir)
        elif args.command in ("status", "verify"):
            rows = d.status()
            if not rows:
                print("Nothing deployed.")
            for row in rows:
                print("%-60s %-6s %-10s %s" % row)
            if args.command == "verify" and any(r[3] != "ok" for r in rows):
                return 1
        elif args.command == "uninstall":
            done = d.uninstall()
            print("Restored %d file(s)." % len(done) if done else "Nothing deployed.")
        elif args.command == "record-pristine":
            paths = args.paths
            if paths == ["-"]:  # read one path per line from stdin (for long lists)
                paths = [line.strip() for line in sys.stdin if line.strip()]
            if not paths:
                ap.error("record-pristine needs game-relative paths (or '-' to read them from stdin)")
            d.record_pristine(paths)
            print("Recorded %d path(s)" % len(paths))
    except DeployError as e:
        print("ERROR:", e, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
