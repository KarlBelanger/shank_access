#pragma once
// Small in-memory code patches to Shank.exe (never on disk). Each one checks the exact original
// bytes first and does nothing if they differ.
namespace patches {

// TESTING ARTIFACTS (user instruction, 2026-09-24). They speed up restarts during testing. Since B18
// (the user, 2026-09-27) they are applied only when test mode is on at start-up (F3; see test_mode.h).

// Skips the FIRST startup movie (introscee.usm): the unskippable logo sequence with its own music.
bool SkipLogoMovie();

// Skips the SECOND startup movie (introtomain.usm), which is skippable anyway.
bool SkipIntroMovie();

}  // namespace patches
