# shank-access

An accessibility mod for **Shank** (Klei Entertainment, 2010), the Steam PC version. The goal is to make the game fully playable with a screen reader and audio cues.

**Status:** early development. See [docs/PLAN.md](docs/PLAN.md) for the phased plan and the current status.

## Planned features
- Screen-reader output (via Tolk) for menus, dialogs and tutorial text.
- Spoken status: health, grenades, weapons, combo, boss health.
- Positional audio cues for:
  - ledges, drops and deadly pits;
  - hazards;
  - item pickups;
  - enemies, including idle enemies and attack wind-ups.
- Navigation aids: active cues (platform overhead, jump target in range), a waypoint beacon toward the next checkpoint, and an explore mode.

## How it works
- The mod never ships Klei's files. It consists of our own files plus small patches that `tools/deploy.py` applies to your installed game.
- Deploying backs up every file it touches, and `uninstall` restores them.
- A small native DLL, loaded through a `dinput8.dll` proxy, plays the cues and talks to your screen reader. It works out most cues itself from the level's collision data and Shank's live position; small patches to the game scripts report pickups and Shank's position.

## Requirements (development)
- Windows 10/11, Shank on Steam.
- Visual Studio 2022 Build Tools (C++ with the x86 compiler), CMake, Python 3.12+.

```bash
py -m venv .venv
.venv/Scripts/python -m pip install -r requirements.txt
.venv/Scripts/python -m unittest discover -s tests
```

## Licence
Our code: to be decided. Third-party code keeps its own licence: Lua 5.0.3 (MIT) is in `third_party/lua-5.0.3`; MinHook v1.3.4 (BSD 2-clause) is in `third_party/minhook`; Tolk (LGPL-3.0, commit e5149f0) and its screen reader client DLLs (NVDA controller client: LGPL-2.1, see `LICENSE-NVDA.txt`) are in `third_party/tolk`. Tolk is built as a separate DLL and loaded at runtime.
