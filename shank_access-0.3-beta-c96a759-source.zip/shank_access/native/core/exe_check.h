#pragma once
#include <string>

// Every hard-coded address in this mod is only valid for the Shank.exe builds in game.h (docs/RE-NOTES.md);
// game::Select picks the table by this hash (B49: the Steam build and the classic branch).

// Lower-case hex SHA-256 of the file, or an empty string on failure.
std::string Sha256File(const wchar_t* path);

// B54-7: the game build the installed mod files in the game folder `root` were made for: "steam", "classic", or "" (can't
// tell). Setup and deploy.py write bin/shank_access_build.txt; without it, the patched scripts tell (only the Steam set
// patches Shank's shank_transitions.lua; only the classic set's stategraphutil.lua has A11Y_ClassicState).
std::string InstalledFilesBuild(const std::wstring& root);

// B55-2 / B56-1 (the user, 2026-10-10: "Have the mod move its files on a version mismatch." / switching without setup):
// the mod's build-specific files (the data-pc scripts with the "shank-access" marker every patch writes, and bin's
// geometry, paths, paths.key and build.txt) are kept per game build in <root>\shank_access_builds\<build>\ (with
// made_by.txt = the installed mod version they came with). Setup and deploy.py write and clear these stores too.
std::string InstalledModVersion(const std::wstring& root);  // bin/shank_access_version.txt ("" for a dev deploy)
std::wstring StoreDir(const std::wstring& root, const std::string& build);
size_t StashBuildFiles(const std::wstring& root, const std::string& files_for, const std::string& made_by);  // active -> store
bool StoreUsable(const std::wstring& root, const std::string& build, const std::string& made_by);  // made by this version
size_t UnstashBuildFiles(const std::wstring& root, const std::string& build);  // store -> active (the store removed)
void MigrateOldSetAside(const std::wstring& root);  // B55-2's shank_access_set_aside: kept as a store of its build

// B57-2 (the user, 2026-10-11: "Build the safeties"): setup is installing or uninstalling in `root` right now: its
// shank_access_setup.lock names a process that's still running and is under 60 minutes old. The mod then leaves its
// files to setup and stays off for that game.
bool SetupRunning(const std::wstring& root);
