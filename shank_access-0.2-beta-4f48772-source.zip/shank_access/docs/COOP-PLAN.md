# Solo co-op: implementation plan (not started)

A plan for playing Shank's co-op campaign alone: the mod follows the player's own character, and a bot plays the other one
through a virtual controller. Written 2026-10-01 at the user's request: "Build out an implementation plan similar to the
one for the main mod in case I ever decide to take this on." Nothing here is built. Co-op stays out of scope for the main
mod (PLAN Decision log, 2026-09-29 and 2026-10-01).

Same working rules as the main mod (CLAUDE.md): batches with test points, docs written as things happen, Lua 5.0 only,
the game folder changed only through `tools/deploy.py`.

## 1. What we know (2026-10-01)

- **From the co-op session's log** (`build/logs/20261001-152442-coop`, coop_1_bikersinabrothel and coop_1_getthosebikerboys):
  - The two players are Shank characters on two teams (24 / 25), with attributes `shank.lua`, `shank2.lua`, `shank_mp.lua`.
  - The mod's "which character is Shank" flipped between them 2,656 times in about 15 minutes, because it takes the
    `shank*` character nearest the tracked spot.
  - Each player has their own HUD block (`HUD.player1`, `HUD.player2`). The mod reads only player1's.
  - The co-op levels (`coop_*`) have no extracted geometry or paths, so there are no edge, wall, jump or waypoint cues.
  - The lobby (`multiplayerlobby.gfx`) has a join button per player (`_level0.player0.readyBtn` "JOIN" ...).
- **From the user (2026-10-01):**
  - "One player can never get more than a screen in front of the other. The game doesn't let the leading player get
    further if the trailing is at the far left edge of the screen."
  - "if one player dies from enemies they remain on the ground an can be revived by the other player with the usual
    down+grappel pickup command."
  - "There are two join buttons in the lobby, and it just matters which device hits which join button. P1 is shank and p2
    is his partner."
  - No friendly fire; who gets a kill doesn't matter; reviving is the only direct interaction seen ("From my limited
    testing revival seems to be the only way the two directly interact").
  - Pit deaths are untested. The user's guess: "they would regenerate as a downed player at the spawn point or at the
    nearest safe spot on screen."
- **The game's AI can't be reused for P2.** Goon behaviour is engine code: `data/strategizers/defaultstrategizer.lua` is
  empty, and `data/strategy.lua` only holds attack, hit, shot and grapple-ignore timings. P2 is a Shank driven by an input
  device.

## 2. Architecture (target)

- **Session player**: which player the human is (P1 or P2), picked in the lobby and kept for the session. Every
  Shank-centred part of the mod uses that character:
  - the position tracker and the Lua ping, which needs a player index;
  - enemy cues and the enemy list, which must not count either player as an enemy;
  - status readouts (the HUD block of that player);
  - pickups, edges, jump targets and waypoints;
  - the game-sound pan centre.
- **Virtual pad**: the XInputGetState / XInputGetKeystroke hooks (`input_block`, B40) report a connected pad on a free
  index and return the bot's buttons and sticks each frame. The human's own devices pass through untouched.
- **Bot** (`native/core/coop_bot.*`): reads the bot character's position and state, the human's, and the enemies. It
  decides the inputs on the cue thread's tick and hands them to the virtual pad.
- **Co-op level data**: `extract_levels.py`, `geometry.py` and `path_graph` run over the `coop_*` levels too.

## 3. Phases

### Phase C0: knowledge (RE and one supervised test)
- [ ] C0-1 The two Shanks: how to tell P1's item from P2's (their team ids, attributes `shank2` / `shank_mp`, an index in
  the item, or the order they're created). Confirm from a log with both moving.
- [ ] C0-2 The Lua position ping per player: make the patched Shank stategraph report its player index
  (`a11y/pos_<index>_...`), or find a Lua accessor for it.
- [ ] C0-3 Lobby: the join buttons' names and events for both players; what pressing join with a pad sends.
- [ ] C0-4 Downed state: the state names for down / revive (the Shank stategraph); how the revive is triggered
  (Down + Grapple near the partner); what the partner sees.
- [ ] C0-5 **Pit death in co-op** (the user's suggestion: build just enough to get there, then get P2 killed): needs C1
  and the most basic C2 (a pad that only walks), then a test: walk the bot into a pit and watch the log for where it comes
  back (the spawn point, a safe spot on screen) and in what state.

### Phase C1: the mod follows one player in co-op
- [ ] C1-1 Session player: pick it from the lobby's join press (P1 or P2); keep it for the session; F7 shows it.
- [ ] C1-2 Tracker and enemies: follow the session player's character only (no flipping); the other player is neither
  Shank nor an enemy (a "partner" class: its own quiet cue, or none, to decide with the user).
- [ ] C1-3 Status: health, grenades and combo from the session player's HUD block.
- [ ] C1-4 Co-op level data: geometry, paths and checkpoints for the `coop_*` levels; the waypoint goals (the co-op
  campaign's checkpoints and story goals).
- [ ] C1-5 Test point C1: the user plays co-op with a second device on P2 (or P2 idle): the mod follows the right one and
  its cues work in co-op levels.

### Phase C2: the virtual pad
- [ ] C2-1 A connected pad on a free XInput index (GetState, GetCapabilities, GetKeystroke), off unless solo co-op is on
  (a setting, F7).
- [ ] C2-2 Lobby: the mod presses join on the button the human didn't use.
- [ ] C2-3 A scripted input source for tests (hold right, jump every N seconds), then the bot's.
- [ ] C2-4 Test point C2: P2 joins on its own and walks; then C0-5's pit test.

### Phase C3: the bot, following
- [ ] C3-1 Follow: stay within a screen of the human (the game holds the leader anyway), on the same floor where
  possible; walk toward them, stop near them.
- [ ] C3-2 Traversal: use the path graph toward the human's spot (the same jump model and launch windows as the cues),
  jump when the path says, retry or wait when a jump fails; never into a pit if it can be helped.
- [ ] C3-3 Stuck handling: if it can't make progress for a while, wait where it is (the human can come back; the
  camera rule keeps them close); if pit deaths respawn it near the human (C0-5), falling is only a small delay.
- [ ] C3-4 Test point C3: a co-op level's walk-through with the bot following.

### Phase C4: the bot, fighting
- [ ] C4-1 (no friendly fire: it can swing freely) Attack the nearest enemy in reach (quick and heavy attacks; the gun at range), block when an attack wind-up is
  near (the `State()` patch's wind-up reports, as the cues use).
- [ ] C4-2 Grapple openings and finishers (the same opening reports as the bell); grenades rarely.
- [ ] C4-3 Revive: when the human is down, walk to them and Down + Grapple; the human can revive the bot the same way
  (the mod tells them: "Partner down, left").
- [ ] C4-4 Pickups: leave health for the human unless the bot is low.
- [ ] C4-5 Test point C4: co-op fights and boss fights with the bot.

### Phase C5: cues and controls for the partner
- [ ] C5-1 The partner's own sound (where they are), the "partner down" and "partner revived" speech, and a key (and
  controller binding) for the partner's health and position.
- [ ] C5-2 Bot commands (optional): stay / follow / come here.
- [ ] C5-3 Test point C5.

## 4. Open questions / risks

- Pit deaths in co-op (C0-5): where and how a player comes back.
- Whether the bot's inputs need the game's window focus (the human's are read the same way: probably fine).
- Boss fights designed for two players (the co-op bosses, the biker bosses and the bodyguard): may need the bot to do its
  part, or the human to carry the fight.
- Bot quality: a weak bot is fine (revives keep it in the run). (Settled 2026-10-01, the user: "there doesn't seem to be
  friendly fire, and who gets a kill doesn't really matter either. From my limited testing revival seems to be the only
  way the two directly interact." So the bot can't hurt the human or take anything from them; only blocking the way
  might matter, if bodies collide: unconfirmed.)
- The size: C0-C2 are a batch each; C3 and C4 are the big ones.

## 5. Decision log

| Date | Decision | Why |
|---|---|---|
| 2026-10-01 | The plan exists; nothing built | The user: "in case I ever decide to take this on" |
| 2026-10-01 | P2 is played through a virtual controller, not the game's AI | Goon AI is engine code aimed at Shank's team; P2 is a Shank driven by an input device |
| 2026-10-01 | The human picks their player with their own join press; the virtual pad takes the other | The user: "have the mod auto select the join button the player didn't use, and set the tracking on that player for the session" |
| 2026-10-01 | The bot needs no care about hurting the human or taking kills | The user: no friendly fire, kills don't matter, revival is the only interaction |
| 2026-10-01 | Pit deaths are found out by building C1 + a walking pad first | The user: "we'd probably have to just build enough to let me play to that point and get the other player killed" |
