"""Print a compact project-state briefing for Claude Code.

Run by the SessionStart hook in .claude/settings.json (on startup, resume, /clear and
after compaction). Its output is injected into Claude's context, so details that
live in the docs survive compaction.
Standard library only, so it works even if .venv is missing.
"""
import os
import re
import subprocess
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read(rel):
    try:
        with open(os.path.join(REPO, rel), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


def section(text, heading_prefix):
    """Body of the first '## <heading_prefix>...' section, up to the next '## ' or '---'."""
    m = re.search(r"^## %s[^\n]*\n(.*?)(?=^## |^---\s*$|\Z)" % re.escape(heading_prefix), text, re.S | re.M)
    return m.group(1).strip() if m else "(section not found)"


def last_work_log(text, n):
    body = section(text, "7. Work log")
    entries = re.split(r"\n(?=- \*\*)", body)
    return "\n".join(entries[-n:]).strip()


def git(*args):
    try:
        out = subprocess.run(["git", "-C", REPO] + list(args), capture_output=True, text=True, timeout=10)
        return out.stdout.strip() or "(clean)"
    except Exception as e:  # noqa: BLE001 - best effort briefing
        return "(git unavailable: %s)" % e


def awaiting_tests(text):
    heads = re.findall(r"^## (\d{4}-\d{2}-\d{2} .*awaiting user.*)$", text, re.M)
    return "\n".join("- " + h for h in heads) or "none"


def main():
    plan = read("docs/PLAN.md")
    testing = read("docs/TESTING.md")
    parts = [
        "=== shank-access session briefing (auto-injected by the SessionStart hook) ===",
        "Rules and layout are in CLAUDE.md. Plan: docs/PLAN.md. Engine facts: docs/RE-NOTES.md. "
        "Cues, hotkeys, config and user goals: docs/DESIGN.md. Test records: docs/TESTING.md.",
        "If this follows a compaction: re-read the In flight section below and the docs it names before "
        "continuing. Don't rely on the summary for details.",
        "",
        "--- PLAN.md Status ---",
        section(plan, "Status"),
        "",
        "--- PLAN.md In flight ---",
        section(plan, "In flight"),
        "",
        "--- Test sessions awaiting the user (docs/TESTING.md) ---",
        awaiting_tests(testing),
        "",
        "--- Recent work log ---",
        last_work_log(plan, 4),
        "",
        "--- git status --short ---",
        git("status", "--short"),
        "",
        "--- git log --oneline -8 ---",
        git("log", "--oneline", "-8"),
        "=== end briefing ===",
    ]
    sys.stdout.reconfigure(encoding="utf-8")  # Windows consoles default to cp1252
    sys.stdout.write("\n".join(parts) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
