-- Run by tools/loadtest50.py after loading a goon stategraph (Lua 5.0), B8-4; rules as of B26.
-- Asserts that the patched State() put PlaySound("a11y/en_windup_<kind>") first in the on_enter of attack states only
-- (tagged "attack" as a whole word or "chargeattack", untagged "_pre" grenade/shoot/... states, or states that start the
-- special-attack flash: B24; at least one), and never in: dodge / dazed / block-without-flash states, recovery
-- ("_pst") states, intros, knock-backs, or states acting on someone already held (B26).
local function first_is_windup(st)
  local e = st.on_enter
  return type(e) == "table" and type(e[1]) == "table" and e[1].Type == "playsound" and string.find(e[1].sound, "a11y/en_windup_", 1, true) == 1
end
local with, problems = {}, {}
for _, st in ipairs(StateGraph.States) do
  if first_is_windup(st) then
    table.insert(with, st.name .. "=" .. string.sub(st.on_enter[1].sound, 16))
    local tags = st.tags or ""
    local wt = " " .. string.gsub(tags, ",", " ") .. " "
    local attack = string.find(wt, " attack ", 1, true) or string.find(wt, " chargeattack ", 1, true)
    local flash = A11Y_Flashes(st)
    local n = st.name
    if (not attack and not flash and not string.find(n, "_pre", 1, true))
       or (not attack and not flash and string.find(tags, "block", 1, true))
       or string.find(n, "dodge", 1, true) or string.find(tags, "dazed", 1, true)
       or string.sub(n, -4) == "_pst" or string.find(n, "intro", 1, true) or string.find(n, "knock", 1, true) == 1 then
      table.insert(problems, n .. " (" .. tags .. ")")
    end
  end
end
print("  wind-up reports in " .. table.getn(with) .. " states: " .. table.concat(with, ", "))
if table.getn(problems) > 0 then error("wrong states: " .. table.concat(problems, "; ")) end
if table.getn(with) == 0 then error("no wind-up reports") end
return true
