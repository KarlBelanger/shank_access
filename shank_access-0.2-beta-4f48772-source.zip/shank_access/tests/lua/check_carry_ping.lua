-- Run by tools/loadtest50.py after loading Shank's stategraph (Lua 5.0), B15-4:
--   .venv/Scripts/python tools/loadtest50.py --check tests/lua/check_carry_ping.lua
-- The position ping must not sit inside the carried weapons' drop wrappers (a CompoundTransition with actions runs
-- them whenever a child fires: every ping dropped another minigun), but must still run while carrying.
local function contains(t, x, seen)
  if type(t) ~= "table" or seen[t] then return false end
  seen[t] = true
  if t == x then return true end
  for _, v in pairs(t) do
    if contains(v, x, seen) then return true end
  end
  return false
end
local problems = {}
for _, name in ipairs({"MINIGUN_REACTIONS", "FLAMETHROWER_REACTIONS"}) do
  local list = _G[name]
  if type(list) ~= "table" then
    table.insert(problems, name .. " missing")
  else
    local top = false
    for i = 1, table.getn(list) do
      if list[i] == A11Y_POS_PING then
        top = true
      elseif list[i] ~= A11Y_TURN_R and list[i] ~= A11Y_TURN_L and list[i] ~= A11Y_UP_ON and list[i] ~= A11Y_UP_OFF and
             list[i] ~= A11Y_DOWN_ON and list[i] ~= A11Y_DOWN_OFF and list[i] ~= A11Y_FWD_ON and list[i] ~= A11Y_FWD_OFF and
             list[i] ~= A11Y_BACK_ON and list[i] ~= A11Y_BACK_OFF and (contains(list[i], A11Y_POS_PING, {}) or
             contains(list[i], A11Y_TURN_R, {}) or contains(list[i], A11Y_TURN_L, {}) or contains(list[i], A11Y_UP_ON, {}) or
             contains(list[i], A11Y_UP_OFF, {}) or contains(list[i], A11Y_DOWN_ON, {}) or contains(list[i], A11Y_DOWN_OFF, {}) or
             contains(list[i], A11Y_FWD_ON, {}) or contains(list[i], A11Y_FWD_OFF, {}) or contains(list[i], A11Y_BACK_ON, {}) or
             contains(list[i], A11Y_BACK_OFF, {})) then
        table.insert(problems, name .. "[" .. i .. "] still has the ping or a turn / Up / Down report inside")  -- (B19-2, B44-1 too)
      end
    end
    if not top then table.insert(problems, name .. " has no ping of its own") end
  end
end
-- REACTIONS itself keeps the ping (on foot).
if not contains(REACTIONS, A11Y_POS_PING, {}) then table.insert(problems, "REACTIONS lost the ping") end
print("  carry ping check: " .. table.getn(problems) .. " problem(s)")
if table.getn(problems) > 0 then error(table.concat(problems, "; ")) end
return true
