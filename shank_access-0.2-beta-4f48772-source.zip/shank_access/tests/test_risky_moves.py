"""Tests for tools/levels/risky_moves.py (B42-4): the move descriptions, and on the real generated data (skipped without it)
that 1-c's opening route is listed with directions.

Run: .venv/Scripts/python -m unittest discover -s tests -v
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools", "levels"))
import risky_moves  # noqa: E402

HAVE_DATA = os.path.exists(os.path.join(ROOT, "build", "levels", "shank_access_paths.txt")) and \
    os.path.exists(os.path.join(ROOT, "build", "levels", "campaign_1c_meatpacking.geometry.json"))


class DescribeTest(unittest.TestCase):
    def test_tiles(self):
        self.assertEqual(risky_moves.tiles(64), "1 tile")
        self.assertEqual(risky_moves.tiles(-640), "10 tiles")

    def test_describe(self):
        surfaces = {"s0": [(0.0, 256.0), (5376.0, 256.0)]}
        features = [("swing_point", [(4726.0, 1045.0)])]
        walls = [("left", 5376.0, 384.0, 1600.0, True)]
        step = ("w0", "f0", "wall_jump", 5344.0, 800.0, "L")
        text = risky_moves.describe(step, None, surfaces, features, walls)
        self.assertEqual(text, "wall jump facing left onto a swing point, 10 tiles left, 4 tiles up")
        walk = risky_moves.describe(("s0", "w0", "run_up_wall", 5376.0, 416.0, "R"), 768.0, surfaces, features, walls)
        self.assertTrue(walk.startswith("walk 72 tiles right, then run up the wall onto a climbable wall"), walk)
        hard = risky_moves.risks(("w0", "f0", "wall_jump!!", 5344.0, 800.0, "L"), surfaces, features, walls,
                                 {"surfaces": []}, [(5344.0, 820.0, "a real death")])
        self.assertIn("one spot only (a narrow window)", hard)
        self.assertIn("1× a real death in the logs", hard)


@unittest.skipUnless(HAVE_DATA, "build/levels not generated")
class RealDataTest(unittest.TestCase):
    def test_meat_packing(self):
        n, lines = risky_moves.level_report("campaign_1c_meatpacking")
        self.assertGreater(n, 0)
        text = "\n".join(lines)
        self.assertIn('Meatpacking Plant, checkpoint "Level Start"', text)  # the game's chapter name
        self.assertIn("1. walk 72 tiles right, then run up the wall onto a climbable wall", text)


if __name__ == "__main__":
    unittest.main()
