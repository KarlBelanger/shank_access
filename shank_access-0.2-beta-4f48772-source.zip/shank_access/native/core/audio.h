#pragma once
// Phase 4 (4-1): our own cue player. XAudio2 2.9 (part of Windows 10/11), next to the game's FMOD.
// Every sound is synthesized here at start-up (short mono tones and noise bursts): no Klei assets,
// and mono sources so our panning isn't fighting baked-in stereo (DESIGN "Sound vocabulary").
#include <vector>

namespace audio {

enum Sound {
    kDrop,     // a drop ahead: a low "tock" with a falling pitch
    kWall,     // a wall ahead: a short, soft knock (filtered noise)
    kPickup,   // a pickup (B15-4: health; grenades and weapons have their own): two rising sine notes
    kInReach,  // a pickup within reach: one bright ping
    kDeadly,   // a deadly drop ahead (B4): a low buzz, two detuned square-ish tones beating
    kTarget,   // a jump target nearby (B5): a plucked string
    kJumpNow,  // a jump started now reaches a target (B5): a rising sine chirp (700 -> 1500 Hz, 90 ms)
    kHazardFall,        // B7: something falling (rock, ceiling): B15-8 two stone clacks (2 ms noise bursts through ~2.9 / 4.3
                        // kHz resonances, 28 ms apart); B8-0's snap and B7's whistle weren't right (the user)
    kHazardProjectile,  // B7: a rocket or missile: a siren-like warble (1000 Hz +- 250, 8 Hz, 180 ms)
    kHazardExplosive,   // B7: an enemy grenade or a barrel: a harsh double beep (square-ish 1600 Hz, 35 ms x 2)
    // B8 enemies: short FM "bonks" (a family of their own), pitch by class; the *Behind variants are the same
    // sound low-passed (muffled) for an enemy behind Shank.
    kEnemyMedium,  // 600 Hz, 70 ms
    kEnemyLarge,   // 250 Hz, 110 ms (deep)
    kEnemyGirl,    // 1100 Hz, 60 ms
    kEnemyDog,     // 800 Hz, 30 ms x 2
    kEnemyBoss,    // 180 Hz, 160 ms (gong-like)
    kEnemyMediumBehind,
    kEnemyLargeBehind,
    kEnemyGirlBehind,
    kEnemyDogBehind,
    kEnemyBossBehind,
    kEnemyWindup,  // B9-1: a heavy attack starting (a charge, or any attack by a big goon or boss): a harsh falling
                   // tremolo buzz (square-ish 700 -> 250 Hz, 25 Hz tremolo, 250 ms). (B8-4 had a whoosh for every attack.)
    kLockInLine,   // B8-6: the locked enemy is in the line of fire: a bright "ting" (2000 + 3000 Hz, 60 ms)
    kEnemyPass,    // B8d: an enemy crossing to Shank's other side: a falling noise whoosh (2500 -> 400 Hz, 130 ms)
    kWaypointChime,  // B10: the next checkpoint in waypoint mode: a soft, slow FM bell (1047 Hz, ratio 2, 450 ms)
    kEnemyOpening, // B9c: a boss open to a grapple: a bright FM bell (1320 Hz, ratio 3.5, 220 ms), fast
    kLockTick,     // B9b: the locked enemy's tick: a bright radar ping with an echo (sine 1300 Hz 30 ms, again softer 45 ms later)
    kEnemyGrab,    // B9-1: a grab / grapple / pounce starting: two quick harsh rising chirps (square-ish 400 -> 1200 Hz, 80 ms x 2)
    kHazardFire,   // B13-3: a fire trap nearby (3-c's Priest fight): a crackle (random noise pops over a low hiss, 160 ms)
    kEnemyAim,     // B13-4: a gunman aiming, about to fire: a thin rising whine with a fast flutter (1800 -> 2600 Hz, 40 Hz, 150 ms)
    kPickupItem,      // B15-4 grenades; B23-3 grenades or a weapon nearby (the weapon chime was dropped: the user's sound
                      // audit): the pickup's two rising notes as short square-ish blips (700 -> 1050 Hz)
    kGap,             // B15-6: a narrow gap ahead that running carries him over: the drop's tock, twice, quick and higher
    kTurn,            // B19-2: Shank turned: a slight, soft noise whoosh (3200 -> 1400 Hz, 90 ms), panned a little to his new facing
    kTargetDown,      // B21-2: a hanging meat shot down (its chain dropped), or a breakable door broken: a descending
                      // tone; B22-2 square-ish, 1500 -> 450 Hz, 240 ms (was a sine 900 -> 300, 180 ms: lost in gunfire)
                      // B23-2: also any locked enemy killed (was "Target down" speech)
    kEnemySetup,      // B23-4: a boss set up for an opening (a charge to dodge, a trap lined up): the opening bell, slow
                      // (two 150 ms strikes 330 ms apart per play, played every 660 ms; the open bell strikes every 140 ms)
    kSoundCount
};

// Starts XAudio2 and synthesizes the sounds. False (logged) if audio can't start; Play is then a no-op.
bool Start();

// Plays a sound once. pan: -1 left … 0 centre … +1 right (equal-power). semitones: pitch shift
// (±12 at most). volume: 0…1, times the master volume. Any thread; never blocks for long.
void Play(Sound sound, float pan, float semitones, float volume);

// Pauses/resumes our audio engine (test mode F4, for the B3 lag check). Returns the new state.
bool ToggleEnabled();
bool Enabled();
// B20-6: the game is closing (the ExitProcess hook, before other threads are killed): stop the engine; nothing is
// released (no teardown at process exit).
void StopForExit();

// Master volume for all our cues, 0…1 (shank_access.ini [cues] volume, percent).
void SetMasterVolume(float volume);

// The synthesized samples (mono float, kSampleRate): for tests.
constexpr unsigned kSampleRate = 44100;
const float* Samples(Sound sound, unsigned* count);

// B15-2: what each sound means, for "Learn sounds" in the settings menu ("Drop ahead: a low falling tock ...").
const char* Describe(Sound sound);

// B17-3: the order "Learn sounds" lists them in, by category (each sound once): the sound and its group's name.
struct LearnItem {
    Sound sound;
    const char* group;  // "Edges and jumps", "Pickups", "Hazards", "Enemies", "Lock-on", "Waypoint"
};
const std::vector<LearnItem>& LearnOrder();

}  // namespace audio
