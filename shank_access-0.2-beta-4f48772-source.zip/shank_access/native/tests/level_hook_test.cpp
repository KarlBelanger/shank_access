// Host-side test of the level hook (never deployed): hooks stand-ins with the game's conventions
// (the loader is thiscall(level, stream) -> bool, ret 4; the name getter thiscall(level) -> const char*)
// and checks the game's result is kept and the listener gets the level's name. Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <string>

#include "../core/level_hooks.h"
#include "../core/log.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

struct FakeLevel {
    char pad[16];
    const char* name;
    bool load_ok;
};

int g_loads = 0;
void* g_seen_stream = nullptr;
std::string g_heard;

__declspec(noinline) bool __fastcall FakeLoad(void* level, void*, void* stream) {
    ++g_loads;
    g_seen_stream = stream;
    return static_cast<FakeLevel*>(level)->load_ok;
}

__declspec(noinline) const char* __fastcall FakeName(void* level, void*) { return static_cast<FakeLevel*>(level)->name; }

// A fake simulation with the bounds at +0xb0 (min x, min y, max x, max y) and the default flag at +0xc0.
struct FakeSim {
    unsigned char bytes[0x100];
};
FakeSim g_sim_obj;

__declspec(noinline) void __fastcall FakeExecute(void*, void*, void* ctx) {
    unsigned char* sim = *static_cast<unsigned char**>(ctx);
    float* f = reinterpret_cast<float*>(sim + 0xb0);
    f[0] = 2822;
    f[1] = -42;
    f[2] = 6994;
    f[3] = 1114;
    sim[0xc0] = 0;
}

}  // namespace

int main() {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_level_hook_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    level_hooks::SetListener([](const char* name) { g_heard = name; });
    Check(level_hooks::InstallAt(reinterpret_cast<unsigned>(&FakeLoad), reinterpret_cast<unsigned>(&FakeName),
                                 reinterpret_cast<unsigned>(&FakeExecute)),
          "hooked the stand-in loader and bounds action");
    Check(!level_hooks::CurrentBounds().known, "no bounds before the first bounds action");
    void* ctx = &g_sim_obj;
    volatile auto execute = &FakeExecute;
    execute(nullptr, nullptr, &ctx);
    level_hooks::Bounds b = level_hooks::CurrentBounds();
    Check(b.known && b.min_x == 2822 && b.max_x == 6994 && b.min_y == -42 && b.max_y == 1114 && !b.is_default,
          "bounds read from the simulation the action targeted (1-a's first arena)");
    reinterpret_cast<float*>(g_sim_obj.bytes + 0xb0)[2] = 9000;
    g_sim_obj.bytes[0xc0] = 1;
    b = level_hooks::CurrentBounds();
    Check(b.max_x == 9000 && b.is_default, "later changes read directly (a checkpoint restore, the default bounds)");
    level_hooks::ForgetBounds();
    Check(!level_hooks::CurrentBounds().known, "forgotten at a level load");
    FakeLevel level{{}, "campaign_1a_wrestlingring", true};
    int stream = 0;
    volatile auto load = &FakeLoad;  // call through a pointer, as the game does
    const bool ok = load(&level, nullptr, &stream);
    Check(ok && g_loads == 1 && g_seen_stream == &stream, "the game's loader ran with its arguments; result kept");
    Check(g_heard == "campaign_1a_wrestlingring", "listener got the level name");
    g_heard.clear();
    FakeLevel failed{{}, "broken", false};
    Check(!load(&failed, nullptr, &stream) && g_heard.empty(), "a failed load: result kept, no listener call");
    FakeLevel unnamed{{}, nullptr, true};
    Check(load(&unnamed, nullptr, &stream) && g_heard.empty(), "no name: no listener call");
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
