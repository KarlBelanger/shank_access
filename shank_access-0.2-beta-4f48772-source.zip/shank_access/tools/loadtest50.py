"""Execute game scripts (with our patches applied) under real Lua 5.0 to catch load-time errors.

A syntax check (luacheck50.py) can't catch runtime errors like calling an undefined function,
and those would crash the game at level load. This runs the actual load chain.

Usage (repo root):
  .venv/Scripts/python tools/loadtest50.py [ENTRY] [--check tests/lua/<file>.lua]
ENTRY defaults to stategraphs/shank/shank_stategraph.lua (relative to <game>/data).
"""
import argparse
import os
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import deploy  # noqa: E402

LUA50 = os.path.join(deploy.REPO, "build", "lua50", "Release", "lua50.exe")
HARNESS = os.path.join(deploy.REPO, "tools", "lua50", "loadtest.lua")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("entry", nargs="?", default="stategraphs/shank/shank_stategraph.lua")
    ap.add_argument("--check", help="Lua 5.0 file run after loading; return false or error = fail")
    ap.add_argument("--game-dir", default=deploy.DEFAULT_GAME_DIR)
    ap.add_argument("--state-dir", default=deploy.DEFAULT_STATE_DIR)
    args = ap.parse_args()

    d = deploy.Deployer(args.game_dir, args.state_dir)
    built = d.build(d.load_state())
    with tempfile.TemporaryDirectory() as tmp:
        lines = []
        for rel, _kind, _orig, new in built:
            if not rel.lower().endswith(".lua"):
                continue
            # Engine LoadFile paths are relative to data/ or data-pc/
            for prefix in ("data/", "data-pc/"):
                if rel.lower().startswith(prefix):
                    key = rel[len(prefix):].lower()
                    out = os.path.join(tmp, rel.replace("/", "_"))
                    with open(out, "wb") as f:
                        f.write(new)
                    lines.append("%s\t%s" % (key, out.replace("\\", "/")))
        overlay = os.path.join(tmp, "overlay.txt")
        with open(overlay, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        env = dict(os.environ)
        if args.check:
            env["LOADTEST_CHECK"] = os.path.abspath(args.check)
        roots = [os.path.join(args.game_dir, "data"), os.path.join(args.game_dir, "data-pc")]
        cmd = [LUA50, HARNESS, overlay, args.entry] + [r.replace("\\", "/") for r in roots]
        r = subprocess.run(cmd, env=env, capture_output=True, text=True)
        sys.stdout.write(r.stdout)
        sys.stderr.write(r.stderr)
        return r.returncode


if __name__ == "__main__":
    sys.exit(main())
