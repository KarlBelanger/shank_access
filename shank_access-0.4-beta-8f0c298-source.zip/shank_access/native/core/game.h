#pragma once
// Shank.exe addresses and layouts, per supported build (see docs/RE-NOTES.md for the evidence behind each one).
// B49 (2026-10-07): two builds, the current Steam exe and the Steam "classic" branch exe; Select() picks the table
// by the exe's SHA-256 at startup. A 0 address = not found in that build yet: whatever needs it stays off.
#include <cstdint>
#include <cstring>
#include <string>

namespace game {

enum class Build { kSteam, kClassic };

struct Addresses {
    Build build;
    const char* name;    // for the log
    const char* sha256;  // bin/Shank.exe

    // Sound (RE-NOTES "Sound system").
    // PlaySoundAt: esi = event name (char*), [esp+4] = const float* pos (x, y); caller cleans the stack.
    uintptr_t play_sound_at;
    // PlaySound (non-positional; only the UI "playsound" callback uses it): esi = event name.
    uintptr_t play_sound;
    // Pan listener: four consecutive floats, half-width, half-height, centre x, centre y.
    uintptr_t listener_half_w;
    // B8f: the per-frame sound update that copies the camera's half-size (esi) and centre (edi) into those globals;
    // dt on the stack (caller cleans); returns nothing used.
    uintptr_t sound_update;
    // B31-3: the game's category volumes as it holds them (floats), and B32's scale (both set to setting × this).
    uintptr_t game_volume, music_volume, volume_scale;
    uintptr_t event_system_ptr;  // the FMOD EventSystem*

    // B34 checkpoint jump (RE-NOTES "Checkpoint jump"): NextCheckPoint's setter and the debug LoadToLastCheckpoint.
    uintptr_t set_restart_checkpoint;   // thiscall(sim, const char* name, const vec2* pos), ret 8
    uintptr_t load_to_last_checkpoint;  // cdecl(cSimulation*)
    uintptr_t zero_vector;              // the position NextCheckPoint passes
    uintptr_t shank_sim_vtable;         // cShankSimulation (RTTI offset 0)
    uintptr_t shank_sim_vtable2;        // ...its second base at +4

    // Debug-settings block (fixed global). Byte flags the retail game still honours. Test mode only.
    uintptr_t debug_god_mode, debug_super_speed;

    // Levels (RE-NOTES "Levels"). LevelData::LoadSimData: thiscall(level, stream) -> bool, ret 4; LevelData name
    // getter: thiscall(level) -> const char*. cSetBoundsAction::Execute: thiscall(action; ctx) ret 4.
    uintptr_t load_sim_data, level_name, set_bounds_execute;
    // B7 safe edges: HasTag_ParseNode::Evaluate: thiscall(node, ctx) -> 0/1 in eax, ret 4.
    uintptr_t has_tag_evaluate;

    // Scaleform UI (RE-NOTES "UI"): SwfExternalInterface::Callback (vtable slot 1), SwfSymbol::SetVariableInternal,
    // ObjectInterface::ObjectRelease, SwfSymbol::InvokeV, SwfScreen::Update (vtable slot 5),
    // SwfSymbol::InvokeMethodInternal.
    uintptr_t ui_callback, ui_set_variable, ui_object_release, ui_invoke_v, ui_screen_update, ui_invoke_method_internal;

    uintptr_t controller_vtable;  // Input::XInputController (B40-4, game_pads)
    // B8 / B53 the enemy reader (enemies.cpp): cGameItemManager, cShankGameItem, cGameItem (primary vtables). The layouts
    // (manager items +0x24 / +0x28; item team +0x24, hash +0x40, physics +0x5c, life +0x64) are the same in both builds.
    uintptr_t item_manager_vtable, shank_item_vtable, game_item_vtable;

    // Startup movie skips (test mode): "mov edx, offset <movie>.usm; call <play video>" (10 bytes); the call is NOPed.
    uintptr_t logo_movie_at;   // introscee.usm, in the intro screen's activation
    unsigned char logo_movie_bytes[10];
    uintptr_t intro_movie_at;  // introtomain.usm, in the intro screen's update
    unsigned char intro_movie_bytes[10];
};

// The current Steam build (Shank.exe linked 2012-09-20).
inline constexpr Addresses kSteam = {
    Build::kSteam, "Steam", "a3b58dde9e4e3588664389bc6a36422d3f6110e6cf0869c493f0cb91fce79e2a",
    0x55ab90, 0x55ab10, 0xae6860, 0x55b0d0, 0x8899f8, 0x8899fc, 0x889a00, 0xadfdf0,
    0x406b80, 0x781580, 0xae10e0, 0x837d80, 0x837db0,
    0xae6530 + 0x09, 0xae6530 + 0x0a,
    0x495e30, 0x4323e0, 0x4eb940,
    0x4f92c0,
    0x5534d0, 0x559a50, 0x5c7620, 0x559b50, 0x553d50, 0x559920,
    0x843fdc,
    0x83ae44, 0x837e88, 0x83b174,
    0x792c37, {0xBA, 0xB8, 0x44, 0x83, 0x00, 0xE8, 0xCF, 0xA7, 0xDB, 0xFF},
    0x792ced, {0xBA, 0xC8, 0x44, 0x83, 0x00, 0xE8, 0x19, 0xA7, 0xDB, 0xFF},
};

// B49: the Steam "classic" branch (Shank.exe linked 2014-03-18 from Klei's archived original PC source;
// docs/CLASSIC-ASSESSMENT.md). Found statically 2026-10-07 (RE-NOTES "The classic build"; B51: the level load, name,
// checkpoint setter, LoadToLastCheckpoint and zero vector; B55-3: god mode / super speed, at the same +9 / +0xa as
// Steam's although the intro skip flag is at +0x6c, not +0x70). HasTag_ParseNode::Evaluate 0x4f8c50 (CLASSIC-ASSESSMENT)
// is hooked since B60 for the test-mode cheats; safe edges stay off (the classic Shank has no anti-fall rule).
inline constexpr Addresses kClassic = {
    Build::kClassic, "classic", "e75f922996b3a7828b3a62cf9ce7e17eab5d83138b219aa5cc676c3c5d52fc3c",
    0x559000, 0x558f80, 0xae175c, 0x559540, 0x8849e8, 0x8849ec, 0x8849f0, 0xadad20,
    0x4076f0, 0x77f0d0, 0xadc004, 0x833b30, 0x833b60,
    0xae1430 + 0x09, 0xae1430 + 0x0a,  // (B55-3: ToggleGodMode 0x77e1a0 / ToggleSuperSpeed 0x77e1d0 flip +9 / +0xa of 0x529410()'s block)
    0x495220, 0x431da0, 0x4eb040,
    0x4f8c50,  // (B60: hooked for the cheats only; safe edges stay off on classic, which has no anti-fall rule)
    0x551960, 0x557e30, 0x5c51b0, 0x557f30, 0x5521e0, 0x557d00,
    0x83f994,
    0x836954, 0x833c38, 0x836c28,
    0x790037, {0xBA, 0xA8, 0x02, 0x83, 0x00, 0xE8, 0x9F, 0xBC, 0xDB, 0xFF},
    0x7900ed, {0xBA, 0xB8, 0x02, 0x83, 0x00, 0xE8, 0xE9, 0xBB, 0xDB, 0xFF},
};

inline const Addresses* g_current = &kSteam;  // (host tests: the Steam table)

inline const Addresses& A() { return *g_current; }
inline bool IsClassic() { return g_current->build == Build::kClassic; }

// Picks the table for this exe; false (and nothing changed) for an unknown build.
inline bool Select(const std::string& sha256) {
    for (const Addresses* a : {&kSteam, &kClassic}) {
        if (sha256 == a->sha256) {
            g_current = a;
            return true;
        }
    }
    return false;
}

// Prologue checks: -1 = any byte (absolute addresses inside an instruction, which differ between builds).
inline bool BytesMatch(uintptr_t addr, const int* pattern, size_t n) {
    if (!addr) return false;
    const unsigned char* p = reinterpret_cast<const unsigned char*>(addr);
    for (size_t i = 0; i < n; ++i) {
        if (pattern[i] >= 0 && p[i] != static_cast<unsigned char>(pattern[i])) return false;
    }
    return true;
}

// Layouts (the same in both builds where checked; RE-NOTES).
inline constexpr uintptr_t kSimRestartCheckpoint = 0x38;  // sim+0x38: std::string, the restart checkpoint's name
inline constexpr uintptr_t kSimBoundsMinX = 0xb0;         // (classic: not checked yet)
inline constexpr uintptr_t kSimBoundsDefault = 0xc0;

}  // namespace game
