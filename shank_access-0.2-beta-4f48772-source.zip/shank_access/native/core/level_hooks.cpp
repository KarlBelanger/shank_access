#include "level_hooks.h"

#include <windows.h>

#include <cstdio>
#include <cstring>

#include "MinHook.h"
#include "game.h"
#include "log.h"

namespace level_hooks {
namespace {

// thiscall(level, stream) -> bool (al), ret 4: the same shape as __fastcall(level, edx, stream).
using LoadFn = bool(__fastcall*)(void* level, void* edx, void* stream);
using NameFn = const char*(__fastcall*)(void* level, void* edx);
LoadFn g_orig_load = nullptr;
NameFn g_name = nullptr;
LevelListener g_listener = nullptr;

// B5-2: the simulation holding the arena bounds (learnt from the bounds action).
using ExecuteFn = void(__fastcall*)(void* action, void* edx, void* ctx);
ExecuteFn g_orig_execute = nullptr;
void* volatile g_sim = nullptr;

void* ReadTarget(void* ctx) {
    __try {
        return ctx ? *static_cast<void* const*>(ctx) : nullptr;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

void __fastcall HookExecute(void* action, void* edx, void* ctx) {
    void* sim = ReadTarget(ctx);
    g_orig_execute(action, edx, ctx);
    if (sim && sim != g_sim) {
        g_sim = sim;
        alog::Write("bounds: simulation %p", sim);
    }
    const Bounds b = CurrentBounds();
    if (b.known) {
        alog::Write("bounds: x %.0f..%.0f, y %.0f..%.0f%s", b.min_x, b.max_x, b.min_y, b.max_y,
                    b.is_default ? " (default)" : "");
    }
}

bool ReadName(void* level, char* buf, size_t n) {
    __try {
        const char* name = g_name(level, nullptr);
        if (!name) return false;
        _snprintf_s(buf, n, _TRUNCATE, "%s", name);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool __fastcall HookLoad(void* level, void* edx, void* stream) {
    const bool ok = g_orig_load(level, edx, stream);
    char name[260] = "?";
    const bool named = ReadName(level, name, sizeof name);
    alog::Write("level: LoadSimData(%p) -> %d, name %s", level, ok ? 1 : 0, named ? name : "(unreadable)");
    if (ok && named && g_listener) g_listener(name);
    return ok;
}

// 0x495e30: push -1; push 0x7c6428; mov eax, fs:[0]
const unsigned char kLoadPrologue[] = {0x6A, 0xFF, 0x68, 0x28, 0x64, 0x7C, 0x00, 0x64, 0xA1, 0x00, 0x00, 0x00, 0x00};
// 0x4323e0: push ebp; mov ebp, esp; push ecx; mov [ebp-4], ecx
const unsigned char kNamePrologue[] = {0x55, 0x8B, 0xEC, 0x51, 0x89, 0x4D, 0xFC};
// 0x4eb940: mov eax, [esp+4]; mov eax, [eax]; test eax, eax
const unsigned char kExecutePrologue[] = {0x8B, 0x44, 0x24, 0x04, 0x8B, 0x00, 0x85, 0xC0};

}  // namespace

void SetListener(LevelListener listener) { g_listener = listener; }

Bounds CurrentBounds() {
    Bounds b;
    const unsigned char* sim = static_cast<const unsigned char*>(g_sim);
    if (!sim) return b;
    __try {
        const float* f = reinterpret_cast<const float*>(sim + game::kSimBoundsMinX);
        b.min_x = f[0];
        b.min_y = f[1];
        b.max_x = f[2];
        b.max_y = f[3];
        b.is_default = sim[game::kSimBoundsDefault] != 0;
        b.known = b.max_x > b.min_x && b.max_y > b.min_y;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        b.known = false;
    }
    return b;
}

void ForgetBounds() { g_sim = nullptr; }

void* Simulation() { return g_sim; }

bool InstallAt(unsigned load_sim_data, unsigned level_name, unsigned set_bounds_execute) {
    g_name = reinterpret_cast<NameFn>(static_cast<uintptr_t>(level_name));
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) return false;
    void* target = reinterpret_cast<void*>(static_cast<uintptr_t>(load_sim_data));
    st = MH_CreateHook(target, reinterpret_cast<void*>(&HookLoad), reinterpret_cast<void**>(&g_orig_load));
    if (st == MH_OK) st = MH_EnableHook(target);
    alog::Write("hook LevelData::LoadSimData at 0x%08x: %s", load_sim_data, st == MH_OK ? "installed" : MH_StatusToString(st));
    bool ok = st == MH_OK;
    if (set_bounds_execute) {
        void* exec = reinterpret_cast<void*>(static_cast<uintptr_t>(set_bounds_execute));
        st = MH_CreateHook(exec, reinterpret_cast<void*>(&HookExecute), reinterpret_cast<void**>(&g_orig_execute));
        if (st == MH_OK) st = MH_EnableHook(exec);
        alog::Write("hook cSetBoundsAction::Execute at 0x%08x: %s", set_bounds_execute,
                    st == MH_OK ? "installed" : MH_StatusToString(st));
        ok = ok && st == MH_OK;
    }
    return ok;
}

bool Install() {
    if (std::memcmp(reinterpret_cast<const void*>(game::kLoadSimData), kLoadPrologue, sizeof kLoadPrologue) != 0 ||
        std::memcmp(reinterpret_cast<const void*>(game::kLevelName), kNamePrologue, sizeof kNamePrologue) != 0 ||
        std::memcmp(reinterpret_cast<const void*>(game::kSetBoundsExecute), kExecutePrologue, sizeof kExecutePrologue) != 0) {
        alog::Write("level hooks: function bytes don't match the expected build; not hooking");
        return false;
    }
    return InstallAt(game::kLoadSimData, game::kLevelName, game::kSetBoundsExecute);
}

}  // namespace level_hooks
