"""B37-3 / B37-3b: Shank Access setup (frozen into shank-access-setup.exe with PyInstaller: tools/setup/build_setup.py).

A small window (wxPython: native Windows controls, which screen readers read): finds the Shank folder (Steam's own
folder and every Steam library from libraryfolders.vdf, e.g. D:\\SteamLibrary; a Browse button for another), says
whether Shank Access is installed there and at which version, and installs, updates or uninstalls it.

Installing (the user, 2026-10-03: "have it check the running system for the shank folder, either in program files
(x86) or a steam library folder ... If the program detects the mod is already installed, it offers to update the mod
if the mod is out of date, or uninstall it."):
  1. checks bin/Shank.exe (the regular Steam build or, since B54, the Steam classic branch: each gets its own script
     changes and routes) and that the game isn't running;
  2. copies the mod's own files (bundled: the DLLs, the screen reader DLLs, shank_access.ini) into the game folder;
  3. applies our patches (mod/patches/*.patch.json) to the game's data files, written as new files under data-pc/
     (the game's own files stay untouched, as tools/deploy.py does);
  4. extracts the levels and builds bin/shank_access_geometry.txt (extract_levels.py + geometry.py);
  5. extracts the drawn UI text into bin/shank_access_ui_text.txt (extract_ui_text.py);
  6. runs path_graph.exe (ours) for bin/shank_access_paths.txt;
  7. writes bin/shank_access_version.txt and the list of every file it wrote (bin/shank_access_setup_files.txt).
Uninstalling removes exactly the listed files (the player's own settings, bin/shank_access_user.ini, are kept unless
asked). B54-2: everything is made in a staging folder first, then put in place writing only the files whose content
differs and removing the old install's files the new one doesn't have; so updating, and switching between the Steam and
classic builds (offered when the installed files are for the other one), change only what differs. B57: while it works,
shank_access_setup.lock in the game folder keeps a game started meanwhile from touching the mod's files, and the game
must be closed again before anything is put in place. B58: each install keeps a copy of its build's sources
(shank_access_sources), so an Update remakes the other build's stored set as well.

Command line (for testing; no window): shank-access-setup.exe --game <Shank folder> [--target <folder>] [--uninstall]
"""
import argparse
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time

# B54-2: the builds the mod supports (native/core/game.h): Shank.exe's SHA-256 -> (id, the name players see)
BUILDS = {
    "a3b58dde9e4e3588664389bc6a36422d3f6110e6cf0869c493f0cb91fce79e2a": ("steam", "the regular Steam version"),
    "e75f922996b3a7828b3a62cf9ce7e17eab5d83138b219aa5cc676c3c5d52fc3c": ("classic", "the Steam classic version"),
}
BUILD_NAMES = {b: name for b, name in BUILDS.values()}
FROZEN = getattr(sys, "frozen", False)
REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA = getattr(sys, "_MEIPASS", REPO)  # bundled data (mod/patches, mod/pristine.json, payload/, path_graph.exe)
if not FROZEN:
    for sub in ("tools", os.path.join("tools", "levels"), os.path.join("tools", "ui_text")):
        sys.path.insert(0, os.path.join(REPO, sub))

import deploy  # noqa: E402  (apply_ops, override_path)
import extract_levels  # noqa: E402
import extract_ui_text  # noqa: E402
import geometry  # noqa: E402

LIST = "bin/shank_access_setup_files.txt"
OLD_MOD_LIST = "bin/shank_access_files.txt"  # (release 0.1's package list)
VERSION_FILE = "bin/shank_access_version.txt"
BUILD_FILE = "bin/shank_access_build.txt"  # B54-2: which game build the installed files are for ("steam" / "classic")
USER_INI = "bin/shank_access_user.ini"
RUNTIME_LOGS = ["a11y.log", "a11y_marks.log"]  # written by the mod while playing; removed with it
SET_ASIDE = "shank_access_set_aside"  # B55-2: the mod moved its patched scripts here on a build mismatch (until B56)
STORES = "shank_access_builds"  # B56: one store per game build of its build-specific files (native/core/exe_check.h)
PATHS_KEY = "bin/shank_access_paths.key"  # B56-3: what the installed routes were worked out from
# The build-specific files in bin (besides the patched scripts in data-pc): what a build's store holds.
BUILD_BIN_FILES = ["bin/shank_access_geometry.txt", "bin/shank_access_paths.txt", PATHS_KEY, "bin/shank_access_build.txt"]
CREATE_NO_WINDOW = 0x08000000
# B57-1: in the game folder while setup installs or uninstalls (its process id): the mod, started meanwhile, stays off
# and leaves its files alone (native/core/exe_check.h SetupRunning; a lock over 60 minutes old counts as stale there).
LOCK = "shank_access_setup.lock"
# B58 (the user, 2026-10-11: "Update should check if the other version's files exist, and update both versions at once
# if so."): while one build is installed, the other build's game files aren't on disk (Steam swaps the whole install),
# so each install keeps a copy of what setup builds from (its levels' .lua / .slev, campaigns.lua, the props'
# attributes and the vanilla scripts it patches: about 6 MB) in <game>\shank_access_sources\<build>\, laid out like the
# game folder. An Update then remakes the other build's store from that copy.
SOURCES = "shank_access_sources"
TMP_SUFFIX = ".shank_access_new"  # B57-1: a file being put in place, before it replaces the old one


class SetupError(Exception):
    pass


# ---------------------------------------------------------------- the version this setup installs

def bundled_version():
    for p in (os.path.join(DATA, "payload", "version.txt"),):
        if os.path.exists(p):
            return open(p, encoding="utf-8").read().strip()
    try:
        rev = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
    except OSError:
        rev = ""
    return "dev-" + (rev or "unknown")


def installed_version(game):
    p = os.path.join(game, VERSION_FILE)
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    if os.path.exists(os.path.join(game, "bin", "shank_access.dll")):
        return "unknown (installed by hand)"
    return None


def installed_build(game):
    """The game build the installed mod's files were made for; installs from before B54 were all for the Steam build.
    None when the mod moved its files to a store (B56: the game was switched in Steam and no usable set was stored)."""
    p = os.path.join(game, BUILD_FILE)
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    if os.path.isdir(os.path.join(game, STORES)) or os.path.isdir(os.path.join(game, SET_ASIDE)):
        return None
    return "steam" if installed_version(game) else None


def store_dir(target, build):
    return os.path.join(target, STORES, build)


def keep_as_store(target, build, made_by, rels):
    """B56-2: the installed set of the other build (its patched scripts and build-specific bin files) copied into its
    store before a switch replaces it, so the mod can switch back at the game's start without setup."""
    store = store_dir(target, build)
    shutil.rmtree(store, ignore_errors=True)
    n = 0
    for rel in rels:
        if not (rel.startswith("data-pc/") or rel in BUILD_BIN_FILES):
            continue
        src = os.path.join(target, rel)
        if os.path.isfile(src):
            dest = os.path.join(store, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            n += 1
    if n:
        with open(os.path.join(store, "made_by.txt"), "w", encoding="utf-8", newline="\n") as f:
            f.write(made_by + "\n")
        with open(os.path.join(store, "build.txt"), "w", encoding="utf-8", newline="\n") as f:
            f.write(build + "\n")
    return n


def sources_dir(target, build):
    return os.path.join(target, SOURCES, build)


def patch_rels(build):
    """The game files the build's patch set changes (data/..., as the game folder has them)."""
    root = os.path.join(DATA, "mod", "patches-classic" if build == "classic" else "patches")
    rels = []
    for dirpath, _, names in os.walk(root):
        for name in sorted(names):
            if name.endswith(".patch.json"):
                rels.append(os.path.relpath(os.path.join(dirpath, name), root).replace("\\", "/")[:-len(".patch.json")])
    return rels


def source_files(game, build):
    """B58: every game file setup builds the build-specific set from (apply_patches, extract_levels, geometry)."""
    rels = ["data/campaigns.lua"] + patch_rels(build)
    rels += ["data/attributes/props/" + n for n in sorted(os.listdir(os.path.join(game, "data", "attributes", "props")))
             if n.endswith(".lua")]
    levels = os.path.join(game, "data-pc", "levels")
    for d in sorted(os.listdir(levels)):
        if d.startswith("campaign_") and os.path.isdir(os.path.join(levels, d)):
            rels += ["data-pc/levels/%s/%s" % (d, n) for n in sorted(os.listdir(os.path.join(levels, d)))
                     if n.endswith(".lua") or n.endswith(".slev")]
    return rels


def save_sources(game, target, build):
    """B58: a copy of this build's sources, for remaking its set from the other build's Update."""
    dest = sources_dir(target, build)
    tmp = dest + TMP_SUFFIX
    shutil.rmtree(tmp, ignore_errors=True)
    for rel in source_files(game, build):
        src = os.path.join(game, rel)
        if os.path.isfile(src):
            os.makedirs(os.path.dirname(os.path.join(tmp, rel)), exist_ok=True)
            shutil.copyfile(src, os.path.join(tmp, rel))
    with open(os.path.join(tmp, "build.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write(build + "\n")
    shutil.rmtree(dest, ignore_errors=True)
    os.replace(tmp, dest)


def other_build(build):
    return "classic" if build == "steam" else "steam"


def has_sources(target, build):
    """B58: a kept copy of the build's sources is here."""
    p = os.path.join(sources_dir(target, build), "build.txt")
    return os.path.isfile(p) and open(p, encoding="utf-8").read().strip() == build


def store_made_by(target, build):
    p = os.path.join(store_dir(target, build), "made_by.txt")
    return open(p, encoding="utf-8").read().strip() if os.path.isfile(p) else None


def put_store(stage, target, build, made_by, rels):
    """B58: a remade set of the other build becomes its store (replacing the old one whole)."""
    store = store_dir(target, build)
    tmp = store + TMP_SUFFIX
    shutil.rmtree(tmp, ignore_errors=True)
    for rel in rels:
        if rel.startswith("data-pc/") or rel in BUILD_BIN_FILES:
            os.makedirs(os.path.dirname(os.path.join(tmp, rel)), exist_ok=True)
            shutil.copyfile(os.path.join(stage, rel), os.path.join(tmp, rel))
    with open(os.path.join(tmp, "made_by.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write(made_by + "\n")
    with open(os.path.join(tmp, "build.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write(build + "\n")
    shutil.rmtree(store, ignore_errors=True)
    os.makedirs(os.path.dirname(store), exist_ok=True)
    os.replace(tmp, store)


def graph_version():
    """B56-3: the version of the route code (build_setup.py's graph_version), bundled as payload/graph_version.txt."""
    p = os.path.join(DATA, "payload", "graph_version.txt")
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    sys.path.insert(0, os.path.join(REPO, "tools", "setup"))
    import build_setup
    return build_setup.graph_version(REPO)


def paths_key(geometry_bytes, build):
    return "%s %s %s" % (hashlib.sha256(geometry_bytes).hexdigest()[:16], graph_version(), build)


def cached_paths(installed, build, key):
    """B56-3: an installed routes file (active, or in this build's store) worked out from the same geometry, route code
    and build: the same routes, no need to work them out again."""
    for base in (installed, store_dir(installed, build)):
        k, p = os.path.join(base, PATHS_KEY), os.path.join(base, "bin", "shank_access_paths.txt")
        if os.path.isfile(k) and os.path.isfile(p) and open(k, encoding="utf-8").read().strip() == key:
            return open(p, "rb").read()
    return None


# ---------------------------------------------------------------- finding the game

def steam_libraries():
    """Steam's own folder and every library listed in its libraryfolders.vdf."""
    roots = []
    try:
        import winreg
        for hive, key, name in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
                                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath")):
            try:
                with winreg.OpenKey(hive, key) as k:
                    roots.append(os.path.normpath(winreg.QueryValueEx(k, name)[0]))
            except OSError:
                pass
    except ImportError:
        pass
    roots.append(os.path.normpath(os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), "Steam")))
    libs = []
    for r in roots:
        vdf = os.path.join(r, "steamapps", "libraryfolders.vdf")
        if os.path.exists(vdf):
            for m in re.finditer(r'"path"\s+"([^"]+)"', open(vdf, encoding="utf-8", errors="replace").read()):
                libs.append(os.path.normpath(m.group(1).replace("\\\\", "\\")))
        libs.append(r)
    for letter in "CDEFGHIJ":  # (a library Steam no longer lists: the usual names)
        for name in ("SteamLibrary", "Steam", r"Program Files (x86)\Steam", "Games\\Steam"):
            libs.append(os.path.normpath("%s:\\%s" % (letter, name)))
    seen, out = set(), []
    for l in libs:
        if l.lower() not in seen:
            seen.add(l.lower())
            out.append(l)
    return out


def find_games():
    found = []
    for lib in steam_libraries():
        g = os.path.join(lib, "steamapps", "common", "Shank")
        if os.path.exists(os.path.join(g, "bin", "Shank.exe")) and g not in found:
            found.append(g)
    return found


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def game_build(game):
    """'steam', 'classic', or None (another build, or no Shank.exe)."""
    exe = os.path.join(game, "bin", "Shank.exe")
    if not os.path.exists(exe):
        return None
    b = BUILDS.get(sha256(exe))
    return b[0] if b else None


def check_game(game):
    """The build of the Shank in that folder (B54-2: the regular Steam version or the classic branch)."""
    exe = os.path.join(game, "bin", "Shank.exe")
    if not os.path.exists(exe):
        raise SetupError("Shank isn't in that folder (no bin\\Shank.exe). Choose the Shank folder, the one with the bin "
                         "and data folders.")
    build = game_build(game)
    if not build:
        raise SetupError("This copy of Shank isn't a version Shank Access supports (the regular Steam version or the Steam "
                         "classic version), so nothing was changed.")
    return build


def game_running():
    # (read as bytes: tasklist writes its localized "no tasks" line in the console code page, and text=True decoded it
    # in the ANSI one; a byte that doesn't decode there (German "ausgeführt": 0x81 in cp1252) left .stdout None, and
    # players got "Setup failed: 'NoneType' object has no attribute 'lower'", 2026-10-18. The image name is ASCII.)
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Shank.exe", "/NH"], capture_output=True,
                             creationflags=CREATE_NO_WINDOW).stdout or b""
        return b"shank.exe" in out.lower()
    except OSError:
        return False


def pid_alive(pid):
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ok = k.GetExitCodeProcess(h, ctypes.byref(code))
        k.CloseHandle(h)
        return bool(ok) and code.value == 259  # STILL_ACTIVE
    except (OSError, ValueError, AttributeError):
        return False


class SetupLock:
    """B57-1 (the user, 2026-10-11: "Build the safeties"): marks the game folder as being changed by this setup, so a game
    started meanwhile leaves the mod's files alone; another setup working on the same folder is refused."""

    def __init__(self, target):
        self.path = os.path.join(target, LOCK)

    def __enter__(self):
        try:
            pid = int(open(self.path, encoding="utf-8").read().split()[0])
        except (OSError, ValueError, IndexError):
            pid = 0
        if pid and pid != os.getpid() and pid_alive(pid) and time.time() - os.path.getmtime(self.path) < 3600:
            raise SetupError("Another Shank Access setup is working on this Shank folder. Let it finish, then try again.")
        try:
            with open(self.path, "w", encoding="utf-8", newline="\n") as f:
                f.write("%d\n" % os.getpid())
        except OSError as e:
            raise SetupError("Setup can't write to the Shank folder (%s)." % e)
        return self

    def __exit__(self, *exc):
        try:
            os.remove(self.path)
        except OSError:
            pass
        return False


IN_USE = ("A Shank Access file in the Shank folder was in use (%s), so setup couldn't finish. Close Shank, then run setup "
          "again: it finishes the job, changing only what's left.")


def wait_for_game(target, game, ask=None):
    """B57-1: Shank started while setup worked: before the game folder changes, the game must be closed again. ask() (the
    window's Retry / Cancel) returns True to look again; without it, or on Cancel, nothing in the folder changes."""
    while target == game and game_running():
        if ask is None or not ask():
            raise SetupError("Shank is running, so nothing in the Shank folder was changed. Close the game, then run setup "
                             "again.")


# ---------------------------------------------------------------- installing

def write(target, rel, data, written):
    dest = os.path.join(target, rel)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "wb") as f:
        f.write(data)
    written.append(rel.replace("\\", "/"))


def copy_payload(target, written, say):
    root = os.path.join(DATA, "payload", "files")
    if not os.path.isdir(root):  # (run from the source: the deployed set, as mod/artifacts.json + mod/files list it)
        n = 0
        for rel, src in json.load(open(os.path.join(REPO, "mod", "artifacts.json"), encoding="utf-8")).items():
            if rel in ("bin/shank_access_ui_text.txt", "bin/shank_access_geometry.txt", "bin/shank_access_paths.txt"):
                continue
            write(target, rel, open(os.path.join(REPO, src), "rb").read(), written)
            n += 1
        for src in glob.glob(os.path.join(REPO, "mod", "files", "**", "*"), recursive=True):
            if os.path.isfile(src) and not src.endswith(".gitkeep"):
                write(target, os.path.relpath(src, os.path.join(REPO, "mod", "files")), open(src, "rb").read(), written)
                n += 1
    else:
        n = 0
        for src in glob.glob(os.path.join(root, "**", "*"), recursive=True):
            if os.path.isfile(src):
                write(target, os.path.relpath(src, root), open(src, "rb").read(), written)
                n += 1
    say("Copied %d Shank Access files." % n)


def apply_patches(game, target, written, say, build="steam"):
    # (B54-2: the classic build has its own patch set and vanilla hashes: tools/make_classic_patches.py)
    classic = build == "classic"
    pristine = json.load(open(os.path.join(DATA, "mod", "pristine-classic.json" if classic else "pristine.json"),
                              encoding="utf-8"))
    root = os.path.join(DATA, "mod", "patches-classic" if classic else "patches")
    n = 0
    for dirpath, _, names in os.walk(root):
        for name in sorted(names):
            if not name.endswith(".patch.json"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, name), root).replace("\\", "/")[:-len(".patch.json")]
            src = os.path.join(game, rel)
            if not os.path.exists(src):
                raise SetupError("The game file %s is missing. Verify the game's files in Steam, then run setup again." % rel)
            want = pristine.get(rel)
            if want and sha256(src) != want:
                raise SetupError("The game file %s has been changed (by another mod or a game update). Verify the game's "
                                 "files in Steam, then run setup again." % rel)
            spec = json.load(open(os.path.join(dirpath, name), encoding="utf-8"))
            with open(src, "rb") as f:
                new = deploy.apply_ops(f.read(), spec["ops"], rel)
            write(target, deploy.override_path(rel), new, written)
            n += 1
    say("Applied %d game script changes." % n)


def path_graph_exe():
    for p in (os.path.join(DATA, "path_graph.exe"), os.path.join(REPO, "build", "native", "out", "path_graph.exe")):
        if os.path.exists(p):
            return p
    raise SetupError("path_graph.exe is missing from setup.")


class Cancelled(Exception):
    pass


class Progress:
    """B37-3c (the user: "It needs a standard progress bar for status tracking, plus a cancel button during the install
    with confirmation and proper cleanup."): the share of the work done (0..1) for the window's bar, and the cancel check
    (raises Cancelled; called between steps, at every line the level readers print, and while path_graph runs)."""

    def __init__(self, report=None, cancelled=None):
        self.report = report or (lambda fraction: None)
        self.cancelled = cancelled or (lambda: False)

    def check(self):
        if self.cancelled():
            raise Cancelled()

    def set(self, fraction):
        self.check()
        self.report(max(0.0, min(1.0, fraction)))


class LineCounter:
    """sys.stdout while a level reader runs: each line it prints (about one per level) moves the bar from lo toward hi."""

    def __init__(self, progress, lo, hi, expected):
        self.progress, self.lo, self.hi, self.expected, self.lines = progress, lo, hi, expected, 0

    def write(self, text):
        self.lines += text.count("\n")
        self.progress.set(self.lo + (self.hi - self.lo) * min(1.0, self.lines / float(self.expected)))
        return len(text)

    def flush(self):
        pass


def run_counting(fn, progress, lo, hi, expected):
    out = sys.stdout
    sys.stdout = LineCounter(progress, lo, hi, expected)
    try:
        fn()
    finally:
        sys.stdout = out


class SubProgress:
    """B58: one part of the bar (the installed build's work, then the other build's)."""

    def __init__(self, progress, lo, hi):
        self.progress, self.lo, self.hi = progress, lo, hi

    def check(self):
        self.progress.check()

    def set(self, fraction):
        self.progress.set(self.lo + (self.hi - self.lo) * max(0.0, min(1.0, fraction)))


def generate(game, target, written, work, say, progress, build="steam", installed=None, ui_text=True):
    levels = os.path.join(work, "levels")
    os.makedirs(levels, exist_ok=True)
    say("Reading the levels.")
    argv = sys.argv
    try:
        sys.argv = ["extract_levels", "--game-dir", game, "--out", levels]
        run_counting(extract_levels.main, progress, 0.05, 0.30, 12)
    finally:
        sys.argv = argv
    say("Mapping the levels.")
    geometry.GAME = game
    geometry.LEVELS_DIR = os.path.join(game, "data-pc", "levels")
    geometry.OUT_DIR = levels
    run_counting(lambda: geometry.main(["geometry"]), progress, 0.30, 0.50, 11)
    geo = os.path.join(levels, "shank_access_geometry.txt")
    write(target, "bin/shank_access_geometry.txt", open(geo, "rb").read(), written)
    if ui_text:  # (B58: not for the other build's store: the UI text isn't build-specific)
        say("Reading the game's screen text.")
        ui = os.path.join(work, "shank_access_ui_text.txt")
        run_counting(lambda: extract_ui_text.main(["--game", game, "--out", ui]), progress, 0.50, 0.53, 1)
        write(target, "bin/shank_access_ui_text.txt", open(ui, "rb").read(), written)
    key = paths_key(open(geo, "rb").read(), build)
    write(target, PATHS_KEY, (key + "\n").encode("utf-8"), written)
    cached = cached_paths(installed, build, key) if installed else None
    if cached is not None:  # B56-3
        say("The routes between checkpoints are already worked out for this version.")
        write(target, "bin/shank_access_paths.txt", cached, written)
        progress.set(0.98)
        return
    say("Working out the routes between checkpoints. This is the longest step.")
    paths = os.path.join(work, "shank_access_paths.txt")
    env = dict(os.environ)
    if build == "classic":
        env["SHANK_BUILD"] = "classic"  # B54-2: the classic build's jumps (jump_model::ClassicScale)
    else:
        env.pop("SHANK_BUILD", None)
    proc = subprocess.Popen([path_graph_exe(), geo, paths], stdout=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW,
                            env=env)
    start = time.time()
    try:
        while proc.poll() is None:
            # (its output only arrives at the end: the bar follows the time it usually takes, about 90 s)
            progress.set(0.53 + 0.45 * min(0.97, (time.time() - start) / 90.0))
            time.sleep(0.2)
    except Cancelled:
        proc.kill()
        proc.wait()
        raise
    if proc.returncode != 0:
        raise SetupError("Working out the routes failed (path_graph exit code %d)." % proc.returncode)
    write(target, "bin/shank_access_paths.txt", open(paths, "rb").read(), written)


def installed_files(target):
    """The files the installed mod's setup (or release 0.1's package) listed."""
    rels = []
    for lst in (LIST, OLD_MOD_LIST):
        p = os.path.join(target, lst)
        if os.path.exists(p):
            rels += open(p, encoding="utf-8").read().split()
    return rels


def sync(stage, target, new_rels, old_rels):
    """B54-2 (the user: "if the mod is already installed for the other version offer to switch to the new version while
    only changing what's actually different"): puts the staged files in place, writing only those whose content differs
    from what's there; then removes the old install's files the new one doesn't have. Returns (written, kept, removed)."""
    written = kept = 0
    for rel in new_rels:
        src, dest = os.path.join(stage, rel), os.path.join(target, rel)
        data = open(src, "rb").read()
        if os.path.isfile(dest) and open(dest, "rb").read() == data:
            kept += 1
            continue
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        # B57-1: written beside it, then swapped in whole: a game reading the file meanwhile never gets half of it
        tmp = dest + TMP_SUFFIX
        try:
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, dest)
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise
        written += 1
    keep = {r.lower() for r in new_rels} | {LIST.lower(), OLD_MOD_LIST.lower(), USER_INI.lower()}
    removed = remove_files(target, [r for r in old_rels if r.lower() not in keep])
    old_list = os.path.join(target, OLD_MOD_LIST)
    if os.path.exists(old_list):
        os.remove(old_list)
    return written, kept, removed


def commit(stage, target, written, build, had, had_build, other_set=None):
    """Puts the staged install in place (B54-2: only what differs). other_set (B58): (its stage, its files, made_by) of
    the other build's remade set, which becomes its store. Returns sync's (written, kept, removed)."""
    try:
        old = installed_files(target)
        if other_set:
            put_store(other_set[0], target, other_build(build), other_set[2], other_set[1])
        # B56-2: the other build's set stays, for switching back. (B57-1: unless the mod, started while setup worked,
        # already moved it to its store: its build file is gone then.)
        elif had and had_build and had_build != build and os.path.exists(os.path.join(target, BUILD_FILE)):
            keep_as_store(target, had_build, had, old)
        counts = sync(stage, target, written, old)
        shutil.rmtree(os.path.join(target, SET_ASIDE), ignore_errors=True)  # (B55-2's folder: replaced by the stores)
        shutil.rmtree(store_dir(target, build), ignore_errors=True)  # (this build's set is the installed one now)
        stores = os.path.join(target, STORES)
        if os.path.isdir(stores) and not os.listdir(stores):
            os.rmdir(stores)
        with open(os.path.join(target, LIST), "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(written) + "\n")
    except OSError as e:  # B57-1 (a loaded DLL can't be replaced: the game was started after the last check)
        raise SetupError(IN_USE % os.path.basename(getattr(e, "filename", None) or str(e)))
    return counts


def install(game, target=None, say=print, progress=None, ask_game_open=None):
    progress = progress or Progress()
    target = target or game
    build = check_game(game)
    if target == game and game_running():
        raise SetupError("Shank is running. Close the game, then try again.")
    os.makedirs(target, exist_ok=True)  # (a new --target folder: the lock goes in first)
    with SetupLock(target):
        return _install(game, target, build, say, progress, ask_game_open)


def _install(game, target, build, say, progress, ask_game_open):
    had = installed_version(target)
    had_build = installed_build(target) if had else None
    written = []
    # B54-2: everything is made in a staging folder first; the game folder changes only once it's all ready (a cancel
    # leaves it as it was), and then only where a file's content differs.
    other = other_build(build)
    # B58: the other build's set is remade too when it's stored here (or being switched away from) and its sources are
    # kept; else (stores from before B58) it stays as it is, and its first start asks for setup on that version.
    other_wanted = os.path.isdir(store_dir(target, other)) or (had and had_build == other)
    remake_other = bool(other_wanted) and has_sources(target, other)
    version = bundled_version()
    other_note = ""
    with tempfile.TemporaryDirectory() as work:
        stage = os.path.join(work, "stage")
        stage_other, written_other = os.path.join(work, "stage_other"), []
        main = SubProgress(progress, 0.0, 0.5 if remake_other else 1.0)
        try:
            main.set(0.0)
            copy_payload(stage, written, say)
            main.set(0.02)
            apply_patches(game, stage, written, say, build)
            main.set(0.05)
            generate(game, stage, written, work, say, main, build, installed=target)
            progress.check()
            if remake_other:
                name = BUILD_NAMES[other]

                def say_other(msg):
                    say("For %s: %s" % (name, msg[0].lower() + msg[1:]))
                try:
                    src = sources_dir(target, other)
                    apply_patches(src, stage_other, written_other, say_other, other)
                    os.makedirs(os.path.join(work, "other"), exist_ok=True)
                    generate(src, stage_other, written_other, os.path.join(work, "other"), say_other,
                             SubProgress(progress, 0.5, 1.0), other, installed=target, ui_text=False)
                    write(stage_other, BUILD_FILE, other.encode("utf-8"), written_other)
                    other_note = " Its files for %s are updated too." % name
                except SetupError:  # (the kept copy no longer matches: that version's first start asks for setup)
                    remake_other = False
                    other_note = (" Its files for %s couldn't be updated from the copy setup kept: the first time you "
                                  "start that version, run setup there once." % name)
            progress.check()
        except Cancelled:
            raise SetupError("Installation cancelled. Nothing in the Shank folder was changed.")
        write(stage, VERSION_FILE, version.encode("utf-8"), written)
        write(stage, BUILD_FILE, build.encode("utf-8"), written)
        wait_for_game(target, game, ask_game_open)  # B57-1: Shank may have been started meanwhile
        say("Putting the files in place.")
        changed, kept, removed = commit(stage, target, written, build, had, had_build,
                                        other_set=(stage_other, written_other, version) if remake_other else None)
        try:
            save_sources(game, target, build)  # B58: for the other build's Update
        except OSError:
            pass  # (only the other build's Update needs it: that one then asks for setup on this version)
    made_by = store_made_by(target, other)
    if made_by and made_by != version and not other_note:
        other_note = (" Its stored files for %s are from an earlier setup: the first time you start that version, run "
                      "setup there once." % BUILD_NAMES[other])
    if had and had_build != build:
        return ("Shank Access %s is switched to %s: %d files changed, %d removed, %d already the same.%s Start Shank to "
                "play." % (version, BUILD_NAMES.get(build, build), changed, removed, kept, other_note))
    return "Shank Access %s is installed for %s.%s Start Shank to play." % (version, BUILD_NAMES.get(build, build),
                                                                         other_note)


def uninstall(target, remove_settings=False, say=print):
    if target and game_running() and os.path.exists(os.path.join(target, "bin", "Shank.exe")):
        raise SetupError("Shank is running. Close the game, then try again.")
    try:
        with SetupLock(target):  # B57-1
            return _uninstall(target, remove_settings)
    except OSError as e:
        raise SetupError(IN_USE % os.path.basename(getattr(e, "filename", None) or str(e)))


def _uninstall(target, remove_settings):
    removed = 0
    rels = []
    for lst in (LIST, OLD_MOD_LIST):
        p = os.path.join(target, lst)
        if os.path.exists(p):
            rels += open(p, encoding="utf-8").read().split()
            rels.append(lst)
    if remove_settings:
        rels.append(USER_INI)
    if rels:  # (the mod's own logs in the game folder, written while playing, not by setup: the user's clean-state check)
        rels += RUNTIME_LOGS
    removed = remove_files(target, rels)
    shutil.rmtree(os.path.join(target, SET_ASIDE), ignore_errors=True)  # (B55-2)
    shutil.rmtree(os.path.join(target, STORES), ignore_errors=True)  # (B56: every build's store)
    shutil.rmtree(os.path.join(target, SOURCES), ignore_errors=True)  # (B58: the kept copies of each build's sources)
    return "Shank Access is uninstalled (%d files removed). The game's own files were never changed." % removed


def remove_files(target, rels):
    """Removes the listed files, then any folder left empty by that (data-pc\\stategraphs\\..., made by setup), never
    the target itself. Returns how many files were removed."""
    removed = 0
    dirs = set()
    for rel in rels:
        p = os.path.join(target, rel)
        if os.path.isfile(p):
            os.remove(p)
            removed += 1
            dirs.add(os.path.dirname(os.path.normpath(p)))
    root = os.path.normpath(target)
    for d in sorted(dirs, key=len, reverse=True):
        while d.startswith(root + os.sep) and os.path.isdir(d) and not os.listdir(d):
            os.rmdir(d)
            d = os.path.dirname(d)
    return removed


# ---------------------------------------------------------------- the window

def run_window():
    import wx

    class Frame(wx.Frame):
        def __init__(self):
            super().__init__(None, title="Shank Access setup", size=(640, 300))
            p = wx.Panel(self)
            s = wx.BoxSizer(wx.VERTICAL)
            s.Add(wx.StaticText(p, label="Shank folder:"), 0, wx.ALL, 6)
            row = wx.BoxSizer(wx.HORIZONTAL)
            self.path = wx.TextCtrl(p, name="Shank folder")
            row.Add(self.path, 1, wx.RIGHT, 6)
            self.browse = wx.Button(p, label="&Browse...")
            row.Add(self.browse)
            s.Add(row, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 6)
            self.status = wx.TextCtrl(p, style=wx.TE_READONLY | wx.TE_MULTILINE | wx.TE_NO_VSCROLL, size=(-1, 70),
                                      name="Status")
            s.Add(self.status, 0, wx.EXPAND | wx.ALL, 6)
            s.Add(wx.StaticText(p, label="Progress:"), 0, wx.LEFT | wx.RIGHT, 6)
            self.gauge = wx.Gauge(p, range=100, name="Progress")  # (a standard Windows progress bar)
            s.Add(self.gauge, 0, wx.EXPAND | wx.ALL, 6)
            buttons = wx.BoxSizer(wx.HORIZONTAL)
            self.go = wx.Button(p, label="&Install")
            self.remove = wx.Button(p, label="&Uninstall")
            self.cancel = wx.Button(p, label="C&ancel install")
            self.close = wx.Button(p, wx.ID_CANCEL, label="&Close")
            for b in (self.go, self.remove, self.cancel, self.close):
                buttons.Add(b, 0, wx.RIGHT, 6)
            s.Add(buttons, 0, wx.ALL, 6)
            p.SetSizer(s)
            self.cancel.Hide()
            self.cancel_asked = False
            self.running = False
            self.switching = False
            self.browse.Bind(wx.EVT_BUTTON, self.on_browse)
            self.go.Bind(wx.EVT_BUTTON, self.on_install)
            self.remove.Bind(wx.EVT_BUTTON, self.on_uninstall)
            self.close.Bind(wx.EVT_BUTTON, lambda e: self.Close())
            self.cancel.Bind(wx.EVT_BUTTON, lambda e: self.ask_cancel())
            self.Bind(wx.EVT_CLOSE, self.on_close)
            self.path.Bind(wx.EVT_TEXT, lambda e: self.refresh())
            games = find_games()
            self.path.SetValue(games[0] if games else "")
            if not games:
                self.set_status("Shank wasn't found in your Steam libraries. Choose its folder with Browse.")
            self.refresh()
            self.path.SetFocus()

        def set_status(self, text):
            self.status.SetValue(text)

        def refresh(self):
            game = self.path.GetValue().strip()
            ok = os.path.exists(os.path.join(game, "bin", "Shank.exe"))
            have = installed_version(game) if ok else None
            new = bundled_version()
            build = game_build(game) if ok else None  # B54-2
            self.switching = False
            if not ok:
                self.set_status("No Shank game in this folder. Choose the Shank folder (the one with the bin and data folders).")
                self.go.SetLabel("&Install")
            elif not build:
                self.set_status("This copy of Shank isn't a version Shank Access supports (the regular Steam version or the "
                                "Steam classic version).")
                self.go.SetLabel("&Install")
                ok = False
            elif have and installed_build(game) != build:
                self.switching = True
                self.set_status("Shank Access %s is installed for %s, but this Shank is %s. Switch changes only the files that "
                                "differ between the two." % (have, BUILD_NAMES.get(installed_build(game), "another version"),
                                                             BUILD_NAMES[build]))
                self.go.SetLabel("&Switch")
            elif not have:
                self.set_status("Shank found (%s). Shank Access isn't installed. This setup installs version %s."
                                % (BUILD_NAMES[build], new))
                self.go.SetLabel("&Install")
            elif have != new:
                both = os.path.isdir(store_dir(game, other_build(build))) and has_sources(game, other_build(build))
                self.set_status("Shank Access %s is installed. This setup has version %s: Update replaces it%s." % (
                    have, new, (", for %s and for %s, which is stored here too" % (BUILD_NAMES[build],
                                                                               BUILD_NAMES[other_build(build)])) if both else ""))
                self.go.SetLabel("&Update")
            else:
                self.set_status("Shank Access %s is installed and up to date. Reinstall makes its files again." % have)
                self.go.SetLabel("&Reinstall")
            self.go.Enable(ok)
            self.remove.Enable(bool(have))

        def on_browse(self, _):
            with wx.DirDialog(self, "Choose the Shank folder", self.path.GetValue()) as d:
                if d.ShowModal() == wx.ID_OK:
                    self.path.SetValue(d.GetPath())
            self.path.SetFocus()

        def busy(self, on, cancellable=False):
            self.running = on
            for c in (self.go, self.remove, self.browse, self.path, self.close):
                c.Enable(not on)
            self.cancel.Show(on and cancellable)
            self.cancel.Enable(on and cancellable)
            self.Layout()

        def work(self, fn, title, cancellable=False):
            self.cancel_asked = False
            self.gauge.SetValue(0)
            self.busy(True, cancellable)
            (self.cancel if cancellable else self.status).SetFocus()

            def say(msg):
                wx.CallAfter(self.set_status, msg)

            def report(fraction):
                wx.CallAfter(self.gauge.SetValue, int(round(fraction * 100)))

            progress = Progress(report, lambda: self.cancel_asked)

            def run():
                try:
                    result, icon = fn(say, progress), wx.ICON_INFORMATION
                    wx.CallAfter(self.gauge.SetValue, 100)
                except SetupError as e:
                    result, icon = str(e), wx.ICON_WARNING
                except Exception as e:  # noqa: BLE001
                    result, icon = "Setup failed: %s" % e, wx.ICON_ERROR
                wx.CallAfter(self.done, result, icon, title)

            threading.Thread(target=run, daemon=True).start()

        def done(self, result, icon, title):
            self.busy(False)
            self.refresh()
            wx.MessageBox(result, title, wx.OK | icon, self)
            self.go.SetFocus()

        def ask_cancel(self):
            if self.cancel_asked or not self.running:
                return
            a = wx.MessageBox("Cancel the installation? Everything it has done so far will be removed.", "Cancel install",
                              wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION, self)
            if a == wx.YES and self.running:
                self.cancel_asked = True
                self.cancel.Enable(False)
                self.set_status("Cancelling and cleaning up.")

        def on_close(self, event):
            if self.running:  # (closing the window during an install asks to cancel, and waits for the cleanup)
                if self.cancel.IsShown():
                    self.ask_cancel()
                event.Veto()
                return
            event.Skip()

        def on_install(self, _):
            game = self.path.GetValue().strip()
            if self.switching:  # B54-2: offer the switch (only what differs changes)
                a = wx.MessageBox("Shank Access is installed for the other version of Shank. Switch it to %s? Only the files "
                                  "that differ are changed; your settings stay." % BUILD_NAMES[game_build(game)],
                                  "Switch Shank Access", wx.YES_NO | wx.YES_DEFAULT | wx.ICON_QUESTION, self)
                if a != wx.YES:
                    return
            self.set_status("Installing. This takes about two minutes, and a message says when it's done.")
            self.work(lambda say, progress: install(game, say=say, progress=progress, ask_game_open=self.ask_game_open),
                      "Shank Access setup", cancellable=True)

        def ask_game_open(self):
            """B57-1 (from the install's thread): Shank was started while setup worked. Retry looks again (the work done so
            far is kept); Cancel leaves the Shank folder as it was."""
            answer, ready = {}, threading.Event()

            def show():
                with wx.MessageDialog(self, "Shank was started while setup was working. Close the game, then choose Retry to "
                                      "finish installing. Cancel leaves the Shank folder as it was.", "Shank is running",
                                      wx.OK | wx.CANCEL | wx.OK_DEFAULT | wx.ICON_WARNING) as d:
                    d.SetOKCancelLabels("&Retry", "&Cancel")
                    answer["ok"] = d.ShowModal() == wx.ID_OK
                ready.set()

            wx.CallAfter(show)
            ready.wait()
            return answer.get("ok", False)

        def on_uninstall(self, _):
            game = self.path.GetValue().strip()
            # (the user, 2026-10-03: "I'd recommend a choose what to uninstall prompt, with "mod plus your settings", "Mod
            # only", and a cancel button."; the native message box, its buttons relabelled)
            with wx.MessageDialog(self, "Choose what to uninstall. Your settings are your key bindings, volumes and other "
                                  "choices from the mod menu.", "Uninstall Shank Access",
                                  wx.YES_NO | wx.CANCEL | wx.CANCEL_DEFAULT | wx.ICON_QUESTION) as d:
                d.SetYesNoCancelLabels("Mod plus your &settings", "&Mod only", "&Cancel")
                a = d.ShowModal()
            if a not in (wx.ID_YES, wx.ID_NO):
                return
            a = wx.YES if a == wx.ID_YES else wx.NO
            self.work(lambda say, progress: uninstall(game, remove_settings=a == wx.YES, say=say), "Shank Access setup")

    app = wx.App()
    Frame().Show()
    app.MainLoop()


def main(argv):
    ap = argparse.ArgumentParser(description="Shank Access setup")
    ap.add_argument("--game")
    ap.add_argument("--target")
    ap.add_argument("--uninstall", action="store_true")
    args = ap.parse_args(argv)
    if not args.game and not args.uninstall:
        run_window()
        return 0
    try:
        if args.uninstall:
            print(uninstall(args.target or args.game))
        else:
            print(install(args.game, args.target))
    except SetupError as e:
        print(e)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
