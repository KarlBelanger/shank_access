"""Level geometry analysis (B4 G2/G3): what Shank can walk on, where each walkable surface really ends and
what is beyond each end, plus the traversal features (swing points, poles, ropes, wall-run zones).

Input: the level's collision (`.slev`, decoded by slev.py) and the level JSON from extract_levels.py (deadly
pits = fatal area effects; arena bounds). Output: build/levels/<level>.geometry.json and .geometry.txt.

Model (docs/RE-NOTES.md "Levels"): pixels, y up, 64 px = 1 tile; a segment's solid side is on the right of its
direction. A *surface* is a chain of walkable segments (floors and gentle slopes) joined end to end, so seams
between collision pieces don't count as edges. At each end of a surface we look for:
  - a wall rising from the end (a step if it's low enough to hop, else a wall; `noclimb` noted), or
  - a drop: the highest walkable surface below, just past the end, and its depth; "deadly" if the fall lands in
    a fatal pit zone or there is nothing below at all.

Usage:
  python tools/levels/geometry.py                 # every campaign level -> build/levels/
  python tools/levels/geometry.py <level> [...]   # selected levels, e.g. campaign_1a_wrestlingring
"""
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import slev  # noqa: E402

GAME = r"C:\Program Files (x86)\Steam\steamapps\common\Shank"
LEVELS_DIR = os.path.join(GAME, "data-pc", "levels")
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "build", "levels")
TILE = 64.0
JOIN = 2.0            # endpoints closer than this are the same point
PROBE = 16.0          # how far past an end we look for the ground below / a wall
# B10b: running or sliding off an edge carries him out while he falls (the B10 log: off 1-c's slippery surface 31
# at x 20224 he died in a grinder at x 20532; its pit starts at x 20245, just past PROBE). A pit counts if he can
# drift to it before falling to its top: at most DRIFT, at run speed (8 MPS) under the measured gravity.
DRIFT = 6 * TILE
RUN_SPEED = 768.0
SLIDE_SPEED = 1248.0
GRAVITY = 3200.0
STEP_MAX = 1.0 * TILE  # a rise Shank hops up without climbing (the game's `hop`: lastrunintowallheight <= 1 tile)
WALKABLE_NY = 0.5     # a slope is walkable if its up-normal is at least this (<= 60 degrees)


def unit_normal_up(seg):
    """The outward normal's y component (outward = left of the direction, the non-solid side)."""
    (x1, y1), (x2, y2) = seg["p1"], seg["p2"]
    dx, dy = x2 - x1, y2 - y1
    length = math.hypot(dx, dy) or 1.0
    return dx / length  # outward normal = (-dy, dx) / length; its y component


def walkable(seg):
    return unit_normal_up(seg) >= WALKABLE_NY


def y_at(seg, x):
    (x1, y1), (x2, y2) = seg["p1"], seg["p2"]
    if x2 == x1:
        return max(y1, y2)
    t = (x - x1) / (x2 - x1)
    return y1 + t * (y2 - y1)


def x_range(seg):
    return min(seg["p1"][0], seg["p2"][0]), max(seg["p1"][0], seg["p2"][0])


def near(a, b):
    return abs(a[0] - b[0]) <= JOIN and abs(a[1] - b[1]) <= JOIN


def build_surfaces(segs):
    """Chains of walkable segments joined end to end (left to right: a walkable segment runs left→right)."""
    walk = [i for i, s in enumerate(segs) if walkable(s)]
    by_start = {}
    for i in walk:
        by_start.setdefault((round(segs[i]["p1"][0]), round(segs[i]["p1"][1])), []).append(i)
    has_prev = set()
    nxt = {}
    for i in walk:
        end = segs[i]["p2"]
        for j in walk:
            if j != i and near(segs[j]["p1"], end):
                nxt[i] = j
                has_prev.add(j)
                break
    surfaces, seen = [], set()
    for i in walk:
        if i in has_prev or i in seen:
            continue
        chain = [i]
        seen.add(i)
        while chain[-1] in nxt and nxt[chain[-1]] not in seen:
            chain.append(nxt[chain[-1]])
            seen.add(chain[-1])
        surfaces.append(chain)
    for i in walk:  # loops (shouldn't happen)
        if i not in seen:
            surfaces.append([i])
            seen.add(i)
    return surfaces


def rising_wall(segs, point, outward):
    """A wall going up from `point` on the outward side (x = point.x, solid beyond the end). Returns
    (height, tags) following the wall up through joined pieces, or None."""
    x, y = point
    height, tags, cur_y, found = 0.0, set(), y, True
    while found:
        found = False
        for s in segs:
            (x1, y1), (x2, y2) = s["p1"], s["p2"]
            if abs(x1 - x2) > JOIN or abs(x1 - x) > JOIN:
                continue
            lo, hi = min(y1, y2), max(y1, y2)
            # right end (outward +1): the wall faces left (goes up); left end: faces right (goes down).
            faces = "wall_facing_left" if outward > 0 else "wall_facing_right"
            if s["kind"] == faces and abs(lo - cur_y) <= JOIN and hi > cur_y + JOIN:
                height += hi - cur_y
                cur_y = hi
                tags.update(s["tags"])
                found = True
                break
    return (height, sorted(tags)) if height > 0 else None


def lowest_wall_tags(segs, point, outward):
    """Tags of the wall piece rising straight from `point` (the part he'd run up first)."""
    faces = "wall_facing_left" if outward > 0 else "wall_facing_right"
    for s in segs:
        (x1, y1), (x2, y2) = s["p1"], s["p2"]
        if s["kind"] == faces and abs(x1 - point[0]) <= JOIN and abs(min(y1, y2) - point[1]) <= JOIN:
            return s["tags"]
    return []


def walls(segs):
    """Every wall as vertical runs: joined pieces at the same x facing the same way, split where
    climbability changes. Each: facing ("left" = solid to its right: he meets it moving right), x, y1 < y2,
    climbable (no `noclimb`), tags."""
    runs = []
    pieces = sorted((s for s in segs if s["kind"] in ("wall_facing_left", "wall_facing_right")),
                    key=lambda s: (s["kind"], s["p1"][0], min(s["p1"][1], s["p2"][1])))
    for s in pieces:
        x = s["p1"][0]
        lo, hi = sorted((s["p1"][1], s["p2"][1]))
        facing = "left" if s["kind"] == "wall_facing_left" else "right"
        climb = "noclimb" not in s["tags"]
        last = runs[-1] if runs else None
        joins = last and last["facing"] == facing and abs(last["x"] - x) <= JOIN and abs(last["y2"] - lo) <= JOIN
        if joins and last["climbable"] == climb:
            last["y2"] = hi
            last["tags"] = sorted(set(last["tags"]) | set(s["tags"]))
        else:
            runs.append({"facing": facing, "x": x, "y1": lo, "y2": hi, "climbable": climb, "tags": list(s["tags"])})
    return runs


def ground_below(segs, x, y):
    """The highest walkable segment under (x, y): (its y, segment index) or None."""
    best = None
    for i, s in enumerate(segs):
        if not walkable(s):
            continue
        lo, hi = x_range(s)
        if lo - JOIN <= x <= hi + JOIN:
            gy = y_at(s, x)
            if gy < y - JOIN and (best is None or gy > best[0]):
                best = (gy, i)
    return best


def in_pit(pits, x, y_top, y_bottom):
    """A fatal pit zone that a fall at x from y_top down to y_bottom passes through."""
    for p in pits:
        (lx, ly), (ux, uy) = p["lower"], p["upper"]
        if lx <= x <= ux and ly <= y_top and uy >= y_bottom:
            return p
    return None


def classify_end(segs, pits, point, outward, speed=None):
    wall = rising_wall(segs, point, outward)
    if wall:
        height, tags = wall
        kind = "step" if height <= STEP_MAX + JOIN else "wall"
        low = lowest_wall_tags(segs, point, outward)
        return {"type": kind, "height": height, "tags": tags, "climbable": kind == "wall" and "noclimb" not in low}
    x = point[0] + outward * PROBE
    below = ground_below(segs, x, point[1])
    land_y = below[0] if below else -1e9
    pit = in_pit(pits, x, point[1], land_y if below else -1e9)
    for k in range(1, 13):  # B10b: a pit within his drift off the edge (a fall that carries on outward)
        if pit:
            break
        xs = x + outward * DRIFT * k / 12
        b = ground_below(segs, xs, point[1])
        pit = in_pit(pits, xs, point[1], b[0] if b else -1e9)
        if pit:
            fall = max(point[1] - pit["upper"][1], 0.0)
            if abs(xs - point[0]) > (speed or RUN_SPEED) * math.sqrt(2 * fall / GRAVITY) + PROBE:
                pit = None
    if not below:
        return {"type": "drop", "depth": None, "deadly": True, "why": "nothing below"}
    depth = point[1] - land_y
    out = {"type": "drop", "depth": depth, "deadly": bool(pit), "lands_on": below[1]}
    if pit:
        out["why"] = "fatal pit zone"
    return out


def analyse(level):
    path = os.path.join(LEVELS_DIR, level, level + ".slev")
    data = slev.decode(open(path, "rb").read())
    segs = data["segments"]
    info_path = os.path.join(OUT_DIR, level + ".json")
    info = json.load(open(info_path)) if os.path.exists(info_path) else {}
    # B10b: only pits that apply to the player (2-b's "After Buildings" checkpoint sits inside one that doesn't).
    pits = [p for p in info.get("pits", []) if p.get("applytoplayer", True)]
    surfaces = []
    for n, chain in enumerate(build_surfaces(segs)):
        pts = [segs[chain[0]]["p1"]] + [segs[i]["p2"] for i in chain]
        tags = sorted({t for i in chain for t in segs[i]["tags"]})
        surf = {
            "id": n,
            "segments": chain,
            "points": pts,
            "tags": tags,
            # B12-1: off a slippery slope's low end he keeps the slide's speed (13 MPS)
            "left": classify_end(segs, pits, pts[0], -1, SLIDE_SPEED if "slipperyleft" in tags else None),
            "right": classify_end(segs, pits, pts[-1], +1, SLIDE_SPEED if "slipperyright" in tags else None),
        }
        surfaces.append(surf)
    mark_gaps(surfaces)
    # Traversal features straight from the file (meanings are hypotheses: RE-NOTES "Levels").
    features = []
    for p in data["points"]:
        features.append({"type": "swing_point", "pos": p})
    for b in data["boxes"]:
        features.append({"type": "wallrun_zone", "min": b["min"], "max": b["max"]})
    for n, p in enumerate(data["paths"]):
        pts = [nd["p"] for nd in p["nodes"]] + [p["end"]]
        for k, nd in enumerate(p["nodes"]):  # piece by piece: a path can go up a pole, then along a rope
            (x1, y1), (x2, y2) = pts[k], pts[k + 1]
            vertical = abs(x2 - x1) < abs(y2 - y1) * 0.2
            kind = ("slide_pole" if "slide" in nd["tags"] else "pole") if vertical else "shimmy_line"
            features.append({"type": kind, "points": [pts[k], pts[k + 1]], "tags": nd["tags"], "path": n})
    for i, s in enumerate(segs):
        if "skinny" in s["tags"] and s["kind"] in ("floor", "slope"):
            features.append({"type": "skinny_ledge", "segment": i, "p1": s["p1"], "p2": s["p2"]})
    ceilings = [{"p1": s["p1"], "p2": s["p2"]} for s in segs if s["kind"] in ("ceiling", "overhang")]
    return {"level": level, "surfaces": surfaces, "features": features, "walls": walls(segs), "ceilings": ceilings,
            "segment_count": len(segs),
            "bounds": info.get("bounds", []), "pits": pits, "checkpoints": checkpoint_chain(info.get("checkpoints", [])),
            "story": [t for t in info.get("triggers", []) if t.get("story") and t.get("region")]}  # B29-6


def checkpoint_chain(cps):
    """B10-1: the level's checkpoints in play order: from the initial one along the "next" names."""
    by_name = {c["name"]: c for c in cps}
    start = next((c for c in cps if c.get("key") == "Initial"), cps[0] if cps else None)
    chain, seen = [], set()
    c = start
    while c and c["name"] not in seen:
        chain.append(c)
        seen.add(c["name"])
        c = by_name.get(c.get("next") or "")
    chain += [c for c in cps if c["name"] not in seen]  # any off the chain, at the end
    return chain


def tiles(v):
    return "%g" % round(v / TILE, 1)


# B15-6: a narrow gap. Running off an edge with another floor this close across, at about the same height, the
# engine's "air warp" (mAirWarpTarget / Offset / Duration in Shank.exe) carries him over without a jump (B13b log:
# 1-b train, a 192 px gap between cars crossed both ways with an 18 px hop). The limits are the engine's (not in the
# scripts): these are guesses from the 3-tile gaps seen (hypothesis).
GAP_MAX = 4 * TILE
GAP_RISE_MAX = 3 * TILE    # the far floor at most this much higher (B28b, mark 4, 2-c x 68736 -> 68992: 4 tiles across,
                           # 3 up, crossed without input: carried over, then the ledge grab and climb; was 1 tile)
GAP_DROP_MAX = 1 * TILE    # ...or this much lower


def mark_gaps(surfaces):
    """Marks drop ends with a floor close across as a gap: end["gap"] = its width in px."""
    for s in surfaces:
        for side, outward in (("left", -1), ("right", 1)):
            e = s[side]
            if e["type"] != "drop":
                continue
            ex, ey = s["points"][0] if outward < 0 else s["points"][-1]
            best = None
            for o in surfaces:
                if o is s:
                    continue
                ox, oy = o["points"][-1] if outward < 0 else o["points"][0]  # its end facing this one
                width = (ex - ox) if outward < 0 else (ox - ex)
                if 0 < width <= GAP_MAX and -GAP_DROP_MAX <= oy - ey <= GAP_RISE_MAX and (best is None or width < best):
                    best = width
            if best is not None:
                e["gap"] = best


def describe_end(e):
    if e["type"] in ("step", "wall"):
        extra = " (noclimb)" if "noclimb" in e["tags"] else ""
        return "%s %s tiles high%s" % (e["type"], tiles(e["height"]), extra)
    if e.get("gap"):
        return "gap %s tiles across (run across)%s" % (tiles(e["gap"]), ", deadly below" if e["deadly"] else "")
    if e["depth"] is None:
        return "drop into nothing (deadly)"
    return "drop %s tiles%s" % (tiles(e["depth"]), " (DEADLY: %s)" % e["why"] if e["deadly"] else "")


def report(g):
    lines = ["Level: %s" % g["level"], "%d segments; %d walkable surfaces; %d features" %
             (g["segment_count"], len(g["surfaces"]), len(g["features"])), "", "Surfaces, left to right:"]
    for s in sorted(g["surfaces"], key=lambda s: (s["points"][0][0], s["points"][0][1])):
        (x1, y1), (x2, y2) = s["points"][0], s["points"][-1]
        if x2 - x1 < TILE / 2:
            continue
        lines.append("  #%d x %g..%g, y %g..%g (%s tiles)%s: left end %s; right end %s" % (
            s["id"], x1, x2, y1, y2, tiles(x2 - x1), " [%s]" % ",".join(s["tags"]) if s["tags"] else "",
            describe_end(s["left"]), describe_end(s["right"])))
    lines += ["", "Features:"]
    for f in g["features"]:
        if f["type"] == "skinny_ledge":
            continue
        where = f.get("pos") or f.get("min") or f["points"][0]
        lines.append("  %s at (%g, %g)%s" % (f["type"], where[0], where[1],
                                                  " to (%g, %g)" % tuple(f["points"][-1]) if "points" in f else ""))
    lines.append("  skinny ledges: %d" % sum(1 for f in g["features"] if f["type"] == "skinny_ledge"))
    return "\n".join(lines) + "\n"


def artifact_lines(g):
    """The DLL's compact form (native/core/level_geometry.cpp), one level section:
      [<level>]
      surface <id> <tags|-> <left end> <right end> <n> x1 y1 ... xn yn
          end = <wall|cwall|step|drop|gap> <height or depth, -1 = nothing below> <deadly 0|1>   (cwall: climbable;
                gap (B15-6): a drop with a floor close across that running carries him over)
      wall <left|right> <x> <y1> <y2> <climbable 0|1>   (left: solid to its right, met moving right)
      ceil x1 y1 x2 y2   (an underside: solid above; blocks jumps going up)
      feature <swing_point|wallrun_zone|pole|slide_pole|shimmy_line> <n> x1 y1 ... (wallrun: min and max corners)
      pit x1 y1 x2 y2
      checkpoint <order> <spawn x> <spawn y> <region x> <region y> <region w> <region h> <name ...>   (B10-1)
    """
    def end(e):
        value = e.get("height", e.get("depth"))
        kind = "cwall" if e.get("climbable") else "gap" if e.get("gap") else e["type"]  # cwall = a wall he can run up
        return "%s %g %d" % (kind, -1 if value is None else value, 1 if e.get("deadly") else 0)
    out = ["[%s]" % g["level"]]
    for s in g["surfaces"]:
        pts = " ".join("%g %g" % (x, y) for x, y in s["points"])
        out.append("surface %d %s %s %s %d %s" % (s["id"], ",".join(s["tags"]) or "-", end(s["left"]), end(s["right"]),
                                                  len(s["points"]), pts))
    for f in g["features"]:
        if f["type"] == "skinny_ledge":
            continue
        if f["type"] == "swing_point":
            pts = [f["pos"]]
        elif f["type"] == "wallrun_zone":
            pts = [f["min"], f["max"]]
        else:
            pts = f["points"]
        out.append("feature %s %d %s" % (f["type"], len(pts), " ".join("%g %g" % (x, y) for x, y in pts)))
    for w in g["walls"]:  # every wall (B6: they also block jumps); a wall he meets moving left ("right") or right
        out.append("wall %s %g %g %g %d" % (w["facing"], w["x"], w["y1"], w["y2"], 1 if w["climbable"] else 0))
    for c in g["ceilings"]:  # B6: undersides (solid above) block jumps going up
        out.append("ceil %g %g %g %g" % (c["p1"][0], c["p1"][1], c["p2"][0], c["p2"][1]))
    for p in g["pits"]:
        out.append("pit %g %g %g %g" % (p["lower"][0], p["lower"][1], p["upper"][0], p["upper"][1]))
    for i, c in enumerate(g["checkpoints"]):  # B10-1: in play order; region = trigger rectangle (corner, size), -1 if none
        r = c.get("region") or {"x": -1, "y": -1, "w": -1, "h": -1}
        out.append("checkpoint %d %g %g %g %g %g %g %s" % (i, c["spawn"][0], c["spawn"][1], r["x"], r["y"], r["w"], r["h"], c["name"]))
    return out


def story_chapters():
    """B29-2: {level: [(start checkpoint name or "", chapter name)]} from the game's campaigns.lua, Story Mode only
    (a level's sublevels, or the level's own name when it has none, e.g. 1-b pre-train)."""
    import re
    text = open(os.path.join(GAME, "data", "campaigns.lua"), encoding="latin-1").read()
    story = text.split('startlevel="coop', 1)[0]
    chapters, level, pending = {}, None, None
    for m in re.finditer(r'(?<![A-Za-z_])(name|level|startcp)\s*=\s*"([^"]*)"', story):
        key, value = m.group(1), m.group(2)
        if key == "name":
            pending = value
        elif key == "level":
            level = value
            chapters[level] = [("", pending)] if pending and pending != "Story Mode" else []
            pending = None
        elif key == "startcp" and level and pending:
            if chapters[level] and chapters[level][0][0] == "" and value == "":
                chapters[level] = []  # (its first sublevel names the start, not the level's own name)
            chapters[level].append((value, pending))
            pending = None
    return chapters


def goal_lines(g):
    """B29-6 (the user: "treat the tile immediately before the one that triggers the next level transition, as well as
    spots which trigger boss encounter scenes as checkpoints"): `goal <after checkpoint> <x> <y> <w> <h> <boss|cinematic>`,
    a region that starts a boss fight or a cinematic (a level's end) when entered, in its checkpoint's actions; each
    checkpoint's nearest first."""
    out = []
    order = {c["name"]: i for i, c in enumerate(g["checkpoints"])}
    goals = []
    for t in g.get("story", []):
        ctx = t["context"].split("/")[0]
        if not ctx.startswith("checkpoint:") or ctx[len("checkpoint:"):] not in order:
            continue  # (level-wide triggers aren't tied to a place in the level's order)
        i = order[ctx[len("checkpoint:"):]]
        sx, sy = g["checkpoints"][i]["spawn"]
        r = t["region"]
        d = math.hypot(r["x"] + r["w"] / 2 - sx, r["y"] + r["h"] / 2 - sy)
        goals.append((i, d, r, t["story"]))
    for i, d, r, kind in sorted(goals, key=lambda x: (x[0], x[1])):
        out.append("goal %d %g %g %g %g %s" % (i, r["x"], r["y"], r["w"], r["h"], kind))
    return out


def chapter_lines(g, chapters):
    """`chapter <checkpoint order> <name>`: the chapter that starts at that checkpoint (0 = the level's start)."""
    out = []
    names = [c["name"] for c in g["checkpoints"]]
    for startcp, name in chapters.get(g["level"], []):
        if not startcp:
            out.append("chapter 0 %s" % name)
        elif startcp in names:
            out.append("chapter %d %s" % (names.index(startcp), name))
        else:
            print("  (chapter %s: no checkpoint named %s)" % (name, startcp))
    return out


def main(argv):
    levels = argv[1:] or sorted(d for d in os.listdir(LEVELS_DIR) if d.startswith("campaign_") and "paxdemo" not in d)
    os.makedirs(OUT_DIR, exist_ok=True)
    chapters = story_chapters()  # B29-2
    combined = ["# shank-access level geometry (generated by tools/levels/geometry.py from the game's own files;",
                "# deployed as bin/shank_access_geometry.txt; never commit)"]
    for level in levels:
        g = analyse(level)
        combined += artifact_lines(g) + chapter_lines(g, chapters) + goal_lines(g)
        base = os.path.join(OUT_DIR, level + ".geometry")
        json.dump(g, open(base + ".json", "w"), indent=1)
        open(base + ".txt", "w").write(report(g))
        deadly = sum(1 for s in g["surfaces"] for e in (s["left"], s["right"]) if e.get("deadly"))
        print("%-32s surfaces %3d  features %3d  deadly ends %3d" % (level, len(g["surfaces"]), len(g["features"]), deadly))
    if not argv[1:]:  # the DLL's artifact covers every campaign level
        path = os.path.join(OUT_DIR, "shank_access_geometry.txt")
        open(path, "w", newline="\n").write("\n".join(combined) + "\n")
        print("wrote", os.path.normpath(path))


if __name__ == "__main__":
    main(sys.argv)
