#pragma once
// B14: feedback marks (the user, 2026-09-27: "put it on f2. If possible, have an edit box pop up where I can write
// comments, and that way each comment is directly tied to its mark."). The mark key numbers a moment in play: the
// mark and its context (level, Shank's position, health, the next move, the last thing spoken, ...) go to a11y.log
// and to a11y_marks.log in the game root (appended, so it survives relaunches); then a small comment window opens
// (a plain Win32 edit box the screen reader reads: Enter saves, Escape skips) and the comment is written under the
// same number. The game gets no keys while the window is open (input_block).
#include <functional>
#include <string>

namespace marks {

struct Hooks {
    std::function<std::string()> context;            // one line: where he is and what the mod was saying
    std::function<void(const std::string&)> say;
    std::function<void(bool)> block_input;
};

// marks_path: <game root>\a11y_marks.log.
void Init(const std::wstring& marks_path, const Hooks& hooks);
void Mark();  // the mark key (any thread; ignored while a comment window is open)

// The lines written for a mark and its comment (testable without a window).
std::string MarkLine(int n, const std::string& time, const std::string& context);
std::string CommentLine(int n, const std::string& comment);

}  // namespace marks
