#pragma once
// B13-2: the mod's own settings menu (the settings key, F7 by default): a spoken list the game doesn't see
// (input_block hides the keyboard from it while open). Up / Down move, Left / Right change a value, Enter /
// Space toggles or starts rebinding a key, Home / End jump, Escape or the settings key closes. Every change
// is saved at once (shank_access_user.ini). Design: docs/DESIGN.md "F7: settings".
#include <functional>
#include <string>
#include <vector>

namespace mod_menu {

struct Hooks {
    std::function<int()> get_volume;            // 0..100
    std::function<void(int)> set_volume;
    std::function<bool()> get_pan;              // sound panning relative to Shank (false: relative to the camera)
    std::function<void(bool)> set_pan;
    std::function<bool()> get_safe_edges;       // null when safe edges are unavailable
    std::function<void(bool)> set_safe_edges;
    std::function<bool()> get_waypoint;         // B38-1: waypoint mode (null: no item)
    std::function<void(bool)> set_waypoint;
    std::function<void()> save;
    std::function<void(const std::string&)> say;
    std::function<void(bool)> block_input;      // input_block::SetBlocking
    std::function<void(void (*)(int))> set_key_handler;  // hotkeys::SetMenuHandler
    std::function<void(void (*)(unsigned))> set_pad_handler;  // B39: hotkeys::SetPadCaptureHandler
    std::function<unsigned()> game_pad_inputs;  // B40-4: the controller inputs the game has bound (game_pads)
    // B15-2 "Learn sounds": each cue sound's spoken description, and playing it (by position in the list).
    std::vector<std::string> sounds;
    std::function<void(size_t)> play_sound;
    // B16 "Speech settings": each channel's engine (channel 0 menu, 1 stats, 2 automatic; engine 0 screen reader,
    // 1 SAPI) and our SAPI voice. get_engine unset = no speech settings item.
    std::function<int(int)> get_engine;
    std::function<void(int, int)> set_engine;
    std::function<std::vector<std::string>()> voices;
    std::function<std::string()> get_voice;  // "" = the Windows default
    std::function<void(const std::string&)> set_voice;
    std::function<int()> get_rate;           // -10..10
    std::function<void(int)> set_rate;
    std::function<int()> get_sapi_volume;    // 0..100
    std::function<void(int)> set_sapi_volume;
    std::function<void(const std::string&)> sample;  // speak through SAPI (a preview)
    // B34 "Go to checkpoint" (test mode only): the current level's checkpoints (spoken names), and going to one (returns
    // what to say: "Loading ..." or why not).
    std::function<bool()> test_mode;
    std::function<std::vector<std::string>()> checkpoints;
    std::function<std::string(int)> go_to_checkpoint;
    // B38-2: in a level, pause the game while the menu is open (our focus window); true if it paused. And back.
    std::function<bool()> pause_game;
    std::function<void()> resume_game;
};

void Init(const Hooks& hooks);
void Toggle();   // the settings key
bool IsOpen();
void OnKey(int vk);  // menu mode: a key went down (poll thread)

// B38-2b: what the menu shows now (its title, the list, the selected one), for the visual window; any thread.
struct View {
    std::string title;
    std::vector<std::string> items;
    int selected = -1;
};
View CurrentView();

// For tests: the text of the item at `index` ("" past the end) and the number of items.
std::string ItemText(size_t index);
size_t ItemCount();

}  // namespace mod_menu
