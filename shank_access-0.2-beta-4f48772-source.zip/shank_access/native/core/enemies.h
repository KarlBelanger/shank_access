#pragma once
// B8 enemy awareness: the enemies, read from the game's own item manager (RE-NOTES "Game items and the enemy
// list"). The manager is found once per level by scanning memory for its vtable; every tick its item vector is
// read (SEH-guarded): team, attributes hash (-> the character's name, from the game's own
// data/attributes/characters/*.lua file names), position. No Lua reports, so the goons' AI is untouched.
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include "position.h"

namespace enemies {

enum Class { kMedium, kLarge, kGirl, kDog, kBoss, kOther, kClassCount };

struct Enemy {
    uintptr_t item = 0;   // the game's item (identity while it lives)
    std::string name;     // attributes name, e.g. "med_thug_knifepistol"
    Class cls = kOther;
    float x = 0, y = 0;   // the same space as Shank's position (feet + 32)
    int team = 0;
};

// Character names: every data/attributes/characters/*.lua file name (hashed like the engine's names).
size_t LoadNames(const std::wstring& characters_dir);
size_t LoadPropNames(const std::wstring& props_dir);  // props: known, not characters (quiet diagnostics)
void AddName(const std::string& name);  // tests
uint32_t Hash(const std::string& name);  // sdbm of the lowercased name (0x43d060)
Class ClassOf(const std::string& name);
// Spoken kind: "knife goon", "large charger", "dog", "girl with uzi", "boss" ...
std::string Describe(const std::string& name);
// B8d special enemies (the user: "big, grenade throwing, wielding special weapons"): big goons, bosses, and goons
// with grenades, a grenade launcher, minigun, flamethrower, shotgun, rifle or shield.
bool IsSpecial(const std::string& name);

// Each cue tick (not the game's thread). Finds the manager when needed and reads the enemies.
void Update(unsigned now_ms, const position::Pos& shank);
std::vector<Enemy> Current();  // the characters, then any targets reported lately (B19-1)

// B19-1 (the user, 2026-09-27: "track the hanging meat in the butcher boss fight as enemies when they are targetable"):
// a prop that can be shot, from a Lua report (a11y/en_target_<kind>, every 0.5 s while it can be): listed by
// Current() as an enemy (name "meatslab" for kind "meat"; its id is a small number, never a game item) until it stops
// reporting for kTargetStaleMs.
void ReportTarget(const std::string& kind, float x, float y, unsigned now_ms);
// B21-2: the target at (x, y) was just shot down (its Lua report): off the list at once. False if none matched.
bool TargetDown(const std::string& kind, float x, float y, unsigned now_ms);
bool IsTarget(const std::string& name);  // a prop to shoot (not a character)
bool IsNonCombatant(const std::string& name);  // B36b-1: a scripted character that can't fight (not listed)
// B22-1: 900 ms lost the slabs during the Butcher's slow-motion attacks (the report's 0.5 s countdown is game time; 11
// blips in one fight). Shot down / broken is reported at once now (TargetDown), so this is only a backstop.
constexpr unsigned kTargetStaleMs = 3000;
constexpr float kTargetMatchPx = 96.f;
constexpr uintptr_t kTargetIdLimit = 0x10000;  // ids 1..0xffff: below any heap address
void OnLevel();  // a level load: the manager and items are gone

// The layout (RE-NOTES). Exposed for tests.
constexpr uint32_t kManagerVtable = 0x83ae44;
constexpr uint32_t kShankItemVtable = 0x837e88;  // cShankGameItem
constexpr uint32_t kGameItemVtable = 0x83b174;   // cGameItem
constexpr uint32_t kItemsFirst = 0x24, kItemsLast = 0x28;  // in the manager
constexpr uint32_t kTeam = 0x24, kAttrHash = 0x40, kPhysics = 0x5c, kLife = 0x64;  // in an item
constexpr uint32_t kPhysicsPos = 0xc, kLifeFlag = 0x24;
constexpr size_t kMaxItems = 4096;
constexpr unsigned kScanEveryMs = 3000;  // no manager yet: look again this often

// For tests: the memory access. read: copy n bytes at addr (false on a fault). scan: every 4-aligned
// address holding value (the vtable), in the game's writable memory.
using ReadFn = std::function<bool(uintptr_t addr, void* out, size_t n)>;
using ScanFn = std::function<std::vector<uintptr_t>(uint32_t value)>;
void SetMemory(ReadFn read, ScanFn scan);
// For tests of the cues: sets the current enemies directly.
void SetCurrentForTests(const std::vector<Enemy>& list);
// B36-1: when the whole list was last lost (the manager no longer valid as the level unloads, or a level load); 0 never.
// Enemies leaving then didn't die (the B35 log: after Denny's end video, the boss and a slave gave target down tones).
unsigned ListLostMs();
void SetListLostForTests(unsigned ms);

}  // namespace enemies
