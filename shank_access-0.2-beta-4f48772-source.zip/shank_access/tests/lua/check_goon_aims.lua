-- Run by tools/loadtest50.py after loading a gunman's stategraph (Lua 5.0), B13-4.
-- Asserts that the patched State() put PlaySound("a11y/en_aim") first in the on_enter of aiming states (tagged
-- "aiming", or a gun's "_pre" state), that those states carry no wind-up report too, and that at least one exists.
local function first_sound(st)
  local e = st.on_enter
  if type(e) == "table" and type(e[1]) == "table" and e[1].Type == "playsound" then return e[1].sound end
  return nil
end
local aims, problems = {}, {}
for _, st in ipairs(StateGraph.States) do
  if first_sound(st) == "a11y/en_aim" then
    table.insert(aims, st.name)
    local second = st.on_enter[2]
    if type(second) == "table" and second.Type == "playsound" and string.find(second.sound, "a11y/en_windup_", 1, true) then
      table.insert(problems, st.name .. " also reports a wind-up")
    end
    local tags = st.tags or ""
    if not string.find(tags, "aiming", 1, true) and not string.find(st.name, "_pre", 1, true) then
      table.insert(problems, st.name .. " (" .. tags .. ") isn't an aiming state")
    end
  end
end
print("  aim reports in " .. table.getn(aims) .. " states: " .. table.concat(aims, ", "))
if table.getn(problems) > 0 then error("wrong states: " .. table.concat(problems, "; ")) end
if table.getn(aims) == 0 then error("no aim reports") end
return true
