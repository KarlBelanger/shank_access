Shank Access 0.3 beta adds support for the classic version of Shank (Steam's "classic" beta branch), and makes
setup faster and safer.

## Installing or updating

Download **shank-access-setup.exe** below and run it. Setup works out whether you have the regular or the classic
version of Shank and installs the mod for it. Your settings are kept.

## The classic version

- Menus, readouts, positional sounds, enemy sounds, jump cues and waypoint mode all work on the classic version.
- Safe edges isn't available there, because that version of the game has no edge stop for the mod to use. The mod
  menu says so.

## Setup and switching versions

- If you switch Shank between the regular and the classic version in Steam, run setup once on each version. After
  that, the mod keeps both sets of its files and swaps them by itself when the game starts.
- If the mod finds files for the other version and has no set of its own, it sets its script changes aside so the game
  runs unmodified, and asks you to run setup.
- Updates change only the files that differ. When the routes don't need working out again, an update takes seconds
  instead of two minutes.
- Once setup has been run on both versions, Update updates both at once.
- Cancelling an install leaves the Shank folder as it was.
- If you start Shank while setup is working, the mod stays off for that game and says so, and setup waits for you to
  close the game before it finishes.

## Other changes

- The weapon unlock pop-up is read aloud: the weapon's name, what it does, its new move and how to equip it. F8
  repeats it.
- Safe edges no longer lets Shank walk over an edge while you keep holding the direction. Let go and press again to
  go over.
- An enemy outside the normal range only makes its sound while it's on screen, and N also lists enemies on screen
  beyond that range. Doors and other things to shoot outside the area you can reach are left out.
- A boss's "open to a grapple" sound no longer stops when a grapple misses him. It stops when the finisher starts.
- Escape in the feedback mark's comment box now cancels the mark.
- Start-up messages, such as the one about running setup, now use the voice you chose for automatic announcements.

Single player only. Copies of Shank from outside Steam aren't supported yet; on those, the mod says it's disabled.

Version 0.3-beta-REV. The source zip below has the full source for this version.
