#include "localization.h"

#include <windows.h>

#include <cstdio>
#include <map>

namespace localization {
namespace {

std::map<std::string, std::string> g_table;
SRWLOCK g_lock = SRWLOCK_INIT;

std::string DecodeEntities(const std::string& s) {
    static const struct {
        const char* entity;
        char ch;
    } kEntities[] = {{"&amp;", '&'}, {"&quot;", '"'}, {"&lt;", '<'}, {"&gt;", '>'}, {"&apos;", '\''}};
    std::string out;
    out.reserve(s.size());
    for (size_t i = 0; i < s.size();) {
        bool matched = false;
        if (s[i] == '&') {
            for (const auto& e : kEntities) {
                const size_t len = std::char_traits<char>::length(e.entity);
                if (s.compare(i, len, e.entity) == 0) {
                    out += e.ch;
                    i += len;
                    matched = true;
                    break;
                }
            }
        }
        if (!matched) out += s[i++];
    }
    return out;
}

}  // namespace

size_t LoadFromXliff(const std::string& xml) {
    std::map<std::string, std::string> table;
    static const std::string kResname = "resname=\"";
    static const std::string kSource = "<source>";
    static const std::string kSourceEnd = "</source>";
    size_t pos = 0;
    while ((pos = xml.find(kResname, pos)) != std::string::npos) {
        const size_t key_start = pos + kResname.size();
        const size_t key_end = xml.find('"', key_start);
        if (key_end == std::string::npos) break;
        const std::string key = xml.substr(key_start, key_end - key_start);
        const size_t next_unit = xml.find(kResname, key_end);
        const size_t src = xml.find(kSource, key_end);
        pos = key_end;
        if (src == std::string::npos || (next_unit != std::string::npos && src > next_unit)) continue;
        const size_t text_start = src + kSource.size();
        const size_t text_end = xml.find(kSourceEnd, text_start);
        if (text_end == std::string::npos) break;
        table[key] = DecodeEntities(xml.substr(text_start, text_end - text_start));
        pos = text_end;
    }
    AcquireSRWLockExclusive(&g_lock);
    g_table.swap(table);
    const size_t n = g_table.size();
    ReleaseSRWLockExclusive(&g_lock);
    return n;
}

size_t Load(const std::wstring& path) {
    FILE* f = nullptr;
    if (_wfopen_s(&f, path.c_str(), L"rb") != 0 || !f) return 0;
    std::string xml;
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) xml.append(buf, n);
    fclose(f);
    return LoadFromXliff(xml);
}

std::string Translate(const std::string& key) {
    AcquireSRWLockShared(&g_lock);
    auto it = g_table.find(key);
    std::string out = it != g_table.end() ? it->second : key;
    ReleaseSRWLockShared(&g_lock);
    return out;
}

}  // namespace localization
