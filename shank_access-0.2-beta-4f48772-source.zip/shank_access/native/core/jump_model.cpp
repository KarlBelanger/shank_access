#include "jump_model.h"

#include <algorithm>
#include <cmath>

namespace jump_model {
namespace {

const std::vector<Obstacle>* g_obstacles = nullptr;
const Target* g_own_swing = nullptr;  // B42c: the swing point a jump up leaves (an interceptor once he falls back past it)
bool g_ledge_grab = false;  // B41-6: the last flight that reached did so by a ledge grab
bool g_pit_death = false;   // B41c: the last flight ended in a deadly pit
const std::vector<Target>* g_interceptors = nullptr;  // B27-5: the level's swing points (they grab him in passing)
thread_local bool g_platform_up = false;  // B12-2: the last successful flight needed the platformup jump
thread_local bool g_allow_platform_up = true;  // B15-7

float Clamp01(float u) { return u < 0.f ? 0.f : u > 1.f ? 1.f : u; }

// Distance from point (px, py) to (x, y).
float ToPoint(float px, float py, float x, float y) { return std::hypot(px - x, py - y); }

// Distance from the target (a point, or a segment sampled) to (x, y).
float TargetTo(const Target& t, float x, float y) {
    if (t.kind == kSwing) return ToPoint(t.x1, t.y1, x, y);  // a point (x2, y2 unused)
    float best = 1e9f;
    for (int i = 0; i <= 16; ++i) {
        const float u = i / 16.f;
        best = std::min(best, ToPoint(t.x1 + u * (t.x2 - t.x1), t.y1 + u * (t.y2 - t.y1), x, y));
    }
    return best;
}

float YAt(const Obstacle& o, float x) {
    return o.x2 > o.x1 ? o.y1 + (x - o.x1) / (o.x2 - o.x1) * (o.y2 - o.y1) : o.y1;
}

// Does the step from (x0, y0) to (x1, y1) run into an obstacle? (His centre; body from feet y-32 to head y+128.)
const Obstacle* Blocked(const std::vector<const Obstacle*>& near, float x0, float y0, float x1, float y1) {
    for (const Obstacle* o : near) {
        switch (o->kind) {
            case Obstacle::kWallSolidRight:  // met moving right: his centre stops kBodyMargin short of it
            case Obstacle::kWallSolidLeft: {
                const bool right = o->kind == Obstacle::kWallSolidRight;
                const float stop = right ? o->x1 - kBodyMargin : o->x1 + kBodyMargin;
                // (B10b: also when he starts within his body's width of it: a launch spot at a floor's end by a wall)
                const bool crosses = right ? (x0 < o->x1 && x1 > x0 && x1 >= stop) : (x0 > o->x1 && x1 < x0 && x1 <= stop);
                if (!crosses) break;
                const float u = x1 != x0 ? Clamp01((stop - x0) / (x1 - x0)) : 0.f;
                const float yc = y0 + u * (y1 - y0);
                if (yc + kHeadUp > o->y1 && yc - kFeet < o->y2) return o;
                break;
            }
            case Obstacle::kCeiling:  // his head going up through its underside
                if (y1 > y0 && x1 + kCeilingHalfWidth >= std::min(o->x1, o->x2) && x1 - kCeilingHalfWidth <= std::max(o->x1, o->x2)) {
                    const float cy = YAt(*o, std::max(std::min(o->x1, o->x2), std::min(std::max(o->x1, o->x2), x1)));
                    // (B10b: or already through it at the start: a cling spot high on a wall under a platform)
                    if (y0 - kFeet < cy && y1 + kHeadUp >= cy) return o;
                }
                break;
            case Obstacle::kPit:  // B10b: into a fatal pit zone: he dies there
                // (B41-6, 1-c mark 1: a jump threading the 34 px between s42's edge and the meat grinder at one exact
                // speed: not something a player does; a flight keeps kPitMarginPx clear of a pit's sides)
                if (x1 >= o->x1 - kPitMarginPx && x1 <= o->x2 + kPitMarginPx && y1 >= o->y1 && y1 <= o->y2) return o;
                break;
            case Obstacle::kFloor:  // his feet coming down onto it: the flight ends there
                if (y1 < y0 && x1 >= o->x1 && x1 <= o->x2) {
                    // B41-1 (the B40d log, 1-c mark 5: walking off s43 "landed" 38 tiles down on s45, through the slope
                    // s59 rising toward him; he really lands on the slope and slides to his death): each end of the step
                    // against the floor's height there, so a rising slope can't pass his feet within one step.
                    const float fy0 = YAt(*o, x0 < o->x1 ? o->x1 : (x0 > o->x2 ? o->x2 : x0));
                    const float fy1 = YAt(*o, x1);
                    if (y0 - kFeet >= fy0 && y1 - kFeet < fy1) return o;
                }
                break;
        }
    }
    return nullptr;
}

// B27-5: does a swing point other than the target grab him at (nx, h) (the same catch as a swing point target)? Not the
// one he's leaving: any within kInterceptSkipPx of the launch.
bool Intercepted(const Target& t, float x0, float y0, float nx, float h, float dir, float vy_now, float peak) {
    if (!g_interceptors || vy_now <= -kGrabMaxFall) return false;
    for (const Target& i : *g_interceptors) {
        // B48d (the villa, B47 marks 2-3 "pathing misses a slide between shimmy and wall"; 2 deaths: the bar jump to the wall
        // past slide pole p16 caught on it and slid him to the bottom): a slide pole in the way catches him too.
        if (i.kind == kPole) {
            if (i.x1 == t.x1 && i.y1 == t.y1 && i.y2 == t.y2) continue;  // (the target itself)
            if (std::fabs(i.x1 - x0) < kInterceptSkipPx && y0 >= std::min(i.y1, i.y2) && y0 <= std::max(i.y1, i.y2)) continue;  // (leaving it)
            const float bottom = std::min(i.y1, i.y2), top = std::max(i.y1, i.y2);
            // (as a slide pole target: not from below it, nor far above where he left: B8c)
            // (B48d: from above his launch too: the villa bar jump caught p16 ~200 px up, coming down; rising past one he goes
            // on: 1-c's swing release past p at 14012 onto the wall behind it, session 1)
            if (h < bottom + kSlideAboveBottomPx || vy_now > 0.f) continue;
            if (h >= bottom && h <= top - kSlideInterceptBelowTopPx && std::fabs(nx - i.x1) <= kBodyMargin &&  // (his body at its line)
                (TargetTo(i, nx + dir * kGrabAhead, h + kGrabUp) <= kGrabRadius || TargetTo(i, nx, h) <= kGrabDisc)) {
                return true;
            }
            continue;
        }
        if (t.kind == kSwing && i.x1 == t.x1 && i.y1 == t.y1) continue;
        // (B42c: the one he leaves catches him again once he has been above it and is coming down: the B42b session, the
        // jump up off 1-c's second swing point rose ~390 px and dropped back onto it; letting go just falls away)
        if (std::hypot(i.x1 - x0, i.y1 - y0) < kInterceptSkipPx && (&i != g_own_swing || vy_now >= 0.f || peak <= i.y1)) continue;
        if (TargetTo(i, nx + dir * kGrabAhead, h + kGrabUp) <= kGrabRadius || (i.y1 >= h + kSwingCatchAbovePx && TargetTo(i, nx, h) <= kGrabDisc)) {
            return true;
        }
    }
    return false;
}

// One path at one sideways speed v (px/s, signed along dir): does it reach the target before anything stops it?
bool Path(const Target& t, float x, float y, float vy, float v, float dir, const std::vector<const Obstacle*>& near,
          float* seconds, bool touch = false) {
    float px = x, py = y;
    g_ledge_grab = false;
    g_pit_death = false;
    // B41c: a jump reaches a ledge from further below (the B40d log's bar jump: ~190 px) than a fall does (the B41b log:
    // falling off s60 caught s61's ledge 56 px up; off s59's end onto s40, 171 px, needs the jump: the user)
    const float ledge_reach = vy > 0.f ? kLedgeHangPx + kLedgeFromPosPx : kLedgeHangPx;
    // B41-4: this landing's ends that are a wall's ledge (the wall under the end), met from the open side: passing that
    // wall with the ledge within reach is a grab (OnAttachToLedge) even if his body misses a short lip (1-c's s29: a
    // 64 px wall under its left end; the logged bar jump caught it, the modelled body passed 1 px over the lip).
    float ledge_x[2] = {0.f, 0.f}, ledge_y[2] = {0.f, 0.f};
    int ledges = 0;
    if (t.kind == kLanding) {
        for (const Obstacle* o : near) {
            const bool right = o->kind == Obstacle::kWallSolidRight;  // met moving right
            if ((!right && o->kind != Obstacle::kWallSolidLeft) || (right ? dir < 0 : dir > 0)) continue;
            for (const float* e : {&t.x1, &t.x2}) {
                const float ex = *e, ey = e == &t.x1 ? t.y1 : t.y2;
                if (ledges < 2 && std::fabs(ex - o->x1) <= kLedgeMatchPx && std::fabs(ey - o->y2) <= kLedgeMatchPx &&
                    (right ? x < o->x1 : x > o->x1)) {
                    ledge_x[ledges] = right ? o->x1 - kBodyMargin : o->x1 + kBodyMargin;
                    ledge_y[ledges++] = ey;
                }
            }
        }
    }
    float y0 = y, vy0 = vy, t0 = 0.f;  // the vertical motion since launch, or since a bump on a ceiling
    float peak = y;                    // (B42c) his highest point so far
    for (float s = kStep; s <= kMaxSeconds; s += kStep) {
        const float h = y0 + vy0 * (s - t0) - 0.5f * kGravity * (s - t0) * (s - t0);
        const float nx = x + dir * v * s;
        const float vy_now = vy0 - kGravity * (s - t0);
        bool hit = false;
        switch (t.kind) {
            case kSwing:
            case kPole: {  // the grab spot (2 tiles ahead of and 3 above him), or within kGrabDisc of him
                // Too fast a fall and he goes past (the measured catches were rising or near the top); the disc
                // catch needs the point level with him or above (B5e).
                const float top = std::max(t.y1, t.kind == kSwing ? t.y1 : t.y2);
                // B8c: a slide pole from below just slides him back down (the user, 2-b: "from the bottom it still
                // registers as a jump target even though I can't seem to jump up to it").
                if (t.slide && (h > y + kSlideCatchAbovePx || h < std::min(t.y1, t.y2) + kSlideAboveBottomPx)) break;
                // (B42c: a swing point only when it's kSwingCatchAbovePx above him: 280 of 289 real catches)
                const float above = t.kind == kSwing ? kSwingCatchAbovePx : -kGrabBelowPx;
                hit = vy_now > -kGrabMaxFall && (TargetTo(t, nx + dir * kGrabAhead, h + kGrabUp) <= kGrabRadius ||
                                                 (top >= h + above && TargetTo(t, nx, h) <= kGrabDisc));
                // B44g (movement_check's false catches: flights passing ~50 px over a pole's top or under its bottom; all 226
                // real pole catches had him between its bottom and kPoleCatchBelowTopPx under its top, within kPoleCatchDx
                // across): a pole only along its length.
                if (hit && t.kind == kPole && (h < std::min(t.y1, t.y2) || h > top - kPoleCatchBelowTopPx ||
                                               std::fabs(nx - (t.x1 + t.x2) / 2) > kPoleCatchDx)) {
                    hit = false;
                }
                break;
            }
            case kShimmy:  // he hangs 3 tiles below it
                // B47c-3 (B47 session 2 mark 4, 4-a: a wall jump bumped the ceiling and came down 0.6 px inside the upper
                // line's end, and fell past it; the real catches were all at or inside an end): within the line's span only
                hit = nx >= std::min(t.x1, t.x2) + kShimmyEndInsidePx && nx <= std::max(t.x1, t.x2) - kShimmyEndInsidePx && TargetTo(t, nx, h + kHangUp) <= kGrabRadius;
                break;
            case kWallZone:
                // (Priest-session mark 1, 3-c: walking off s43 grazed zone f10 ~20 px under its bottom and he fell to his
                // death; the jump entered ~250 px higher and ran. Near the bottom the latch is unreliable (1-c, B5b vs
                // B5c: the same path latched once and fell through once), so a flight must be kWallZoneInsidePx inside.)
                // (B41e tried "only near the end he enters" and B41f took it back: the B41e log, 4-a, a wall jump came down
                // into zone (69326..70646) from above ~257 px inside its end and ran; re-read, the B41d "overshoot" from
                // the pole at 2286 had caught 1-c's f16 too and run to its end)
                // B44g (movement_check's false catches: entries within the body's margin of a zone's end, and fast falls through
                // it, didn't latch; the corpus's real latches were 52+ px inside the nearer end (90%), falling up to ~2170)
                hit = nx >= t.x1 + kWallZoneEndInsidePx && nx <= t.x2 - kWallZoneEndInsidePx && h >= t.y1 + kWallZoneInsidePx &&
                      h <= t.y2 + kBodyMargin && vy_now > -kWallZoneMaxFall;
                break;
            case kWall: {  // his body meets the wall within its height
                const bool ahead = dir > 0 ? t.x1 >= x : t.x1 <= x;
                // B47b-3 (the user, 1-c B47 session 1 mark 2: "a couple points which said jump but walk off worked, one to the
                // wall"): the graph's long jump off s40 at 24008 "to a climbable wall, 2 tiles down" (the face of a block under
                // that floor) went off the floor's far end and fell ~8 tiles past the wall's x: still "met" it. He meets it
                // only with his body at its face (not beyond it by more than this step's travel).
                const float past = dir > 0 ? nx + kBodyMargin - t.x1 : t.x1 - (nx - kBodyMargin);
                const bool meets = past >= 0.f && past <= 2 * kBodyMargin + std::fabs(v) * kStep;
                hit = ahead && meets && h >= t.y1 - kBodyMargin && h <= t.y2;
                break;
            }
            case kLanding: {  // his feet come down through the surface within its extent
                if (nx >= t.x1 && nx <= t.x2) {
                    const float sy = t.x2 > t.x1 ? t.y1 + (nx - t.x1) / (t.x2 - t.x1) * (t.y2 - t.y1) : t.y1;
                    hit = vy_now < 0.f && py - kFeet >= sy && h - kFeet <= sy;
                    // B12-2: touching a one-way floor (it runs through his body): Jump there takes him up onto it
                    if (!hit && touch && t.oneway && h - kFeet < sy && h + kHeadUp > sy) hit = true;
                }
                break;
            }
        }
        for (int i = 0; i < ledges && !hit; ++i) {  // B41-4
            const bool crosses = dir > 0 ? (px < ledge_x[i] && nx >= ledge_x[i]) : (px > ledge_x[i] && nx <= ledge_x[i]);
            const float above = ledge_y[i] - h;
            if (crosses && above >= -kFeet && above <= ledge_reach) hit = g_ledge_grab = true;
        }
        if (hit) {
            if (seconds) *seconds = s;
            return true;
        }
        // B27-5 (the user, 4-c: "pathing missed second swing"): a swing point on the way grabs him first (letting go of
        // f6 toward the pole, he caught f7): this flight ends there, not at the target.
        peak = std::max(peak, h);
        if (Intercepted(t, x, y, nx, h, dir, vy_now, peak)) return false;
        if (const Obstacle* ob = Blocked(near, px, py, nx, h)) {
            if (ob->kind == Obstacle::kPit) g_pit_death = true;  // (B41c)
            // B10b: a ceiling bumps his head and he falls on, still moving across (the B5b log: 1-c's pole-top
            // jump turned from +760 to about -450 px/s at the platform above and still reached the wall-climb zone).
            if (ob->kind == Obstacle::kCeiling) {
                y0 = py;
                vy0 = -kCeilingBounce * std::max(vy_now, 0.f);
                t0 = s - kStep;
                continue;
            }
            // B11-2: a ledge grab: stopped by the wall under this landing's end, with that ledge within LedgeHangDist
            // above him (and not below his feet), he grabs it (OnAttachToLedge) and climbs up onto it.
            if (t.kind == kLanding && (ob->kind == Obstacle::kWallSolidRight || ob->kind == Obstacle::kWallSolidLeft)) {
                for (const float* e : {&t.x1, &t.x2}) {
                    const float ex = *e, ey = e == &t.x1 ? t.y1 : t.y2;
                    const float above = ey - h;
                    if (std::fabs(ex - ob->x1) <= kLedgeMatchPx && std::fabs(ey - ob->y2) <= kLedgeMatchPx && above >= -kFeet &&
                        above <= ledge_reach) {
                        g_ledge_grab = true;
                        if (seconds) *seconds = s;
                        return true;
                    }
                }
            }
            return false;
        }
        px = nx;
        py = h;
        if (h < y - 3000.f) break;  // long gone
    }
    return false;
}

// The obstacles within dx of x (and not above y_top).
std::vector<const Obstacle*> NearObstacles(float x, float dx, float y_top) {
    std::vector<const Obstacle*> near;
    if (!g_obstacles) return near;
    for (const Obstacle& o : *g_obstacles) {
        if (std::max(o.x1, o.x2) < x - dx || std::min(o.x1, o.x2) > x + dx) continue;
        if (std::min(o.y1, o.y2) > y_top) continue;
        near.push_back(&o);
    }
    return near;
}

// One jump: sideways speeds from v_lo to v_hi (air control) are tried as separate paths. dir = +1 right, -1 left.
// only: -1 = a plain landing, then platformup (B12-2); 0 = plain only; 1 = platformup only.
bool Fly(const Target& t, float x, float y, float vy, float v_lo, float v_hi, float dir, float* seconds, int only = -1) {
    // Only the obstacles near this flight (it covers at most kMaxSeconds at the fastest speed).
    const std::vector<const Obstacle*> near = NearObstacles(
        x, std::max(std::fabs(v_lo), std::fabs(v_hi)) * kMaxSeconds + 2 * kBodyMargin, y + vy * vy / (2 * kGravity) + kHeadUp + 64.f);
    const bool touch_ok = t.oneway && g_allow_platform_up;
    for (int touch = only > 0 ? 1 : 0; touch < (touch_ok && only != 0 ? 2 : 1); ++touch) {  // plain first, then platformup
        // B41c (1-c mark 1: a standing jump threading the 34 px between s42's edge and the meat grinder at one exact
        // speed): a speed that reaches counts unless it's alone with a neighbouring speed dying in a pit.
        bool ok[kSpeedSamples], pit[kSpeedSamples];
        for (int k = 0; k < kSpeedSamples; ++k) {
            const float v = v_lo + (v_hi - v_lo) * k / (kSpeedSamples - 1);
            ok[k] = Path(t, x, y, vy, v, dir, near, nullptr, touch != 0);
            pit[k] = !ok[k] && g_pit_death;
        }
        for (int k = 0; k < kSpeedSamples; ++k) {
            if (!ok[k]) continue;
            const bool lo_ok = k > 0 && ok[k - 1], hi_ok = k + 1 < kSpeedSamples && ok[k + 1];
            const bool pit_by = (k > 0 && pit[k - 1]) || (k + 1 < kSpeedSamples && pit[k + 1]);
            if (!lo_ok && !hi_ok && pit_by && v_hi != v_lo && t.kind == kLanding) continue;  // (a needle beside a pit, onto a floor)
            const float v = v_lo + (v_hi - v_lo) * k / (kSpeedSamples - 1);
            Path(t, x, y, vy, v, dir, near, seconds, touch != 0);  // (again, for its time and ledge flag)
            g_platform_up = touch != 0;
            return true;
        }
    }
    return false;
}

}  // namespace

bool Land(float x, float y, float vx, float vy, float* land_x, float* land_y) {
    const std::vector<const Obstacle*> near =
        NearObstacles(x, std::fabs(vx) * kMaxSeconds + 2 * kBodyMargin, y + std::max(0.f, vy * vy / (2 * kGravity)) + kHeadUp + 64.f);
    float px = x, py = y;
    for (float s = kStep; s <= kMaxSeconds; s += kStep) {
        vy -= kGravity * kStep;
        float nx = px + vx * kStep;
        const float ny = py + vy * kStep;
        const Obstacle* o = Blocked(near, px, py, nx, ny);
        if (o && o->kind == Obstacle::kPit) return false;
        if (o && o->kind == Obstacle::kFloor) {
            *land_x = nx;
            *land_y = YAt(*o, nx) + kFeet;
            return true;
        }
        if (o && o->kind == Obstacle::kCeiling) {
            vy = std::min(vy, 0.f);
        } else if (o) {  // a wall: he slides down it
            nx = o->kind == Obstacle::kWallSolidRight ? o->x1 - kBodyMargin : o->x1 + kBodyMargin;
            vx = 0;
        }
        px = nx;
        py = ny;
    }
    return false;
}

bool ReachAtSpeed(const Target& t, float x, float y, float vx, float vy, bool* pit_death, float* seconds) {
    const float dir = vx < 0 ? -1.f : 1.f, v = std::fabs(vx);
    const std::vector<const Obstacle*> near =
        NearObstacles(x, v * kMaxSeconds + 2 * kBodyMargin, y + std::max(0.f, vy * vy / (2 * kGravity)) + kHeadUp + 64.f);
    bool died = false;
    for (int touch = 0; touch < (t.oneway && g_allow_platform_up ? 2 : 1); ++touch) {
        if (Path(t, x, y, vy, v, dir, near, seconds, touch != 0)) {
            g_platform_up = touch != 0;
            if (pit_death) *pit_death = false;
            return true;
        }
        died = died || g_pit_death;
    }
    if (pit_death) *pit_death = died;
    return false;
}

void SetObstacles(const std::vector<Obstacle>* obstacles) { g_obstacles = obstacles; }
void SetInterceptors(const std::vector<Target>* swing_points) { g_interceptors = swing_points; }

bool LastWasPlatformUp() { return g_platform_up; }

bool LastWasLedgeGrab() { return g_ledge_grab; }

void AllowPlatformUp(bool allowed) { g_allow_platform_up = allowed; }

// B44-2: which of a hold's jumps to try (both, or only the one his input makes now).
enum Which { kBoth = 0, kForwardOnly = 1, kUpOnly = 2 };

// (B44e: steer = a direction held: without one the live standing jump / jump up goes straight up)
Jump ReachGround(const Target& t, float x, float y, bool facing_right, float* seconds, Which which, bool steer = true) {
    const float dir = facing_right ? 1.f : -1.f;
    for (int pass = 0; pass < (t.oneway && g_allow_platform_up ? 2 : 1); ++pass) {  // every plain landing before platformup (B12-2)
        if (which != kUpOnly && Fly(t, x, y, kLongVy, kLongMinVx, kLongVx, dir, seconds, pass)) return kLong;
        // The standing jump steers either way; the grab point still follows his facing. B44c (the user, 1-c, facing left left
        // of the tall pole: "a jump target is playing to my right even though I'm facing left"): the one he makes now (the
        // chirp) goes straight up or his facing way; backwards is the other facing's jump (he turns first).
        const float back = which == kUpOnly ? 0.f : -kAirControl, ahead = which == kUpOnly && !steer ? 0.f : kAirControl;
        if (which != kForwardOnly && Fly(t, x, y, kStandVy, back, ahead, dir, seconds, pass)) return kStanding;
    }
    return kNone;
}

Jump Reach(const Target& t, float x, float y, bool facing_right, float* seconds) {
    return ReachGround(t, x, y, facing_right, seconds, kBoth);
}

Jump ReachLong(const Target& t, float x, float y, bool facing_right, float* seconds) {
    return ReachGround(t, x, y, facing_right, seconds, kForwardOnly);
}

Jump ReachStanding(const Target& t, float x, float y, bool facing_right, bool steer, float* seconds) {
    return ReachGround(t, x, y, facing_right, seconds, kUpOnly, steer);
}

float WallTopAbove(float x, float y) {
    if (!g_obstacles) return 1e9f;
    const Obstacle* wall = nullptr;
    for (const Obstacle& o : *g_obstacles) {
        if ((o.kind != Obstacle::kWallSolidLeft && o.kind != Obstacle::kWallSolidRight) || std::fabs(o.x1 - x) > 72.f) continue;
        if (y < o.y1 - 40.f || y > o.y2 + 40.f) continue;
        if (!wall || std::fabs(o.x1 - x) < std::fabs(wall->x1 - x)) wall = &o;
    }
    if (!wall) return 1e9f;
    float top = wall->y2;
    for (bool grown = true; grown;) {  // pieces stacked on it at the same x continue it
        grown = false;
        for (const Obstacle& o : *g_obstacles) {
            if (o.kind == wall->kind && std::fabs(o.x1 - wall->x1) < 1.f && std::fabs(o.y1 - top) < 2.f && o.y2 > top) {
                top = o.y2;
                grown = true;
            }
        }
    }
    return top;
}

Jump ReachFromWall(const Target& t, float x, float y, bool away_right, float* seconds) {
    const float dir = away_right ? 1.f : -1.f;
    // B42b: hanging at the ledge (the wall's top 120..200 px above him) the jump leaves falling
    const float below = WallTopAbove(x, y) - y;
    const float vy = below >= kLedgeJumpBelowMinPx && below <= kLedgeJumpBelowMaxPx ? kLedgeJumpVy : kWallJumpVy;
    return Fly(t, x, y, vy, kWallJumpMinVx, kWallJumpMaxVx, dir, seconds) ? kWallJump : kNone;
}

Jump ReachFromPole(const Target& t, float x, float y, bool away_right, float* seconds) {
    const float dir = away_right ? 1.f : -1.f;
    return Fly(t, x, y, kPoleJumpVy, kPoleJumpMinVx, kPoleJumpVx, dir, seconds) ? kPoleJump : kNone;
}

// B47 fix 2: the wall / pole jump he makes now: steered (a direction held) the whole range, else the unsteered speed.
Jump ReachFromWallAs(const Target& t, float x, float y, bool away_right, bool steer, float* seconds) {
    if (steer) return ReachFromWall(t, x, y, away_right, seconds);
    const float dir = away_right ? 1.f : -1.f;
    const float below = WallTopAbove(x, y) - y;
    const float vy = below >= kLedgeJumpBelowMinPx && below <= kLedgeJumpBelowMaxPx ? kLedgeJumpVy : kWallJumpVy;
    return Fly(t, x, y, vy, kUnsteeredJumpMinVx, kUnsteeredJumpMaxVx, dir, seconds) ? kWallJump : kNone;
}

Jump ReachFromPoleAs(const Target& t, float x, float y, bool away_right, bool steer, float* seconds) {
    if (steer) return ReachFromPole(t, x, y, away_right, seconds);
    const float dir = away_right ? 1.f : -1.f;
    return Fly(t, x, y, kPoleJumpVy, kUnsteeredJumpMinVx, kUnsteeredJumpMaxVx, dir, seconds) ? kPoleJump : kNone;
}

Jump BarJumps(const Target& t, float x, float y, bool facing_right, float* seconds, Which which, bool steer = true) {
    // the jump up: both ways for the graph; live, his facing way while a direction is held, else straight up (B44e)
    const float up_lo = which == kBoth ? -kUpJumpSteer : 0.f, up_hi = which == kBoth || steer ? kUpJumpSteer : 0.f;
    const float dir = facing_right ? 1.f : -1.f;
    y += kBarJumpLiftPx;  // (the pull-up before the flight)
    for (int pass = 0; pass < (t.oneway && g_allow_platform_up ? 2 : 1); ++pass) {
        if (which != kUpOnly && Fly(t, x, y, kBarJumpVy, kBarJumpMinVx, kBarJumpVx, dir, seconds, pass)) return kBarJump;
        if (which != kForwardOnly && Fly(t, x, y, kUpJumpVy, up_lo, up_hi, dir, seconds, pass)) return kUpJump;  // holding up
    }
    return kNone;
}

Jump ReachFromBar(const Target& t, float x, float y, bool facing_right, float* seconds) {
    return BarJumps(t, x, y, facing_right, seconds, kBoth);
}

Jump ReachFromBarAs(const Target& t, float x, float y, bool facing_right, bool up, bool steer, float* seconds) {
    return BarJumps(t, x, y, facing_right, seconds, up ? kUpOnly : kForwardOnly, steer);
}

// B42c: the swing point he hangs from at (x, y): the nearest of the level's (SetInterceptors) within reach, or nullptr.
const Target* SwingPointAt(float x, float y) {
    if (!g_interceptors) return nullptr;
    const Target* best = nullptr;
    float best_d = kSwingRadius + 64.f;
    for (const Target& i : *g_interceptors) {
        if (i.kind != kSwing) continue;  // (B48d: slide poles are in the list too)
        const float d = std::hypot(i.x1 - x, i.y1 - y);
        if (d < best_d) {
            best_d = d;
            best = &i;
        }
    }
    return best;
}

Jump SwingJumps(const Target& t, float x, float y, bool facing_right, float* seconds, Which which, bool steer = true) {
    const float up_lo = which == kBoth ? -kUpJumpSteer : 0.f, up_hi = which == kBoth || steer ? kUpJumpSteer : 0.f;  // (B44e)
    const float dir = facing_right ? 1.f : -1.f;
    // B42c: the release flies from its fixed spot by the point, the jump up from the swing's bottom (wherever he is on it)
    float rx = x, ry = y, ux = x, uy = y;
    if (const Target* p = SwingPointAt(x, y)) {
        rx = p->x1 + dir * kSwingReleaseAheadPx;
        ry = p->y1 - kSwingReleaseBelowPx;
        ux = p->x1;
        uy = p->y1 - kSwingRadius;
    }
    for (int pass = 0; pass < (t.oneway && g_allow_platform_up ? 2 : 1); ++pass) {
        if (which != kUpOnly && Fly(t, rx, ry, kSwingJumpVy, kSwingJumpMinVx, kSwingJumpVx, dir, seconds, pass)) return kSwingJump;
        if (which == kForwardOnly) continue;
        g_own_swing = SwingPointAt(x, y);  // (it catches him again on the way down)
        const bool up = Fly(t, ux, uy, kUpJumpVy, up_lo, up_hi, dir, seconds, pass);  // holding up
        g_own_swing = nullptr;
        if (up) return kUpJump;
    }
    return kNone;
}

Jump ReachFromSwing(const Target& t, float x, float y, bool facing_right, float* seconds) {
    return SwingJumps(t, x, y, facing_right, seconds, kBoth);
}

Jump ReachFromSwingAs(const Target& t, float x, float y, bool facing_right, bool up, bool steer, float* seconds) {
    return SwingJumps(t, x, y, facing_right, seconds, up ? kUpOnly : kForwardOnly, steer);
}

Jump ReachFalling(const Target& t, float x, float y, bool facing_right, float* seconds) {
    const float dir = facing_right ? 1.f : -1.f;
    // B44d (the user, 2-b, hanging from a bar holding Down: "reports valid jump target, but as you can see from my last death
    // it most definitely is not"; the landing 162 px aside at his height, caught as a ledge by the 720 px/s steer): letting go
    // (walldrop, shimmy_fall, poleswing_fall: Jump(1 MPS)) he steers with air control only.
    return Fly(t, x, y, 0.f, 0.f, kAirControl, dir, seconds) ? kWalkOff : kNone;
}

// B41-6 (1-c mark 1: "going left here leads to death"; walking off s42's left end the graph found s40 only at no speed
// at all, straight down past the meat grinder's edge; walking, he goes into it): walking off carries him at least at
// air-control speed.
Jump ReachWalkingOff(const Target& t, float x, float y, bool facing_right, float* seconds) {
    const float dir = facing_right ? 1.f : -1.f;
    return Fly(t, x, y, 0.f, kWalkOffMinVx, kWalkOffMaxVx, dir, seconds) ? kWalkOff : kNone;
}

Jump ReachSliding(const Target& t, float x, float y, bool downhill_right, float* seconds) {
    const float dir = downhill_right ? 1.f : -1.f;
    return Fly(t, x, y, kLongVy, kLongMinVx, kLongVx, dir, seconds) ? kLong : kNone;
}

Jump ReachSlidingOff(const Target& t, float x, float y, bool downhill_right, float* seconds) {
    const float dir = downhill_right ? 1.f : -1.f;
    return Fly(t, x, y, 0.f, kSlideOffMinVx, kSlideOffMaxVx, dir, seconds) ? kWalkOff : kNone;  // (B41c)
}

Jump ReachFromWallRunningUp(const Target& t, float x, float y, bool away_right, float* seconds) {
    const float dir = away_right ? 1.f : -1.f;
    return Fly(t, x, y, kRunUpJumpVy, kRunUpMinVx, kRunUpJumpVx, dir, seconds) ? kRunUpJump : kNone;
}

Jump ReachFromWallRun(const Target& t, float x, float y, bool moving_right, float* seconds) {
    const float dir = moving_right ? 1.f : -1.f;
    return Fly(t, x, y, kWallRunJumpV, kWallRunMinVx, kWallRunJumpV, dir, seconds) ? kWallRunJump : kNone;
}

}  // namespace jump_model
