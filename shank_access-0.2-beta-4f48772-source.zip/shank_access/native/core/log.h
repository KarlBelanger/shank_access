#pragma once
// a11y.log in the game root. Overwritten each launch, like the game's own logs; collect with
// tools/collect_logs.py before relaunching. Thread-safe; each line is flushed immediately so the
// log can be read live while the game is paused (alt-tab).
// B38-4 (the user, 2026-09-30: "The mod should also only save logs to the user's documents folder on exit if it has at
// least one mark."): a release build (SHANK_ACCESS_RELEASE) also copies a session that has a mark into
// Documents\Shank Access\logs (session_logs.h).
namespace alog {

void Open(const wchar_t* path);
void Write(const char* fmt, ...);  // printf-style; a timestamp and newline are added

}  // namespace alog
