#pragma once
// B5-3: Shank's jumps, from the stategraph Lua and his attributes (RE-NOTES "Shank's movement constants"),
// to answer "if he jumped now, would he reach this?". Pixels, y up; Shank's position is his feet + 32.
// Calibrated 2026-09-26 from 10 logged running long jumps (the `traj:` lines, B5 run): gravity 3200 px/s² (median;
// middle half 3154..3239), 720 px/s across all the way, a 205 px rise (so 1145 px/s up, 92% of the scripted
// 1247). The standing and wall jumps are scaled by the same 92% (not measured yet).
#include <vector>

namespace jump_model {

constexpr float kGravity = 3200.f;      // px/s² (measured)
constexpr float kStandVy = 1270.f;      // `jump`: Jump(90°, JUMP_SPEED × 1.15) = 1380 scripted; 92% (not measured)
constexpr float kLongVx = 720.f;        // `jumplong`: Jump(60°, JUMP_SPEED × 1.2) = 1440 px/s
constexpr float kLongVy = 1145.f;       // measured (a 205 px rise)
constexpr float kAirControl = 384.f;    // AirControlSpeed 4 MPS: steering in the air (both jumps)
constexpr float kLongMinVx = 324.f;     // the long jump steered back as far as we assume he can (guess)
constexpr float kWallJumpVx = 548.f;    // `walljump`: Jump(WALL_JUMP_ANGLE 65 degrees, WALL_JUMP_SPEED 13.5 MPS = 1296 px/s)
constexpr float kWallJumpVy = 1045.f;   //   away from the wall (B42b: the corpus, 229 clean wall jumps: ~1045 up, ~541 across
                                        //   unsteered; was 1140 from one 1-c jump's 203 px rise; scripted 1175)
// B42b (the corpus: 49 of 56 wall jumps from 120..200 px under a wall's top left falling; every one lower down rose):
// hanging at the ledge (its top this far above him), the jump goes down and away: ~620 px/s falling, ~540 across.
constexpr float kLedgeJumpBelowMinPx = 120.f, kLedgeJumpBelowMaxPx = 200.f;
constexpr float kLedgeJumpVy = -620.f;
constexpr float kWallJumpMinVx = 450.f; // steered back (guess; 250 let him catch 1-c's swing point from far too high, which the user says misses)
constexpr float kWallJumpMaxVx = 700.f; // measured ~600 across in 1-c's catch (holding away adds speed); the user: some
                                        // angles that work had no chirp with 548 as the top
// Letting go of a swing point (poleswing_jump: Jump(45 degrees, 17 MPS = 1632 px/s)): measured 2026-09-26 in 1-c,
// 1100-1240 across and ~1100 up just after the release, in the direction he faces.
// B42c (the corpus, 341 releases): whenever he presses, the release flies from one spot, ~74 px ahead of the point and
// ~70 below it (the swing sound plays as he passes the bottom, the flight starts ~0.18 s later), at ~1043 up and
// ~1135 across (10%: 970). The jump up (holding up) leaves from the bottom of the swing (the B42b session).
constexpr float kSwingJumpVx = 1145.f;
constexpr float kSwingJumpMinVx = 970.f;
constexpr float kSwingJumpVy = 1045.f;
constexpr float kSwingReleaseAheadPx = 74.f, kSwingReleaseBelowPx = 70.f;
// B6-5, the other launches (scripted, × 0.92 like the measured ones; not measured yet):
constexpr float kUpJumpVy = 1500.f;      // poleswing_jump_up / shimmy_jump_up: Jump(90°, 17 MPS) holding up
constexpr float kUpJumpSteer = 250.f;    //   little sideways (the bar version has air control; guess)
// runtowalljump (jump while running up a wall): scripted Jump(65°, 16.9 MPS), but B42b (the corpus: jumps while still
// running up launch as the wall jump, ~1045 up / ~541 across; was 1410 / 550..715, never measured): the wall jump's.
constexpr float kRunUpJumpVx = kWallJumpMaxVx;
constexpr float kRunUpJumpVy = kWallJumpVy;
constexpr float kRunUpMinVx = kWallJumpMinVx;
constexpr float kRunningUpVy = 450.f;    // clinging and moving up faster than this = running up (runtowall: 10, 6 MPS)
constexpr float kWallRunJumpV = 940.f;   // wallrunjump: Jump(45°, JUMP_SPEED × 1.2 = 1440) → ~1325 × 0.92, both axes
constexpr float kWallRunMinVx = 700.f;
// Jumping off a pole (shimmy_pole_jump, scripted as the wall jump): ~590 across. B10b: mid-pole jumps rise ~197 px
// (1-c's first pole in the B5 logs, 1-c's cold-storage pole in B10), the wall jump's ~1140 up; the 120-131 px rise
// measured at 1-c's pole top in B5b was cut short by the platform above. The jump starts from the side it heads
// to: jumping left from the right side, the game first moves him to the left side (x - 160).
constexpr float kPoleJumpVx = 650.f;
constexpr float kPoleJumpMinVx = 500.f;
constexpr float kPoleJumpVy = kWallJumpVy;  // B42b: the corpus, 146 clean pole jumps: ~1046 up, ~542 across (was 1140)
constexpr float kCeilingBounce = 0.6f;   // B10b: a ceiling turns his rise into a fall this fast (measured once, B5b)
constexpr float kPoleSideDx = 80.f;       // PoleClimbOffset 1.25 tiles: his x is the pole's +- this
// Jumping off a bar/rope (shimmy_jump_out: small hops, then Jump(45 degrees, 16 MPS) at 7.5 frames): measured
// 2026-09-26 in 1-c from the bar's end, ~1140 across and a 168 px rise (~1040 up).
constexpr float kBarJumpVx = 1140.f;
constexpr float kBarJumpMinVx = 1000.f;
constexpr float kBarJumpVy = 1040.f;
// B41-4 (measured, the B40d log, 1-c f19 at x 16014): off a bar he first pulls up 51 px in place (~160 ms), then flies
// (from there: +170 px to the top, matching kBarJumpVy).
constexpr float kBarJumpLiftPx = 51.f;
constexpr float kGrabRadius = 64.f;     // PoleGrabRadius 1 tile
// Measured 2026-09-26 (B5 run, 27 swing-point catches in 1-a and 1-c): he also catches a swing point that
// comes within about this distance of his position from any side (wall jumps in 1-c caught it level with or
// slightly below him, ~180 px to the side), not only through the scripted grab spot. Hanging, he swings on a
// circle of kSwingRadius around it (snapping on at (115 ahead, 137 below)).
constexpr float kGrabDisc = 190.f;
constexpr float kGrabMaxFall = 2000.f;  // ...while falling slower than this (px/s): 1-c's catches fell at ~1400-1550,
                                        // and the user: climbing too high means a miss. B42b: the corpus, 199 catches
                                        // fell at up to ~2020 (90%); was 1600 (movement_check: 37 real moves gained, 8 lost
                                        // with the B42b jump changes; 2400 gained little more)
constexpr float kSwingRadius = 178.f;
constexpr float kGrabBelowPx = 40.f;    // the disc catch needs the point no more than this below him: from swing
                                        // point 2, flights passed ~165 px *above* swing point 1 without catching
                                        // (B5d log); the catches that worked had it level or above. Poles only since B42c:
// B42c (the corpus: 280 of 289 swing-point catches had the point 80+ px above his position): a swing point's disc catch
// needs it this far above him (the release from 1-c's second swing point passes ~175 px over the first and falls past it).
constexpr float kSwingCatchAbovePx = 80.f;
constexpr float kGrabAhead = 128.f;     // PoleGrabOffset (2 tiles ahead, 3 up)
constexpr float kGrabUp = 192.f;
// B11-2 ledge grabs (shank.lua LedgeHangDist 2.5 tiles): a wall's top this far above his position is grabbed.
constexpr float kLedgeHangPx = 2.5f * 64.f;
// B41-4 (hypothesis; the B40d log, 1-c: a bar jump from the shimmy line f19 caught s29's ledge at (16384, 2944) with his
// position 180 px under it): the reach counts from his body's middle (CollisionHeight 2.5 tiles: feet + 80), 48 px above
// our position (feet + 32).
constexpr float kLedgeFromPosPx = 48.f;
constexpr float kLedgeMatchPx = 32.f;   // a landing's end this close to a wall's top is that wall's ledge
constexpr float kHangUp = 192.f;        // ShimmyOffset (0, 3 tiles): he hangs 3 tiles below a bar
constexpr float kFeet = 32.f;           // position = feet + 32
constexpr float kBodyMargin = 32.f;     // his radius, for entering a zone
constexpr float kCeilingHalfWidth = 16.f;  // B47c-3: a ceiling stops his head this far beside its end too (4-a w120: the bump at x 42555, the ceiling ending 42560)
constexpr float kShimmyEndInsidePx = 16.f;  // B47c-3: a shimmy line is caught this far inside its ends
constexpr float kWallZoneInsidePx = 32.f;  // a wall-run zone counts only this far above its bottom (the latch there fails)
constexpr float kPoleCatchBelowTopPx = 24.f, kPoleCatchDx = 120.f;  // B44g: a pole is caught along its length only
constexpr float kSlideInterceptBelowTopPx = 240.f;  // B48d: a slide pole in the way catches him only this far under its top (1-c: ~210 under, he went on to the wall; the villa: ~640 under, caught)
constexpr float kWallZoneEndInsidePx = 48.f;  // B44g: ...and this far inside its ends (was -kBodyMargin: up to 32 px outside)
constexpr float kWallZoneMaxFall = 2400.f;       // B44g: ...falling slower than this
constexpr float kMaxSeconds = 2.0f;
constexpr float kStep = 1.f / 60.f;
// B41d (the user: "make sure they align with the numbers the pathing uses"): shared by the live cues and the graph.
constexpr float kWallRunEndWindowPx = 96.f;  // the long jump off a wall run: this close to its end (wallruntofall)
constexpr float kRunUpMaxPx = 1088.f;        // a run up a wall reaches this far above its foot (the B40d log: 1632 -> 2718)
constexpr float kPitMarginPx = 0.f;  // B41-6 / B41c: none (the B41b log: sliding off s60 he passed 2 px from the pit's side)

enum Kind {
    kSwing,     // a swing point (x1, y1)
    kPole,      // a pole or slide pole (x1, y1)-(x2, y2)
    kShimmy,    // a bar/rope to hang from (x1, y1)-(x2, y2)
    kWallZone,  // a wall-run / wall-climb box (x1, y1) min, (x2, y2) max
    kLanding,   // a surface to land on: (x1, y1)-(x2, y2) left to right
    kWall,      // a wall to catch (he sticks to walls in the air): x = x1, from y1 to y2
};

struct Target {
    Kind kind;
    float x1, y1, x2, y2;
    // B8c: a slide pole (kPole): it only takes him down, so it counts only if he catches it no higher than
    // where the jump started (+kSlideCatchAbovePx) and at least kSlideAboveBottomPx above its bottom.
    bool slide = false;
    // B12-2: a one-way (skinny) floor: touching it in the air, Jump = platformup (a second 90-degree 14 MPS jump up
    // through it), so a flight whose body meets it from below reaches it too (LastWasPlatformUp() says so).
    bool oneway = false;
};
constexpr float kSlideCatchAbovePx = 64.f;
constexpr float kSlideAboveBottomPx = 3 * 64.f;  // a lower catch just slides him off at its foot

// B6-4: level geometry that stops a flight. Walls: x1 == x2, y1 < y2, solid on one side (he's stopped moving
// into it); ceilings: undersides (solid above) that stop him going up; floors: tops he lands on coming down (the
// flight ends there unless that floor is the landing target). Ceilings and floors run x1 < x2.
// B10b: kPit = a fatal pit zone, the box (x1, y1) min to (x2, y2) max: a flight whose centre enters it dies there.
struct Obstacle {
    enum Kind { kWallSolidRight, kWallSolidLeft, kCeiling, kFloor, kPit } kind;
    float x1, y1, x2, y2;
};
// The current level's obstacles (nullptr = none: flights go through everything, as before B6).
void SetObstacles(const std::vector<Obstacle>* obstacles);
// B27-5: the level's swing points (kSwing targets): a flight passing one grabs it first, so it doesn't reach anything
// beyond (nullptr = none). The one he launches from (within kInterceptSkipPx) doesn't count.
void SetInterceptors(const std::vector<Target>* swing_points);
constexpr float kInterceptSkipPx = 300.f;
constexpr float kHeadUp = 128.f;         // his head: position + 128 (CollisionHeight 2.5 tiles above his feet)
constexpr int kSpeedSamples = 9;         // sideways speeds tried across a jump's steerable range

enum Jump { kNone = 0, kStanding = 1, kLong = 2, kWallJump = 3, kSwingJump = 4, kBarJump = 5, kPoleJump = 6,
            kUpJump = 7, kRunUpJump = 8, kWallRunJump = 9, kWalkOff = 10 };

// Which jump started now (from standing on the ground at (x, y), facing that way) reaches the target, if
// any. The long jump is tried first (it's what holding forward does). *seconds = when it gets there.
Jump Reach(const Target& t, float x, float y, bool facing_right, float* seconds = nullptr);

// B42b: the top of the wall beside (x, y) (pieces stacked at the same x joined), from the obstacles; 1e9 = none known.
float WallTopAbove(float x, float y);
// B47 fix 2 (the old launches replayed through the cue: from walls the chirp claimed wall runs and poles that only a
// wall jump steered hard away (700 px/s) reaches; the real unsteered jumps go ~541 (the corpus: 10%-90% 508..553 off walls,
// 530..549 off poles) and fell short): with no direction held the jump judged is the unsteered one.
constexpr float kUnsteeredJumpMinVx = 510.f, kUnsteeredJumpMaxVx = 565.f;
Jump ReachFromWallAs(const Target& t, float x, float y, bool away_right, bool steer, float* seconds = nullptr);
Jump ReachFromPoleAs(const Target& t, float x, float y, bool away_right, bool steer, float* seconds = nullptr);
// B44-2: one jump only, the one his input makes now (the live chirp; Reach / ReachFromBar / ReachFromSwing try both, for
// the graph and the pluck): the long jump (running) or the standing jump; off a bar or swing point, forward or (holding
// up) the jump up.
Jump ReachLong(const Target& t, float x, float y, bool facing_right, float* seconds = nullptr);
// B44e: steer = a direction held (forward or back): without one, the standing jump and the jump up go straight up.
Jump ReachStanding(const Target& t, float x, float y, bool facing_right, bool steer = true, float* seconds = nullptr);
Jump ReachFromBarAs(const Target& t, float x, float y, bool facing_right, bool up, bool steer = true, float* seconds = nullptr);
Jump ReachFromSwingAs(const Target& t, float x, float y, bool facing_right, bool up, bool steer = true, float* seconds = nullptr);
// From clinging to a wall at (x, y): does a wall jump now (away from the wall: away_right = true if the wall
// is on his left) reach the target? kWallJump or kNone.
Jump ReachFromWall(const Target& t, float x, float y, bool away_right, float* seconds = nullptr);
// B6-6: running or walking off an edge (no jump; 0..kLongVx across, as for the long jump), facing its way.
// B41-6: walking off a floor's end (at least air-control speed); ReachFalling: letting go (no speed across).
Jump ReachWalkingOff(const Target& t, float x, float y, bool facing_right, float* seconds = nullptr);
Jump ReachFalling(const Target& t, float x, float y, bool facing_right, float* seconds = nullptr);
// B12-1 slippery slopes (sliding.lua): he slides downhill at kSlideSpeed and can't stop or turn. Jump = slide_jump:
// speed x 0, then the long jump, downhill only (kLong). Off the low end he keeps the slide's speed (slide_fall:
// air control; a 5-frame window to still long-jump, as ReachSliding from the end).
constexpr float kSlideSpeed = 1248.f;   // SetGroundSpeed(13 MPS)
// B41c (measured, the B41b log, 1-c's slopes s51 and s60: their arcs off the end): leaving a slope's end he crosses at
// ~750-790 px/s (both sliding off and jumping there), not the slide's 13 MPS.
constexpr float kSlideOffMinVx = 700.f, kSlideOffMaxVx = 860.f;
// B41-6 walking off a floor's end: at least air control, at most the long jump's speed (B45 trials these against the corpus).
constexpr float kWalkOffMinVx = 384.f, kWalkOffMaxVx = 720.f;
// B12-2: whether the last Reach* that succeeded needed the platformup jump (touching a one-way floor, then Jump).
bool LastWasPlatformUp();
// B41-6: whether the last reach was by grabbing the target's ledge (not landing on it).
bool LastWasLedgeGrab();
// B15-7: whether flights may use the platformup jump at all (default true). The graph asks every plain launch
// first with it off (the B13b log: a plain jump off the wall reached a platform the path sent him up into).
void AllowPlatformUp(bool allowed);
Jump ReachSliding(const Target& t, float x, float y, bool downhill_right, float* seconds = nullptr);
Jump ReachSlidingOff(const Target& t, float x, float y, bool downhill_right, float* seconds = nullptr);
// B6-2: falling (or flying) from (x, y) at (vx, vy): where his feet come down on a floor within kMaxSeconds
// (land_y = his position there, feet + 32). Walls stop him sideways (he slides down them). False = nothing
// (or he falls into a fatal pit zone first).
bool Land(float x, float y, float vx, float vy, float* land_x, float* land_y);
// B42-2 (movement_check): one flight at exactly this launch speed (vx signed, px/s game time) from (x, y): does it
// reach the target by the same catch rules (ledges, swing discs, poles, zones, floors, obstacles)? *pit_death = it died
// in a fatal pit zone instead.
bool ReachAtSpeed(const Target& t, float x, float y, float vx, float vy, bool* pit_death = nullptr, float* seconds = nullptr);
// Running up a wall (just after running into it): the stronger runtowalljump, away from the wall.
Jump ReachFromWallRunningUp(const Target& t, float x, float y, bool away_right, float* seconds = nullptr);
// Wall running (along a wall-run zone, moving that way): the wall-run jump, forward.
Jump ReachFromWallRun(const Target& t, float x, float y, bool moving_right, float* seconds = nullptr);

// From swinging on a swing point at (x, y) facing that way: does letting go now reach the target?
// kSwingJump or kNone.
Jump ReachFromSwing(const Target& t, float x, float y, bool facing_right, float* seconds = nullptr);

// From hanging on a bar/rope at (x, y) facing that way: does jumping off now reach the target? kBarJump or kNone.
Jump ReachFromBar(const Target& t, float x, float y, bool facing_right, float* seconds = nullptr);

// From climbing a pole at (x, y): does the pole jump now (away from the pole) reach the target? kPoleJump or kNone.
Jump ReachFromPole(const Target& t, float x, float y, bool away_right, float* seconds = nullptr);

}  // namespace jump_model
