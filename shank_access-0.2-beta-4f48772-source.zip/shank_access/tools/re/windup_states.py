"""Which goon states the State() patch reports as attack wind-ups, by the patch's own rules (tools/make_windup_patch.py),
read offline from the game's stategraph files (no Lua run). Diagnostic for trimming warnings (the user, 2026-09-28:
"I hear attack warnings when he's out of range or otherwise doesn't seem to do anything").

Usage (repo root):
  .venv/Scripts/python tools/re/windup_states.py boss_priest        # one folder under data/stategraphs/goon
  .venv/Scripts/python tools/re/windup_states.py                    # every goon folder: counts per kind
"""
import os
import re
import sys

GAME = os.environ.get("SHANK_GAME_DIR", r"C:/Program Files (x86)/Steam/steamapps/common/Shank")
GOON = os.path.join(GAME, "data", "stategraphs", "goon")

BAD = ["block", "invincible", "dazed", "inactive", "hit"]
GOOD = ["grenade", "shoot", "gun", "throw", "flame", "fire"]
GRAB = ["grab", "grapple", "pounce"]
CHARGE = ["charge", "ram", "lunge", "dash", "smash", "bellybounce", "piledriver"]
AIM_BAD = BAD
GUNS = ["shoot", "gun", "minigun", "shotgun", "uzi", "grenadelauncher", "missile", "rifle", "pistol"]


def states(src):
    """(name, tags, body) for each State{...} (body = the text up to the next state)."""
    out = []
    marks = [m for m in re.finditer(r'name\s*=\s*"([A-Za-z0-9_]+)"', src)]
    for i, m in enumerate(marks):
        body = src[m.start(): marks[i + 1].start() if i + 1 < len(marks) else len(src)]
        t = re.search(r'tags\s*=\s*"([^"]*)"', body[:400])
        out.append((m.group(1), t.group(1) if t else "", body))
    return out


def kind(name, tags, body):
    if name.startswith("grappled"):
        return None
    if "special_attack_flash_start" in body:  # B24
        return "grab" if any(w in name for w in GRAB) else "charge"
    attack = "attack" in tags
    if not attack:
        if "_pre" not in name or any(b in tags for b in BAD) or not any(g in name for g in GOOD):
            return None
    if any(w in name or w in tags for w in GRAB):
        return "grab"
    if any(w in name for w in CHARGE):
        return "charge"
    return "std"


def aiming(name, tags):
    if "aiming" in tags:
        return True
    if "_pre" not in name or "grappl" in name or any(b in tags for b in AIM_BAD):
        return False
    return any(g in name for g in GUNS)


def words(tags):
    return set(tags.replace(",", " ").split())


def kind_b26(name, tags, body, bases):
    """The B26 rules: grab words in the name or as whole tags (not "nograpple"); no "_pst" recovery states; a
    reported X_pre makes X... (the rest of that attack) silent; a gun's shot after its aim = "shot" (ends the aim,
    no sound)."""
    if name.endswith("_pst") or "_pst_" in name:
        return None
    for b in bases:
        if name != b + "_pre" and name.startswith(b) and not name.endswith("_pre"):
            return None
    k = kind(name, tags, body)
    if k is None:
        return None
    w = words(tags)
    if k == "grab" and not any(g in name for g in GRAB) and not (w & set(GRAB)):
        k = "charge" if any(c in name for c in CHARGE) else "std"
    if k in ("std", "charge") and any(g in name for g in GUNS) and not name.endswith("_pre"):
        return "shot"
    return k


def folder(path, b26=False):
    rows = []
    for f in sorted(os.listdir(path)):
        if not f.lower().endswith(".lua"):
            continue
        src = open(os.path.join(path, f), encoding="latin-1").read()
        bases = []
        for name, tags, body in states(src):
            if aiming(name, tags):
                rows.append((f, name, "aim", tags))
                if name.endswith("_pre"):
                    bases.append(name[:-4])
                continue
            k = kind_b26(name, tags, body, bases) if b26 else kind(name, tags, body)
            if k:
                rows.append((f, name, k, tags))
                if b26 and name.endswith("_pre"):
                    bases.append(name[:-4])
    return rows


def main(argv):
    if len(argv) > 1:
        for f, name, k, tags in folder(os.path.join(GOON, argv[1])):
            print("%-28s %-34s %-6s %s" % (f, name, k, tags))
        return 0
    for d in sorted(os.listdir(GOON)):
        p = os.path.join(GOON, d)
        if os.path.isdir(p):
            rows = folder(p)
            counts = {}
            for _, _, k, _ in rows:
                counts[k] = counts.get(k, 0) + 1
            print("%-20s %s" % (d, counts))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
