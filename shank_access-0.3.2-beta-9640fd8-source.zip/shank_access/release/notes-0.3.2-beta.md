Shank Access 0.3.2 beta fixes a problem that could stop Shank from starting with the mod installed. Nothing else
changes from 0.3.1 beta.

## Installing or updating

Download **shank-access-setup.exe** below and run it. Your settings are kept, and the update is quick: the routes
between checkpoints don't need working out again.

## Fix

- Sometimes Shank never opened its window: the game kept running in Task Manager and had to be ended there. The mod's
  start-up check of the game's version could get stuck waiting on Windows while the game was loading Steam's files.
  It happened only on some launches, and more often after recent Steam and Windows updates. The check no longer
  depends on Windows for this, so it can't get stuck.

Version 0.3.2-beta-REV. The source zip below has the full source for this version.
