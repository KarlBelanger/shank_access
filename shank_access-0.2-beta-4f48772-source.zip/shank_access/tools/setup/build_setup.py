"""B37-3: freeze tools/setup/shank_access_setup.py into build/setup/shank-access-setup.exe (PyInstaller, one file, a
window: wxPython).

Bundles: the mod's own files (mod/artifacts.json's DLLs and mod/files, not the game-derived files: setup makes those),
our patches (mod/patches), the vanilla hashes they check (mod/pristine.json), our path_graph.exe and payload/version.txt
("<RELEASE>-<git rev>": setup offers an update when the installed one differs). No Klei files go in.
Build the native code first. Usage (repo root): .venv/Scripts/python tools/setup/build_setup.py [--release]
  --release  take the DLLs from build/native_rel (the SHANK_ACCESS_RELEASE build) instead of build/native
"""
import json
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RELEASE = "0.2-beta"
GENERATED = {"bin/shank_access_ui_text.txt", "bin/shank_access_geometry.txt", "bin/shank_access_paths.txt"}


CMAKE = r"C:/Program Files/CMake/bin/cmake.exe"


def build_release_dlls():
    """B37-2b: reconfigure build/native_rel (the git rev in the DLL's version is taken at configure time) and rebuild
    the release DLLs, so the mod's version and this setup's version.txt are the same "<RELEASE>-<rev>"."""
    rel = os.path.join(ROOT, "build", "native_rel")
    subprocess.run([CMAKE, "-S", os.path.join(ROOT, "native"), "-B", rel, "-G", "Visual Studio 17 2022", "-A", "Win32",
                    "-DSHANK_ACCESS_RELEASE=ON", "-DSHANK_ACCESS_RELEASE_NUMBER=" + RELEASE], check=True,
                   stdout=subprocess.DEVNULL)
    subprocess.run([CMAKE, "--build", rel, "--config", "Release", "--target", "shank_access", "dinput8", "Tolk"], check=True,
                   stdout=subprocess.DEVNULL)


def main(argv):
    if "--release" in argv:
        build_release_dlls()
    native = os.path.join(ROOT, "build", "native_rel" if "--release" in argv else "native", "out")
    pg = os.path.join(ROOT, "build", "native", "out", "path_graph.exe")
    if not os.path.exists(pg):
        sys.exit("build path_graph.exe first (cmake --build build/native --config Release)")
    payload = os.path.join(ROOT, "build", "setup", "payload")
    shutil.rmtree(payload, ignore_errors=True)
    files = os.path.join(payload, "files")
    for rel, src in json.load(open(os.path.join(ROOT, "mod", "artifacts.json"), encoding="utf-8")).items():
        if rel in GENERATED:
            continue
        if src.startswith("build/native/out/"):
            src = os.path.join(native, os.path.basename(src))
        else:
            src = os.path.join(ROOT, src)
        if not os.path.exists(src):
            sys.exit("missing: " + src)
        os.makedirs(os.path.dirname(os.path.join(files, rel)), exist_ok=True)
        shutil.copy2(src, os.path.join(files, rel))
    for dirpath, _, names in os.walk(os.path.join(ROOT, "mod", "files")):
        for n in names:
            if n == ".gitkeep":
                continue
            rel = os.path.relpath(os.path.join(dirpath, n), os.path.join(ROOT, "mod", "files"))
            os.makedirs(os.path.dirname(os.path.join(files, rel)), exist_ok=True)
            shutil.copy2(os.path.join(dirpath, n), os.path.join(files, rel))
    rev = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT, capture_output=True, text=True).stdout.strip()
    with open(os.path.join(payload, "version.txt"), "w", encoding="utf-8") as f:
        f.write("%s-%s" % (RELEASE, rev or "unknown"))
    sep = os.pathsep
    cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--onefile", "--windowed",
           "--name", "shank-access-setup",
           "--distpath", os.path.join(ROOT, "build", "setup"),
           "--workpath", os.path.join(ROOT, "build", "setup", "work"),
           "--specpath", os.path.join(ROOT, "build", "setup"),
           "--paths", os.path.join(ROOT, "tools"),
           "--paths", os.path.join(ROOT, "tools", "levels"),
           "--paths", os.path.join(ROOT, "tools", "ui_text"),
           "--collect-all", "lupa",
           "--add-data", payload + sep + "payload",
           "--add-data", os.path.join(ROOT, "mod", "patches") + sep + os.path.join("mod", "patches"),
           "--add-data", os.path.join(ROOT, "mod", "pristine.json") + sep + "mod",
           "--add-binary", pg + sep + ".",
           os.path.join(ROOT, "tools", "setup", "shank_access_setup.py")]
    subprocess.run(cmd, check=True)
    print("-> " + os.path.join(ROOT, "build", "setup", "shank-access-setup.exe"))


if __name__ == "__main__":
    main(sys.argv[1:])
