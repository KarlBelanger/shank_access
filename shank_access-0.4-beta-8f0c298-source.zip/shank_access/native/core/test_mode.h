#pragma once
// Developer test mode. B18 (2026-09-27): F3 turns it on and off while playing and the choice is saved
// (shank_access_user.ini); the test keys (F4, ;) follow it (B70: the startup movie skips are their own setting, cheats). B66 (2026-10-18): god mode, super
// speed and Go to checkpoint moved to the cheats (cheats.h, F7 > Cheats), which don't need test mode.
namespace test_mode {

void SetOn(bool on);
bool On();

}  // namespace test_mode
