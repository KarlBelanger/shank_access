"""B42-1: the movement corpus. Every movement Shank made in every collected session, cut out of the logs.

Reads build/logs/<session>/a11y.log (the `traj:` samples, Shank's own movement sounds, deaths, level loads, test-mode
warps and super speed, the slow motion, the jump-now claims) and the level geometry (build/levels/<level>.geometry.json,
from tools/levels/geometry.py) and writes, in build/movements/ (derived numbers only; never commit):
  - movements.json: every movement with where it started, what he was on, how he launched, his fitted speeds (game time),
    the path, and how it ended (what he landed on or caught, a ledge grab, a death);
  - movements.txt: the airborne ones, flat, for native/tests/movement_check.cpp (B42-2);
  - summary.txt (also printed): per kind, the measured numbers next to the jump model's constants.

Usage: movements.py [--session <name substring>] [--quiet]

Pixels, y up; his position is his feet + 32 (as the logs and the jump model).
"""
import argparse
import glob
import json
import math
import os
import re
import statistics
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGS = os.path.join(ROOT, "build", "logs")
LEVELS = os.path.join(ROOT, "build", "levels")
OUT = os.path.join(ROOT, "build", "movements")

G = 3200.0          # jump_model::kGravity (px/s^2)
FEET = 32.0         # position = feet + 32
GAP_MS = 220        # traj samples further apart than this: the tracker lost him (or he stood still)
JUMP_PX = 260       # a step this big between samples: a respawn / warp, not a movement
FIT_TOL_PX = 12.0   # a sample this far off the flight's parabola ends the flight (a catch, a bump, a landing)
MIN_FIT = 4         # samples needed before the parabola is trusted

# Shank's own movement sounds (the event names after "Shank/Character/").
LAUNCH = {"jumpFromGround", "jumpFromWall", "jumpFromAir", "poleSwing"}
END = {
    "land": "land", "landRoll": "land", "ledgeClimb": "ledge", "ledgeGrab": "ledge", "wallAttach": "cling",
    "shimmy": "bar", "Movement_WallRunStep": "wall_run", "runUpWall": "run_up", "Movement/hitWall": "hit_wall",
}
DEATH = {"Shank_Death", "Shank_DeathMeatgrinder", "Shank_YellFalling"}
CONTEXT = {"step", "skidStop", "crouchStep", "crouchstep", "wallClimb", "dekeBehind"}

RX_T = re.compile(r"^\[(\d\d):(\d\d):(\d\d)\.(\d\d\d)\] (.*)$")
RX_TRAJ = re.compile(r"^traj: (\d+) (-?[\d.]+) (-?[\d.]+)")
RX_SND = re.compile(r"^sound at: Shank/Character/(\S+) pos=\((-?\d+), (-?\d+)\)(?: listener=\((-?\d+), (-?\d+)\))?")
RX_LEVEL = re.compile(r"^level: LoadSimData\(.*name (\S+)")
RX_CLAIM = re.compile(r"^cues: jump now reaches (.*) at \((-?\d+), (-?\d+)\) \((.*)\)$")
RX_TURN = re.compile(r"^cue: turn_([lr]) pos=\((-?\d+), (-?\d+)\)")


def short(name):
    """'Voices/Shank/Shank_Death' -> 'Shank_Death'; 'Movement/hitWall' stays (it's a key in END)."""
    if name in END:
        return name
    return name.split("/")[-1]


# ---------------------------------------------------------------------------------------------------------------------
# The log: a timeline per session


def parse_log(path):
    """Returns (events, traj): events = [(t, kind, data)] in log order; traj = [(t, x, y)] on the same clock."""
    events, traj_raw = [], []
    day, last = 0, -1
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = RX_T.match(line.rstrip("\n"))
            if not m:
                continue
            t = ((int(m.group(1)) * 60 + int(m.group(2))) * 60 + int(m.group(3))) * 1000 + int(m.group(4))
            if last >= 0 and t + 12 * 3600 * 1000 < last:
                day += 24 * 3600 * 1000  # past midnight
            last = t
            t += day
            body = m.group(5)
            if body.startswith("traj: "):
                mm = RX_TRAJ.match(body)
                if mm:
                    traj_raw.append((t, int(mm.group(1)), float(mm.group(2)), float(mm.group(3))))
                continue
            if body.startswith("sound at: Shank/Character/"):
                mm = RX_SND.match(body)
                if not mm:
                    continue
                name = short(mm.group(1))
                if name in LAUNCH or name in END or name in DEATH or name in CONTEXT or name in ("speedSlowDown", "speedNormal"):
                    lx = int(mm.group(4)) if mm.group(4) else None
                    ly = int(mm.group(5)) if mm.group(5) else None
                    events.append((t, "snd", (name, int(mm.group(2)), int(mm.group(3)), lx, ly)))
                continue
            if body.startswith("level: LoadSimData"):
                mm = RX_LEVEL.match(body)
                if mm:
                    events.append((t, "level", mm.group(1)))
            elif body.startswith("checkpoint jump: restart checkpoint now"):
                events.append((t, "warp", None))
            elif body.startswith("test mode: Super speed -> "):
                events.append((t, "superspeed", body.split("-> ")[1][:1] == "1"))
            elif body.startswith("cues: jump now reaches "):
                mm = RX_CLAIM.match(body)
                if mm:
                    events.append((t, "claim", (mm.group(1), int(mm.group(2)), int(mm.group(3)), mm.group(4))))
            elif body.startswith("cues: jump no longer reaches"):
                events.append((t, "unclaim", None))
            elif body.startswith("cues: too high for"):
                events.append((t, "toohigh", None))
            elif body.startswith("cue: turn_"):
                mm = RX_TURN.match(body)
                if mm:
                    events.append((t, "turn", mm.group(1) == "r"))
            elif body.startswith(("cue: up_", "cue: down_", "cue: fwd_", "cue: back_")):  # B44 / B44e: what he holds
                events.append((t, "hold", body[len("cue: "):].split(" ")[0]))
            elif body.startswith("waypoint: "):
                events.append((t, "waypoint", body[len("waypoint: "):]))
    # traj carries its own millisecond clock (the cue thread's GetTickCount): put it on the log's clock
    traj = []
    if traj_raw:
        offset = statistics.median(t - tick for t, tick, _, _ in traj_raw)
        traj = [(tick + offset, x, y) for _, tick, x, y in traj_raw]
    return events, traj


# ---------------------------------------------------------------------------------------------------------------------
# Geometry (build/levels/<level>.geometry.json)


def get_level(levels, name):
    if name not in levels:
        levels[name] = Level(name)
    return levels[name]


class Level:
    def __init__(self, name):
        self.name = name
        path = os.path.join(LEVELS, name + ".geometry.json")
        self.ok = os.path.exists(path)
        g = json.load(open(path, encoding="utf-8")) if self.ok else {}
        self.surfaces = g.get("surfaces", [])
        self.walls = g.get("walls", [])
        self.pits = g.get("pits", [])
        # the features as level_geometry indexes them (geometry.py's artifact leaves skinny ledges out)
        self.features = [f for f in g.get("features", []) if f["type"] != "skinny_ledge"]
        self.slopes = [s for s in self.surfaces if self.downhill(s)]

    @staticmethod
    def downhill(s):
        r, l = "slipperyright" in s["tags"], "slipperyleft" in s["tags"]
        return 0 if r == l else (1 if r else -1)

    def surface_at(self, x, y, below=40.0, above=24.0, only=None):
        """The surface (and its segment) whose height at x is within [y - below, y + above] of his feet y, nearest."""
        best, best_d = None, None
        for s in self.surfaces if only is None else only:
            pts = s["points"]
            for i in range(len(pts) - 1):
                (ax, ay), (bx, by) = pts[i], pts[i + 1]
                if bx - ax < 1 or x < ax - 1 or x > bx + 1:
                    continue
                h = ay + (min(max(x, ax), bx) - ax) / (bx - ax) * (by - ay)
                d = y - h
                if -above <= d <= below and (best_d is None or abs(d) < abs(best_d)):
                    best, best_d = (s, i), d
        return best

    def segment_spec(self, s, i):
        (ax, ay), (bx, by) = s["points"][i], s["points"][i + 1]
        return {"type": "landing", "surface": s["id"], "x1": ax, "y1": ay, "x2": bx, "y2": by,
                "oneway": "skinny" in s["tags"], "slope": self.downhill(s)}

    def ledge_near(self, x, y):
        """A floor end (a ledge) he could have grabbed from (x, y): above him within reach, beside him."""
        best, best_d = None, None
        for s in self.surfaces:
            pts = s["points"]
            if len(pts) < 2:
                continue
            for i, (px, py) in ((0, pts[0]), (len(pts) - 2, pts[-1])):
                d = math.hypot(px - x, (py - (y - FEET + 80.0)))
                if d < 260 and (best_d is None or d < best_d):
                    best, best_d = (s, i), d
        return best

    def wall_near(self, x, y, within=72.0):
        best, best_d = None, None
        for i, w in enumerate(self.walls):
            if not (w["y1"] - 32 <= y <= w["y2"] + 64):
                continue
            d = abs(w["x"] - x)
            if d <= within and (best_d is None or d < best_d):
                best, best_d = i, d
        return best

    def feature_near(self, x, y, types, within):
        best, best_d = None, None
        for i, f in enumerate(self.features):
            if f["type"] not in types:
                continue
            d = self.feature_distance(f, x, y)
            if d <= within and (best_d is None or d < best_d):
                best, best_d = i, d
        return best

    @staticmethod
    def feature_distance(f, x, y):
        if f["type"] == "swing_point":
            return math.hypot(f["pos"][0] - x, f["pos"][1] - y)
        if f["type"] == "wallrun_zone":
            (x1, y1), (x2, y2) = f["min"], f["max"]
            dx = max(x1 - x, 0, x - x2)
            dy = max(y1 - y, 0, y - y2)
            return math.hypot(dx, dy)
        pts = f["points"]
        best = None
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            vx, vy = bx - ax, by - ay
            L2 = vx * vx + vy * vy
            u = 0 if L2 == 0 else max(0, min(1, ((x - ax) * vx + (y - ay) * vy) / L2))
            d = math.hypot(ax + u * vx - x, ay + u * vy - y)
            best = d if best is None else min(best, d)
        return best if best is not None else 1e9

    def feature_spec(self, i):
        f = self.features[i]
        if f["type"] == "swing_point":
            x1, y1 = f["pos"]
            x2, y2 = 0, 0
        elif f["type"] == "wallrun_zone":
            (x1, y1), (x2, y2) = f["min"], f["max"]
        else:
            (x1, y1), (x2, y2) = f["points"][0], f["points"][-1] if len(f["points"]) > 1 else f["points"][0]
        kind = {"swing_point": "swing", "wallrun_zone": "wallzone", "pole": "pole", "slide_pole": "pole",
                "shimmy_line": "shimmy"}[f["type"]]
        return {"type": kind, "feature": i, "x1": x1, "y1": y1, "x2": x2, "y2": y2, "slide": f["type"] == "slide_pole"}

    def wall_spec(self, i):
        w = self.walls[i]
        return {"type": "wall", "wall": i, "x1": w["x"], "y1": w["y1"], "x2": w["x"], "y2": w["y2"],
                "climbable": w["climbable"], "facing": w["facing"]}

    def in_pit(self, x, y):
        for p in self.pits:
            (x1, y1), (x2, y2) = p["lower"], p["upper"]
            if x1 <= x <= x2 and y1 - 64 <= y <= y2 + 64:
                return True
        return False

    def what_on(self, x, y):
        """What he's on or holding at (x, y) (a rough label for a start)."""
        hit = self.surface_at(x, y - FEET)
        if hit:
            s, i = hit
            return self.segment_spec(s, i)
        f = self.feature_near(x, y, ("pole", "slide_pole"), 112)
        if f is not None:
            return self.feature_spec(f)
        f = self.feature_near(x, y + 192, ("shimmy_line",), 96)
        if f is not None:
            return self.feature_spec(f)
        f = self.feature_near(x, y, ("swing_point",), 260)
        if f is not None:
            return self.feature_spec(f)
        f = self.feature_near(x, y, ("wallrun_zone",), 48)
        if f is not None:
            return self.feature_spec(f)
        w = self.wall_near(x, y)
        if w is not None:
            return self.wall_spec(w)
        return None


# ---------------------------------------------------------------------------------------------------------------------
# Flights


def fit_parabola(pts):
    """Least squares y = a + b t + c t^2 over [(t, y)]. Returns (a, b, c) or None."""
    n = len(pts)
    if n < 3:
        return None
    s = [0.0] * 5
    r = [0.0] * 3
    for t, y in pts:
        p = 1.0
        for k in range(5):
            s[k] += p
            if k < 3:
                r[k] += p * y
            p *= t
    m = [[s[0], s[1], s[2]], [s[1], s[2], s[3]], [s[2], s[3], s[4]]]
    return solve3(m, r)


def solve3(m, r):
    m = [row[:] + [r[i]] for i, row in enumerate(m)]
    for c in range(3):
        p = max(range(c, 3), key=lambda k: abs(m[k][c]))
        if abs(m[p][c]) < 1e-12:
            return None
        m[c], m[p] = m[p], m[c]
        for k in range(3):
            if k != c:
                f = m[k][c] / m[c][c]
                for j in range(c, 4):
                    m[k][j] -= f * m[c][j]
    return tuple(m[i][3] / m[i][i] for i in range(3))


def fit_line(pts):
    n = len(pts)
    if n < 2:
        return None
    mt = sum(t for t, _ in pts) / n
    mx = sum(x for _, x in pts) / n
    var = sum((t - mt) ** 2 for t, _ in pts)
    if var <= 0:
        return None
    b = sum((t - mt) * (x - mx) for t, x in pts) / var
    return mx - b * mt, b


def max_resid(fit, pts):
    """The worst miss, in units of the tolerance: the samples are read on the cue thread, up to a frame (~17 ms) after
    the game moved him, so a fast fall is off by up to its speed x 17 ms."""
    a, b, c = fit
    return max(abs(a + b * t + c * t * t - y) / (FIT_TOL_PX + 0.02 * abs(b + 2 * c * t)) for t, y in pts)


def ballistic(samples, t0):
    """The longest prefix of samples [(t, x, y)] on one parabola (times in seconds from the launch t0). The launch spot
    itself isn't used: some launches move him first (the pole jump starts from the far side, the bar jump pulls up).
    Returns (count, fit (a, b, c) or None, deviated: bool)."""
    pts = [((t - t0) / 1000.0, y) for t, _, y in samples]
    if len(pts) < 3:
        return len(pts), None, False
    good = fit_parabola(pts[:3])
    used = 3
    for k in range(3, len(pts)):
        fit = fit_parabola(pts[:k + 1])
        if fit is None or (k + 1 > MIN_FIT and max_resid(fit, pts[:k + 1]) > 1.0):
            # the miss shows a sample or two late (the tolerance absorbs them): drop the last ones that are off the
            # parabola of the samples before them
            while used > MIN_FIT + 2:
                base = fit_parabola(pts[:used - 2])
                if base is None or max_resid(base, [pts[used - 1]]) <= 0.5:
                    break
                used -= 1
                good = fit_parabola(pts[:used]) or good
            return used, good, True
        if fit[2] > 400 and k + 1 > MIN_FIT:  # curving up: not a flight (a swing's arc, a run up a wall)
            return used, good, True
        good, used = fit, k + 1
    return used, good, False


class Session:
    def __init__(self, name, events, traj):
        self.name = name
        self.events = events
        self.traj = traj
        self.ttimes = [t for t, _, _ in traj]
        # the level in effect at each event (a level load starts it); warps / super speed / slow motion as spans
        self.level_spans = []
        self.warps = []
        self.superspeed = []
        self.slow = []
        cur, on, slow_on = None, None, None
        for t, kind, data in events:
            if kind == "level":
                self.level_spans.append((t, data))
                self.warps.append(t)
            elif kind == "warp":
                self.warps.append(t)
            elif kind == "superspeed":
                if data and on is None:
                    on = t
                elif not data and on is not None:
                    self.superspeed.append((on, t))
                    on = None
            elif kind == "snd" and data[0] == "speedSlowDown":
                slow_on = t
            elif kind == "snd" and data[0] == "speedNormal" and slow_on is not None:
                self.slow.append((slow_on, t))
                slow_on = None
        if on is not None:
            self.superspeed.append((on, 1e18))
        if slow_on is not None:
            self.slow.append((slow_on, slow_on + 5000))
        # the jump-now claims ((t, data) or (t, None) when one ends) and the turns, for lookups by time
        self.claims = [(t, d if k == "claim" else None) for t, k, d in events if k in ("claim", "unclaim", "level", "warp")]
        self.claim_times = [c[0] for c in self.claims]
        self.turns = [(t, d) for t, k, d in events if k == "turn"]
        self.turn_times = [c[0] for c in self.turns]

    def level_at(self, t):
        name = None
        for ts, n in self.level_spans:
            if ts <= t:
                name = n
        return name

    def traj_index(self, t):
        import bisect
        return bisect.bisect_left(self.ttimes, t)

    def near_traj(self, t, window):
        """The traj sample nearest in time to t within window ms, or None."""
        i = self.traj_index(t)
        best = None
        for j in (i - 1, i):
            if 0 <= j < len(self.traj) and abs(self.traj[j][0] - t) <= window:
                if best is None or abs(self.traj[j][0] - t) < abs(best[0] - t):
                    best = self.traj[j]
        return best

    def is_shank(self, t, x, y, lx, ly):
        """Is a sound at (x, y) his? (Goons share the Character sounds.) Near his traj in time and place, or at the
        listener while the game sounds are centred on him (B8f: the listener is his position then)."""
        s = self.near_traj(t, 400)
        if s is not None and math.hypot(s[1] - x, s[2] - y) < 200:
            return True
        return lx is not None and math.hypot(lx - x, ly - y) < 100

    def spans(self, spans, t):
        return any(a <= t <= b for a, b in spans)


def shank_sounds(sess):
    out = []
    for t, kind, data in sess.events:
        if kind != "snd":
            continue
        name, x, y, lx, ly = data
        if name in ("speedSlowDown", "speedNormal"):
            continue
        if sess.is_shank(t, x, y, lx, ly):
            out.append((t, name, x, y))
    return out


def launch_kind(sess, level, sounds, i, t0, x0, y0):
    """The launch's kind from its sound, what came before it and where he was (the jump model's origin kinds:
    ground, slide, cling, run_up, pole, wall_run, bar, swing, air)."""
    name = sounds[i][1]
    prev = [s for s in sounds[max(0, i - 12):i] if t0 - s[0] <= 2500]
    prev_names = [s[1] for s in prev]
    if name == "jumpFromGround":
        hit = level.surface_at(x0, y0 - FEET, below=48, above=32) if level.ok else None
        if hit and Level.downhill(hit[0]):
            return "slide", level.segment_spec(*hit)
        if not hit and level.ok:  # (B42c: letting go of a swing point, Down + Jump, plays this too)
            on = level.what_on(x0, y0)
            if on and on["type"] in ("swing", "pole", "shimmy"):
                return "drop", on
        return "ground", level.segment_spec(*hit) if hit else None
    if name == "jumpFromWall":
        on = None
        if level.ok:
            z = level.feature_near(x0, y0, ("wallrun_zone",), 8)
            if z is not None and prev_names and prev_names[-1] == "Movement_WallRunStep":
                return "wall_run", level.feature_spec(z)
            p = level.feature_near(x0, y0, ("pole", "slide_pole"), 120)
            if p is not None:
                return "pole", level.feature_spec(p)
            w = level.wall_near(x0, y0)
            on = level.wall_spec(w) if w is not None else None
        # running up it (the live cue's rule): moving up faster than kRunningUpVy (450) just before the jump
        before = [(t, y) for t, x, y in sess.traj[sess.traj_index(t0 - 160):sess.traj_index(t0 + 1)] if abs(x - x0) <= 48]
        if len(before) >= 3:
            ln = fit_line([((t - t0) / 1000.0, y) for t, y in before])
            if ln and ln[1] > 450:
                return "run_up", on
        return "cling", on
    if name == "poleSwing":
        for n in reversed(prev_names):
            if n == "shimmy":
                f = level.feature_near(x0, y0 + 192, ("shimmy_line",), 160) if level.ok else None
                return "bar", level.feature_spec(f) if f is not None else None
            if n in ("land", "landRoll", "wallAttach", "jumpFromWall", "jumpFromGround", "poleSwing"):
                break
        f = level.feature_near(x0, y0, ("swing_point",), 300) if level.ok else None
        if f is None and level.ok:
            g = level.feature_near(x0, y0 + 192, ("shimmy_line",), 160)
            if g is not None:
                return "bar", level.feature_spec(g)
        return "swing", level.feature_spec(f) if f is not None else None
    if prev_names and prev_names[-1] == "Movement_WallRunStep" and level.ok:  # the wall-run jump (wallrunjump)
        z = level.feature_near(x0, y0, ("wallrun_zone",), 96)
        return "wall_run", level.feature_spec(z) if z is not None else None
    return "air", level.what_on(x0, y0) if level.ok else None


def end_label(level, how, ex, ey, vy_end):
    """What the flight ended on: a target spec (as movement_check builds a jump_model::Target) or None."""
    if not level.ok:
        return None
    if how == "death" or level.in_pit(ex, ey - FEET):
        return {"type": "pit"}
    if how == "land" or (how in ("deviated", "lost") and vy_end <= 0):
        hit = level.surface_at(ex, ey - FEET, below=56, above=40)
        if hit:
            return level.segment_spec(*hit)
    if how == "ledge":
        hit = level.ledge_near(ex, ey)
        if hit:
            return dict(level.segment_spec(*hit), ledge=True)
    if how == "bar":
        f = level.feature_near(ex, ey + 192, ("shimmy_line",), 160)
        if f is not None:
            return level.feature_spec(f)
    if how == "wall_run":
        f = level.feature_near(ex, ey, ("wallrun_zone",), 96)
        if f is not None:
            return level.feature_spec(f)
    if how in ("cling", "run_up", "hit_wall"):
        p = level.feature_near(ex, ey, ("pole", "slide_pole"), 120)
        if p is not None:
            return level.feature_spec(p)
        f = level.feature_near(ex, ey + 192, ("shimmy_line",), 96)
        if f is not None and how == "cling":
            return level.feature_spec(f)
        w = level.wall_near(ex, ey, within=96)
        if w is not None:
            return level.wall_spec(w)
    if how in ("deviated", "relaunch", "swing_release"):
        f = level.feature_near(ex, ey, ("swing_point",), 280)
        if f is not None:
            return level.feature_spec(f)
        p = level.feature_near(ex, ey, ("pole", "slide_pole"), 120)
        if p is not None:
            return level.feature_spec(p)
        f = level.feature_near(ex, ey + 192, ("shimmy_line",), 96)
        if f is not None:
            return level.feature_spec(f)
        f = level.feature_near(ex, ey, ("wallrun_zone",), 32)
        if f is not None:
            return level.feature_spec(f)
    hit = level.surface_at(ex, ey - FEET, below=56, above=40)
    if hit:
        return level.segment_spec(*hit)
    return None


def claim_at(sess, t):
    """The jump-now claim in effect at t (the last 'jump now reaches' with no 'no longer reaches' since), or None."""
    import bisect
    k = bisect.bisect_right(sess.claim_times, t) - 1
    claim = sess.claims[k] if k >= 0 else None
    if claim and claim[1] is None:
        claim = None
    if claim and t - claim[0] < 4000:
        return {"what": claim[1][0], "x": claim[1][1], "y": claim[1][2], "kind": claim[1][3], "ms_before": t - claim[0]}
    return None


def flight_from(sess, level, sounds, t0, x0, y0, start_index, stop_names_after):
    """Follows the traj from t0: (samples, end_how, end_t, end_sound) for the airborne part."""
    i = sess.traj_index(t0 - 10)
    samples = []
    last_t, last_x, last_y = t0, x0, y0
    # the next of his movement sounds after the launch ends it
    end_t, end_sound = None, None
    for t, name, x, y in sounds[start_index + 1:]:
        if t <= t0 + 15:
            continue
        if t - t0 > 3000:
            break
        if name in LAUNCH or name in END or name in DEATH:
            end_t, end_sound = t, name
            break
    limit = (end_t + 25) if end_t else t0 + 3000
    while i < len(sess.traj):
        t, x, y = sess.traj[i]
        i += 1
        if t < t0 - 10:
            continue
        if t > limit:
            break
        if t - last_t > GAP_MS or math.hypot(x - last_x, y - last_y) > JUMP_PX:
            if samples or t - t0 > GAP_MS:
                break
        samples.append((t, x, y))
        last_t, last_x, last_y = t, x, y
    return samples, end_t, end_sound


def how_from_sound(name):
    if name is None:
        return None
    if name in DEATH:
        return "death"
    if name in LAUNCH:
        return "swing_release" if name == "poleSwing" else "relaunch"
    return END.get(name)


def analyse_flight(sess, level, sounds, k, t0, x0, y0, kind, start_on, launch):
    samples, end_t, end_sound = flight_from(sess, level, sounds, t0, x0, y0, k, None)
    rec = {"session": sess.name, "level": level.name, "t": int(t0), "launch": launch, "kind": kind,
           "x0": x0, "y0": y0, "start_on": start_on, "samples": len(samples)}
    if len(samples) < 3 or samples[0][0] - t0 > 160 or math.hypot(samples[0][1] - x0, samples[0][2] - y0) > 200:
        rec["end"] = {"how": "no_traj"}
        return rec
    # the fit's time origin: the launch, or (a swing / bar release, poleSwing) when the swing lets him go: it carries on
    # ~0.2 s after the press (poleswing_jump's AtTime), so the first samples are still on the arc
    tf = t0
    if launch == "poleSwing":
        for s0 in range(len(samples)):
            if samples[s0][0] - t0 > 450:
                break
            u, ft, _ = ballistic(samples[s0:], samples[s0][0])
            if u >= 6 and ft and 2200 <= -2 * ft[2] <= 4800:
                if s0:
                    rec["release_ms"] = int(samples[s0][0] - t0)
                    rec["release_at"] = [round(samples[s0][1], 1), round(samples[s0][2], 1)]
                    tf = samples[s0][0]
                    samples = samples[s0:]
                break
    used, fit, deviated = ballistic(samples, tf)
    used = max(used, 1)
    body = samples[:used]
    ex_t, ex, ey = body[-1]
    how = None
    sound_how = how_from_sound(end_sound)
    if end_t is not None and (not deviated or end_t <= ex_t + 120):
        how = sound_how
    elif deviated:
        how = "deviated"
    elif used == len(samples) and (end_t is None or end_t > ex_t + 250):
        how = "lost"
    else:
        how = sound_how or "lost"
    # a death soon after the end with no landing: he fell to it
    for t, name, x, y in sounds:
        if ex_t <= t <= ex_t + 1800 and name in DEATH:
            how = "death"
            break
        if t > ex_t + 1800:
            break
    rec["path"] = [[int(t - t0), round(x, 1), round(y, 1)] for t, x, y in body]
    # speeds: y on the parabola (real time), x on a line; the time scale from the parabola's curvature
    xl = fit_line([((t - tf) / 1000.0, x) for t, x, _ in body])
    f = {}
    if fit:
        a, b, c = fit
        g_real = -2.0 * c
        dur = (ex_t - tf) / 1000.0
        f["g_real"] = round(g_real, 1)
        if g_real > 300 and dur >= 0.15 and used >= 5:
            scale = math.sqrt(g_real / G)
            f["scale"] = round(scale, 3)
        else:
            scale = None
        s = scale if scale and 0.25 < scale < 1.6 else 1.0
        f["vy"] = round(b / s, 1)
        if xl:
            f["vx"] = round(xl[1] / s, 1)
            resid = max(abs(xl[0] + xl[1] * (t - tf) / 1000.0 - x) for t, x, _ in body)
            f["x_resid"] = round(resid, 1)  # large: he steered in the air
            f["x_launch"] = round(xl[0], 1)  # the line at the launch time
        f["y_launch"] = round(a, 1)  # the parabola at the launch time (the launch spot can be off it)
        f["rise"] = round(b * b / (4 * -c), 1) if b > 0 and c < 0 else 0.0  # its top above the launch
        f["drop"] = round(y0 - ey, 1)
        f["dur_ms"] = int(ex_t - tf)
        vy_end = b + 2 * c * dur
        f["vy_end"] = round(vy_end / s, 1)
    else:
        vy_end = -1
    rec["fit"] = f
    rec["end"] = {"how": how, "t": int(ex_t), "x": round(ex, 1), "y": round(ey, 1), "sound": end_sound,
                  "on": end_label(level, how, ex, ey, vy_end)}
    flags = []
    if sess.spans(sess.superspeed, t0):
        flags.append("superspeed")
    if sess.spans(sess.slow, t0) or sess.spans(sess.slow, ex_t):
        flags.append("slowmo")
    if any(t0 - 500 <= w <= ex_t + 500 for w in sess.warps):
        flags.append("warp")
    if f.get("scale") and not 0.85 <= f["scale"] <= 1.15:
        flags.append("timescale")
    rec["flags"] = flags
    rec["claim"] = claim_at(sess, t0)
    return rec


def facing(sess, t, default=True):
    import bisect
    k = bisect.bisect_right(sess.turn_times, t) - 1
    return sess.turns[k][1] if k >= 0 else default


def session_movements(sess, levels):
    sounds = shank_sounds(sess)
    out = []
    covered = []  # (t_start, t_end) of the flights found from launch sounds
    for k, (t, name, x, y) in enumerate(sounds):
        if name not in LAUNCH:
            continue
        lv = sess.level_at(t)
        if not lv:
            continue
        level = get_level(levels, lv)
        kind, on = launch_kind(sess, level, sounds, k, t, x, y)
        rec = analyse_flight(sess, level, sounds, k, t, float(x), float(y), kind, on, name)
        e_on = rec["end"].get("on") or {}
        if kind == "swing" and on and e_on.get("feature") == on.get("feature"):
            rec["kind"] = "swinging"  # the swing's own sound while he swings on it: not a release
        out.append(rec)
        if rec["end"].get("t"):
            covered.append((t - 150, rec["end"]["t"]))
    out.extend(soundless_flights(sess, levels, sounds, covered))
    for r in out:
        recover_walk_off(r, levels)
    out.extend(surface_moves(sess, levels, sounds))
    for r in out:
        if "fit" in r and "vx" in r["fit"] and abs(r["fit"]["vx"]) >= 60:
            r["dir"] = "R" if r["fit"]["vx"] > 0 else "L"
        else:
            r["dir"] = "R" if facing(sess, r["t"]) else "L"
    out.sort(key=lambda r: r["t"])
    return out


def recover_walk_off(r, levels):
    """B45-1 (the user: "Can we extrapolate using the last position near the edge, the trajectory of the fall ... to get a
    good estimate of the speed?"): the tracker usually picks him up already falling, so a walk-off shows as a plain fall.
    Traced back along its parabola (g, at normal game speed) to where his vertical speed was 0, a fall that starts at a
    floor's end, moving off it, is a walk-off (or a slide-off from a slope's low end) from there. The across speed is the
    fall's own (unchanged unless he steered: x_resid)."""
    if r.get("kind") != "fall" or r.get("flags") or "fit" not in r:
        return
    f = r["fit"]
    if "vx" not in f or f.get("scale") is None or not 0.9 <= f["scale"] <= 1.1 or f.get("dur_ms", 0) < 200:
        return
    vy, vx = f["vy"], f["vx"]
    if vy > 50 or abs(vx) < 60:
        return
    back = -vy / G  # seconds since he left the edge
    if back > 0.6:
        return
    xe = f["x_launch"] - vx * back
    ye = f["y_launch"] + vy * vy / (2 * G)
    level = get_level(levels, r["level"])
    if not level.ok:
        return
    best = None
    for s in level.surfaces:
        pts = s["points"]
        if len(pts) < 2:
            continue
        for end, side in ((pts[0], -1), (pts[-1], 1)):
            if side * vx <= 0:
                continue  # moving away from that end: he went off it
            dx, dy = (xe - end[0]) * side, ye - FEET - end[1]
            if -24 <= dx <= 72 and abs(dy) <= 24 and (best is None or abs(dy) < abs(best[2])):
                best = (s, side, dy)
    if not best:
        return
    s, side, _ = best
    r["kind"] = "slide_off" if Level.downhill(s) else "walk_off"  # (off any end of a slope: he was sliding)
    r["recovered_ms"] = int(back * 1000)
    r["start_on"] = level.segment_spec(s, 0 if side < 0 else len(s["points"]) - 2)
    r["x0"], r["y0"] = round(xe, 1), round(ye, 1)
    f["x_launch"], f["y_launch"], f["vy"] = round(xe, 1), round(ye, 1), 0.0
    f["dur_ms"] = f.get("dur_ms", 0) + r["recovered_ms"]


def fall_start(run, i):
    """Does a fall (a parabola with gravity) start at run[i]? The next 6 samples sit on one, and the sample before
    doesn't (he was standing, sliding down a wall or a slope, hanging, running along a wall)."""
    win = run[i:i + 6]
    if len(win) < 6:
        return False
    t0 = win[0][0]
    pts = [((t - t0) / 1000.0, y) for t, _, y in win]
    fit = fit_parabola(pts)
    if not fit or not 2200 <= -2 * fit[2] <= 4800 or max_resid(fit, pts) > 1.0:
        return False
    if fit[1] > 300:
        return False  # going up at its start: a launch (they have their sounds)
    if i == 0:
        return True
    prev = [((t - t0) / 1000.0, y) for t, _, y in run[i - 1:i + 6]]
    pf = fit_parabola(prev)
    return not pf or not 2200 <= -2 * pf[2] <= 4800 or max_resid(pf, prev) > 1.0


def soundless_kind(level, ctx, x, y, vx):
    """What he fell from (no launch sound): walking or sliding off a floor's end, letting go of a wall, pole, bar or
    swing point, running off a wall run's end; else a plain fall (after a bump or a hit)."""
    if not level.ok:
        return "fall", None
    ahead = 1 if vx >= 0 else -1
    for s in level.surfaces:
        pts = s["points"]
        if len(pts) < 2:
            continue
        for end, side in ((pts[0], -1), (pts[-1], 1)):
            # just past the end, at its height (he left it moving that way)
            if 0 <= (x - end[0]) * side <= 72 and -40 <= y - FEET - end[1] <= 24 and side == ahead:
                spec = level.segment_spec(s, 0 if side < 0 else len(pts) - 2)
                return ("slide_off" if Level.downhill(s) else "walk_off"), spec  # (B45: any end of a slope)
    hit = level.surface_at(x, y - FEET, below=24, above=24)
    if hit:
        return ("slide_off" if Level.downhill(hit[0]) else "walk_off"), level.segment_spec(*hit)  # (B45: off a slope he was sliding)
    if ctx == "Movement_WallRunStep":
        z = level.feature_near(x, y, ("wallrun_zone",), 96)
        return "wall_run_off", level.feature_spec(z) if z is not None else None
    if ctx in ("wallClimb", "wallAttach", "runUpWall", "shimmy", "poleSwing", None):
        on = level.what_on(x, y)
        if on and on["type"] != "landing":
            return "drop", on
    return "fall", level.what_on(x, y)


def soundless_flights(sess, levels, sounds, covered):
    """Flights with no launch sound: wherever a fall starts in the traj and no launch's flight covers it."""
    import bisect
    out = []
    traj = sess.traj
    snd_times = [s[0] for s in sounds]
    i = 0
    while i < len(traj):
        # one run: samples no further apart than GAP_MS, no jumps
        j = i + 1
        while j < len(traj) and traj[j][0] - traj[j - 1][0] <= GAP_MS and                 math.hypot(traj[j][1] - traj[j - 1][1], traj[j][2] - traj[j - 1][2]) <= JUMP_PX:
            j += 1
        run = traj[i:j]
        k = 0
        while k < len(run):
            t, x, y = run[k]
            if any(a <= t <= b for a, b in covered) or not fall_start(run, k):
                k += 1
                continue
            lv = sess.level_at(t)
            if not lv:
                k += 1
                continue
            level = get_level(levels, lv)
            si = bisect.bisect_left(snd_times, t) - 1
            ctx = sounds[si][1] if si >= 0 and t - sounds[si][0] <= 2500 and sounds[si][1] not in DEATH else None
            vx = (run[min(k + 3, len(run) - 1)][1] - x)
            kind, on = soundless_kind(level, ctx, x, y, vx)
            rec = analyse_flight(sess, level, sounds, si, t - 1, x, y, kind, on, None)
            rec["context"] = ctx
            if rec.get("fit", {}).get("vy", 0) > 120:
                rec["kind"] = "hop"  # going up with no jump sound: a step he hops up, a vault (not a fall)
            out.append(rec)
            end_t = rec["end"].get("t") or t
            covered.append((t, end_t))
            while k < len(run) and run[k][0] <= end_t:
                k += 1
        i = j
    return out


# ---------------------------------------------------------------------------------------------------------------------
# Output


def flat_line(r):
    """movements.txt: one airborne movement per line for movement_check (fields separated by spaces; '-' = none):
    m <session>:<t> <level> <kind> <x0> <y0> <R|L> <vx> <vy> <scale|-> <x_resid> <fx> <fy> <flags|-> <end how> <end x> <end y> <target> <dur_ms>
      x0 y0 = where he was at the launch (its sound, or the fall's first sample); fx fy = the fitted path there;
      vx vy = the fitted launch speeds (game time); x_resid = how far x strays from a straight line (he steered);
      target = <type> <x1> <y1> <x2> <y2> <extra>  (type: landing / ledge / swing / pole / shimmy / wallzone / wall / pit / -;
               extra: landing, ledge: oneway 0|1; pole: slide 0|1; wall: climbable 0|1 + L|R (facing); else -)
    claim <what...> | <kind> <x> <y>  follows when a jump-now claim was in effect at the launch (spaces as _)."""
    f = r.get("fit", {})
    e = r["end"]
    on = e.get("on")
    if on is None:
        tgt = "- 0 0 0 0 -"
    elif on["type"] == "pit":
        tgt = "pit 0 0 0 0 -"
    else:
        typ = "ledge" if on.get("ledge") else on["type"]
        extra = "-"
        if on["type"] == "landing":
            extra = "1" if on.get("oneway") else "0"
        elif on["type"] == "pole":
            extra = "1" if on.get("slide") else "0"
        elif on["type"] == "wall":
            extra = ("1" if on.get("climbable") else "0") + ("L" if on.get("facing") == "left" else "R")
        tgt = "%s %g %g %g %g %s" % (typ, on["x1"], on["y1"], on["x2"], on["y2"], extra)
    line = "m %s:%d %s %s %.1f %.1f %s %.1f %.1f %s %.1f %.1f %.1f %s %s %.1f %.1f %s %d" % (
        r["session"], r["t"], r["level"], r["kind"], r["x0"], r["y0"], r["dir"], f.get("vx", 0.0), f.get("vy", 0.0),
        ("%.3f" % f["scale"]) if f.get("scale") else "-", f.get("x_resid", 0.0), f.get("x_launch", r["x0"]),
        f.get("y_launch", r["y0"]), ",".join(r.get("flags", [])) or "-", e["how"], e["x"], e["y"], tgt, f.get("dur_ms", 0))
    c = r.get("claim")
    if c:
        line += "\nclaim %s | %s %d %d" % (c["what"].replace(" ", "_"), c["kind"].replace(" ", "_"), c["x"], c["y"])
    return line


def surface_moves(sess, levels, sounds):
    """B42-1c: the moves on a surface, from his own sounds and the traj: runs up walls (runUpWall, every ~285 ms),
    wall runs (Movement_WallRunStep), shimmying (shimmy), slope slides (traj samples on a slippery surface)."""
    out = []

    def series(name, max_gap, same_x):
        runs, cur = [], []
        for t, n, x, y in sounds:
            if n != name:
                if n in LAUNCH or n in DEATH or n in ("land", "landRoll", "wallAttach"):
                    if cur:
                        runs.append(cur)
                    cur = []
                continue
            if cur and (t - cur[-1][0] > max_gap or (same_x and abs(x - cur[-1][2]) > 24)):
                runs.append(cur)
                cur = []
            cur.append((t, n, x, y))
        if cur:
            runs.append(cur)
        return runs

    import bisect
    snd_times = [q[0] for q in sounds]

    def next_sound(t):
        for te, n, x, y in sounds[bisect.bisect_right(snd_times, t + 5):]:
            if n not in ("step", name_of_run):
                return te, n
        return None, None

    # runs up walls: from the first runUpWall (at the wall's foot when he ran into it) to the top (traj)
    name_of_run = "runUpWall"
    for run in series("runUpWall", 700, True):
        t0, _, x0, y0 = run[0]
        lv = sess.level_at(t0)
        if not lv:
            continue
        level = get_level(levels, lv)
        # follow him up the wall (same x) to his highest point: the run up (~620 px/s), then the climb after the
        # wallClimb sound (slower), to a vault over the top (ledgeClimb), a jump, or sliding back down
        pts = []
        for t, x, y in sess.traj[sess.traj_index(t0 - 50):]:
            if t > t0 + 5000 or (pts and (t - pts[-1][0] > GAP_MS or abs(x - x0) > 40)):
                break
            pts.append((t, x, y))
        if len(pts) < 4:
            continue
        ti = max(range(len(pts)), key=lambda q: pts[q][2])
        t_top, _, top = pts[ti]
        how = "slid_back" if ti < len(pts) - 1 and pts[-1][2] < top - 16 else "lost"
        for te, n, x, y in sounds[bisect.bisect_left(snd_times, t_top - 400):]:
            if te > t_top + 250:
                break
            if n in ("ledgeClimb", "ledgeGrab"):
                how = "vaulted"
            elif n in ("jumpFromWall", "jumpFromAir"):
                how = "jumped"
        part = [((t - t0) / 1000.0, y) for t, _, y in pts if t - t0 <= 250]
        ln = fit_line(part) if len(part) >= 3 else None
        foot = level.surface_at(x0, y0 - FEET, below=40, above=40) if level.ok else None
        w = level.wall_near(x0, y0) if level.ok else None
        wall = level.walls[w] if w is not None else None
        out.append({"session": sess.name, "level": lv, "t": int(t0), "kind": "run_up_wall", "x0": x0, "y0": y0,
                    "from_floor": foot is not None, "top": round(top, 1), "height": round(top - y0, 1),
                    "speed": round(ln[1], 1) if ln else None, "secs_to_top": round((t_top - t0) / 1000.0, 2), "ended": how,
                    "wall_top": wall["y2"] if wall else None, "wall_climbable": wall["climbable"] if wall else None,
                    "end": {"how": how}})
    # wall runs: speed along, where he left the zone
    name_of_run = "Movement_WallRunStep"
    for run in series("Movement_WallRunStep", 600, False):
        if len(run) < 2:
            continue
        t0, _, x0, y0 = run[0]
        t1, _, x1, y1 = run[-1]
        lv = sess.level_at(t0)
        if not lv:
            continue
        level = get_level(levels, lv)
        z = level.feature_near(x0, y0, ("wallrun_zone",), 96) if level.ok else None
        te, how = next_sound(t1)
        rec = {"session": sess.name, "level": lv, "t": int(t0), "kind": "wall_running", "x0": x0, "y0": y0, "x1": x1, "y1": y1,
               "speed": round((x1 - x0) / max((t1 - t0) / 1000.0, 0.001), 1), "ended": how, "end": {"how": how or "-"}}
        if z is not None:
            zf = level.features[z]
            (zx1, zy1), (zx2, zy2) = zf["min"], zf["max"]
            ahead = zx2 if x1 > x0 else zx1
            rec["zone"] = z
            rec["left_to_end"] = round(abs(ahead - x1), 1)  # from the last step to the zone's end he runs toward
            rec["above_bottom"] = round(y0 - zy1, 1)
        out.append(rec)
    # shimmying: speed along the line
    name_of_run = "shimmy"
    for run in series("shimmy", 900, False):
        if len(run) < 3:
            continue
        t0, _, x0, y0 = run[0]
        t1, _, x1, y1 = run[-1]
        lv = sess.level_at(t0)
        if not lv:
            continue
        out.append({"session": sess.name, "level": lv, "t": int(t0), "kind": "shimmy_along", "x0": x0, "y0": y0,
                    "speed": round(math.hypot(x1 - x0, y1 - y0) / max((t1 - t0) / 1000.0, 0.001), 1), "end": {"how": "-"}})
    # slope slides: consecutive traj samples on one slippery surface
    cur = None
    for t, x, y in sess.traj:
        lv = sess.level_at(t)
        level = get_level(levels, lv) if lv else None
        hit = level.surface_at(x, y - FEET, below=20, above=20, only=level.slopes) if level and level.slopes else None
        on = hit[0]["id"] if hit else None
        if cur and (on != cur["surface"] or t - cur["pts"][-1][0] > GAP_MS):
            if len(cur["pts"]) >= 4:
                (ta, xa, ya), (tb, xb, yb) = cur["pts"][0], cur["pts"][-1]
                out.append({"session": sess.name, "level": cur["level"], "t": int(ta), "kind": "slope_slide", "surface": cur["surface"],
                            "x0": xa, "y0": ya, "x1": xb, "y1": yb, "speed_x": round((xb - xa) / max((tb - ta) / 1000.0, 0.001), 1),
                            "speed": round(math.hypot(xb - xa, yb - ya) / max((tb - ta) / 1000.0, 0.001), 1), "end": {"how": "-"}})
            cur = None
        if on is not None:
            if cur is None:
                cur = {"surface": on, "level": lv, "pts": []}
            cur["pts"].append((t, x, y))
    return out


def model_constants():
    """jump_model.h's constexpr floats, as numbers (so the summary always shows the model as built)."""
    path = os.path.join(ROOT, "native", "core", "jump_model.h")
    out = {}
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()
    for line in lines:
        if not line.strip().startswith("constexpr float"):
            continue
        decl = line.split("//")[0].strip()[len("constexpr float"):].rstrip(";")
        for part in decl.split(","):
            if "=" not in part:
                continue
            name, expr = part.split("=", 1)
            expr = expr.strip().replace("f", "")
            if re.fullmatch(r"[\d.\s*/+-]+", expr):
                try:
                    out[name.strip()] = float(eval(expr))
                except (SyntaxError, ZeroDivisionError):
                    pass
    return out


def clean(r, min_ms=200, min_samples=6, steer=None):
    """A flight good for measuring: a normal game speed, no warp, a long enough fit (and unsteered, if asked)."""
    f = r.get("fit") or {}
    if r.get("flags") or "vy" not in f or f.get("dur_ms", 0) < min_ms or r.get("samples", 0) < min_samples:
        return False
    if f.get("scale") is None or not 0.9 <= f["scale"] <= 1.1:
        return False
    return steer is None or f.get("x_resid", 99) <= steer


def stats(vals):
    vals = sorted(v for v in vals if v is not None)
    if not vals:
        return "n 0"
    q = lambda p: vals[min(len(vals) - 1, int(p * (len(vals) - 1) + 0.5))]
    return "n %d, median %.0f (10%%-90%%: %.0f..%.0f)" % (len(vals), statistics.median(vals), q(0.1), q(0.9))


def summary(moves):
    """B42-1d: per kind, the measured numbers next to the jump model's constants (jump_model.h as it is now)."""
    K = model_constants()
    k = lambda name: ("%g" % K[name]) if name in K else "?"
    by = {}
    for r in moves:
        by.setdefault(r["kind"], []).append(r)
    L = ["B42-1 movement corpus: %d movements in %d sessions (tools/movements.py)" % (len(moves), len({r["session"] for r in moves})),
         "", "Counts and how each kind ended:"]
    for kind in sorted(by):
        ends = {}
        for r in by[kind]:
            ends[r["end"]["how"]] = ends.get(r["end"]["how"], 0) + 1
        L.append("  %-13s %5d  %s" % (kind, len(by[kind]), ", ".join("%s %d" % kv for kv in sorted(ends.items(), key=lambda kv: -kv[1]))))
    L.append("")
    L.append("Launch speeds (game time; clean flights: normal speed, no warp, 200+ ms, 6+ samples; vx from flights he didn't steer):")

    def launch(kind, label, vy_model, vx_model, sel=lambda r: True):
        rs = [r for r in by.get(kind, []) if clean(r) and sel(r)]
        un = [r for r in rs if r["fit"].get("x_resid", 99) <= 12]
        L.append("  %s:" % label)
        L.append("    up:     %s   model %s" % (stats([r["fit"]["vy"] for r in rs]), vy_model))
        L.append("    across: %s   model %s" % (stats([abs(r["fit"].get("vx", 0)) for r in un]), vx_model))

    launch("ground", "long jump (across 500+)", k("kLongVy"), k("kLongVx") + " (steer down to " + k("kLongMinVx") + ")",
           lambda r: abs(r["fit"].get("vx", 0)) >= 500)
    launch("ground", "standing jump (across under 250)", k("kStandVy"), "air control " + k("kAirControl"),
           lambda r: abs(r["fit"].get("vx", 0)) < 250)
    launch("cling", "wall jump", k("kWallJumpVy"), "%s..%s (%s)" % (k("kWallJumpMinVx"), k("kWallJumpMaxVx"), k("kWallJumpVx")))
    launch("run_up", "jump while running up a wall", k("kRunUpJumpVy"), "%s (min %s)" % (k("kRunUpJumpVx"), k("kRunUpMinVx")))
    launch("pole", "pole jump", k("kPoleJumpVy"), "%s (min %s)" % (k("kPoleJumpVx"), k("kPoleJumpMinVx")))
    launch("bar", "bar / shimmy jump", k("kBarJumpVy"), "%s (min %s)" % (k("kBarJumpVx"), k("kBarJumpMinVx")))
    launch("swing", "swing release", k("kSwingJumpVy"), "%s (min %s)" % (k("kSwingJumpVx"), k("kSwingJumpMinVx")))
    launch("wall_run", "wall-run jump", k("kWallRunJumpV"), "%s (min %s)" % (k("kWallRunJumpV"), k("kWallRunMinVx")))
    launch("slide", "jump off a slope", k("kLongVy"), k("kLongVx"))
    for kind, label, model in (("walk_off", "walking off a floor's end", "at least air control " + k("kAirControl") + ", up to " + k("kLongVx")),
                               ("slide_off", "sliding off a slope's end", "%s..%s" % (k("kSlideOffMinVx"), k("kSlideOffMaxVx"))),
                               ("wall_run_off", "running off a wall run's end", "-"),
                               ("drop", "letting go (wall, pole, bar, swing)", "0 across")):
        rs = [r for r in by.get(kind, []) if clean(r, min_ms=150, min_samples=5)]
        L.append("  %s: across at the start: %s   model %s" % (label, stats([abs(r["fit"].get("vx", 0)) for r in rs if r["fit"].get("x_resid", 99) <= 20]), model))
    # the bar's pull-up: the parabola's height at the launch above the hang (the sound's spot)
    rs = [r for r in by.get("bar", []) if clean(r)]
    L.append("  bar pull-up before the flight (the parabola at the launch, above the hang): %s   model %s"
             % (stats([r["fit"]["y_launch"] - r["y0"] for r in rs]), k("kBarJumpLiftPx")))
    g = [r["fit"]["g_real"] for kind in by for r in by[kind] if clean(r, min_ms=350, min_samples=10) and not r.get("flags")]
    L.append("  gravity (real time, flights of 350+ ms): %s   model %s" % (stats(g), k("kGravity")))

    L.append("")
    L.append("Catches (where the flight's last sample was):")
    ledge = [r for kind in by for r in by[kind] if r["end"]["how"] == "ledge" and (r["end"].get("on") or {}).get("ledge")]

    def ledge_dy(r):
        on, e = r["end"]["on"], r["end"]
        top = on["y1"] if abs(on["x1"] - e["x"]) < abs(on["x2"] - e["x"]) else on["y2"]
        return top - e["y"]
    up = [ledge_dy(r) for r in ledge if r["fit"].get("vy_end", 0) > 0]
    down = [ledge_dy(r) for r in ledge if r["fit"].get("vy_end", 0) <= 0]
    L.append("  ledge grabs, the ledge above his position: rising %s; falling %s   model: hang %s + %s from his middle (rising)"
             % (stats(up), stats(down), k("kLedgeHangPx"), k("kLedgeFromPosPx")))
    sw = [r for kind in by for r in by[kind] if kind != "swinging" and (r["end"].get("on") or {}).get("type") == "swing"
          and r["end"]["how"] in ("deviated", "swing_release")]
    L.append("  swing-point catches, distance: %s; the point below him (px): %s; falling at: %s   model disc %s, at most %s below, falling under %s"
             % (stats([math.hypot(r["end"]["x"] - r["end"]["on"]["x1"], r["end"]["y"] - r["end"]["on"]["y1"]) for r in sw]),
                stats([r["end"]["y"] - r["end"]["on"]["y1"] for r in sw]),
                stats([-r["fit"].get("vy_end", 0) for r in sw if "vy_end" in r["fit"]]), k("kGrabDisc"), k("kGrabBelowPx"), k("kGrabMaxFall")))
    wz = [r for kind in by for r in by[kind] if r["end"]["how"] == "wall_run" and (r["end"].get("on") or {}).get("type") == "wallzone"]

    def inside(r):
        on, e = r["end"]["on"], r["end"]
        return min(e["x"] - on["x1"], on["x2"] - e["x"])
    L.append("  wall-run latches: inside the zone from its nearer end: %s; above its bottom: %s; falling at: %s   model: anywhere inside (B41f), %s above the bottom"
             % (stats([inside(r) for r in wz]), stats([r["end"]["y"] - r["end"]["on"]["y1"] for r in wz]),
                stats([-r["fit"].get("vy_end", 0) for r in wz if "vy_end" in r["fit"]]), k("kWallZoneInsidePx")))
    pc = [r for kind in by for r in by[kind] if r["end"]["how"] == "cling" and (r["end"].get("on") or {}).get("type") == "pole"]
    L.append("  pole catches, across from the pole: %s   model grab %s, hangs at %s"
             % (stats([abs(r["end"]["x"] - r["end"]["on"]["x1"]) for r in pc]), k("kGrabRadius"), k("kPoleSideDx")))

    L.append("")
    L.append("On a surface:")
    ru = by.get("run_up_wall", [])
    slid_back = [r for r in ru if r.get("from_floor") and r.get("ended") == "slid_back"]
    L.append("  runs up walls from the floor, highest point when he slid back (the run's reach): %s; seconds to it: %s   model %s"
             % (stats([r["height"] for r in slid_back]), stats([r["secs_to_top"] * 1000 for r in slid_back]), k("kRunUpMaxPx")))
    L.append("  runs up walls, speed over the first 250 ms: %s   model: running up = faster than %s" % (stats([r["speed"] for r in ru]), k("kRunningUpVy")))
    for how in ("vaulted", "jumped"):
        L.append("  runs up walls from the floor that %s, the height: %s" % (how, stats([r["height"] for r in ru if r.get("from_floor") and r.get("ended") == how])))
    wr = by.get("wall_running", [])
    L.append("  wall runs, speed: %s" % stats([abs(r["speed"]) for r in wr]))
    L.append("  wall runs ending in a jump, from the last step to the zone's end: %s; ending with no jump: %s   model window %s"
             % (stats([r.get("left_to_end") for r in wr if r.get("ended") in ("jumpFromWall", "jumpFromAir")]),
                stats([r.get("left_to_end") for r in wr if r.get("ended") not in ("jumpFromWall", "jumpFromAir")]), k("kWallRunEndWindowPx")))
    L.append("  shimmying, speed: %s" % stats([r["speed"] for r in by.get("shimmy_along", [])]))
    L.append("  slope slides, speed along: %s   model %s" % (stats([r["speed"] for r in by.get("slope_slide", []) if r["speed"] > 200]), k("kSlideSpeed")))
    return "\n".join(L)


def write_timeline(sess, path):
    """B47-1: his positions over the session for native/tests/cue_replay.cpp (today's cue code fed the old movements):
      L <t> <level>         a level load
      P <t> <x> <y>         a traj sample (his tracked position)
      G <t> <x> <y>         one of his ground sounds (step, land, landRoll, skidStop): where he stood
      F <t> R|L             he turned
      H <t> <up_on|...>     a key held / let go (the Lua reports, from B44)
    t = ms on the log's clock (movements.txt's keys use the same)."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rows = []
    for t, kind, data in sess.events:
        if kind == "level":
            rows.append((t, "L %d %s" % (t, data)))
        elif kind == "turn":
            rows.append((t, "F %d %s" % (t, "R" if data else "L")))
        elif kind == "hold":
            rows.append((t, "H %d %s" % (t, data)))
    for t, x, y in sess.traj:
        rows.append((t, "P %d %.1f %.1f" % (t, x, y)))
    for t, name, x, y in shank_sounds(sess):
        if name in ("step", "land", "landRoll", "skidStop"):
            rows.append((t, "G %d %d %d" % (t, x, y)))
    rows.sort(key=lambda r: r[0])
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(r[1] for r in rows) + "\n")


def show(key):
    """--show: one movement from movements.json, then the log around it (his traj samples and his sounds)."""
    session, t = key.rsplit(":", 1)
    t = int(t)
    moves = json.load(open(os.path.join(OUT, "movements.json"), encoding="utf-8"))
    rec = next((r for r in moves if r["session"] == session and r["t"] == t), None)
    if rec is None:
        print("no movement %s in %s" % (key, os.path.join(OUT, "movements.json")))
        return 1
    print(json.dumps({k: v for k, v in rec.items() if k != "path"}, indent=1))
    events, traj = parse_log(os.path.join(LOGS, session, "a11y.log"))
    sess = Session(session, events, traj)
    t_end = rec["end"].get("t", t + 1000)
    marks = {int(t + p[0]) for p in rec.get("path", [])}
    for tt, x, y in traj:
        if t - 600 <= tt <= t_end + 800:
            print("  traj %+6d  %8.1f %8.1f %s" % (tt - t, x, y, "*" if int(tt) in marks else ""))
    for tt, name, x, y in shank_sounds(sess):
        if t - 1500 <= tt <= t_end + 1500:
            print("  sound %+6d %s (%d, %d)" % (tt - t, name, x, y))
    return 0


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--session", help="only sessions whose folder name contains this")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--show", metavar="SESSION:T", help="print one movement (a key from movements.txt / check.txt) "
                    "and his traj and sounds around it, from the corpus already built")
    a = ap.parse_args(argv)
    if a.show:
        return show(a.show)
    out_dir = OUT if not a.session else os.path.join(OUT, "only_" + a.session)  # (never over the full corpus)
    levels = {}
    moves = []
    # A copy taken while the game still ran (collect_logs mid-session) repeats the start of the full one collected later:
    # keep only the longest log per game start (its first line: the mod's start time and thread).
    longest = {}
    for d in sorted(glob.glob(os.path.join(LOGS, "*"))):
        path = os.path.join(d, "a11y.log")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8", errors="replace") as f:
            first = f.readline().strip()
        size = os.path.getsize(path)
        if first not in longest or size > longest[first][1]:
            longest[first] = (d, size)
    keep = {d for d, _ in longest.values()}
    for d in sorted(glob.glob(os.path.join(LOGS, "*"))):
        path = os.path.join(d, "a11y.log")
        name = os.path.basename(d)
        if not os.path.exists(path) or d not in keep or (a.session and a.session not in name):
            continue
        events, traj = parse_log(path)
        if not traj:
            continue
        sess = Session(name, events, traj)
        moves.extend(session_movements(sess, levels))
        write_timeline(sess, os.path.join(out_dir, "timelines", name + ".txt"))
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "movements.json"), "w", encoding="utf-8") as f:
        json.dump(moves, f, indent=0)
    with open(os.path.join(out_dir, "movements.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write("# B42-1 movement corpus (tools/movements.py from build/logs; derived, never commit)\n")
        for r in moves:
            if r["end"]["how"] == "no_traj" or "fit" not in r or r["kind"] == "swinging":
                continue
            f.write(flat_line(r) + "\n")
    text = summary(moves)
    with open(os.path.join(out_dir, "summary.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write(text + "\n")
    if not a.quiet:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
