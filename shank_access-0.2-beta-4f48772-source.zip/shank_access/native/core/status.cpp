#include "status.h"

#include <windows.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "announce.h"
#include "log.h"

namespace status {
namespace {

constexpr const char* kHealthPath = "_level0.HUD.player1.healthBar.value";
constexpr const char* kGrenadePath = "_level0.HUD.player1.grenadeTxt.text";

SRWLOCK g_lock = SRWLOCK_INIT;
bool g_have_health = false;
double g_health = 0;
bool g_armed[sizeof kHealthLevels / sizeof kHealthLevels[0]] = {true, true, true};
bool g_have_grenades = false;
int g_grenades = 0;
std::string g_boss;  // the last boss name announced
unsigned g_reset_ms = 0;  // when health was last reset to full (a level load or respawn: B1c)
bool g_have_reset = false;
// 3-2 pickups waiting for their result.
bool g_health_pickup = false;
unsigned g_health_pickup_ms = 0;
bool g_grenade_pickup = false;
unsigned g_grenade_pickup_ms = 0;
bool g_grenades_said = false;  // a pickup rise was announced at g_grenades_said_ms
unsigned g_grenades_said_ms = 0;
// 3-4: the combo in progress (0 = none) and its last hit.
constexpr const char* kComboPath = "_level0.HUD.player1.comboanim.combo.comboNum.text";
int g_combo = 0;
unsigned g_combo_ms = 0;

std::string ComboText(int n) {
    char buf[32];
    _snprintf_s(buf, sizeof buf, _TRUNCATE, "%d hit combo", n);
    return buf;
}

// Our cue names ("got_<kind>", the pickup stategraph's name) -> spoken names.
const char* WeaponName(const std::string& kind) {
    static const struct {
        const char* kind;
        const char* name;
    } kWeapons[] = {{"minigun", "minigun"}, {"grenadelauncher", "grenade launcher"}, {"flamethrower", "flamethrower"},
                    {"machete", "machete"}, {"sword", "katana"}, {"uzi", "Uzi"}, {"shotgun", "shotgun"}};
    for (const auto& w : kWeapons) {
        if (kind == w.kind) return w.name;
    }
    return nullptr;
}

std::string Grenades(long n) {
    char buf[32];
    _snprintf_s(buf, sizeof buf, _TRUNCATE, "%ld grenade%s", n, n == 1 ? "" : "s");
    return buf;
}

bool IsBossName(const std::string& path) {
    return path == "_level0.HUD.enemyBoss.nameTxt.text" || path == "_level0.HUD.enemyBosses.boss1.nameTxt.text" ||
           path == "_level0.HUD.enemyBosses.boss2.nameTxt.text";
}

std::string Percent(double v, const char* what = "health") {
    char buf[160];
    _snprintf_s(buf, sizeof buf, _TRUNCATE, "%.0f percent %s", std::floor(v + 0.5), what);
    return buf;
}

constexpr size_t kLevels = sizeof kHealthLevels / sizeof kHealthLevels[0];

// A health value went from `before` to `v`: true if it dropped below an armed level (which is then
// disarmed); levels are re-armed once the value is above them again.
bool Crossed(bool had, double before, double v, bool* armed) {
    bool crossed = false;
    for (size_t i = 0; i < kLevels; ++i) {
        if (v > kHealthLevels[i]) {
            armed[i] = true;  // healed above it (or a new life): announce the next drop again
        } else if (had && before > kHealthLevels[i] && armed[i]) {
            armed[i] = false;
            crossed = true;
        }
    }
    return crossed;
}

// 3-3: the boss health bars. The single boss bar is confirmed (1c-3 log); the two-boss bars'
// healthBar paths are assumed to follow the same pattern as their nameTxt (RE-NOTES).
struct BossBar {
    const char* prefix;
    std::string name;  // "" = no boss on this bar
    bool have = false;
    double health = 0;
    bool armed[kLevels] = {true, true, true};
};
BossBar g_bosses[] = {{"_level0.HUD.enemyBoss."}, {"_level0.HUD.enemyBosses.boss1."}, {"_level0.HUD.enemyBosses.boss2."}};

BossBar* BossFor(const std::string& path, const char* member) {
    for (BossBar& b : g_bosses) {
        if (path == std::string(b.prefix) + member) return &b;
    }
    return nullptr;
}

// "40 percent boss health" for the single boss bar; "40 percent <name>" when two bosses share the screen.
std::string BossText(const BossBar& b) {
    const bool single = &b == &g_bosses[0];
    return Percent(b.health, single || b.name.empty() ? "boss health" : b.name.c_str());
}

}  // namespace

std::string OnValue(const std::string& path, const ui_hooks::FlashValue& value, unsigned now_ms) {
    if (path == kHealthPath) {
        if (value.kind != ui_hooks::FlashValue::kNumber) return std::string();
        const double v = value.n;
        AcquireSRWLockExclusive(&g_lock);
        const bool had = g_have_health;
        const double before = g_health;
        if (v >= 100 && (!had || before < 100)) {  // back to full: a level load or respawn
            g_reset_ms = now_ms;
            g_have_reset = true;
        }
        g_have_health = true;
        g_health = v;
        const bool crossed = Crossed(had, before, v, g_armed);
        ReleaseSRWLockExclusive(&g_lock);
        if (!crossed) return std::string();
        const std::string said = Percent(v);
        alog::Write("status: health %.1f (was %.1f) -> say \"%s\"%s", v, before, said.c_str(), announce::On(announce::kHealth) ? "" : " (off)");
        return announce::On(announce::kHealth) ? said : std::string();
    }
    if (path == kGrenadePath) {
        if (value.kind != ui_hooks::FlashValue::kText) return std::string();
        char* end = nullptr;
        const long n = std::strtol(value.text.c_str(), &end, 10);
        AcquireSRWLockExclusive(&g_lock);
        if (value.text.empty() || end == value.text.c_str()) {  // cleared: the next value is a fresh start
            g_have_grenades = false;
            ReleaseSRWLockExclusive(&g_lock);
            return std::string();
        }
        const bool had = g_have_grenades;
        const int before = g_grenades;
        g_have_grenades = true;
        g_grenades = static_cast<int>(n);
        // A level load or respawn resets health and grenades together (the same ms in the logs):
        // not a pickup (the user: it "re-announces the grenade value" on each new level).
        const bool with_reset = g_have_reset && now_ms - g_reset_ms <= kResetWindowMs;
        const bool rise = had && n > before && !with_reset;
        if (rise) {
            g_grenade_pickup = false;  // the rise is the pickup's announcement
            g_grenades_said = true;
            g_grenades_said_ms = now_ms;
        }
        ReleaseSRWLockExclusive(&g_lock);
        if (!had || n <= before) return std::string();  // only pickups
        if (with_reset) {
            alog::Write("status: grenades %d -> %ld with a health reset (level load/respawn): silent", before, n);
            return std::string();
        }
        const std::string said = Grenades(n);
        alog::Write("status: grenades %d -> %ld -> say \"%s\"", before, n, said.c_str());
        return announce::On(announce::kPickups) ? said : std::string();
    }
    if (path == kComboPath) {
        if (value.kind != ui_hooks::FlashValue::kText) return std::string();
        char* end = nullptr;
        const long n = std::strtol(value.text.c_str(), &end, 10);
        const bool number = !value.text.empty() && end != value.text.c_str();
        AcquireSRWLockExclusive(&g_lock);
        const int before = g_combo;
        std::string said;
        if (!number) {
            g_combo = 0;  // cleared (a level load): silent
        } else if (n > before) {
            g_combo = static_cast<int>(n);  // climbing: silent (the user: too chatty)
            g_combo_ms = now_ms;
        } else if (n < before) {
            // A new combo always starts again at 1, so it shows as a lower number. The same number
            // again is ignored (in case the HUD rewrites it without a hit; the logs show changes only).
            if (before >= kMinCombo) said = ComboText(before);  // started again: the last one is over
            g_combo = static_cast<int>(n);
            g_combo_ms = now_ms;
        }
        ReleaseSRWLockExclusive(&g_lock);
        if (!said.empty()) alog::Write("status: combo restarted at %ld -> say \"%s\"", n, said.c_str());
        return announce::On(announce::kCombo) ? said : std::string();
    }
    if (BossBar* b = BossFor(path, "healthBar.value")) {
        if (value.kind != ui_hooks::FlashValue::kNumber) return std::string();
        const double v = value.n < 0 ? 0 : value.n;  // overkill writes negative values (-750, -2500)
        AcquireSRWLockExclusive(&g_lock);
        const bool had = b->have;
        const double before = b->health;
        b->have = true;
        b->health = v;
        const bool crossed = Crossed(had, before, v, b->armed);
        const std::string said = crossed ? BossText(*b) : std::string();
        ReleaseSRWLockExclusive(&g_lock);
        if (crossed) alog::Write("status: %shealthBar %.1f (was %.1f) -> say \"%s\"", b->prefix, v, before, said.c_str());
        return announce::On(announce::kBoss) ? said : std::string();
    }
    if (IsBossName(path)) {
        if (value.kind != ui_hooks::FlashValue::kText) return std::string();
        AcquireSRWLockExclusive(&g_lock);
        const bool fresh = !value.text.empty() && value.text != g_boss;
        g_boss = value.text;  // "" when the boss bar is cleared, so the same boss is announced again next time
        if (BossBar* b = BossFor(path, "nameTxt.text")) {
            if (b->name != value.text) {  // a new fight (or the bar cleared): its health starts afresh
                b->name = value.text;
                b->have = false;
                for (bool& a : b->armed) a = true;
            }
        }
        ReleaseSRWLockExclusive(&g_lock);
        if (!fresh) return std::string();
        alog::Write("status: boss %s", value.text.c_str());
        return announce::On(announce::kBoss) ? "Boss: " + value.text : std::string();
    }
    return std::string();
}

std::string OnPickup(const std::string& kind, unsigned now_ms) {
    if (const char* weapon = WeaponName(kind)) {
        alog::Write("status: picked up %s", kind.c_str());
        return announce::On(announce::kPickups) ? std::string("Picked up ") + weapon : std::string();
    }
    AcquireSRWLockExclusive(&g_lock);
    std::string note;
    if (kind == "health") {
        g_health_pickup = true;
        g_health_pickup_ms = now_ms;
        note = "health: result in a moment";
    } else if (kind == "grenades") {
        if (g_grenades_said && now_ms - g_grenades_said_ms <= 1000) {
            note = "grenades: the count already went up";
        } else {
            g_grenade_pickup = true;
            g_grenade_pickup_ms = now_ms;
            note = "grenades: waiting for the count";
        }
    } else {
        note = "unknown kind";
    }
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("status: picked up %s (%s)", kind.c_str(), note.c_str());
    return std::string();
}

std::string OnFrame(unsigned now_ms) {
    std::string said;
    bool combo_said = false;
    AcquireSRWLockExclusive(&g_lock);
    if (g_health_pickup && now_ms - g_health_pickup_ms >= kHealthPickupDelayMs) {
        g_health_pickup = false;
        said = g_have_health ? "Picked up health, " + Percent(g_health) : std::string("Picked up health");
    } else if (g_grenade_pickup && now_ms - g_grenade_pickup_ms >= kGrenadePickupWaitMs) {
        g_grenade_pickup = false;  // the count didn't go up: already at the maximum
        said = g_have_grenades ? Grenades(g_grenades) : std::string("Picked up grenades");
    } else if (g_combo > 0 && now_ms - g_combo_ms >= kComboIdleMs) {
        if (g_combo >= kMinCombo) said = ComboText(g_combo);  // no hits for a while: the combo is over
        combo_said = !said.empty();
        g_combo = 0;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (!said.empty()) alog::Write("status: later -> say \"%s\"", said.c_str());
    if (said.empty() || !announce::On(combo_said ? announce::kCombo : announce::kPickups)) return std::string();
    return said;
}

std::string HealthText() {
    AcquireSRWLockShared(&g_lock);
    const bool h = g_have_health;
    const double health = g_health;
    std::string text = h ? Percent(health) : "No health yet";
    for (const BossBar& b : g_bosses) {  // 3-3: boss health after the player's (the user, 2026-09-26)
        // B7b: a boss at 0 is gone (defeated, or 1-a's scripted fake Butcher, whose bar is set to -650 and
        // never hidden by a write we see): H stopped saying "0 percent boss health" for the rest of the session.
        if (b.have && !b.name.empty() && b.health > 0) text += ", " + BossText(b);
    }
    ReleaseSRWLockShared(&g_lock);
    return text;
}

std::string GrenadeText() {
    AcquireSRWLockShared(&g_lock);
    const bool g = g_have_grenades;
    const int grenades = g_grenades;
    ReleaseSRWLockShared(&g_lock);
    return g ? Grenades(grenades) : "No grenade count yet";
}

void ForgetBosses() {
    AcquireSRWLockExclusive(&g_lock);
    for (BossBar& b : g_bosses) {
        b.name.clear();
        b.have = false;
        b.health = 0;
        for (bool& a : b.armed) a = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
}

void Reset() {
    AcquireSRWLockExclusive(&g_lock);
    g_have_health = false;
    g_health = 0;
    for (bool& a : g_armed) a = true;
    g_have_grenades = false;
    g_grenades = 0;
    g_boss.clear();
    g_reset_ms = 0;
    g_have_reset = false;
    g_health_pickup = false;
    g_grenade_pickup = false;
    g_grenades_said = false;
    g_combo = 0;
    for (BossBar& b : g_bosses) {
        b.name.clear();
        b.have = false;
        b.health = 0;
        for (bool& a : b.armed) a = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
}

}  // namespace status
