# Interactive tutorial: feasibility assessment (2026-10-11)

The user (2026-10-11): "Please assess the viability of creating an interactive tutorial for the mod. I'm envisioning
something like:
- The tutorial is started through the mod menu, and is only visible in Return Home.
- The tutorial explains what each sound means as you encounter them, pausing the game while it talks, with enter to
  continue or f8 to repeat.
- Waypoint mode and speak moves are turned on for the tutorial, and give additional information to help new players
  navigate.
- For combat, it would walk you through tracking enemies, locking onto one, discuss big goons, special attacks etc over
  the first few combats of the level.
- The tutorial would conclude with the fake butcher boss fight, highlighting the bell sound when he's about to charge,
  the grapple window once he finishes, etc.
- All other tutorial messages and loading tips throughout the game would use mod specific language and the user's
  actual key bindings where relevant."

Discussion only; nothing built. The user's answers (2026-10-11) are at the end; the batches are planned in
PLAN (B61-B64), not started.

**Verdict: viable, and mostly built from parts the mod already has.** About four batches, plus writing the text. The
work is less about new engine knowledge and more about timing (when to pause), wording, and play-testing with a new
player's ears. One piece needs new reverse engineering: the game's own **keyboard** bindings (the controller ones are
already read).

Effort sizes: **small** = one batch step; **medium** = most of a batch; **large** = several batches.

## What already exists

- **Level and chapter:** level_hooks names the level at every load; Return Home and A Big Show are both chapters of
  campaign_1a_wrestlingring (the geometry's chapter lines), and the fake Butcher is its boss ("Boss: The Butcher" in
  1-a, the 2026-10-11 grenade run).
- **Pausing:** the mod menu already pauses the game (B38-2: our own focus window takes the focus; the game pauses as on
  alt-tab), blocks its keys (input_block), and resumes cleanly ("Resumed" when the game's pause menu closes). A tutorial
  page can use the same window: its text on screen, Enter to continue, F8 to repeat. Our own sounds (XAudio2) still play
  while the game is paused, so a page can play the sound it explains.
- **Knowing a sound is happening:** every cue is decided in one place (`cues`: edge, drop, deadly drop, wall, pluck,
  jump-now chirp, pickup beacon and "in reach", enemy tick, pass and attack whooshes, the boss setup bell and opening
  bell, waypoint chime, hazards), with per-sound counters already logged ("cues: played in 5 s"). A "first time this
  sound plays in the tutorial" hook is small.
- **Explanations:** Learn sounds (B15-2) already has a spoken description for every sound.
- **Waypoint mode and Speak each move:** both are toggles the tutorial can switch on, then restore afterwards.
- **Combat signals:** N, L / K, special-enemy announcements, attack wind-ups (grab / heavy), boss names and health,
  setup bells (the Butcher's charge), openings, "Grapple now" and "Mash attack" prompts, combo counts: all reported to
  the mod already.
- **The game's tutorials and tips:** menu_reader already reads the loading tip (`_level0.hintText.text`, 23 different
  tips seen in the logs), the tutorial hints (`_level0.tutorial.help.helpText.text`) and the tutorial screens' drawn
  text (ui_text: tutorialmovement, tutorialbasicattacks, tutorialblock, tutorialgrapplestart / finish,
  tutorialgrenades, tutorialpouncestart, tutorialclimb, tutorialwallrun, tutorialgimp, ...). Replacing what's said is a
  lookup by text before speaking.
- **Mod key names:** hotkeys knows every binding (key and controller button); the game's controller bindings come from
  game_pads (B40-4).

## The parts

1. **The tutorial framework (medium).**
   - A `tutorial` module: an ordered list of pages, each with a trigger (a sound's first time, a checkpoint reached, an
     enemy count, a boss event, a key the player is asked to press) and its text.
   - F7 shows "Start tutorial" (and "Stop tutorial" while it runs) only in 1-a; release builds too (it's for players).
   - Starting it: waypoint mode and Speak each move on (restored at the end); optionally back to the level's start
     (checkpoint_jump works on both builds).
   - A page: pause, show and speak it, play its sound; Enter continues, F8 repeats, Escape offers to end the tutorial.
   - **Timing rules** (the main design work): never pause while Shank is in the air, mid-attack or while an enemy attack
     is coming; hold the page until the next calm moment (on the ground, nothing winding up). Each topic once per run.
2. **Sounds as you meet them (medium).** First edge, drop, wall, jump pluck, jump-now chirp, pickup and "in reach",
   waypoint chime, hazard. A check of which sounds 1-a actually has (its level data and the movement corpus); those it
   doesn't (deadly drops, rockets, slide poles) are covered in a closing page or by Learn sounds.
3. **Navigation help (small-medium).** Generic, so it works on both builds: the first time Q's route uses each kind of
   move (walk, jump up, long jump, swing point, wall run, drop down, climb), one page explaining that move and how its
   sounds lead you through it. No per-spot authoring.
4. **Combat (medium).** Over 1-a's first fights:
   - the first enemy: the tick and its pan, then "press N"; the page waits until N is pressed;
   - lock-on: "press L", then K;
   - the first big goon: the special-enemy announcement;
   - the first grab and heavy wind-ups;
   - health warnings and H;
   - the first grapple and pounce prompts.

   Each follows the game's own events, so the same text works on both builds.
5. **The fake Butcher (small).**
   - At "Boss: The Butcher", one page before the fight.
   - At the first slow setup bell, a short page: his charge is coming, step aside.
   - At the first opening bell and "Grapple now", what to press.
   - Then H for his health, and a closing page that ends the tutorial.
   - Pausing at the bell freezes the charge exactly where it was, so these pages must stay short.
6. **The game's tips and tutorials in mod language (medium; mostly writing, plus one RE step).**
   - A table from each game text (the ~23 loading tips, the ~10 tutorial hints and the tutorial screens) to our own
     wording, with placeholders for keys ({block}, {grapple}, {mod:health}).
   - Unknown or changed text (classic's tips may differ) falls back to the game's own.
   - The game's keyboard bindings need finding: the controller map is read from Input::XInputController (B40-4); the
     keyboard is likely a sibling object with the same map layout (small-medium RE, both builds).
   - Until then, the game's default keys (RE-NOTES "Keyboard bindings").
   - This part helps every player, tutorial or not, and could ship first.

## Risks

- **Too many pauses** turn a tutorial into a chore. Each topic once, short pages, and an easy way to end it.
- **Pausing at the wrong moment** (mid-jump, an attack in flight) could cost a life. The calm-moment rule above. (No
  infinite health in the tutorial: the user, 2026-10-11, below.)
- **Resuming:** keys held when a page opens are released for the game (B38-2), so a jump or run in progress stops; the
  pages wait for a calm moment for this reason too.
- **Game sounds can't be replayed while paused.** Only our own sounds can; a page about a game sound (the Butcher's
  roar) describes it instead.
- **Classic:** 1-a is the same level; generic triggers carry over; safe edges' page is left out there.
- **Testing** needs fresh ears: the user knows the sounds by heart now; a friend's run, or the user judging wording and
  timing rather than learning.

## Suggested order

1. Part 6 first, on its own: tips and tutorials in mod language, the game's keyboard bindings (one batch; helps
   everyone).
2. Parts 1 and 2: the framework and the sound pages (one batch, tested in 1-a's opening).
3. Parts 3 and 4: navigation and combat pages (one batch).
4. Part 5 and polish: the Butcher, the closing page, timing fixes from testing (one batch).

## Questions for the user

Answered 2026-10-11 (the user's words; "Don't start implementing yet, just update the plan."):

1. Pause for every page? "Every page should pause, especially for larger descriptions like using K and L. Shorter
   messages could get missed or drowned out." -> every page pauses, in fights too (at the calm-moment rule).
2. Restart or begin where you are? "It should reload the level, and play a message stating the tutorial can be started
   from the mod menu on level load." -> Start tutorial reloads 1-a from its start; and whenever 1-a loads (tutorial not
   running), a spoken message says the tutorial can be started from the mod menu.
3. Keys in rewritten tips: "Based on last input." -> keyboard keys or controller buttons, whichever the player used
   last.
4. Replace or follow? "They should convey the same information, rewritten to work with the mod." -> each tip / hint
   rewritten in our words with the same information, mod terms and the player's keys; it replaces the game's text.
5. Infinite health in the tutorial? "No, death isn't very punishing anyway, and learning to deal with it is part of the
   game." -> no cheats in the tutorial.
