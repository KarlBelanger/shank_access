#pragma once
// B38-2 (the user, 2026-09-30: "Make the menu pause the game on open if a level is loaded"; then "If you can't find the
// pause functions, just build a simple gui window for the menu and have it gain focus like the mark window does"): a
// window of our own that takes the focus while the mod menu is open. The game pauses when its window loses the focus
// (RE-NOTES "Pausing"); the keys keep coming through the hotkey poll (our window counts as the game there, unlike the mark
// window). On close the game gets the focus back (it then shows its pause menu, as after a mark).
// B38-2b (the user: "Since you're building the window, might as well make the menu visual, simple text and highlighting
// is fine"): it draws the menu's current list, the selected item highlighted, redrawn when it changes.
#include <functional>
#include <string>
#include <vector>

namespace focus_window {

constexpr const wchar_t* kClassName = L"ShankAccessMenu";

struct Content {
    std::string title;               // UTF-8
    std::vector<std::string> lines;  // UTF-8
    int selected = -1;
    bool operator==(const Content& o) const { return title == o.title && lines == o.lines && selected == o.selected; }
};

// Opens the window (drawing what `content` returns, polled every 100 ms) and waits up to about a second until it has
// the focus. False if it couldn't be made.
bool Open(const wchar_t* title, std::function<Content()> content);
// Closes it (if open) and gives the game back the focus.
void Close();
bool IsOpen();

}  // namespace focus_window
