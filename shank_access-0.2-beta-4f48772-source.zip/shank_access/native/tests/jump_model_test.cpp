// Host-side test of the jump model (never deployed). Numbers follow from the constants: a standing jump
// rises 1380² / (2 × 3293) ≈ 289 px; a long jump at the same height lands after 2 × 1247 / 3293 ≈ 0.76 s,
// between 245 and 545 px ahead. Exit 0 = pass.
#include <cstdio>
#include <vector>

#include "../core/jump_model.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

using jump_model::Target;

}  // namespace

int main() {
    const float x = 1000, y = 224;  // standing on a floor at 192
    // Swing points: caught within 1 tile of a spot 2 tiles ahead and 3 up.
    Check(jump_model::Reach(Target{jump_model::kSwing, x + 128, y + 192 + 250, 0, 0}, x, y, true) != jump_model::kNone,
          "a swing point just above the grab spot's reach: reached");
    Check(jump_model::Reach(Target{jump_model::kSwing, x + 128, y + 192 + 450, 0, 0}, x, y, true) == jump_model::kNone,
          "a swing point too high: not reached");
    Check(jump_model::Reach(Target{jump_model::kSwing, x + 450, y + 192 + 150, 0, 0}, x, y, true) == jump_model::kLong,
          "a swing point ahead and up: the long jump");
    Check(jump_model::Reach(Target{jump_model::kSwing, x - 450, y + 192 + 150, 0, 0}, x, y, true) == jump_model::kNone,
          "the same point behind him: not reached (turn first)");
    Check(jump_model::Reach(Target{jump_model::kSwing, x - 450, y + 192 + 150, 0, 0}, x, y, false) == jump_model::kLong,
          "facing it: reached");
    // Landing across a gap at the same height.
    Check(jump_model::Reach(Target{jump_model::kLanding, x + 300, 192, x + 900, 192}, x, y, true) == jump_model::kLong,
          "a landing 300 px ahead: the long jump");
    Check(jump_model::Reach(Target{jump_model::kLanding, x + 700, 192, x + 900, 192}, x, y, true) == jump_model::kNone,
          "a landing 700 px ahead at the same height: too far");
    Check(jump_model::Reach(Target{jump_model::kLanding, x + 700, -300, x + 900, -300}, x, y, true) == jump_model::kLong,
          "700 px ahead but 500 px lower: the long jump gets there on the way down");
    Check(jump_model::Reach(Target{jump_model::kLanding, x + 200, 700, x + 600, 700}, x, y, true) == jump_model::kNone,
          "a ledge 500 px higher: out of reach");
    // Bars to hang from: 3 tiles below it.
    Check(jump_model::Reach(Target{jump_model::kShimmy, x - 100, y + 192 + 200, x + 300, y + 192 + 200}, x, y, true) ==
              jump_model::kLong,
          "a bar overhead: reached");
    // 1-a's wall run: the floor at y 2176 ends deadly at x 26304; the zone is x 26428..27612, y 2286..2600.
    const Target run{jump_model::kWallZone, 26428, 2286, 27612, 2600};
    Check(jump_model::Reach(run, 26200, 2208, true) == jump_model::kLong, "1-a wall run from x 26200: reached");
    Check(jump_model::Reach(run, 25500, 2208, true) == jump_model::kNone, "1-a wall run from x 25500: too early");
    Check(jump_model::Reach(run, 26200, 2208, false) != jump_model::kLong, "1-a wall run facing away: no long jump");
    // 1-c's climb: clinging to the street's end wall (x 5376, climbable to y 1600) at x 5344, a wall jump
    // away (left) toward the swing point at (4725, 1044).
    const Target swing{jump_model::kSwing, 4725, 1044, 0, 0};
    Check(jump_model::ReachFromWall(swing, 5344, 1190, false) == jump_model::kWallJump, "1-c: wall jump from y 1190 (the logged catch launched from 1188): reaches the swing point");
    Check(jump_model::ReachFromWall(swing, 5344, 3500, false) == jump_model::kNone, "1-c: from far too high (y 3500): misses");
    Check(jump_model::ReachFromWall(swing, 5344, 1250, false) == jump_model::kWallJump, "1-c: from y 1250 (as in the log): caught just above it");
    Check(jump_model::ReachFromWall(swing, 5344, 1600, false) == jump_model::kNone, "1-c: from the top of the climbable wall: falling too fast to catch it");
    Check(jump_model::ReachFromWall(swing, 5344, 1130, true) == jump_model::kNone, "jumping the wrong way: misses");
    // Wall to wall: a climbable wall 400 px away, 300 px high above his height.
    const Target wall{jump_model::kWall, 4944, 1000, 0, 1600};
    Check(jump_model::ReachFromWall(wall, 5344, 1130, false) == jump_model::kWallJump, "a wall 400 px across: caught");
    const Target far_wall{jump_model::kWall, 4344, 1000, 0, 1600};
    Check(jump_model::ReachFromWall(far_wall, 5344, 1130, false) == jump_model::kNone, "a wall 1000 px across: too far");
    // B5d, from the B5c log: letting go of 1-c's first swing point (4726, 1045) at (4670, 955) facing left
    // reached the second (4110, 1158) (the user: it "does not show up as a valid jump target").
    const Target swing2{jump_model::kSwing, 4110, 1158, 0, 0};
    Check(jump_model::ReachFromSwing(swing2, 4670, 955, false) == jump_model::kSwingJump, "1-c: swing to swing: reached");
    Check(jump_model::ReachFromSwing(swing2, 4670, 955, true) == jump_model::kNone, "1-c: swing to swing facing away: not");
    // The logged wall jump from y 1082 (about 600 px/s across, a 203 px rise) caught the first swing point.
    Check(jump_model::ReachFromWall(swing, 5344, 1082, false) == jump_model::kWallJump, "1-c: the logged wall jump from y 1082");
    // B5e, from the B5d log: releasing swing point 2 facing right, the flights passed ~165 px *above* swing
    // point 1 and never caught it (the user: "I always fly over it").
    Check(jump_model::ReachFromSwing(swing, 4300, 1178, true) != jump_model::kSwingJump, "1-c: swing 2 to swing 1: the release flies over (a miss)");
    // B42c (the B42b session there: the constant chirp for swing 1 facing right, and the jump up dropped back onto swing 2):
    // with the level's swing points known, the release leaves from its fixed spot and the jump up from the bottom.
    {
        const std::vector<Target> points = {swing, swing2};
        jump_model::SetInterceptors(&points);
        Check(jump_model::ReachFromSwing(swing, 4110, 980, true) == jump_model::kNone, "B42c: swing 2 facing right: neither the release nor the jump up reaches swing 1");
        Check(jump_model::ReachFromSwing(swing, 4180, 1000, true) == jump_model::kNone, "B42c: (anywhere on swing 2's arc)");
        Check(jump_model::ReachFromSwing(swing2, 4726, 867, false) == jump_model::kSwingJump, "B42c: swing 1 facing left: the release reaches swing 2 (the route)");
        const Target above{jump_model::kLanding, 3900, 1250, 4300, 1250};  // a floor in the jump up's rise
        Check(jump_model::ReachFromSwing(above, 4110, 980, true) == jump_model::kUpJump, "B42c: the jump up reaches a floor in its rise");
        const Target left{jump_model::kLanding, 3300, 700, 3700, 700};
        Check(jump_model::ReachFromSwing(left, 4110, 980, false) != jump_model::kUpJump, "B42c: the jump up falls back onto its own point, not past it");
        jump_model::SetInterceptors(nullptr);
    }
    // Off the bar's end (2601, 3996) facing right toward the platform 2624..3328 at y 3904. B41-4: re-read in the B5 log
    // (build/logs/20260926-115445-B5, 11:44:16): he pulled up 48 px in place, rose 170 px from there and crossed y 3904 at
    // x ~3416, past the platform's end: a miss (the B5 test had it as a landing, without the pull-up).
    const Target platform{jump_model::kLanding, 2624, 3904, 3328, 3904};
    Check(jump_model::ReachFromBar(platform, 2601, 3996, true) != jump_model::kBarJump, "1-c: off the bar's end: over the platform (the B5 log)");
    // B6-5: the other launches. Jump up (holding up) off a swing point: a bar 300 px straight above.
    const Target above{jump_model::kSwing, 1000, 1300 + 192 + 300, 0, 0};
    Check(jump_model::ReachFromSwing(above, 1000, 1300, true) == jump_model::kUpJump, "swing: a point straight above: the jump up");
    Check(jump_model::ReachFromBar(Target{jump_model::kLanding, 700, 1450, 1100, 1450}, 900, 1300, true) ==
              jump_model::kUpJump, "bar: a ledge just above: the jump up");
    // B42b: the jump while running up a wall launches as the wall jump (the corpus): no further than it.
    const Target wall700{jump_model::kWall, 4644, 1000, 0, 1600};
    Check(jump_model::ReachFromWall(wall700, 5344, 1130, false) == jump_model::kNone, "a wall 700 px across: no wall jump");
    Check(jump_model::ReachFromWallRunningUp(wall700, 5344, 1130, false) == jump_model::kNone,
          "the same wall while running up: not reached either");
    // The wall-run jump: a landing 600 px ahead and level.
    Check(jump_model::ReachFromWallRun(Target{jump_model::kLanding, 1400, 1000, 2000, 1000}, 1000, 1032, true) ==
              jump_model::kWallRunJump, "wall run: a landing 400 px ahead");
    Check(jump_model::ReachFromWallRun(Target{jump_model::kLanding, 1400, 1000, 2000, 1000}, 1000, 1032, false) ==
              jump_model::kNone, "wall run the other way: not");
    // B11-2 ledge grab: a platform whose top (y 448) is 4 tiles above the floor (192), with a wall under its left
    // end (x 1300, y 192..448, solid to its right). A long jump from x 1150 can't land on top (the rise is ~205 px),
    // but it meets the wall with the ledge within reach: he grabs it and climbs up.
    {
        const std::vector<jump_model::Obstacle> obs = {
            {jump_model::Obstacle::kWallSolidRight, 1300, 192, 1300, 448},
            {jump_model::Obstacle::kFloor, 1300, 448, 1800, 448},
            {jump_model::Obstacle::kFloor, 0, 192, 1300, 192}};
        jump_model::SetObstacles(&obs);
        const Target top{jump_model::kLanding, 1300, 448, 1800, 448};
        Check(jump_model::Reach(top, 1150, 224, true) != jump_model::kNone, "a ledge 4 tiles up, jumping at its wall: grabbed");
        const Target high{jump_model::kLanding, 1300, 700, 1800, 700};
        const std::vector<jump_model::Obstacle> obs2 = {
            {jump_model::Obstacle::kWallSolidRight, 1300, 192, 1300, 700},
            {jump_model::Obstacle::kFloor, 1300, 700, 1800, 700}};
        jump_model::SetObstacles(&obs2);
        Check(jump_model::Reach(high, 1150, 224, true) == jump_model::kNone, "a ledge 8 tiles up: out of reach");
        jump_model::SetObstacles(nullptr);
    }
    // B42b: hanging at a wall's top (120..200 px under it) the wall jump leaves falling (the corpus: 49 of 56 there).
    {
        const std::vector<jump_model::Obstacle> obs = {
            {jump_model::Obstacle::kWallSolidRight, 2000, 0, 2000, 1000},
            {jump_model::Obstacle::kWallSolidRight, 2000, 1000, 2000, 1200}};  // a piece stacked on it
        jump_model::SetObstacles(&obs);
        Check(jump_model::WallTopAbove(1968, 600) == 1200, "the wall's top: its stacked pieces joined");
        const Target level{jump_model::kLanding, 1500, 600, 1700, 600};  // 300 px away, level with his feet + 32
        Check(jump_model::ReachFromWall(level, 1968, 600, false) == jump_model::kWallJump, "low on the wall: the jump rises onto it");
        const Target hang{jump_model::kLanding, 1500, 1040, 1700, 1040};
        Check(jump_model::ReachFromWall(hang, 1968, 1040, false) == jump_model::kNone, "160 under the top: the jump falls, a floor level with him missed");
        const Target below{jump_model::kLanding, 1500, 700, 1900, 700};
        Check(jump_model::ReachFromWall(below, 1968, 1040, false) == jump_model::kWallJump, "160 under the top: a floor below is reached");
        jump_model::SetObstacles(nullptr);
    }
    // B8c, 2-b's slide pole (x 14779, y 1397..4290), from the B8 live log: from the ledge at (14595, 3873) the
    // long jump caught it (and he slid); from its foot (14524, 1488) jumping "up to it" does nothing useful.
    Target slide{jump_model::kPole, 14778.7f, 4290, 14778.7f, 1396.67f};
    slide.slide = true;
    Check(jump_model::Reach(slide, 14595, 3873, true) != jump_model::kNone, "2-b slide pole: from the ledge beside its top: reached");
    Check(jump_model::Reach(slide, 14524, 1488, true) == jump_model::kNone, "2-b slide pole: from its foot: not a target");
    Target climb = slide;
    climb.slide = false;
    Check(jump_model::Reach(climb, 14524, 1488, true) != jump_model::kNone, "(the same pole, climbable: reached from the foot)");
    // B12-1 slippery slopes: the long jump downhill only; off the low end at the slide's speed he goes much further.
    const Target ahead{jump_model::kLanding, x + 300, 192, x + 900, 192};
    Check(jump_model::ReachSliding(ahead, x, y, true) == jump_model::kLong, "sliding right: the long jump reaches a landing ahead");
    Check(jump_model::ReachSliding(ahead, x, y, false) == jump_model::kNone, "sliding left: it's behind him");
    const Target far_low{jump_model::kLanding, x + 500, -200, x + 800, -200};
    Check(jump_model::ReachFalling(far_low, x, y, true) == jump_model::kNone, "walking off: a landing 500 px out, 400 down: short");
    // (B41c: off a slope's end he crosses at ~780 px/s, measured: a landing 300-600 px out, 400 down)
    const Target slide_low{jump_model::kLanding, x + 300, -200, x + 600, -200};
    Check(jump_model::ReachSlidingOff(slide_low, x, y, true) != jump_model::kNone, "sliding off: reached");
    Check(jump_model::ReachSlidingOff(far_low, x, y, true) == jump_model::kNone, "sliding off: 500 px out, 400 down: short (B41c)");
    // B12-2 platformup: a platform whose top (y 540) is out of a jump's reach (his feet peak ~250 px up, at ~480),
    // but his body meets it from below: one-way, Jump again there takes him onto it; solid, it doesn't.
    Target plat{jump_model::kLanding, x - 100, 540, x + 300, 540};
    Check(jump_model::Reach(plat, x, y, true) == jump_model::kNone, "a solid platform 5 tiles above his feet: out of reach");
    plat.oneway = true;
    Check(jump_model::Reach(plat, x, y, true) != jump_model::kNone && jump_model::LastWasPlatformUp(),
          "the same platform one-way: reached by jumping again inside it");
    plat.y1 = plat.y2 = 400;
    Check(jump_model::Reach(plat, x, y, true) != jump_model::kNone && !jump_model::LastWasPlatformUp(),
          "a one-way platform in plain reach: an ordinary landing");
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
