#include "mod_menu.h"

#include <windows.h>

#include <vector>

#include "announce.h"
#include "hotkeys.h"
#include "log.h"

namespace mod_menu {
namespace {

enum class Item { kVolume, kLearn, kSpeech, kPan, kSafeEdges, kWaypoint, kAnnounce, kKey, kPad, kClose, kCategory, kBack, kCheckpoint };
struct Entry {
    Item item;
    int index;  // the announcement kind, the binding's position, or the category
};

// B17-2 (the user: "break the f7 menu up into category submenus, enemies, navigation, etc which have the settings and
// controls for their respective keys"): the top level lists these, then Close; each holds its settings and keys, then
// Back. Speech opens the speech list.
// B34: "Go to checkpoint" only in test mode, with a level's checkpoints known.
enum Category { kCatSpeech, kCatSounds, kCatNavigation, kCatEnemies, kCatStatus, kCatGeneral, kCatCheckpoints, kCatCount };
const char* const kCategoryNames[kCatCount] = {"Speech", "Sounds", "Navigation", "Enemies", "Status and pickups", "General",
                                               "Go to checkpoint"};
struct CategoryKeys {
    Category cat;
    const char* ids[6];  // hotkey ids (hotkeys::Binding::id), nullptr-terminated
};
const CategoryKeys kCategoryKeys[] = {
    {kCatSounds, {"pan", nullptr}},
    {kCatNavigation, {"safe_edges", "waypoint", "next_move", "traversal", nullptr}},
    {kCatEnemies, {"enemies", "lock", "lock_special", nullptr}},
    {kCatStatus, {"health", "grenades", "pickups", nullptr}},
#ifdef SHANK_ACCESS_RELEASE
    {kCatGeneral, {"repeat_long", "mark", "settings", nullptr}},  // (B37-2: no test mode in a release build)
#else
    {kCatGeneral, {"repeat_long", "mark", "settings", "test_mode", nullptr}},
#endif
};
int g_cat = -1;  // the open category (-1 = the top level)
void BackToTop(int cat = -2);  // (below)

Hooks g_hooks;
bool g_open = false;
bool g_paused = false;  // B38-2: the game paused by our focus window
SRWLOCK g_view_lock = SRWLOCK_INIT;  // B38-2b: the snapshot the window draws
View g_view;
void UpdateView();  // (below)

bool CheckpointsShown() {
    return g_hooks.test_mode && g_hooks.test_mode() && g_hooks.checkpoints && !g_hooks.checkpoints().empty();
}
size_t g_at = 0;
bool g_capturing = false;  // waiting for the new key of the entry at g_at
bool g_pad_capturing = false;  // B39: waiting for the new controller buttons of the entry at g_at
bool g_learning = false;   // B15-2: in the "Learn sounds" list
size_t g_sound = 0;
bool g_speech = false;     // B16: in the "Speech settings" list
size_t g_sp_at = 0;

std::vector<Entry> Entries() {
    std::vector<Entry> e;
    if (g_cat < 0) {  // the top level
        for (int c = 0; c < kCatCount; ++c) {
            if (c == kCatSpeech && !g_hooks.get_engine) continue;
            if (c == kCatCheckpoints && !CheckpointsShown()) continue;
            e.push_back({Item::kCategory, c});
        }
        e.push_back({Item::kClose, 0});
        return e;
    }
    switch (g_cat) {
        case kCatSounds:  // (B38-1: Learn sounds first, the user)
            if (!g_hooks.sounds.empty()) e.push_back({Item::kLearn, 0});
            e.push_back({Item::kVolume, 0});
            e.push_back({Item::kPan, 0});
            break;
        case kCatNavigation:
            if (g_hooks.get_safe_edges) e.push_back({Item::kSafeEdges, 0});
            if (g_hooks.get_waypoint) e.push_back({Item::kWaypoint, 0});  // B38-1
            e.push_back({Item::kAnnounce, announce::kMoves});  // B48
            break;
        case kCatEnemies:
            for (announce::Kind k : {announce::kSpecialEnemies, announce::kBoss, announce::kPrompts}) e.push_back({Item::kAnnounce, k});
            break;
        case kCatStatus:
            for (announce::Kind k : {announce::kHealth, announce::kPickups, announce::kInReach, announce::kCombo}) {
                e.push_back({Item::kAnnounce, k});
            }
            break;
        case kCatGeneral:
            e.push_back({Item::kAnnounce, announce::kTips});
            break;
        case kCatCheckpoints: {  // B34: this level's checkpoints, then Back
            const auto cps = g_hooks.checkpoints ? g_hooks.checkpoints() : std::vector<std::string>();
            for (size_t i = 0; i < cps.size(); ++i) e.push_back({Item::kCheckpoint, static_cast<int>(i)});
            break;
        }
        default:
            break;
    }
    const auto keys = hotkeys::Bindings();  // the category's keys, in the order of the list above
    std::vector<int> mine;
    for (const CategoryKeys& ck : kCategoryKeys) {
        if (ck.cat != g_cat) continue;
        for (const char* const* k = ck.ids; *k; ++k) {
            for (size_t i = 0; i < keys.size(); ++i) {
                if (keys[i].id == *k) mine.push_back(static_cast<int>(i));
            }
        }
    }
    if (g_cat == kCatGeneral) {  // any key not listed anywhere
        for (size_t i = 0; i < keys.size(); ++i) {
            bool listed = false;
            for (const CategoryKeys& ck : kCategoryKeys) {
                for (const char* const* k = ck.ids; *k; ++k) listed = listed || keys[i].id == *k;
            }
            if (!listed) mine.push_back(static_cast<int>(i));
        }
    }
    // B39 (the user: "In each submenu, group all keyboard keys together, then controller bindings below them").
    for (int i : mine) e.push_back({Item::kKey, i});
    for (int i : mine) e.push_back({Item::kPad, i});
    e.push_back({Item::kBack, 0});
    return e;
}

std::string OnOff(bool on) { return on ? "on" : "off"; }

std::string Text(const Entry& e) {
    switch (e.item) {
        case Item::kVolume: return "Cue volume, " + std::to_string(g_hooks.get_volume ? g_hooks.get_volume() : 0) + " percent";
        case Item::kLearn: return "Learn sounds";
        case Item::kSpeech: return "Speech settings";
        case Item::kPan:  // B38-1 (the user: "Sound panning" with "Relative to Shank" and "relative to camera")
            return std::string("Sound panning, ") + (g_hooks.get_pan && g_hooks.get_pan() ? "relative to Shank" : "relative to camera");
        case Item::kSafeEdges: return "Safe edges, " + OnOff(g_hooks.get_safe_edges && g_hooks.get_safe_edges());
        case Item::kWaypoint: return "Waypoint mode, " + OnOff(g_hooks.get_waypoint && g_hooks.get_waypoint());
        case Item::kAnnounce: {
            const auto k = static_cast<announce::Kind>(e.index);
            return std::string(announce::Label(k)) + ", " + OnOff(announce::On(k));
        }
        case Item::kKey: {
            const auto keys = hotkeys::Bindings();
            if (static_cast<size_t>(e.index) >= keys.size()) return std::string();
            return keys[e.index].label + " key, " + hotkeys::KeyName(keys[e.index].vk);
        }
        case Item::kPad: {  // B39
            const auto keys = hotkeys::Bindings();
            if (static_cast<size_t>(e.index) >= keys.size()) return std::string();
            const unsigned pad = keys[e.index].pad;
            return keys[e.index].label + " controller button, " + (pad ? hotkeys::PadName(pad) : std::string("not set"));
        }
        case Item::kClose: return "Close";
        case Item::kCategory: return e.index >= 0 && e.index < kCatCount ? kCategoryNames[e.index] : "";
        case Item::kBack: return "Back";
        case Item::kCheckpoint: {
            const auto cps = g_hooks.checkpoints ? g_hooks.checkpoints() : std::vector<std::string>();
            return static_cast<size_t>(e.index) < cps.size() ? cps[e.index] : std::string();
        }
    }
    return std::string();
}

// B38-1 (the user: "For each setting, add brief explainer text that plays last which describes in a sentence or sentence
// fragment what that setting does"): spoken after the item's position when moving onto it (not after a change).
const struct {
    const char* id;
    const char* text;
} kKeyExplainers[] = {
    {"pan", "Switches sound panning between Shank and the camera."},
    {"safe_edges", "Turns safe edges on and off."},
    {"waypoint", "Turns waypoint mode on and off."},
    {"next_move", "Speaks the next move toward the next checkpoint."},
    {"traversal", "Lists nearby things to climb, swing on or run along."},
    {"enemies", "Counts the enemies nearby and names the nearest."},
    {"lock", "Locks the enemy cue onto one enemy in range; press again for the next."},
    {"lock_special", "Like lock on, for special enemies only."},
    {"health", "Speaks Shank's health, and a boss's."},
    {"grenades", "Speaks how many grenades Shank carries."},
    {"pickups", "Lists the pickups nearby."},
    {"repeat_long", "Repeats the last long message, such as a tutorial or tip."},
    {"mark", "Marks a moment for feedback, with a comment."},
    {"settings", "Opens and closes this menu."},
    {"test_mode", "Turns test mode on and off."},
};

std::string Explainer(const Entry& e) {
    switch (e.item) {
        case Item::kVolume: return "How loud the mod's own sounds are.";
        case Item::kLearn: return "Plays each of the mod's sounds with what it means.";
        case Item::kPan: return "Where game sounds are placed: around Shank, or around the camera's view.";
        case Item::kSafeEdges: return "Shank stops at drops; move again to go over.";
        case Item::kWaypoint: return "Guides you to the next checkpoint, one move at a time.";
        case Item::kAnnounce:
            switch (static_cast<announce::Kind>(e.index)) {
                case announce::kHealth: return "Speaks when Shank's health drops past 75, 50 and 25 percent.";
                case announce::kPickups: return "Speaks what Shank picks up.";
                case announce::kInReach: return "Speaks when a pickup is close enough to grab.";
                case announce::kCombo: return "Speaks the hit count when a combo ends.";
                case announce::kBoss: return "Speaks a boss's name and health as it drops.";
                case announce::kSpecialEnemies: return "Names big and specially armed enemies as they arrive.";
                case announce::kPrompts: return "Speaks boss button prompts, such as Grapple now.";
                case announce::kTips: return "Reads loading tips and tutorial hints.";
                case announce::kMoves: return "With waypoint mode on, speaks the next move each time you finish one, as Q would.";
                default: return std::string();
            }
        case Item::kKey:
        case Item::kPad: {  // (B39: a controller binding does what its key does)
            const auto keys = hotkeys::Bindings();
            if (static_cast<size_t>(e.index) >= keys.size()) return std::string();
            for (const auto& k : kKeyExplainers) {
                if (keys[e.index].id == k.id) return k.text;
            }
            return std::string();
        }
        default: return std::string();
    }
}

std::string WithExplainer(const std::string& said, const Entry& e) {
    const std::string x = Explainer(e);
    return x.empty() ? said : said + ". " + x;
}

void Say(const std::string& s) {
    alog::Write("settings: say \"%s\"", s.c_str());
    if (g_hooks.say) g_hooks.say(s);
    UpdateView();  // (every key ends in a Say)
}

void Save() {
    if (g_hooks.save) g_hooks.save();
}

void SayCurrent() {
    const auto e = Entries();
    if (g_at >= e.size()) g_at = e.size() - 1;
    Say(WithExplainer(Text(e[g_at]) + ", " + std::to_string(g_at + 1) + " of " + std::to_string(e.size()), e[g_at]));
}

// Keys the game binds by default (RE-NOTES "Controls screen runtime"): arrows, Ctrl, Shift, Alt, Space, Enter,
// Caps Lock, 1-4 (the player may have moved them; a clash is allowed, only mentioned).
bool GameDefault(int vk) {
    switch (vk) {
        case VK_LEFT: case VK_RIGHT: case VK_UP: case VK_DOWN: case VK_LCONTROL: case VK_RCONTROL: case VK_LSHIFT:
        case VK_RSHIFT: case VK_LMENU: case VK_RMENU: case VK_SPACE: case VK_RETURN: case VK_CAPITAL:
        case '1': case '2': case '3': case '4':
            return true;
        default:
            return false;
    }
}

// B15-2: a key in the "Learn sounds" list.
void LearnKey(int vk) {
    const size_t n = g_hooks.sounds.size();
    auto say_at = [&] { Say(g_hooks.sounds[g_sound] + ", " + std::to_string(g_sound + 1) + " of " + std::to_string(n)); };
    switch (vk) {
        case VK_UP:
            g_sound = g_sound == 0 ? n - 1 : g_sound - 1;
            say_at();
            return;
        case VK_DOWN:
            g_sound = (g_sound + 1) % n;
            say_at();
            return;
        case VK_HOME:
            g_sound = 0;
            say_at();
            return;
        case VK_END:
            g_sound = n - 1;
            say_at();
            return;
        case VK_RETURN:
        case VK_SPACE:
        case VK_RIGHT:
            if (g_hooks.play_sound) g_hooks.play_sound(g_sound);
            return;
        case VK_ESCAPE:
        case VK_LEFT:
        case VK_BACK:
            g_learning = false;
            Say("Learn sounds");
            return;
        default:
            return;
    }
}

// B16: the "Speech settings" list: the three channels, then our SAPI voice, rate and volume, then Back.
const char* const kChannelLabels[3] = {"Menu reading", "Keys and stats", "Automatic messages"};
constexpr size_t kSpeechItems = 7;  // 3 channels, voice, rate, volume, Back

std::string SpeechText(size_t i) {
    if (i < 3) {
        const int engine = g_hooks.get_engine ? g_hooks.get_engine(static_cast<int>(i)) : 0;
        return std::string(kChannelLabels[i]) + ": " + (engine ? "SAPI" : "screen reader");
    }
    if (i == 3) {
        const std::string v = g_hooks.get_voice ? g_hooks.get_voice() : std::string();
        return "SAPI voice: " + (v.empty() ? std::string("Windows default") : v);
    }
    if (i == 4) return "SAPI rate: " + std::to_string(g_hooks.get_rate ? g_hooks.get_rate() : 0);
    if (i == 5) return "SAPI volume: " + std::to_string(g_hooks.get_sapi_volume ? g_hooks.get_sapi_volume() : 100) + " percent";
    return "Back";
}

const char* const kSpeechExplainers[kSpeechItems] = {
    "Which voice reads menus: your screen reader or SAPI.",
    "Which voice speaks key presses and readouts.",
    "Which voice speaks automatic messages during play.",
    "The voice for channels set to SAPI.",
    "How fast the SAPI voice speaks.",
    "How loud the SAPI voice is.",
    "",
};

std::string SpeechWithExplainer(size_t i) {
    const std::string said = SpeechText(i) + ", " + std::to_string(i + 1) + " of " + std::to_string(kSpeechItems);
    return *kSpeechExplainers[i] ? said + ". " + kSpeechExplainers[i] : said;
}

void SaySpeechAt() { Say(SpeechWithExplainer(g_sp_at)); }

// Changing the voice, rate or volume: say the new setting, then a preview in that voice.
void Preview() {
    if (g_hooks.sample) g_hooks.sample("This is how SAPI sounds now");
}

void SpeechChange(int dir) {  // -1 / +1 = Left / Right, 0 = Enter / Space
    if (g_sp_at < 3) {
        if (!g_hooks.get_engine || !g_hooks.set_engine) return;
        const int c = static_cast<int>(g_sp_at);
        g_hooks.set_engine(c, g_hooks.get_engine(c) ? 0 : 1);
        Save();
        Say(SpeechText(g_sp_at));  // (spoken by the stats channel's engine, which may just have changed)
        return;
    }
    if (g_sp_at == 3) {
        if (!g_hooks.voices || !g_hooks.set_voice || !g_hooks.get_voice) return;
        std::vector<std::string> list = {""};  // "" = Windows default, then the installed voices
        for (const std::string& v : g_hooks.voices()) list.push_back(v);
        size_t at = 0;
        for (size_t i = 0; i < list.size(); ++i) {
            if (list[i] == g_hooks.get_voice()) at = i;
        }
        at = dir < 0 ? (at == 0 ? list.size() - 1 : at - 1) : (at + 1) % list.size();
        g_hooks.set_voice(list[at]);
        Save();
        Say(SpeechText(3) + ", " + std::to_string(at + 1) + " of " + std::to_string(list.size()));
        Preview();
        return;
    }
    if (g_sp_at == 4) {
        if (!g_hooks.get_rate || !g_hooks.set_rate || dir == 0) return;
        g_hooks.set_rate(g_hooks.get_rate() + dir);
        Save();
        Say(SpeechText(4));
        Preview();
        return;
    }
    if (g_sp_at == 5) {
        if (!g_hooks.get_sapi_volume || !g_hooks.set_sapi_volume || dir == 0) return;
        g_hooks.set_sapi_volume(g_hooks.get_sapi_volume() + 10 * dir);
        Save();
        Say(SpeechText(5));
        Preview();
        return;
    }
    if (dir == 0) BackToTop(kCatSpeech);  // Back
}

void SpeechKey(int vk) {
    switch (vk) {
        case VK_UP:
            g_sp_at = g_sp_at == 0 ? kSpeechItems - 1 : g_sp_at - 1;
            SaySpeechAt();
            return;
        case VK_DOWN:
            g_sp_at = (g_sp_at + 1) % kSpeechItems;
            SaySpeechAt();
            return;
        case VK_HOME:
            g_sp_at = 0;
            SaySpeechAt();
            return;
        case VK_END:
            g_sp_at = kSpeechItems - 1;
            SaySpeechAt();
            return;
        case VK_LEFT:
        case VK_RIGHT:
            SpeechChange(vk == VK_LEFT ? -1 : 1);
            return;
        case VK_RETURN:
        case VK_SPACE:
            SpeechChange(0);
            return;
        case VK_ESCAPE:
        case VK_BACK:
            BackToTop(kCatSpeech);
            return;
        default:
            return;
    }
}

// B17-2: from a category (or the speech list) back to the top level, on that category.
void BackToTop(int cat) {
    const int from = cat == -2 ? g_cat : cat;
    g_cat = -1;
    g_speech = false;
    const auto top = Entries();
    g_at = 0;
    for (size_t i = 0; i < top.size(); ++i) {
        if (top[i].item == Item::kCategory && top[i].index == from) g_at = i;
    }
    Say(Text(top[g_at]) + ", " + std::to_string(g_at + 1) + " of " + std::to_string(top.size()));
}

void Close() {
    g_open = false;
    g_capturing = false;
    if (g_pad_capturing && g_hooks.set_pad_handler) g_hooks.set_pad_handler(nullptr);
    g_pad_capturing = false;
    g_learning = false;
    g_speech = false;
    g_cat = -1;
    if (g_hooks.set_key_handler) g_hooks.set_key_handler(nullptr);
    if (g_hooks.block_input) g_hooks.block_input(false);
    Say("Mod menu closed");
    if (g_paused && g_hooks.resume_game) g_hooks.resume_game();
    g_paused = false;
}

void Capture(int vk) {
    g_capturing = false;
    const auto e = Entries();
    const auto keys = hotkeys::Bindings();
    if (g_at >= e.size() || e[g_at].item != Item::kKey || static_cast<size_t>(e[g_at].index) >= keys.size()) return;
    const hotkeys::Binding& b = keys[e[g_at].index];
    if (vk == VK_ESCAPE) {
        Say("Cancelled. " + b.label + " key, " + hotkeys::KeyName(b.vk));
        return;
    }
    if (vk == VK_F9) {
        Say("F9 repeats the last message. " + b.label + " key unchanged");
        return;
    }
    for (const hotkeys::Binding& o : keys) {
        if (o.id != b.id && o.vk == vk) {
            Say(hotkeys::KeyName(vk) + " is already the " + o.label + " key. " + b.label + " key unchanged");
            return;
        }
    }
    hotkeys::SetKey(b.id, vk);
    Save();
    Say(b.label + " key, " + hotkeys::KeyName(vk) + (GameDefault(vk) ? ". The game uses this key too" : ""));
}

// B39: the controller buttons captured for the entry at g_at (the poll thread).
void PadCaptured(unsigned buttons) {
    if (!g_pad_capturing) return;
    g_pad_capturing = false;
    if (g_hooks.set_pad_handler) g_hooks.set_pad_handler(nullptr);
    const auto e = Entries();
    const auto keys = hotkeys::Bindings();
    if (g_at >= e.size() || e[g_at].item != Item::kPad || static_cast<size_t>(e[g_at].index) >= keys.size()) return;
    const hotkeys::Binding& b = keys[e[g_at].index];
    // B40-4 (the user: "refuses to bind a controller button/direction if the main game has a binding for it").
    const unsigned game = g_hooks.game_pad_inputs ? g_hooks.game_pad_inputs() : 0;
    if (buttons & game) {
        const unsigned clash = buttons & game;
        Say(hotkeys::PadName(clash) + (clash & (clash - 1) ? " are" : " is") + " used by the game. " + b.label + " unchanged");
        return;
    }
    for (const hotkeys::Binding& o : keys) {
        if (o.id != b.id && o.pad == buttons) {
            Say(hotkeys::PadName(buttons) + " is already the " + o.label + " controller button. " + b.label + " unchanged");
            return;
        }
        // B40b: nor one holding another binding inside it (with Back for the mod menu, Back + X would open the menu too)
        if (o.id != b.id && o.pad && ((o.pad & buttons) == o.pad || (o.pad & buttons) == buttons)) {
            Say(hotkeys::PadName(buttons) + " overlaps the " + o.label + " controller button, " + hotkeys::PadName(o.pad) + ". " +
                b.label + " unchanged");
            return;
        }
    }
    hotkeys::SetPad(b.id, buttons);
    Save();
    Say(b.label + " controller button, " + hotkeys::PadName(buttons));
}

void Change(const Entry& e, int dir) {  // dir: -1 / +1 (Left / Right), 0 = Enter / Space
    switch (e.item) {
        case Item::kVolume: {
            if (!g_hooks.get_volume || !g_hooks.set_volume || dir == 0) break;
            int v = g_hooks.get_volume() + 10 * dir;
            v = v < 0 ? 0 : (v > 100 ? 100 : v);
            g_hooks.set_volume(v);
            Save();
            break;
        }
        case Item::kPan:
            if (g_hooks.set_pan && g_hooks.get_pan) g_hooks.set_pan(!g_hooks.get_pan());
            Save();
            break;
        case Item::kSafeEdges:
            if (g_hooks.set_safe_edges && g_hooks.get_safe_edges) g_hooks.set_safe_edges(!g_hooks.get_safe_edges());
            Save();
            break;
        case Item::kWaypoint:  // (not saved: W isn't either)
            if (g_hooks.set_waypoint && g_hooks.get_waypoint) g_hooks.set_waypoint(!g_hooks.get_waypoint());
            break;
        case Item::kAnnounce: {
            const auto k = static_cast<announce::Kind>(e.index);
            announce::Set(k, !announce::On(k));
            Save();
            break;
        }
        case Item::kLearn:
            if (dir < 0) return;
            g_learning = true;
            g_sound = 0;
            Say("Learn sounds. Up and down to choose, Enter to play, Escape to go back. " + g_hooks.sounds[0] + ", 1 of " +
                std::to_string(g_hooks.sounds.size()));
            return;
        case Item::kSpeech:
            if (dir < 0) return;
            g_speech = true;
            g_sp_at = 0;
            Say("Speech settings. Up and down to choose, left and right or Enter to change, Escape to go back. " +
                SpeechWithExplainer(0));
            return;
        case Item::kKey:
            if (dir != 0) return;  // (Left / Right do nothing here)
            g_capturing = true;
            Say("Press the new key for " + hotkeys::Bindings()[e.index].label + ". Escape cancels");
            return;
        case Item::kPad:  // B39: capture the buttons (the most held together, when let go)
            if (dir != 0) return;
            g_pad_capturing = true;
            if (g_hooks.set_pad_handler) g_hooks.set_pad_handler(&PadCaptured);
            Say("Press the new controller button for " + hotkeys::Bindings()[e.index].label +
                ", or hold several together, then let go. Escape cancels");
            return;
        case Item::kClose:
            if (dir == 0) Close();
            return;
        case Item::kCategory: {  // B17-2: open it
            if (dir < 0) return;
            if (e.index == kCatSpeech) {
                g_speech = true;
                g_sp_at = 0;
                Say("Speech. Up and down to choose, left and right or Enter to change, Escape to go back. " + SpeechWithExplainer(0));
                return;
            }
            g_cat = e.index;
            g_at = 0;
            const auto items = Entries();
            Say(std::string(kCategoryNames[g_cat]) + ". " +
                WithExplainer(Text(items[0]) + ", 1 of " + std::to_string(items.size()), items[0]));
            return;
        }
        case Item::kBack:
            if (dir == 0) BackToTop();
            return;
        case Item::kCheckpoint:  // B34: go there (the menu closes; the game reloads at it)
            if (dir != 0) return;
            {
                const std::string said = g_hooks.go_to_checkpoint ? g_hooks.go_to_checkpoint(e.index) : std::string("Not available");
                Close();
                Say(said);
            }
            return;
    }
    Say(Text(e));
}

void UpdateView() {
    View v;
    if (!g_open) {
    } else if (g_learning) {
        v.title = "Learn sounds";
        v.items = g_hooks.sounds;
        v.selected = static_cast<int>(g_sound);
    } else if (g_speech) {
        v.title = "Speech";
        for (size_t i = 0; i < kSpeechItems; ++i) v.items.push_back(SpeechText(i));
        v.selected = static_cast<int>(g_sp_at);
    } else {
        v.title = g_cat >= 0 && g_cat < kCatCount ? kCategoryNames[g_cat] : "Shank Access mod menu";
        for (const Entry& e : Entries()) v.items.push_back(Text(e));
        v.selected = static_cast<int>(g_at);
        if (g_capturing) v.title += ": press the new key";
        if (g_pad_capturing) v.title += ": press the new controller buttons";
    }
    AcquireSRWLockExclusive(&g_view_lock);
    g_view = v;
    ReleaseSRWLockExclusive(&g_view_lock);
}

}  // namespace

View CurrentView() {
    AcquireSRWLockShared(&g_view_lock);
    View v = g_view;
    ReleaseSRWLockShared(&g_view_lock);
    return v;
}

void Init(const Hooks& hooks) { g_hooks = hooks; }

bool IsOpen() { return g_open; }

void Toggle() {
    if (g_open) {
        Close();
        return;
    }
    g_open = true;
    g_at = 0;
    g_capturing = false;
    if (g_hooks.block_input) g_hooks.block_input(true);
    if (g_hooks.set_key_handler) g_hooks.set_key_handler(&OnKey);
    UpdateView();
    g_paused = g_hooks.pause_game && g_hooks.pause_game();  // (before speaking: the window's focus is announced first)
    const auto e = Entries();
    Say("Shank Access mod menu. Up and down to move, left and right or Enter to change, Escape to close. " + Text(e[0]) +
        ", 1 of " + std::to_string(e.size()));
}

void OnKey(int vk) {
    if (!g_open) return;
    if (g_capturing) {
        Capture(vk);
        return;
    }
    if (g_pad_capturing) {  // B39: only Escape (cancel) here; the buttons come from the pad
        if (vk == VK_ESCAPE) {
            g_pad_capturing = false;
            if (g_hooks.set_pad_handler) g_hooks.set_pad_handler(nullptr);
            SayCurrent();
        }
        return;
    }
    if (g_learning) {
        LearnKey(vk);
        return;
    }
    if (g_speech) {
        int settings_key = 0;
        for (const hotkeys::Binding& b : hotkeys::Bindings()) {
            if (b.id == "settings") settings_key = b.vk;
        }
        if (vk == settings_key) {
            Close();
            return;
        }
        SpeechKey(vk);
        return;
    }
    const auto e = Entries();
    int settings_vk = 0;
    for (const hotkeys::Binding& b : hotkeys::Bindings()) {
        if (b.id == "settings") settings_vk = b.vk;
    }
    switch (vk) {
        case VK_ESCAPE:
        case VK_BACK:
            if (g_cat >= 0) BackToTop();  // B17-2: out of a category
            else if (vk == VK_ESCAPE) Close();
            return;
        case VK_UP:
            g_at = g_at == 0 ? e.size() - 1 : g_at - 1;
            SayCurrent();
            return;
        case VK_DOWN:
            g_at = (g_at + 1) % e.size();
            SayCurrent();
            return;
        case VK_HOME:
            g_at = 0;
            SayCurrent();
            return;
        case VK_END:
            g_at = e.size() - 1;
            SayCurrent();
            return;
        case VK_LEFT:
        case VK_RIGHT:
            Change(e[g_at], vk == VK_LEFT ? -1 : 1);
            return;
        case VK_RETURN:
        case VK_SPACE:
            Change(e[g_at], 0);
            return;
        case VK_DELETE:  // B39: clears a controller binding
            if (e[g_at].item == Item::kPad) {
                const auto keys = hotkeys::Bindings();
                if (static_cast<size_t>(e[g_at].index) < keys.size()) {
                    hotkeys::SetPad(keys[e[g_at].index].id, 0);
                    Save();
                    Say(Text(e[g_at]));
                }
            }
            return;
        default:
            if (vk == settings_vk) Close();
            return;
    }
}

std::string ItemText(size_t index) {
    const auto e = Entries();
    return index < e.size() ? Text(e[index]) : std::string();
}

size_t ItemCount() { return Entries().size(); }

}  // namespace mod_menu
