# Shank Access: the Shank 2 port handoff

Hello, and thanks for taking on the Shank 2 port.

This folder is the full development copy of **Shank Access**, the screen reader and audio accessibility mod for Shank
(Klei, 2010). Karl Belanger, who is blind, built it with Claude Code between 2026-09-24 and 2026-10-03. It's out as a
public beta: https://github.com/KarlBelanger/shank_access.

You get the source, its complete git history, every design note and test record, and a plan for porting the mod to
**Shank 2**. The aim: unzip, open the folder in Claude Code, paste the start prompt, and Claude picks up the plan.

## Quick start

1. Unzip anywhere. A short path without spaces is best, e.g. `C:\dev\shank-access`.
2. Install the tools listed under "What you need" below.
3. Open the folder in Claude Code (the desktop app's Code tab, or `claude` in a terminal in that folder).
4. Paste the prompt from `START-PROMPT.txt`, after filling in the short "About me" part.
5. On the first start, Claude Code asks whether to trust the project's settings. Say yes: its start-up hook runs
   `tools/session_context.py`, which gives Claude the briefing (status, the plan's in-flight work, recent history)
   at the start of every session and after every context compaction.

## What's in the zip

- The repository, with its full git history (`.git`). The link to Karl's private GitHub repo has been removed, so
  nothing you do can push there by accident. Add your own remote if you want one.
- `README-FIRST.md` (this file) and `START-PROMPT.txt`, also kept in the repo as `handoff/`.
- `claude-memory/`: Claude's per-machine memory notes from Karl's sessions (see "Claude's memory" below).

Not included:
- `build/`: everything generated (native builds, level data, logs). It all regenerates from the source plus a game
  install. One exception is Karl's collected Shank 1 play logs, the movement corpus. They're Shank 1-specific, and
  Karl can send them if they're ever needed.
- Any Klei file. The project never ships or commits game assets (scripts, sounds, textures, levels): only our own
  code and small patches applied to the player's own install.

## What you need

- Windows 10 or 11.
- **Shank 2** on Steam. The plan expects the Steam build whose `bin\shank2.exe` has SHA-256
  `3cd7aeb0d9f135dc82c4bba491463ecb85fec9aa33b9189ab2cee5160dd045d3`.
- **Shank** (the first game) on Steam: optional, but recommended. The Shank 1 mod is the working reference: you can
  play it to hear what the port is aiming for, and the shared code's host tests use it.
- **Visual Studio 2022 Build Tools**, with "Desktop development with C++" (the MSVC x86/x64 compilers and a Windows
  SDK). The game is 32-bit, so everything native builds with `-A Win32`.
- **CMake** (installed at `C:\Program Files\CMake`; the commands in CLAUDE.md use that path).
- **Python 3.12 or newer** (Karl used 3.14), then in the folder:
  `py -m venv .venv` and `.venv\Scripts\python -m pip install -r requirements.txt`.
- **Git** (Git for Windows: Claude's shell commands use its Git Bash).
- **Claude Code**.
- A screen reader is optional. The mod speaks through NVDA, JAWS and others via Tolk, or through SAPI voices.

Claude can do most of this setup for you, building and running the tests as its first step (plan step S2B0).

## How the project is run (Claude knows this, but you should too)

- **CLAUDE.md** holds the project rules, layout and commands. Claude reads it every session.
- **docs/SHANK2-PLAN.md is your plan**: its batches (S2B0, S2B1, ...), Status, In flight, decisions and work log.
  docs/SHANK2-ASSESSMENT.md explains why the plan looks the way it does.
- **docs/PLAN.md, RE-NOTES.md, DESIGN.md and TESTING.md** are the Shank 1 record: how every feature was designed,
  reverse-engineered and tested. They're well worth Claude's (and your) reading time.
- **Memory discipline.** Claude writes decisions, findings and promises into the docs as they happen, because a long
  conversation gets compacted and loses detail. Type `/sync-memory` to have it compare the conversation against the
  docs; it also does this on its own at the end of tasks.
- **Batches and test points.** Claude builds and host-tests several steps, then asks you to test them together in
  the game, with a written test plan. You play, then tell it when you're done. Don't relaunch the game before it has
  collected the logs: each launch overwrites them.
- **F2 feedback marks.** While playing, press F2, type a comment and close the window. The comment and Shank's exact
  situation go into the logs, so Claude can find the moment afterwards.
- **Deploying.** Claude installs the mod into the game folder only through `tools/deploy.py`, and asks first. The
  game's own files stay untouched: our files go in beside them, as overrides under `data-pc`. Steam's "verify
  files" restores the game if anything ever goes wrong.

## Test mode and the movie skip (the Shank 1 developer build)

The development build has a **test mode** for testing. Release builds leave it out completely.

- **F3** turns test mode on or off. It's spoken ("Test mode on" / "Test mode off") and saved in
  `bin\shank_access_user.ini`, so it stays across launches. When test mode is on, the mod's start-up announcement ends
  with "Test mode on."
- **The movie skip:** with test mode on at launch, the mod patches the game in memory to skip both startup movies:
  the long logo sequence, which can't be skipped normally, and the intro movie. You go straight to the title screen.
  The patch is applied once at start-up, so turning F3 on or off takes effect at the next launch. The game's files
  are never changed.
- While test mode is on:
  - **F7 > Go to checkpoint** lists the current level's checkpoints. Pick one and the game reloads you there.
    This is the main testing tool: test plans tell you "go to checkpoint X, then do these moves".
  - **F5** god mode and **F6** super speed (the game's own debug flags).
  - **F4** turns the mod's own cue sounds off and on.
  - **;** (semicolon) switches where enemy cues are panned: around Shank, or like the game's camera.
- With test mode off, those keys do nothing and the game behaves as a player's would.

Shank 2 has none of this yet. Plan batch S2B2 rebuilds it early (Shank 2's own startup movies, Go to checkpoint, and
god mode if Shank 2 has the flags), because it makes every later test faster.

The mod's other keys are listed in CLAUDE.md ("hotkeys") and docs/DESIGN.md, and spoken by the F7 menu's
"Learn keys". All of them except F9 and the test keys (F4, F5, F6, ;) can be rebound in F7.

## Trying the Shank 1 mod (optional, recommended)

- **The easy way:** the public setup from https://github.com/KarlBelanger/shank_access/releases is the player
  version, without test mode.
- **The developer build, with test mode:** ask Claude to "build the Shank 1 dev build and deploy it to my Shank
  install". It runs the CMake build, the level tools and `tools/deploy.py`, and asks before deploying.
  `tools/deploy.py uninstall` removes it again.
- Tools that read a game install assume the default Steam folder
  (`C:\Program Files (x86)\Steam\steamapps\common\Shank`). If yours is elsewhere, set the `SHANK_GAME_DIR`
  environment variable, or tell Claude. A few scripts hard-code the default path: Claude can fix them as it meets
  them.

## Claude's memory

- The project's real memory is the docs above. On Karl's machine, Claude's own per-machine memory held only one note
  saying exactly that ("Project docs are the source of truth"). The note is in `claude-memory/` for completeness.
- You don't need to install it. If you want it, copy the two files into your Claude Code memory folder for this
  project, under `%USERPROFILE%\.claude\projects\<the project's folder key>\memory\`. Claude Code creates that folder
  the first time it runs in the project.

## Things in the docs that are Karl's

- "The user" in CLAUDE.md and the docs means Karl. His working preferences (CLAUDE.md "Working with the user": test
  plan format, level naming, how deaths are judged, no internal labels in replies) are good defaults. Tell Claude
  yours at the first session, and it will record them under your own heading.
- The paths, the "Deployed to the game right now" line in docs/PLAN.md, `saves/` (backups of Karl's own Shank 1
  save) and the Steam user id in CLAUDE.md all describe Karl's machine.
- The public repo, its releases and the AudioGames.net forum thread are Karl's. Agree with Karl before publishing
  anything for Shank 2.
- The git history's commits carry Karl's GitHub name and email as author.

## The start prompt

It's in `START-PROMPT.txt`, ready to paste.
