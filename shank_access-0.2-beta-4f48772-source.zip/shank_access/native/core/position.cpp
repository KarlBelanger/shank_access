#include "position.h"

#include <windows.h>

#include <algorithm>
#include <cmath>
#include <cstring>

#include "log.h"

namespace position {
namespace {

struct Candidate {
    uintptr_t addr;
    int follows;  // pings followed after Shank had moved away from the scan spot
};

SRWLOCK g_lock = SRWLOCK_INIT;
bool g_have_ping = false;
float g_px = 0, g_py = 0;
bool g_facing_right = true;
unsigned g_ping_ms = 0;
bool g_scan_wanted = false;
float g_scan_x = 0, g_scan_y = 0;       // the spot being scanned / last scanned
unsigned g_generation = 0;              // bumped by OnLevel: a scan from before is stale
std::vector<Candidate> g_candidates;
uintptr_t g_tracked = 0;
float g_last_x = 0;                     // last live read, for the velocity
float g_last_y = 0;
float g_vy = 0;
unsigned g_last_ms = 0;
bool g_have_last = false;
float g_vx = 0;
// B28 (the B27play log: a scratch-like address held Shank's position only while his own update ran, i.e. at every
// ping, and other things' positions in between, so the ping-time check never caught it): checks between pings.
float g_prev_px = 0, g_prev_py = 0;     // the ping before the last one, for the ping's own speed
unsigned g_prev_ping_ms = 0;
std::vector<unsigned> g_strikes;        // times of implausible reads of the tracked address
// B28b: addresses dropped for implausible reads, not picked again for kBanMs (B28 banned them for the whole level,
// and a grab's snap once banned his real object: the rest of the level tracked junk).
struct Ban {
    uintptr_t addr;
    unsigned since_ms;
};
std::vector<Ban> g_banned;
unsigned g_now_ms = 0;                  // the latest time seen (pings, reads, sounds), for the bans
bool g_scanning = false;                // a background scan is running (B28-3)
std::vector<unsigned> g_sound_mismatches;  // times his own sounds disagreed with the tracked read
bool g_scan_in_background = true;       // the real scan runs on its own thread; tests' fake scans run inline
float g_raw_x = 0, g_raw_y = 0;         // B28b: the previous read of the tracked address, used or not
unsigned g_raw_ms = 0;
bool g_have_raw = false;
unsigned g_off_ping_struck_ms = 0;      // the ping an "off the ping" strike was last counted for

bool Banned(uintptr_t a) {
    for (const Ban& b : g_banned) {
        if (b.addr == a && g_now_ms - b.since_ms < kBanMs) return true;
    }
    return false;
}

// Where Shank can be now_ms after the last ping: within this of it.
float Reach(unsigned now_ms) {
    const unsigned age = now_ms - g_ping_ms;
    return kCheckSlackPx + kMaxSpeedPxPerS * static_cast<float>(age < 60000 ? age : 60000) / 1000.f;
}

void DropTracked(const char* why, float x, float y, unsigned now_ms) {
    alog::Write("position: tracked address %p dropped: %s (read (%.0f, %.0f), last ping (%.0f, %.0f))",
                reinterpret_cast<void*>(g_tracked), why, x, y, g_px, g_py);
    g_banned.erase(std::remove_if(g_banned.begin(), g_banned.end(),
                                  [now_ms](const Ban& b) { return now_ms - b.since_ms >= kBanMs; }),
                   g_banned.end());
    g_banned.push_back(Ban{g_tracked, now_ms});
    g_have_raw = false;
    const uintptr_t gone = g_tracked;
    g_candidates.erase(std::remove_if(g_candidates.begin(), g_candidates.end(),
                                      [gone](const Candidate& c) { return c.addr == gone; }),
                       g_candidates.end());
    g_tracked = 0;
    g_have_last = false;
    g_strikes.clear();
    g_sound_mismatches.clear();
    g_vx = g_vy = 0;
}

bool DefaultRead(uintptr_t addr, void* out, size_t n) {
    __try {
        std::memcpy(out, reinterpret_cast<const void*>(addr), n);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Scans one committed region for the pair; false if it faulted part way (the region went away).
bool ScanRegion(const unsigned char* base, size_t size, uint32_t bx, uint32_t by, std::vector<uintptr_t>* out) {
    __try {
        const uint32_t* p = reinterpret_cast<const uint32_t*>(base);
        const size_t n = size / 4;
        for (size_t i = 0; i + 1 < n; ++i) {
            if (p[i] == bx && p[i + 1] == by) {
                out->push_back(reinterpret_cast<uintptr_t>(p + i));
                if (out->size() >= kMaxCandidates) return true;
            }
        }
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

std::vector<uintptr_t> DefaultScan(float x, float y) {
    uint32_t bx, by;
    std::memcpy(&bx, &x, 4);
    std::memcpy(&by, &y, 4);
    std::vector<uintptr_t> out;
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    const unsigned char* p = static_cast<const unsigned char*>(si.lpMinimumApplicationAddress);
    const unsigned char* end = static_cast<const unsigned char*>(si.lpMaximumApplicationAddress);
    MEMORY_BASIC_INFORMATION mbi;
    // B28: thread stacks are left out: they hold copies of our own estimate of his position (locals of the cue
    // thread and others) that match him at ping time and hold anything in between; the B27play log tracked one,
    // 0x001AF6E0, for 16 minutes. A stack is an allocation with a guard page; his object never lives there.
    std::vector<const void*> stacks;
    for (const unsigned char* q = p; q < end && VirtualQuery(q, &mbi, sizeof mbi) == sizeof mbi;) {
        const unsigned char* next = static_cast<const unsigned char*>(mbi.BaseAddress) + mbi.RegionSize;
        if (mbi.State == MEM_COMMIT && (mbi.Protect & PAGE_GUARD)) stacks.push_back(mbi.AllocationBase);
        if (next <= q) break;
        q = next;
    }
    size_t scanned = 0, skipped = 0;
    while (p < end && VirtualQuery(p, &mbi, sizeof mbi) == sizeof mbi && out.size() < kMaxCandidates) {
        const unsigned char* next = static_cast<const unsigned char*>(mbi.BaseAddress) + mbi.RegionSize;
        const DWORD prot = mbi.Protect & 0xff;
        bool stack = false;
        for (const void* s : stacks) stack = stack || s == mbi.AllocationBase;
        if (stack && mbi.State == MEM_COMMIT) skipped += mbi.RegionSize;
        // Not guard pages, and not uncached / write-combined ones (graphics memory: slow to read).
        if (!stack && mbi.State == MEM_COMMIT && mbi.Type == MEM_PRIVATE &&
            !(mbi.Protect & (PAGE_GUARD | PAGE_NOCACHE | PAGE_WRITECOMBINE)) &&
            (prot == PAGE_READWRITE || prot == PAGE_EXECUTE_READWRITE)) {
            ScanRegion(static_cast<const unsigned char*>(mbi.BaseAddress), mbi.RegionSize, bx, by, &out);
            scanned += mbi.RegionSize;
        }
        if (next <= p) break;
        p = next;
    }
    alog::Write("position: scanned %u MB for (%.0f, %.0f): %u candidates (%u stacks, %u KB, left out)",
                static_cast<unsigned>(scanned >> 20), x, y, static_cast<unsigned>(out.size()),
                static_cast<unsigned>(stacks.size()), static_cast<unsigned>(skipped >> 10));
    return out;
}

ReadFn g_read = DefaultRead;
ScanFn g_scan = DefaultScan;

bool ReadPair(uintptr_t addr, float* x, float* y) {
    float v[2];
    if (!g_read(addr, v, sizeof v)) return false;
    if (!std::isfinite(v[0]) || !std::isfinite(v[1])) return false;
    *x = v[0];
    *y = v[1];
    return true;
}

}  // namespace

void SetMemory(ReadFn read, ScanFn scan) {
    AcquireSRWLockExclusive(&g_lock);
    g_read = read ? read : DefaultRead;
    g_scan = scan ? scan : DefaultScan;
    g_scan_in_background = scan == nullptr;
    ReleaseSRWLockExclusive(&g_lock);
}

void OnPing(float x, float y, bool facing_right, unsigned now_ms) {
    AcquireSRWLockExclusive(&g_lock);
    g_now_ms = now_ms;
    const bool still = g_have_ping && g_px == x && g_py == y;
    // B28: the ping's own speed (from the last ping), for the allowance below.
    const bool had_ping = g_have_ping;
    const float ping_step = had_ping ? std::hypot(x - g_px, y - g_py) : 0.f;
    const unsigned ping_dt = had_ping ? now_ms - g_ping_ms : 0;
    const float ping_speed = ping_dt >= 50 ? ping_step * 1000.f / static_cast<float>(ping_dt) : 0.f;
    g_prev_px = g_px;
    g_prev_py = g_py;
    g_prev_ping_ms = g_ping_ms;
    g_have_ping = true;
    g_px = x;
    g_py = y;
    g_facing_right = facing_right;
    g_ping_ms = now_ms;
    const bool moved = std::hypot(x - g_scan_x, y - g_scan_y) >= kMovedPx;
    // The ping lags the live read by about a frame: allow for his speed (B5c log: the tracked address was
    // "lost" falling at ~2300 px/s, 37 px off the ping by then and more a frame later). B28: the speed is capped at
    // the fastest he moves, so a read that jumps about can't widen the allowance without limit.
    const float speed = std::min(std::max(ping_speed, std::hypot(g_vx, g_vy)), kMaxSpeedPxPerS);
    const float follow = kFollowPx + kFollowSeconds * speed;
    // Keep the candidates that are where Shank is (a frame's lag allowed); count the ones that moved with him.
    size_t kept = 0;
    for (Candidate& c : g_candidates) {
        float cx, cy;
        if (!ReadPair(c.addr, &cx, &cy) || std::fabs(cx - x) > follow || std::fabs(cy - y) > follow) continue;
        if (moved) ++c.follows;
        g_candidates[kept++] = c;
    }
    const size_t before = g_candidates.size();
    g_candidates.resize(kept);
    if (g_tracked) {
        bool still_there = false;
        for (const Candidate& c : g_candidates) still_there = still_there || c.addr == g_tracked;
        if (!still_there) {
            alog::Write("position: tracked address %p lost at ping (%.0f, %.0f)", reinterpret_cast<void*>(g_tracked), x, y);
            g_tracked = 0;
            g_have_last = false;
            g_have_raw = false;
        }
    }
    if (!g_tracked) {
        for (const Candidate& c : g_candidates) {
            if (c.follows >= kConfirmMoves && !Banned(c.addr)) {
                g_tracked = c.addr;
                g_strikes.clear();
                g_sound_mismatches.clear();
                g_have_raw = false;
                            alog::Write("position: tracking %p (%u candidates left of %u)", reinterpret_cast<void*>(c.addr),
                            static_cast<unsigned>(g_candidates.size()), static_cast<unsigned>(before));
                break;
            }
        }
    }
    // Nothing to follow: scan when he stands still (the pair is stable while the scan runs).
    if (!g_tracked && g_candidates.empty() && !g_scan_wanted && !g_scanning && still) {
        g_scan_wanted = true;
        g_scan_x = x;
        g_scan_y = y;
    }
    ReleaseSRWLockExclusive(&g_lock);
}

void OnLevel() {
    AcquireSRWLockExclusive(&g_lock);
    ++g_generation;
    g_candidates.clear();
    g_tracked = 0;
    g_scan_wanted = false;
    g_have_ping = false;
    g_have_last = false;
    g_strikes.clear();
    g_sound_mismatches.clear();
    g_banned.clear();  // (a new level's objects can reuse any address)
    ReleaseSRWLockExclusive(&g_lock);
}

namespace {

// Stores a finished scan's results (unless a level load or a new request made it stale).
void StoreScan(const std::vector<uintptr_t>& found, unsigned gen) {
    AcquireSRWLockExclusive(&g_lock);
    g_scanning = false;
    if (gen == g_generation && g_scan_wanted) {
        g_candidates.clear();
        for (uintptr_t a : found) {
            if (!Banned(a)) g_candidates.push_back(Candidate{a, 0});
        }
        g_scan_wanted = false;
    }
    ReleaseSRWLockExclusive(&g_lock);
}

struct ScanJob {  // (x and y apart: an (x, y) pair here would be a candidate itself)
    ScanFn scan;
    float x;
    unsigned gen;
    float y;
};

DWORD WINAPI ScanThread(LPVOID param) {
    ScanJob* job = static_cast<ScanJob*>(param);
    StoreScan(job->scan(job->x, job->y), job->gen);
    delete job;
    return 0;
}

}  // namespace

void Work(unsigned now_ms) {
    AcquireSRWLockExclusive(&g_lock);
    // B28: between pings, candidates that aren't where he can be are dropped before any is trusted (an address
    // that only matches at ping time never gets to follow two pings).
    if (!g_tracked && g_have_ping && !g_candidates.empty()) {
        const float reach = Reach(now_ms);
        size_t kept = 0;
        for (const Candidate& c : g_candidates) {
            float cx, cy;
            if (ReadPair(c.addr, &cx, &cy) && std::fabs(cx - g_px) <= reach && std::fabs(cy - g_py) <= reach) g_candidates[kept++] = c;
        }
        g_candidates.resize(kept);
    }
    const bool wanted = g_scan_wanted && !g_scanning;
    const float x = g_scan_x, y = g_scan_y;
    const unsigned gen = g_generation;
    const ScanFn scan = g_scan;
    const bool background = g_scan_in_background;
    if (wanted) g_scanning = true;
    ReleaseSRWLockExclusive(&g_lock);
    if (!wanted) return;
    // B28-3: the real scan (~500 MB, ~140 ms) runs on its own thread, so the cue thread never waits on it (each scan
    // froze every cue for that long). Tests scan inline.
    if (background) {
        HANDLE t = CreateThread(nullptr, 0, ScanThread, new ScanJob{scan, x, gen, y}, 0, nullptr);
        if (t) {
            CloseHandle(t);
            return;
        }
    }
    StoreScan(scan(x, y), gen);
}

bool IsShankOnlySound(const char* name) {
    static const char* const kNames[] = {"Shank/Character/blockEnter", "Shank/Character/skidStop", "Shank/Character/wallClimb",
                                         "Shank/Character/shimmy", "Shank/Character/ledgeClimb"};
    if (!name) return false;
    for (const char* n : kNames) {
        if (std::strcmp(name, n) == 0) return true;
    }
    return false;
}

void OnShankSound(float x, float y, unsigned now_ms) {
    AcquireSRWLockExclusive(&g_lock);
    g_now_ms = now_ms;
    auto close_to = [&](uintptr_t a) {
        float cx, cy;
        return ReadPair(a, &cx, &cy) && std::fabs(cx - x) <= kSoundCheckPx && std::fabs(cy - y) <= kSoundCheckPx;
    };
    if (g_tracked) {
        float tx = 0, ty = 0;
        const bool read = ReadPair(g_tracked, &tx, &ty) && !(tx == 0.f && ty == 0.f);  // (B28b: (0, 0) = no position)
        if (read && !close_to(g_tracked)) {
            while (!g_sound_mismatches.empty() && now_ms - g_sound_mismatches.front() > kSoundWindowMs)
                g_sound_mismatches.erase(g_sound_mismatches.begin());
            g_sound_mismatches.push_back(now_ms);
            alog::Write("position: his own sound at (%.0f, %.0f), the tracked read (%.0f, %.0f)", x, y, tx, ty);
            if (g_sound_mismatches.size() >= kSoundMismatchesToDrop) DropTracked("his own sounds are elsewhere", tx, ty, now_ms);
        }
    } else if (!g_candidates.empty()) {
        g_candidates.erase(std::remove_if(g_candidates.begin(), g_candidates.end(),
                                          [&](const Candidate& c) { return !close_to(c.addr); }),
                           g_candidates.end());
    }
    ReleaseSRWLockExclusive(&g_lock);
}

bool Scanning() {
    AcquireSRWLockShared(&g_lock);
    const bool s = g_scanning;
    ReleaseSRWLockShared(&g_lock);
    return s;
}

Pos Current(unsigned now_ms) {
    Pos p;
    AcquireSRWLockExclusive(&g_lock);
    g_now_ms = now_ms;
    p.known = g_have_ping && now_ms - g_ping_ms <= kPingStaleMs;
    p.x = g_px;
    p.y = g_py;
    p.facing_right = g_facing_right;
    p.ping_facing_right = g_facing_right;
    const uintptr_t addr = g_tracked;
    float x, y;
    // B28b: (0, 0) is what his object holds during some finishers and cinematics (the B28 log, Cesar): not a
    // position, but not a sign of a wrong address either.
    if (p.known && addr && ReadPair(addr, &x, &y) && !(x == 0.f && y == 0.f)) {
        // B28: a read he can't be at (farther from the last ping than he can move since) isn't used; B28b: that counts
        // as a strike at most once per ping (after a grab snaps him, reads are right and the ping is behind until the
        // next one). A jump between two reads in a row faster than he moves is a strike each time: a real snap (a
        // grab, a throw) makes one, an address that flips between him and something else makes many.
        const float reach = Reach(now_ms);
        const bool off_ping = std::fabs(x - g_px) > reach || std::fabs(y - g_py) > reach;
        const unsigned raw_dt = now_ms - g_raw_ms;
        const bool jumped = g_have_raw && std::hypot(x - g_raw_x, y - g_raw_y) >
                                              kCheckSlackPx + kMaxSpeedPxPerS * static_cast<float>(raw_dt) / 1000.f;
        g_raw_x = x;
        g_raw_y = y;
        g_raw_ms = now_ms;
        g_have_raw = true;
        const bool strike = jumped || (off_ping && g_off_ping_struck_ms != g_ping_ms);
        if (off_ping) g_off_ping_struck_ms = g_ping_ms;
        if (strike) {
            while (!g_strikes.empty() && now_ms - g_strikes.front() > kStrikeWindowMs) g_strikes.erase(g_strikes.begin());
            g_strikes.push_back(now_ms);
            if (g_strikes.size() >= kStrikesToDrop) DropTracked(jumped ? "jumps about" : "too far from the last ping", x, y, now_ms);
        }
        if (off_ping || jumped) {
        } else {
            p.live = true;
            p.x = x;
            p.y = y;
            if (g_have_last && now_ms - g_last_ms >= 10) {
                const float v = (x - g_last_x) * 1000.f / static_cast<float>(now_ms - g_last_ms);
                g_vx += 0.3f * (v - g_vx);
                const float w = (y - g_last_y) * 1000.f / static_cast<float>(now_ms - g_last_ms);
                g_vy += 0.3f * (w - g_vy);
            }
            if (!g_have_last || now_ms - g_last_ms >= 10) {
                g_last_x = x;
                g_last_y = y;
                g_last_ms = now_ms;
                g_have_last = true;
            }
            // Facing from the movement when he's clearly moving (the ping's facing is up to 0.5 s old).
            if (std::fabs(g_vx) > 150.f) p.facing_right = g_vx > 0;
        }
    }
    p.vx = g_vx;
    p.vy = g_vy;
    ReleaseSRWLockExclusive(&g_lock);
    return p;
}

void Reset() {
    OnLevel();
    AcquireSRWLockExclusive(&g_lock);
    g_px = g_py = 0;
    g_scan_x = g_scan_y = 0;
    g_facing_right = true;
    g_vx = 0;
    g_vy = 0;
    ReleaseSRWLockExclusive(&g_lock);
}

size_t CandidateCount() {
    AcquireSRWLockShared(&g_lock);
    const size_t n = g_candidates.size();
    ReleaseSRWLockShared(&g_lock);
    return n;
}

uintptr_t TrackedAddress() {
    AcquireSRWLockShared(&g_lock);
    const uintptr_t a = g_tracked;
    ReleaseSRWLockShared(&g_lock);
    return a;
}

}  // namespace position
