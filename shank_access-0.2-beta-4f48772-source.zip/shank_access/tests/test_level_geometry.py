"""Checks of the .slev decoder and the geometry analysis against the real install (read only; skipped
without it). Known facts from level 1-a (B3c log and RE-NOTES "Levels").

Run: .venv/Scripts/python -m unittest discover -s tests -v
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools", "levels"))
import geometry  # noqa: E402
import slev  # noqa: E402

LEVEL = "campaign_1a_wrestlingring"
HAVE_GAME = os.path.isdir(os.path.join(geometry.LEVELS_DIR, LEVEL))


@unittest.skipUnless(HAVE_GAME, "Shank install not found")
class LevelGeometryTest(unittest.TestCase):
    def test_every_level_decodes_to_the_end(self):
        for level in os.listdir(geometry.LEVELS_DIR):
            path = os.path.join(geometry.LEVELS_DIR, level, level + ".slev")
            if os.path.exists(path):
                d = slev.decode(open(path, "rb").read())  # raises if anything is left over
                self.assertEqual(d["moving_platforms"], 0, level)

    def test_tags_are_sdbm_names(self):
        self.assertEqual(slev.sdbm("noclimb"), 0xBD1AEAD4)
        self.assertEqual(slev.sdbm("skinny"), 0xA59FC808)
        self.assertEqual(slev.sdbm("slide"), 0x582732F1)

    def test_1a_known_spots(self):
        g = geometry.analyse(LEVEL)
        by_start = {tuple(s["points"][0]): s for s in g["surfaces"]}
        street = by_start[(512.0, 192.0)]
        self.assertEqual(street["points"][-1], [2816.0, 192.0])
        self.assertEqual(street["right"]["type"], "wall")  # the 2-tile step Shank climbed at x 2816
        self.assertEqual(street["right"]["height"], 128.0)
        step = by_start[(2816.0, 320.0)]
        self.assertEqual(step["right"]["type"], "drop")  # and dropped off at x 3200
        self.assertEqual(step["right"]["depth"], 128.0)
        self.assertFalse(step["right"]["deadly"])
        bar = by_start[(3200.0, 192.0)]  # one floor: no edge at x 5704 (B3c's false edge)
        self.assertEqual(bar["points"][-1], [7296.0, 192.0])
        self.assertEqual(bar["right"]["type"], "wall")
        # The bridge gap: a deadly end, with swing points above the pit zone.
        ends = [(s["points"][-1], s["right"]) for s in g["surfaces"] if s["right"].get("deadly")]
        self.assertTrue(any(18000 < p[0] < 20000 for p, _ in ends))
        swings = [f["pos"] for f in g["features"] if f["type"] == "swing_point"]
        self.assertTrue(any(18019 <= x <= 19923 for x, _ in swings))
        runs = [f for f in g["features"] if f["type"] == "wallrun_zone"]
        self.assertEqual(len(runs), 1)
        self.assertTrue(26049 <= runs[0]["min"][0] <= 28557)  # over the wall-run pit


if __name__ == "__main__":
    unittest.main()
