// Host-side test of the position tracker (never deployed) against fake memory: Shank's live position,
// a copy that lags a frame, and a stale copy (e.g. the spawn point) that never moves. Also runs the
// real memory scan over this test process once. Exit 0 = pass.
#include <windows.h>

#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

#include "../core/log.h"
#include "../core/position.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

// Fake memory: pairs of floats at "addresses" 0x1000 + 8 * index.
float g_mem[64][2];
bool g_valid[64];
constexpr uintptr_t kBase = 0x1000;
uintptr_t Addr(int i) { return kBase + 8 * i; }

void Place(int i, float x, float y) {
    g_mem[i][0] = x;
    g_mem[i][1] = y;
    g_valid[i] = true;
}

}  // namespace

int main() {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_position_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    int scans = 0;
    position::SetMemory(
        [](uintptr_t addr, void* out, size_t n) {
            const size_t i = (addr - kBase) / 8;
            if (addr < kBase || i >= 64 || !g_valid[i] || n != 8) return false;
            std::memcpy(out, g_mem[i], 8);
            return true;
        },
        [&scans](float x, float y) {
            ++scans;
            std::vector<uintptr_t> out;
            for (int i = 0; i < 64; ++i)
                if (g_valid[i] && g_mem[i][0] == x && g_mem[i][1] == y) out.push_back(Addr(i));
            return out;
        });
    Place(0, 712, 224);   // Shank
    Place(10, 712, 224);  // a stale copy (spawn point)
    Place(20, 712, 224);  // a copy one frame behind
    Place(30, 5, 5);      // unrelated

    Check(!position::Current(0).known, "nothing before a ping");
    position::OnPing(712, 224, true, 1000);
    position::Work(1000);
    Check(scans == 0, "one ping: no scan yet (he might be moving)");
    position::OnPing(712, 224, true, 1500);
    position::Work(1500);
    Check(scans == 1 && position::CandidateCount() == 3, "standing still: scanned, 3 candidates");
    position::Pos p = position::Current(1600);
    Check(p.known && !p.live && p.x == 712, "not tracking yet: the ping's position");

    Place(0, 812, 224);
    Place(20, 800, 224);
    position::OnPing(812, 224, true, 2000);
    Check(position::CandidateCount() == 2 && position::TrackedAddress() == 0, "moved: the stale copy is gone, not trusted yet");
    Place(0, 1012, 224);
    Place(20, 1000, 224);
    position::OnPing(1012, 224, true, 2500);
    Check(position::TrackedAddress() == Addr(0), "followed twice: tracking Shank's address");

    Place(0, 1100, 224);
    p = position::Current(2600);
    Check(p.live && p.x == 1100, "live read between pings");
    Place(0, 1180, 224);
    p = position::Current(2700);
    Place(0, 1260, 224);
    p = position::Current(2800);
    Check(p.vx > 200 && p.facing_right, "velocity from live reads; facing from movement");
    Place(0, 1200, 224);
    position::Current(2900);
    Place(0, 1100, 224);
    position::Current(3000);
    Place(0, 1000, 224);
    position::Current(3100);
    Place(0, 900, 224);
    p = position::Current(3200);
    Check(p.vx < -150 && !p.facing_right, "running left: facing left before the ping says so");

    // B5c log: falling fast, the ping lags the live position by more than kFollowPx: still tracked.
    {
        const uintptr_t before = position::TrackedAddress();
        float fy = 224;
        for (unsigned t = 3210; t <= 3400; t += 15) {  // falling at ~2000 px/s (y down)
            fy -= 30;
            Place(0, 900, fy);
            Place(20, 905, fy + 5);  // the lagging copy follows too (it's used below)
            position::Current(t);
        }
        position::OnPing(900, fy + 110, false, 3400);  // the ping from a frame or two earlier
        Check(position::TrackedAddress() == before, "falling fast: a ping 110 px behind doesn't lose him");
        Place(0, 900, 224);
        for (unsigned t = 3401; t < 3490; t += 15) position::Current(t);  // (settle the velocity again)
    }
    // The object goes away: the next ping drops it and the lagging copy takes over.
    g_valid[0] = false;
    Place(20, 905, 224);
    position::OnPing(900, 224, false, 3500);
    Check(position::TrackedAddress() == Addr(20), "tracked address lost: the other follower takes over");
    // A level load forgets everything; the next still pings scan again.
    position::OnLevel();
    Check(position::CandidateCount() == 0 && position::TrackedAddress() == 0 && !position::Current(3600).known, "level load");
    Place(0, 50, 60);
    g_valid[0] = true;
    position::OnPing(50, 60, true, 4000);
    position::OnPing(50, 60, true, 4500);
    position::Work(4500);
    Check(scans == 2 && position::CandidateCount() == 1, "rescanned after the level load");

    // B28 (the B27play log, 4-a): after a grab, the rescan (him held still) found an address lower than his own that
    // holds his position only while his own update runs, i.e. at every ping, and another spot in between (a fight
    // arena's point, x frozen). It passed every ping check and was tracked for 16 minutes.
    {
        position::OnLevel();
        for (int i = 0; i < 64; ++i) g_valid[i] = false;
        const int kScratch = 1, kShank = 2;  // the scratch address is lower: it would be confirmed first
        float sx = 5825, sy = 352;
        auto at_ping = [&](unsigned t) {  // the ping: both hold his position right then
            Place(kShank, sx, sy);
            Place(kScratch, sx, sy);
            position::OnPing(sx, sy, true, t);
        };
        auto between = [&](unsigned t) {  // between pings: his object moves on, the scratch holds another spot
            Place(kShank, sx, sy);
            Place(kScratch, 5652.4f, 125.f);
            if (t % 300 == 0) position::OnShankSound(sx, sy, t);  // his own sounds now and then (a skid stop, a block)
            position::Work(t);
            position::Current(t);
        };
        at_ping(10000);
        at_ping(10500);
        position::Work(10500);
        Check(position::CandidateCount() == 2, "B28: held still after a grab: both addresses are candidates");
        unsigned t = 10500;
        for (int k = 0; k < 4; ++k) {
            for (int j = 1; j <= 3; ++j) between(t + 150 * j);
            sx += 200;
            t += 500;
            at_ping(t);
        }
        Check(position::TrackedAddress() == Addr(kShank), "B28: the scratch address is dropped between pings; his own is tracked");
        Place(kShank, sx + 10, sy);
        const position::Pos q = position::Current(t + 50);
        Check(q.live && q.x == sx + 10, "B28: ...and read live");
    }
    // B28: an address already tracked that jumps away between pings is dropped after a few reads, and not picked
    // again although it matches at the pings.
    {
        position::OnLevel();
        for (int i = 0; i < 64; ++i) g_valid[i] = false;
        const int kA = 3;
        float ax = 1000, ay = 352;
        Place(kA, ax, ay);
        position::OnPing(ax, ay, true, 20000);
        position::OnPing(ax, ay, true, 20500);
        position::Work(20500);
        for (unsigned t = 21000; t <= 22000; t += 500) {
            ax += 200;
            Place(kA, ax, ay);
            position::OnPing(ax, ay, true, t);
        }
        Check(position::TrackedAddress() == Addr(kA), "B28: tracking (a plain follower)");
        Place(kA, ax - 2000, ay - 300);  // somewhere he can't be 30 ms after a ping
        position::Pos q = position::Current(22030);
        Check(!q.live && q.x == ax, "B28: an impossible read isn't used (the ping's position instead)");
        Place(kA, ax, ay);  // B28b: flipping between him and elsewhere (a jump each way)
        position::Current(22060);
        Place(kA, ax - 2000, ay - 300);
        position::Current(22090);
        Check(position::TrackedAddress() == 0, "B28: an address that flips about (three jumps in a second) is dropped");
        ax += 200;
        Place(kA, ax, ay);
        position::OnPing(ax, ay, true, 22500);
        ax += 200;
        Place(kA, ax, ay);
        position::OnPing(ax, ay, true, 23000);
        Check(position::TrackedAddress() == 0, "B28: ...and it isn't picked again in this level");
    }
    // B28b (the B28 log, 2-c 20:51:26): a grappler grabs him and the grab snaps him 330 px in one frame; the pings stop
    // for a while. The reads are right: still tracked. And (the Cesar fight) his object reads (0, 0) during finishers:
    // not a position, not a strike.
    {
        position::OnLevel();
        for (int i = 0; i < 64; ++i) g_valid[i] = false;
        const int kS = 5;
        float gx = 26000, gy = 864;
        Place(kS, gx, gy);
        position::OnPing(gx, gy, true, 40000);
        position::OnPing(gx, gy, true, 40500);
        position::Work(40500);
        for (unsigned t = 41000; t <= 42000; t += 500) {
            gx += 200;
            Place(kS, gx, gy);
            position::OnPing(gx, gy, true, t);
        }
        Check(position::TrackedAddress() == Addr(kS), "B28b: tracking before the grab");
        for (unsigned t = 42015; t < 42300; t += 15) position::Current(t);
        Place(kS, gx - 330, gy + 135);  // the grab's snap
        for (unsigned t = 42300; t < 43500; t += 15) position::Current(t);  // no pings while he's held
        const position::Pos q = position::Current(43500);
        Check(position::TrackedAddress() == Addr(kS) && q.live && q.x == gx - 330, "B28b: a grab's snap: still tracked, read live");
        Place(kS, 0, 0);  // a finisher
        for (unsigned t = 43515; t < 44500; t += 15) position::Current(t);
        position::OnShankSound(gx - 330, gy + 135, 44000);
        position::OnShankSound(gx - 330, gy + 135, 44200);
        const position::Pos z = position::Current(44500);
        Check(position::TrackedAddress() == Addr(kS) && !z.live, "B28b: (0, 0) reads: not used, not a strike");
    }
    // B28: his own game sounds (a skid stop, a wall climb) elsewhere than the tracked read, twice: dropped.
    {
        position::OnLevel();
        for (int i = 0; i < 64; ++i) g_valid[i] = false;
        const int kB = 4;
        float bx = 3000, by = 352;
        Place(kB, bx, by);
        position::OnPing(bx, by, true, 30000);
        position::OnPing(bx, by, true, 30500);
        position::Work(30500);
        for (unsigned t = 31000; t <= 32000; t += 500) {
            bx += 200;
            Place(kB, bx, by);
            position::OnPing(bx, by, true, t);
        }
        Check(position::TrackedAddress() == Addr(kB), "B28: tracking before the sounds");
        position::OnShankSound(bx + 50, by, 32100);
        Check(position::TrackedAddress() == Addr(kB), "B28: his sound 50 px from the read: fine");
        position::OnShankSound(bx + 200, by + 600, 32200);
        Check(position::TrackedAddress() == Addr(kB), "B28: one mismatch: kept");
        position::OnShankSound(bx + 200, by + 650, 32400);
        Check(position::TrackedAddress() == 0, "B28: a second mismatch: dropped");
        Check(position::IsShankOnlySound("Shank/Character/wallClimb") && !position::IsShankOnlySound("Shank/Character/step"),
              "B28: wall climbs count, steps don't (other characters' steps use the same event)");
    }

    // The real scan over this process finds a pair we plant on the heap. B28-3: it runs on its own thread.
    position::SetMemory(nullptr, nullptr);
    position::Reset();
    float* planted = new float[2]{12345.5f, -678.25f};
    volatile float on_stack[2] = {12345.5f, -678.25f};  // B28: a stack copy (like our threads' locals) isn't a candidate
    position::OnPing(12345.5f, -678.25f, true, 5000);
    position::OnPing(12345.5f, -678.25f, true, 5500);
    const DWORD t0 = GetTickCount();
    position::Work(5500);
    const DWORD returned = GetTickCount() - t0;
    Check(position::Scanning() || position::CandidateCount() >= 1, "B28-3: the real scan started");
    while (position::Scanning() && GetTickCount() - t0 < 20000) Sleep(5);
    const DWORD took = GetTickCount() - t0;
    printf("Work returned after %lu ms; the scan took %lu ms\n", returned, took);
    Check(returned < 50 || took < 50, "B28-3: Work doesn't wait for the scan");
    printf("real scan took %lu ms, %u candidates\n", took, static_cast<unsigned>(position::CandidateCount()));
    Check(position::CandidateCount() == 1, "real scan: found the planted pair, and not the stack copies (B28)");
    (void)on_stack[0];
    planted[0] = 12545.5f;
    position::OnPing(12545.5f, -678.25f, true, 6000);
    planted[0] = 12745.5f;
    position::OnPing(12745.5f, -678.25f, true, 6500);
    Check(position::TrackedAddress() == reinterpret_cast<uintptr_t>(planted), "real memory: tracking the planted pair");
    delete[] planted;
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
