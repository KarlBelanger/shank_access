#pragma once
// B40-4 (the user, 2026-09-30: "add a conflict check that refuses to bind a controller button/direction if the main game
// has a binding for it"): the game's own controller bindings, read from its Input::XInputController objects (vtable
// 0x843fdc; RE-NOTES "The game's controller bindings"), as a hotkeys::PadButton mask. Falls back to the game's defaults
// if none is found.
namespace game_pads {

// The inputs the game has bound now (any thread; scans memory the first time, then re-reads the maps).
unsigned BoundInputs();
// The game's default controller map (its Controls screen, RE-NOTES "The game's default controller map").
unsigned DefaultInputs();

// For tests: one binding value (the map node's value) as a mask: type 0 axis (axis 0..3 = LX, LY, RX, RY; positive
// = Right / Up), 1 trigger (0 left, 1 right), 2 button (an XInput bit).
unsigned BindingToMask(unsigned type, unsigned axis, bool positive, unsigned trigger, unsigned button);

}  // namespace game_pads
