"""B37-3 / B37-3b: Shank Access setup (frozen into shank-access-setup.exe with PyInstaller: tools/setup/build_setup.py).

A small window (wxPython: native Windows controls, which screen readers read): finds the Shank folder (Steam's own
folder and every Steam library from libraryfolders.vdf, e.g. D:\\SteamLibrary; a Browse button for another), says
whether Shank Access is installed there and at which version, and installs, updates or uninstalls it.

Installing (the user, 2026-10-03: "have it check the running system for the shank folder, either in program files
(x86) or a steam library folder ... If the program detects the mod is already installed, it offers to update the mod
if the mod is out of date, or uninstall it."):
  1. checks bin/Shank.exe (the Steam build the mod's addresses are for) and that the game isn't running;
  2. copies the mod's own files (bundled: the DLLs, the screen reader DLLs, shank_access.ini) into the game folder;
  3. applies our patches (mod/patches/*.patch.json) to the game's data files, written as new files under data-pc/
     (the game's own files stay untouched, as tools/deploy.py does);
  4. extracts the levels and builds bin/shank_access_geometry.txt (extract_levels.py + geometry.py);
  5. extracts the drawn UI text into bin/shank_access_ui_text.txt (extract_ui_text.py);
  6. runs path_graph.exe (ours) for bin/shank_access_paths.txt;
  7. writes bin/shank_access_version.txt and the list of every file it wrote (bin/shank_access_setup_files.txt).
Uninstalling removes exactly the listed files (the player's own settings, bin/shank_access_user.ini, are kept unless
asked). Updating = uninstall the old files, then install.

Command line (for testing; no window): shank-access-setup.exe --game <Shank folder> [--target <folder>] [--uninstall]
"""
import argparse
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time

EXE_SHA256 = "a3b58dde9e4e3588664389bc6a36422d3f6110e6cf0869c493f0cb91fce79e2a"  # native/core/exe_check.h
FROZEN = getattr(sys, "frozen", False)
REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA = getattr(sys, "_MEIPASS", REPO)  # bundled data (mod/patches, mod/pristine.json, payload/, path_graph.exe)
if not FROZEN:
    for sub in ("tools", os.path.join("tools", "levels"), os.path.join("tools", "ui_text")):
        sys.path.insert(0, os.path.join(REPO, sub))

import deploy  # noqa: E402  (apply_ops, override_path)
import extract_levels  # noqa: E402
import extract_ui_text  # noqa: E402
import geometry  # noqa: E402

LIST = "bin/shank_access_setup_files.txt"
OLD_MOD_LIST = "bin/shank_access_files.txt"  # (release 0.1's package list)
VERSION_FILE = "bin/shank_access_version.txt"
USER_INI = "bin/shank_access_user.ini"
RUNTIME_LOGS = ["a11y.log", "a11y_marks.log"]  # written by the mod while playing; removed with it
CREATE_NO_WINDOW = 0x08000000


class SetupError(Exception):
    pass


# ---------------------------------------------------------------- the version this setup installs

def bundled_version():
    for p in (os.path.join(DATA, "payload", "version.txt"),):
        if os.path.exists(p):
            return open(p, encoding="utf-8").read().strip()
    try:
        rev = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
    except OSError:
        rev = ""
    return "dev-" + (rev or "unknown")


def installed_version(game):
    p = os.path.join(game, VERSION_FILE)
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    if os.path.exists(os.path.join(game, "bin", "shank_access.dll")):
        return "unknown (installed by hand)"
    return None


# ---------------------------------------------------------------- finding the game

def steam_libraries():
    """Steam's own folder and every library listed in its libraryfolders.vdf."""
    roots = []
    try:
        import winreg
        for hive, key, name in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
                                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath")):
            try:
                with winreg.OpenKey(hive, key) as k:
                    roots.append(os.path.normpath(winreg.QueryValueEx(k, name)[0]))
            except OSError:
                pass
    except ImportError:
        pass
    roots.append(os.path.normpath(os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), "Steam")))
    libs = []
    for r in roots:
        vdf = os.path.join(r, "steamapps", "libraryfolders.vdf")
        if os.path.exists(vdf):
            for m in re.finditer(r'"path"\s+"([^"]+)"', open(vdf, encoding="utf-8", errors="replace").read()):
                libs.append(os.path.normpath(m.group(1).replace("\\\\", "\\")))
        libs.append(r)
    for letter in "CDEFGHIJ":  # (a library Steam no longer lists: the usual names)
        for name in ("SteamLibrary", "Steam", r"Program Files (x86)\Steam", "Games\\Steam"):
            libs.append(os.path.normpath("%s:\\%s" % (letter, name)))
    seen, out = set(), []
    for l in libs:
        if l.lower() not in seen:
            seen.add(l.lower())
            out.append(l)
    return out


def find_games():
    found = []
    for lib in steam_libraries():
        g = os.path.join(lib, "steamapps", "common", "Shank")
        if os.path.exists(os.path.join(g, "bin", "Shank.exe")) and g not in found:
            found.append(g)
    return found


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def check_game(game):
    exe = os.path.join(game, "bin", "Shank.exe")
    if not os.path.exists(exe):
        raise SetupError("Shank isn't in that folder (no bin\\Shank.exe). Choose the Shank folder, the one with the bin "
                         "and data folders.")
    if sha256(exe) != EXE_SHA256:
        raise SetupError("This copy of Shank isn't the Steam version Shank Access supports, so nothing was changed.")


def game_running():
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Shank.exe", "/NH"], capture_output=True, text=True,
                             creationflags=CREATE_NO_WINDOW).stdout
        return "shank.exe" in out.lower()
    except OSError:
        return False


# ---------------------------------------------------------------- installing

def write(target, rel, data, written):
    dest = os.path.join(target, rel)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "wb") as f:
        f.write(data)
    written.append(rel.replace("\\", "/"))


def copy_payload(target, written, say):
    root = os.path.join(DATA, "payload", "files")
    if not os.path.isdir(root):  # (run from the source: the deployed set, as mod/artifacts.json + mod/files list it)
        n = 0
        for rel, src in json.load(open(os.path.join(REPO, "mod", "artifacts.json"), encoding="utf-8")).items():
            if rel in ("bin/shank_access_ui_text.txt", "bin/shank_access_geometry.txt", "bin/shank_access_paths.txt"):
                continue
            write(target, rel, open(os.path.join(REPO, src), "rb").read(), written)
            n += 1
        for src in glob.glob(os.path.join(REPO, "mod", "files", "**", "*"), recursive=True):
            if os.path.isfile(src) and not src.endswith(".gitkeep"):
                write(target, os.path.relpath(src, os.path.join(REPO, "mod", "files")), open(src, "rb").read(), written)
                n += 1
    else:
        n = 0
        for src in glob.glob(os.path.join(root, "**", "*"), recursive=True):
            if os.path.isfile(src):
                write(target, os.path.relpath(src, root), open(src, "rb").read(), written)
                n += 1
    say("Copied %d Shank Access files." % n)


def apply_patches(game, target, written, say):
    pristine = json.load(open(os.path.join(DATA, "mod", "pristine.json"), encoding="utf-8"))
    root = os.path.join(DATA, "mod", "patches")
    n = 0
    for dirpath, _, names in os.walk(root):
        for name in sorted(names):
            if not name.endswith(".patch.json"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, name), root).replace("\\", "/")[:-len(".patch.json")]
            src = os.path.join(game, rel)
            if not os.path.exists(src):
                raise SetupError("The game file %s is missing. Verify the game's files in Steam, then run setup again." % rel)
            want = pristine.get(rel)
            if want and sha256(src) != want:
                raise SetupError("The game file %s has been changed (by another mod or a game update). Verify the game's "
                                 "files in Steam, then run setup again." % rel)
            spec = json.load(open(os.path.join(dirpath, name), encoding="utf-8"))
            with open(src, "rb") as f:
                new = deploy.apply_ops(f.read(), spec["ops"], rel)
            write(target, deploy.override_path(rel), new, written)
            n += 1
    say("Applied %d game script changes." % n)


def path_graph_exe():
    for p in (os.path.join(DATA, "path_graph.exe"), os.path.join(REPO, "build", "native", "out", "path_graph.exe")):
        if os.path.exists(p):
            return p
    raise SetupError("path_graph.exe is missing from setup.")


class Cancelled(Exception):
    pass


class Progress:
    """B37-3c (the user: "It needs a standard progress bar for status tracking, plus a cancel button during the install
    with confirmation and proper cleanup."): the share of the work done (0..1) for the window's bar, and the cancel check
    (raises Cancelled; called between steps, at every line the level readers print, and while path_graph runs)."""

    def __init__(self, report=None, cancelled=None):
        self.report = report or (lambda fraction: None)
        self.cancelled = cancelled or (lambda: False)

    def check(self):
        if self.cancelled():
            raise Cancelled()

    def set(self, fraction):
        self.check()
        self.report(max(0.0, min(1.0, fraction)))


class LineCounter:
    """sys.stdout while a level reader runs: each line it prints (about one per level) moves the bar from lo toward hi."""

    def __init__(self, progress, lo, hi, expected):
        self.progress, self.lo, self.hi, self.expected, self.lines = progress, lo, hi, expected, 0

    def write(self, text):
        self.lines += text.count("\n")
        self.progress.set(self.lo + (self.hi - self.lo) * min(1.0, self.lines / float(self.expected)))
        return len(text)

    def flush(self):
        pass


def run_counting(fn, progress, lo, hi, expected):
    out = sys.stdout
    sys.stdout = LineCounter(progress, lo, hi, expected)
    try:
        fn()
    finally:
        sys.stdout = out


def generate(game, target, written, work, say, progress):
    levels = os.path.join(work, "levels")
    os.makedirs(levels, exist_ok=True)
    say("Reading the levels.")
    argv = sys.argv
    try:
        sys.argv = ["extract_levels", "--game-dir", game, "--out", levels]
        run_counting(extract_levels.main, progress, 0.05, 0.30, 12)
    finally:
        sys.argv = argv
    say("Mapping the levels.")
    geometry.GAME = game
    geometry.LEVELS_DIR = os.path.join(game, "data-pc", "levels")
    geometry.OUT_DIR = levels
    run_counting(lambda: geometry.main(["geometry"]), progress, 0.30, 0.50, 11)
    geo = os.path.join(levels, "shank_access_geometry.txt")
    write(target, "bin/shank_access_geometry.txt", open(geo, "rb").read(), written)
    say("Reading the game's screen text.")
    ui = os.path.join(work, "shank_access_ui_text.txt")
    run_counting(lambda: extract_ui_text.main(["--game", game, "--out", ui]), progress, 0.50, 0.53, 1)
    write(target, "bin/shank_access_ui_text.txt", open(ui, "rb").read(), written)
    say("Working out the routes between checkpoints. This is the longest step.")
    paths = os.path.join(work, "shank_access_paths.txt")
    proc = subprocess.Popen([path_graph_exe(), geo, paths], stdout=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW)
    start = time.time()
    try:
        while proc.poll() is None:
            # (its output only arrives at the end: the bar follows the time it usually takes, about 90 s)
            progress.set(0.53 + 0.45 * min(0.97, (time.time() - start) / 90.0))
            time.sleep(0.2)
    except Cancelled:
        proc.kill()
        proc.wait()
        raise
    if proc.returncode != 0:
        raise SetupError("Working out the routes failed (path_graph exit code %d)." % proc.returncode)
    write(target, "bin/shank_access_paths.txt", open(paths, "rb").read(), written)


def install(game, target=None, say=print, progress=None):
    progress = progress or Progress()
    target = target or game
    check_game(game)
    if target == game and game_running():
        raise SetupError("Shank is running. Close the game, then try again.")
    had = installed_version(target)
    if had:
        uninstall(target, say=lambda m: None)
    written = []
    try:
        with tempfile.TemporaryDirectory() as work:
            progress.set(0.0)
            copy_payload(target, written, say)
            progress.set(0.02)
            apply_patches(game, target, written, say)
            progress.set(0.05)
            generate(game, target, written, work, say, progress)
    except Cancelled:
        remove_files(target, written)  # (cleanup: everything this run wrote, and the folders it made)
        raise SetupError("Installation cancelled. Nothing from it was left behind." +
                         (" The version installed before was removed first, so run setup again to install it." if had else ""))
    version = bundled_version()
    write(target, VERSION_FILE, version.encode("utf-8"), written)
    with open(os.path.join(target, LIST), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(written) + "\n")
    return "Shank Access %s is installed. Start Shank to play." % version


def uninstall(target, remove_settings=False, say=print):
    if target and game_running() and os.path.exists(os.path.join(target, "bin", "Shank.exe")):
        raise SetupError("Shank is running. Close the game, then try again.")
    removed = 0
    rels = []
    for lst in (LIST, OLD_MOD_LIST):
        p = os.path.join(target, lst)
        if os.path.exists(p):
            rels += open(p, encoding="utf-8").read().split()
            rels.append(lst)
    if remove_settings:
        rels.append(USER_INI)
    if rels:  # (the mod's own logs in the game folder, written while playing, not by setup: the user's clean-state check)
        rels += RUNTIME_LOGS
    removed = remove_files(target, rels)
    return "Shank Access is uninstalled (%d files removed). The game's own files were never changed." % removed


def remove_files(target, rels):
    """Removes the listed files, then any folder left empty by that (data-pc\\stategraphs\\..., made by setup), never
    the target itself. Returns how many files were removed."""
    removed = 0
    dirs = set()
    for rel in rels:
        p = os.path.join(target, rel)
        if os.path.isfile(p):
            os.remove(p)
            removed += 1
            dirs.add(os.path.dirname(os.path.normpath(p)))
    root = os.path.normpath(target)
    for d in sorted(dirs, key=len, reverse=True):
        while d.startswith(root + os.sep) and os.path.isdir(d) and not os.listdir(d):
            os.rmdir(d)
            d = os.path.dirname(d)
    return removed


# ---------------------------------------------------------------- the window

def run_window():
    import wx

    class Frame(wx.Frame):
        def __init__(self):
            super().__init__(None, title="Shank Access setup", size=(640, 300))
            p = wx.Panel(self)
            s = wx.BoxSizer(wx.VERTICAL)
            s.Add(wx.StaticText(p, label="Shank folder:"), 0, wx.ALL, 6)
            row = wx.BoxSizer(wx.HORIZONTAL)
            self.path = wx.TextCtrl(p, name="Shank folder")
            row.Add(self.path, 1, wx.RIGHT, 6)
            self.browse = wx.Button(p, label="&Browse...")
            row.Add(self.browse)
            s.Add(row, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 6)
            self.status = wx.TextCtrl(p, style=wx.TE_READONLY | wx.TE_MULTILINE | wx.TE_NO_VSCROLL, size=(-1, 70),
                                      name="Status")
            s.Add(self.status, 0, wx.EXPAND | wx.ALL, 6)
            s.Add(wx.StaticText(p, label="Progress:"), 0, wx.LEFT | wx.RIGHT, 6)
            self.gauge = wx.Gauge(p, range=100, name="Progress")  # (a standard Windows progress bar)
            s.Add(self.gauge, 0, wx.EXPAND | wx.ALL, 6)
            buttons = wx.BoxSizer(wx.HORIZONTAL)
            self.go = wx.Button(p, label="&Install")
            self.remove = wx.Button(p, label="&Uninstall")
            self.cancel = wx.Button(p, label="C&ancel install")
            self.close = wx.Button(p, wx.ID_CANCEL, label="&Close")
            for b in (self.go, self.remove, self.cancel, self.close):
                buttons.Add(b, 0, wx.RIGHT, 6)
            s.Add(buttons, 0, wx.ALL, 6)
            p.SetSizer(s)
            self.cancel.Hide()
            self.cancel_asked = False
            self.running = False
            self.browse.Bind(wx.EVT_BUTTON, self.on_browse)
            self.go.Bind(wx.EVT_BUTTON, self.on_install)
            self.remove.Bind(wx.EVT_BUTTON, self.on_uninstall)
            self.close.Bind(wx.EVT_BUTTON, lambda e: self.Close())
            self.cancel.Bind(wx.EVT_BUTTON, lambda e: self.ask_cancel())
            self.Bind(wx.EVT_CLOSE, self.on_close)
            self.path.Bind(wx.EVT_TEXT, lambda e: self.refresh())
            games = find_games()
            self.path.SetValue(games[0] if games else "")
            if not games:
                self.set_status("Shank wasn't found in your Steam libraries. Choose its folder with Browse.")
            self.refresh()
            self.path.SetFocus()

        def set_status(self, text):
            self.status.SetValue(text)

        def refresh(self):
            game = self.path.GetValue().strip()
            ok = os.path.exists(os.path.join(game, "bin", "Shank.exe"))
            have = installed_version(game) if ok else None
            new = bundled_version()
            if not ok:
                self.set_status("No Shank game in this folder. Choose the Shank folder (the one with the bin and data folders).")
                self.go.SetLabel("&Install")
            elif not have:
                self.set_status("Shank found. Shank Access isn't installed. This setup installs version %s." % new)
                self.go.SetLabel("&Install")
            elif have != new:
                self.set_status("Shank Access %s is installed. This setup has version %s: Update replaces it." % (have, new))
                self.go.SetLabel("&Update")
            else:
                self.set_status("Shank Access %s is installed and up to date. Reinstall makes its files again." % have)
                self.go.SetLabel("&Reinstall")
            self.go.Enable(ok)
            self.remove.Enable(bool(have))

        def on_browse(self, _):
            with wx.DirDialog(self, "Choose the Shank folder", self.path.GetValue()) as d:
                if d.ShowModal() == wx.ID_OK:
                    self.path.SetValue(d.GetPath())
            self.path.SetFocus()

        def busy(self, on, cancellable=False):
            self.running = on
            for c in (self.go, self.remove, self.browse, self.path, self.close):
                c.Enable(not on)
            self.cancel.Show(on and cancellable)
            self.cancel.Enable(on and cancellable)
            self.Layout()

        def work(self, fn, title, cancellable=False):
            self.cancel_asked = False
            self.gauge.SetValue(0)
            self.busy(True, cancellable)
            (self.cancel if cancellable else self.status).SetFocus()

            def say(msg):
                wx.CallAfter(self.set_status, msg)

            def report(fraction):
                wx.CallAfter(self.gauge.SetValue, int(round(fraction * 100)))

            progress = Progress(report, lambda: self.cancel_asked)

            def run():
                try:
                    result, icon = fn(say, progress), wx.ICON_INFORMATION
                    wx.CallAfter(self.gauge.SetValue, 100)
                except SetupError as e:
                    result, icon = str(e), wx.ICON_WARNING
                except Exception as e:  # noqa: BLE001
                    result, icon = "Setup failed: %s" % e, wx.ICON_ERROR
                wx.CallAfter(self.done, result, icon, title)

            threading.Thread(target=run, daemon=True).start()

        def done(self, result, icon, title):
            self.busy(False)
            self.refresh()
            wx.MessageBox(result, title, wx.OK | icon, self)
            self.go.SetFocus()

        def ask_cancel(self):
            if self.cancel_asked or not self.running:
                return
            a = wx.MessageBox("Cancel the installation? Everything it has done so far will be removed.", "Cancel install",
                              wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION, self)
            if a == wx.YES and self.running:
                self.cancel_asked = True
                self.cancel.Enable(False)
                self.set_status("Cancelling and cleaning up.")

        def on_close(self, event):
            if self.running:  # (closing the window during an install asks to cancel, and waits for the cleanup)
                if self.cancel.IsShown():
                    self.ask_cancel()
                event.Veto()
                return
            event.Skip()

        def on_install(self, _):
            game = self.path.GetValue().strip()
            self.set_status("Installing. This takes about two minutes, and a message says when it's done.")
            self.work(lambda say, progress: install(game, say=say, progress=progress), "Shank Access setup", cancellable=True)

        def on_uninstall(self, _):
            game = self.path.GetValue().strip()
            # (the user, 2026-10-03: "I'd recommend a choose what to uninstall prompt, with "mod plus your settings", "Mod
            # only", and a cancel button."; the native message box, its buttons relabelled)
            with wx.MessageDialog(self, "Choose what to uninstall. Your settings are your key bindings, volumes and other "
                                  "choices from the mod menu.", "Uninstall Shank Access",
                                  wx.YES_NO | wx.CANCEL | wx.CANCEL_DEFAULT | wx.ICON_QUESTION) as d:
                d.SetYesNoCancelLabels("Mod plus your &settings", "&Mod only", "&Cancel")
                a = d.ShowModal()
            if a not in (wx.ID_YES, wx.ID_NO):
                return
            a = wx.YES if a == wx.ID_YES else wx.NO
            self.work(lambda say, progress: uninstall(game, remove_settings=a == wx.YES, say=say), "Shank Access setup")

    app = wx.App()
    Frame().Show()
    app.MainLoop()


def main(argv):
    ap = argparse.ArgumentParser(description="Shank Access setup")
    ap.add_argument("--game")
    ap.add_argument("--target")
    ap.add_argument("--uninstall", action="store_true")
    args = ap.parse_args(argv)
    if not args.game and not args.uninstall:
        run_window()
        return 0
    try:
        if args.uninstall:
            print(uninstall(args.target or args.game))
        else:
            print(install(args.game, args.target))
    except SetupError as e:
        print(e)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
