// Host-side test of Phase 2 menu reading logic (never deployed): XLIFF parsing and IDS_* translation,
// and menu_reader::OnEvent (focus rules, names, roles, values) against a fake Flash value table.
// Optional argument: the game root; if given, the real localization_en.xml is loaded (read only) and
// the IDS_* keys seen in 1c-3 must all translate. Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <map>
#include <string>
#include <vector>

#include "../core/localization.h"
#include "../core/log.h"
#include "../core/menu_reader.h"
#include "../core/ui_text.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

// Our own sample in the game's XLIFF shape (not Klei text).
const char kSample[] =
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<xliff version=\"1.0\"><file><body>\r\n"
    "  <trans-unit id=\"001\" resname=\"IDS_ONE\">\r\n    <source>First &amp; best</source>\r\n  </trans-unit>\r\n"
    "  <trans-unit id=\"002\" resname=\"IDS_NOSOURCE\">\r\n  </trans-unit>\r\n"
    "  <trans-unit id=\"003\" resname=\"IDS_TWO\">\r\n    <source>Say &quot;hi&quot; &lt;now&gt;</source>\r\n"
    "  </trans-unit>\r\n</body></file></xliff>\r\n";

}  // namespace

int main(int argc, char** argv) {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_menu_reader_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    Check(localization::LoadFromXliff(kSample) == 2, "sample: two strings (a unit without <source> skipped)");
    Check(localization::Translate("IDS_ONE") == "First & best", "sample: &amp; decoded");
    Check(localization::Translate("IDS_TWO") == "Say \"hi\" <now>", "sample: &quot; &lt; &gt; decoded");
    Check(localization::Translate("IDS_NOSOURCE") == "IDS_NOSOURCE", "sample: unit without source stays a key");
    Check(localization::Translate("Resume Game") == "Resume Game", "plain labels pass through");

    // OnEvent with a fake Flash: a table of path -> value.
    using ui_hooks::FlashValue;
    using ui_hooks::UiEvent;
    std::map<std::string, FlashValue> flash;
    auto text = [](const char* s) {
        FlashValue v;
        v.kind = FlashValue::kText;
        v.text = s;
        return v;
    };
    auto number = [](double n) {
        FlashValue v;
        v.kind = FlashValue::kNumber;
        v.n = n;
        return v;
    };
    auto boolean = [](bool b) {
        FlashValue v;
        v.kind = FlashValue::kBool;
        v.b = b;
        return v;
    };
    const menu_reader::Reader read = [&](void*, const std::string& path) {
        auto it = flash.find(path);
        return it == flash.end() ? FlashValue() : it->second;
    };
    int movie_a = 0, movie_b = 0;
    void* a = &movie_a;
    void* b = &movie_b;
    auto ev = [&](UiEvent::Type t, void* m, const char* path, unsigned ms) {
        return menu_reader::OnEvent(t, m, path, ms, read);
    };

    // B29-5: the credits screen opening on its own (after Cesar) reads the credits; the game's own focus moves on it and
    // the scrolling movie ("Credits movie") are silent; the player's arrows to Back still speak.
    {
        int credits_movie = 0;
        menu_reader::SetCredits("Klei Entertainment. Executive Producer Jamie Cheng.");
        flash["_level0._url"] = text("ui/creditsscreen.gfx");
        const std::string said = menu_reader::OnScreen(true, &credits_movie, 900000, read);
        flash.erase("_level0._url");
        printf("  (end credits: %s)\n", said.c_str());
        Check(said == "Credits. Klei Entertainment. Executive Producer Jamie Cheng." && menu_reader::LastLongMessage() == said,
              "B29-5: the end credits read the credits (F8 repeats them)");
        flash["_level0.backBtn.label"] = text("Back");
        Check(ev(UiEvent::kFocusedSet, &credits_movie, "_level0.backBtn", 902000).empty(), "B29-5: the game's focus on Back: silent");
        Check(ev(UiEvent::kNavigate, &credits_movie, "_level0.creditsMovie", 903000).empty(), "B29-5: the credits movie: silent");
        menu_reader::OnScreen(false, &credits_movie, 910000, read);
        flash.erase("_level0.backBtn.label");
        menu_reader::SetCredits("");
    }
    // B15-3: a tutorial pop-up (its movie's _url names the SWF) says what it teaches; F8 repeats it.
    {
        int tut_movie = 0;
        flash["_level0._url"] = text("D:\\SteamLibrary\\steamapps\\common\\Shank\\data\\ui\\TutorialWallRun.gfx");
        const std::string said = menu_reader::OnScreen(true, &tut_movie, 500, read);
        printf("  (tutorial: %s)\n", said.c_str());
        Check(said == "Tutorial: Wall run. Jump and hold forward to run along the wall." && menu_reader::LastLongMessage() == said,
              "a tutorial screen: its text, kept for F8");
        flash.erase("_level0._url");
        menu_reader::OnScreen(false, &tut_movie, 600, read);
        // B15-1b: two pop-ups in the same frame are said together; the cutscene skip prompt by its file.
        int m2 = 0, m3 = 0, m4 = 0;
        flash["_level0._url"] = text("ui/tutorialbasicattacks.gfx");
        menu_reader::OnScreen(true, &m2, 5000, read);
        flash["_level0._url"] = text("ui/tutorialchangecontrols.gfx");
        const std::string both = menu_reader::OnScreen(true, &m3, 5000, read);
        Check(both.find("Basic combat") != std::string::npos && both.find("change the controls") != std::string::npos,
              "two tutorials at once: both said");
        Check(menu_reader::TakeAutomatic() && !menu_reader::TakeAutomatic(), "B16: tutorials are automatic (and the flag clears)");
        flash["_level0._url"] = text("ui/skipcinematic.gfx");
        Check(menu_reader::OnScreen(true, &m4, 9000, read) == "Space to skip, Escape to pause.", "the cutscene skip prompt");
        Check(!menu_reader::TakeAutomatic(), "B16: the skip prompt (answering Escape) is menu reading");
        flash.erase("_level0._url");
        for (void* m : {static_cast<void*>(&m2), static_cast<void*>(&m3), static_cast<void*>(&m4)}) menu_reader::OnScreen(false, m, 9500, read);
    }

    // 2-1 behaviour: labels, IDS translation, the pause-menu stray focus.
    flash["_level0.x.label"] = text("IDS_ONE");
    flash["_level0.resumeBtn.label"] = text("Resume Game");
    flash["_level0.controls.howToPlayBtn.label"] = text("How to Play");
    flash["_level0.plainBtn.textField.text"] = text("Plain");
    Check(ev(UiEvent::kFocusIn, a, "_level0.x", 1000) == "First & best", "focusIn: label translated");
    Check(ev(UiEvent::kFocusIn, a, "_level0.resumeBtn", 2000) == "Resume Game", "focusIn: plain label (same movie: no title)");
    Check(ev(UiEvent::kFocusIn, b, "_level0.controls.howToPlayBtn", 2005).empty(),
          "focusIn from another movie 5 ms later ignored (pause-menu stray)");
    Check(ev(UiEvent::kFocusIn, b, "_level0.controls.howToPlayBtn", 2060) == "Help and options. How to Play",
          "focusIn from another movie 60 ms later spoken");
    Check(ev(UiEvent::kFocusIn, a, "_level0.plainBtn", 2400) == "Plain", "button label from textField.text");
    Check(ev(UiEvent::kFocusIn, a, "_level0.controls.fooBarBtn", 2500) == "Foo bar", "unlabelled button: prettified name");
    // Same movie within 50 ms: the newer focus wins (Controls screen: listBox then btnPrevious at once).
    flash["_level0.btnPrevious.label"] = text("Previous Controller");
    Check(ev(UiEvent::kFocusedSet, a, "_level0.listBox", 3000) == "Key bindings list", "focused set: our name for listBox");
    Check(ev(UiEvent::kFocusedSet, a, "_level0.btnPrevious", 3001) == "Previous Controller",
          "same movie 1 ms later: spoken (newest wins)");
    Check(ev(UiEvent::kFocusIn, a, "_level0.btnPrevious", 3001).empty(), "focusIn right after focused set: duplicate");

    // navigate: a new path is a focus; the same path (end of list, or after focusIn) is silent.
    flash["_level0.controls.mpBtn.label"] = text("Multiplayer");
    Check(ev(UiEvent::kNavigate, a, "_level0.controls.mpBtn", 4000) == "Multiplayer", "navigate to a new widget");
    Check(ev(UiEvent::kFocusIn, a, "_level0.controls.mpBtn", 4000).empty(), "focusIn after navigate: duplicate");
    Check(ev(UiEvent::kNavigate, a, "_level0.controls.mpBtn", 4500) == "Multiplayer",
          "navigate against the end (focus didn't move): spoken again");
    Check(ev(UiEvent::kNavigate, a, "_level0.controls.mpBtn", 4520).empty(),
          "the same navigate 20 ms later: same press, silent");
    // Re-focusing the same item later (e.g. reopening the pause menu) is spoken again.
    Check(ev(UiEvent::kFocusIn, a, "_level0.controls.mpBtn", 9000) == "Multiplayer", "same item, later: spoken");

    // Settings dialog (2-2).
    flash["_level0.musicVolumeTxt.text"] = text("15");
    flash["_level0.musicSlider.value"] = number(16);
    flash["_level0.soundSlider.value"] = number(99.6);
    flash["_level0.modeSpinner.textField.text"] = text("1920x1080 (16:9)");
    flash["_level0.ratioSpinner.selectedItem"] = text("16:9");
    flash["_level0.cbFullscreen.selected"] = boolean(true);
    flash["_level0.cbBloom.selected"] = boolean(false);
    flash["_level0.cbBloom.label"] = text("Bloom effect");
    flash["_level0.adapterSpinner.textField.text"] = text("Adapter 1");
    flash["_level0.adapterSpinner.disabled"] = boolean(true);
    Check(ev(UiEvent::kFocusedSet, a, "_level0.musicSlider", 10000) == "Music volume, slider, 15",
          "slider: our name, role, value from its text field");
    Check(ev(UiEvent::kNavigate, a, "_level0.soundSlider", 10500) == "Sound volume, slider, 100",
          "slider without a text field: rounded .value");
    Check(ev(UiEvent::kNavigate, a, "_level0.modeSpinner", 11000) == "Resolution, selector, 1920x1080 (16:9)",
          "spinner: value from textField.text");
    Check(ev(UiEvent::kNavigate, a, "_level0.ratioSpinner", 11500) == "Aspect ratio, selector, 16:9",
          "spinner: value from selectedItem");
    Check(ev(UiEvent::kNavigate, a, "_level0.adapterSpinner", 12000) ==
              "Display adapter, selector, Adapter 1, unavailable",
          "disabled widget: unavailable");
    Check(ev(UiEvent::kNavigate, a, "_level0.cbFullscreen", 12500) == "Fullscreen, checkbox, checked", "checkbox");
    Check(ev(UiEvent::kNavigate, a, "_level0.cbBloom", 13000) == "Bloom effect, checkbox, not checked",
          "checkbox: the game's label wins over our name");
    // Value changes: only for the focused widget, value only.
    flash["_level0.cbBloom.selected"] = boolean(true);
    Check(ev(UiEvent::kChange, a, "_level0.cbBloom", 13500) == "checked", "change on the focused checkbox");
    Check(ev(UiEvent::kChange, a, "_level0.modeSpinner", 13600).empty(), "change on an unfocused widget: silent");
    ev(UiEvent::kNavigate, a, "_level0.musicSlider", 14000);
    flash["_level0.musicVolumeTxt.text"] = text("14");
    Check(ev(UiEvent::kChange, a, "_level0.musicSlider", 14100) == "14", "slider change: new value");
    flash["_level0.applyBtn.label"] = text("Apply");
    ev(UiEvent::kNavigate, a, "_level0.applyBtn", 15000);
    Check(ev(UiEvent::kChange, a, "_level0.applyBtn", 15100).empty(), "click on a button: silent");

    // 2-2 fixes after the first test.
    // Checkbox state in _selected when .selected gives nothing.
    flash["_level0.cbBlur._selected"] = boolean(false);
    Check(ev(UiEvent::kNavigate, a, "_level0.cbBlur", 16000) == "Blur, checkbox, not checked", "checkbox via _selected");
    flash["_level0.cbBlur._selected"] = boolean(true);
    Check(ev(UiEvent::kChange, a, "_level0.cbBlur", 16500) == "checked", "select on the focused checkbox");
    // Spinners send change + stepperChange for one press: the second is not repeated.
    ev(UiEvent::kNavigate, a, "_level0.ratioSpinner", 17000);
    flash["_level0.ratioSpinner.selectedItem"] = text("4:3");
    Check(ev(UiEvent::kChange, a, "_level0.ratioSpinner", 17500) == "4:3", "spinner change spoken");
    Check(ev(UiEvent::kChange, a, "_level0.ratioSpinner", 17501).empty(), "same value 1 ms later: not repeated");
    Check(ev(UiEvent::kChange, a, "_level0.ratioSpinner", 17600) == "4:3", "same value later (held key): spoken");
    // Settings opening: focus lands on the slider before its number is written.
    auto late = [&](const char* path, const FlashValue& v, unsigned ms) {
        return menu_reader::OnEvent(UiEvent::kValueSet, nullptr, path, ms, read, &v);
    };
    flash["_level0.musicVolumeTxt.text"] = text("00");
    Check(ev(UiEvent::kFocusedSet, a, "_level0.musicSlider", 20000) == "Settings. Music volume, slider, 00",
          "slider focused before its number is written: stale value");
    Check(late("_level0.HUD.player1.grenadeTxt.text", text("3"), 20001).empty(), "unrelated write: silent");
    Check(late("_level0.musicVolumeTxt.text", text("15"), 20001) == "Settings. Music volume, slider, 15",
          "its number written 1 ms later: re-announced with the new value");
    Check(late("_level0.musicVolumeTxt.text", text("15"), 20002).empty(), "same number again: silent");
    Check(late("_level0.musicVolumeTxt.text", text("16"), 20600).empty(), "a write 600 ms after focus: silent");

    // 2-5a dialog text: headerTxt/bodyTxt written just before the dialog's first button focus.
    auto write = [&](const char* path, const char* value, void* m, unsigned ms) {
        const FlashValue v = text(value);
        return menu_reader::OnEvent(UiEvent::kValueSet, m, path, ms, read, &v);
    };
    flash["_level0.thirdBtn.label"] = text("Cancel");
    flash["_level0.secondBtn.label"] = text("OK");
    Check(write("_level0.headerTxt.text", "Erase Save Data", b, 30000).empty(), "dialog header write: silent");
    write("_level0.bodyTxt.text", "You are about to erase all your saved data. Are you sure you want to do this?", b, 30000);
    Check(ev(UiEvent::kFocusedSet, b, "_level0.thirdBtn", 30001) ==
              "Erase Save Data. You are about to erase all your saved data. Are you sure you want to do this? Cancel",
          "dialog: title and message before the first button");
    Check(ev(UiEvent::kNavigate, b, "_level0.secondBtn", 30500) == "OK", "dialog text spoken once");
    // The busy dialog writes its text and clears it at once: nothing left for a later focus.
    write("_level0.headerTxt.text", "Writing Game Results", b, 31000);
    write("_level0.bodyTxt.text", "Please wait...", b, 31000);
    write("_level0.headerTxt.text", "", b, 31001);
    write("_level0.bodyTxt.text", "", b, 31001);
    Check(ev(UiEvent::kFocusedSet, b, "_level0.thirdBtn", 31100) == "Cancel", "cleared dialog text: not spoken");
    // The lobby pre-fills a dialog while focusing its own button: another parent, so no prefix.
    flash["_level0.player0.readyBtn.label"] = text("JOIN");
    write("_level0.headerTxt.text", "Leave Session", b, 32000);
    write("_level0.bodyTxt.text", "Do you really want to leave the current session?", b, 32000);
    Check(ev(UiEvent::kFocusedSet, b, "_level0.player0.readyBtn", 32001) == "JOIN",
          "focus under another parent: no dialog text");
    // Another movie, or too late: no prefix.
    Check(ev(UiEvent::kFocusedSet, a, "_level0.secondBtn", 32100) == "OK", "focus in another movie: no dialog text");
    Check(ev(UiEvent::kFocusedSet, b, "_level0.thirdBtn", 32600) == "Cancel", "focus 600 ms later: no dialog text");
    // A header without a body, and text that doesn't end a sentence.
    write("_level0.headerTxt.text", "Save Data Erased", b, 33000);
    write("_level0.bodyTxt.text", "", b, 33000);
    Check(ev(UiEvent::kFocusedSet, b, "_level0.secondBtn", 33001) == "Save Data Erased. OK", "header only");

    // Dialog text the game never writes (quitdialog.gfx): read on the first focus in a new movie.
    int movie_q = 0;
    void* q = &movie_q;
    flash["_level0.bodyTxt.text"] = text("Are you sure you want to exit the game?\r");  // SWF text ends in a line break
    flash["_level0.cancelBtn.label"] = text("Cancel");
    flash["_level0.quitBtn.label"] = text("Quit");
    Check(ev(UiEvent::kFocusedSet, q, "_level0.cancelBtn", 34000) == "Are you sure you want to exit the game? Cancel",
          "static dialog text read on the first focus in a new movie");
    Check(ev(UiEvent::kNavigate, q, "_level0.quitBtn", 34500) == "Quit", "same movie: not read again");
    flash.erase("_level0.bodyTxt.text");

    // 2-5b screen titles.
    Check(menu_reader::ScreenTitle("_level0.controls.spBtn") == "Main menu", "title: main menu");
    Check(menu_reader::ScreenTitle("_level0.controls.backBtn").empty(), "title: shared widget: none");
    Check(menu_reader::ScreenTitle("_level0.unlockBtn3") == "Unlocks", "title: prefix match");
    // B13-1: Concept Art, About Us; the credits from credits.xml's rows.
    Check(menu_reader::ScreenTitle("_level0.controls.imageSpinner") == "Concept art", "title: concept art");
    Check(menu_reader::ScreenTitle("_level0.controls.forumsBtn") == "About us", "title: about us");
    Check(menu_reader::ScreenTitle("_level0.nextBtn") == "How to play", "title: How to Play's Next is still How to Play");
    {
        const std::string c = menu_reader::CreditsFromXml(
            "<rows scroll=1.8><header1>KLEI &amp; CO</header1><space/><header2>Executive Producer</header2>"
            "<name>Jamie Cheng</name><space/><header2>Art</header2><name title=\"Lead Animator\">Aaron B</name>"
            "<name title=\"Builds\">Jordan K</name></rows>");
        printf("  (credits: %s)\n", c.c_str());
        Check(c == "KLEI & CO. Executive Producer: Jamie Cheng. Art: Aaron B, Lead Animator; Jordan K, Builds.", "credits text");
    }
    Check(menu_reader::ScreenTitle("_level0.quitBtn").empty(), "title: quitBtn is shared (pause / quit dialog)");
    flash["_level0.helpOptionsBtn.label"] = text("Help and Options");
    int movie_p = 0, movie_d = 0;
    void* pm = &movie_p;
    void* dm = &movie_d;
    Check(ev(UiEvent::kFocusedSet, pm, "_level0.resumeBtn", 60000) == "Pause menu. Resume Game", "pause opens: title");
    Check(ev(UiEvent::kNavigate, pm, "_level0.helpOptionsBtn", 60400) == "Help and Options", "arrow press: no title");
    Check(ev(UiEvent::kFocusedSet, dm, "_level0.thirdBtn", 60800) == "Cancel", "dialog button: no title");
    Check(ev(UiEvent::kFocusedSet, pm, "_level0.helpOptionsBtn", 61200) == "Pause menu. Help and Options",
          "back from a dialog (another movie): the screen title again");
    Check(ev(UiEvent::kFocusedSet, pm, "_level0.resumeBtn", 61300) == "Resume Game",
          "same screen 100 ms later: no title");
    Check(ev(UiEvent::kFocusedSet, pm, "_level0.resumeBtn", 90000) == "Pause menu. Resume Game",
          "pause reopened after playing: title again");
    Check(ev(UiEvent::kNavigate, b, "_level0.controls.helpBtn", 91250) == "Main menu. Help",
          "backing out arrives as a navigate into another movie: title");
    flash["_level0.controls.hardBtn.label"] = text("Hard");
    flash["_level0.controls.normalBtn.label"] = text("Normal");
    Check(ev(UiEvent::kFocusedSet, dm, "_level0.controls.normalBtn", 92000) == "Choose difficulty. Normal",
          "difficulty opens: title");
    Check(ev(UiEvent::kFocusIn, dm, "_level0.controls.hardBtn", 94000) == "Hard",
          "difficulty arrow (focusIn first) after a pause: no title");
    Check(ev(UiEvent::kNavigate, pm, "_level0.resumeBtn", 95000) == "Pause menu. Resume Game",
          "back into a screen via navigate (another movie): title");

    // 2-5b-3: screens shown / hidden (CLIK restores focus silently on back-out and re-entry).
    {
        int mm_ = 0, hm_ = 0, other_ = 0, fresh_ = 0;
        void* mm = &mm_;
        void* hm = &hm_;
        flash["_level0.controls.helpBtn.label"] = text("Help & Options");
        flash["_level0.controls.howToPlayBtn.label"] = text("How to Play");
        Check(ev(UiEvent::kFocusIn, mm, "_level0.controls.helpBtn", 100000) == "Main menu. Help & Options", "main menu");
        Check(menu_reader::OnScreen(true, mm, 100016, read).empty(), "screen shown where the focus already is: silent");
        Check(ev(UiEvent::kFocusedSet, hm, "_level0.controls.howToPlayBtn", 101000) == "Help and options. How to Play",
              "submenu opens (game-set focus)");
        Check(menu_reader::OnScreen(true, hm, 101016, read).empty(), "its screen shown: silent (focus already there)");
        Check(menu_reader::OnScreen(false, hm, 105000, read).empty(), "back out: nothing at once (delayed)");
        Check(menu_reader::OnFrame(105200, read).empty(), "back out: not yet due at 200 ms");
        Check(menu_reader::OnFrame(105300, read) == "Main menu. Help & Options",
              "back out: 300 ms later the main menu's last focus is announced with its title");
        Check(menu_reader::OnFrame(105400, read).empty(), "back out: announced once");
        Check(menu_reader::OnScreen(true, hm, 106000, read) == "Help and options. How to Play",
              "re-enter the submenu (no focus event): its last focus re-announced");
        Check(ev(UiEvent::kFocusedSet, &other_, "_level0.resumeBtn", 107000) == "Pause menu. Resume Game", "pause");
        Check(menu_reader::OnScreen(true, hm, 107050, read).empty(),
              "a screen shown right after the game focused another screen: silent (stray)");
        Check(menu_reader::OnScreen(true, &fresh_, 108000, read).empty(), "a screen never focused before: silent");
        Check(menu_reader::OnScreen(false, mm, 108100, read).empty(), "hiding a screen without the focus: silent");

        // The 2-5b-3 crash: the main menu's movie was destroyed when the level loaded (it never
        // reported "hidden"); hiding the pause menu must not restore into it.
        int pause_ = 0;
        void* pz = &pause_;
        menu_reader::OnScreen(false, hm, 108900, read);  // the Help screen closed earlier
        menu_reader::OnScreen(true, mm, 109000, read);   // main menu marked shown (stale later)
        ev(UiEvent::kFocusIn, mm, "_level0.controls.helpBtn", 109100);
        menu_reader::OnScreen(true, pz, 120000, read);
        ev(UiEvent::kFocusedSet, pz, "_level0.resumeBtn", 120001);
        menu_reader::SetMovieAliveCheck([mm](void* m) { return m != mm; });  // the main menu movie is gone
        Check(menu_reader::OnScreen(false, pz, 121000, read) == "Resumed",
              "the pause menu closes: \"Resumed\", never a restore into the dead main menu");
        menu_reader::SetMovieAliveCheck(nullptr);

        // The 2-5b-4 report: level select opens (no focus event, only SelectCell) and in the same
        // instant the difficulty screen hides; that must not restore into the main menu.
        int diff_ = 0, ls_ = 0;
        void* df = &diff_;
        void* ls = &ls_;
        menu_reader::OnScreen(true, mm, 130000, read);
        ev(UiEvent::kFocusIn, mm, "_level0.controls.helpBtn", 130100);
        menu_reader::OnScreen(true, df, 131000, read);
        ev(UiEvent::kFocusedSet, df, "_level0.controls.normalBtn", 131000);
        const std::string strip_path = "_level0.FilmStrip.LevelSelector";
        menu_reader::OnInvoke(strip_path, "Clear", {}, "", 132000, nullptr, ls);
        menu_reader::OnInvoke(strip_path, "AddCell", {"Return Home", "s.dds", "l.dds", "0", "286.035"}, "", 132000,
                              nullptr, ls);
        Check(menu_reader::OnInvoke(strip_path, "SelectCell", {"0", "1"}, "", 132000, nullptr, ls) ==
                  "Level select. Return Home, completion time 4 minutes 46 seconds, 1 of 1",
              "level select opens");
        Check(menu_reader::OnScreen(false, df, 132001, read).empty(),
              "the difficulty screen hiding underneath level select: silent");

        // 2-5b-6: Escape from the in-level Help & Options closes it, then the pause menu 0.2 s later.
        int pz2_ = 0, ih_ = 0;
        void* pz2 = &pz2_;
        void* ih = &ih_;
        menu_reader::OnScreen(true, pz2, 140000, read);
        ev(UiEvent::kFocusedSet, pz2, "_level0.resumeBtn", 140000);
        ev(UiEvent::kNavigate, pz2, "_level0.helpOptionsBtn", 141000);
        // Help opens without any focus event: the probe asks it on the next frames.
        std::string asked_focus;  // what the fake "Selection.getFocus" answers
        const std::function<std::string(void*)> query = [&](void*) { return asked_focus; };
        Check(menu_reader::OnScreen(true, ih, 142000, read).empty(), "in-level Help shown, no focus yet: silent");
        Check(menu_reader::OnScreenTick(ih, 142016, read, query).empty(), "first frame: no focus yet: silent");
        asked_focus = "_level0.controls.howToPlayBtn";
        Check(menu_reader::OnScreenTick(ih, 142033, read, query) == "Help and options. How to Play",
              "a later frame: the asked focus spoken with the title");
        Check(menu_reader::OnScreenTick(ih, 142050, read, query).empty(), "asked once only");
        Check(menu_reader::OnScreen(false, ih, 145000, read).empty(), "Escape: Help hides; the pause menu is pending");
        Check(menu_reader::OnScreen(false, pz2, 145216, read) == "Resumed", "then the pause menu closes: Resumed");
        Check(menu_reader::OnFrame(145300, read).empty(), "the pending pause announcement was dropped");
        // Back to a screen that closes on its own before the delay: dropped too.
        int s1_ = 0, s2_ = 0;
        menu_reader::OnScreen(true, &s1_, 146000, read);
        ev(UiEvent::kFocusIn, &s1_, "_level0.controls.helpBtn", 146000);
        menu_reader::OnScreen(true, &s2_, 146500, read);
        ev(UiEvent::kFocusedSet, &s2_, "_level0.controls.normalBtn", 146500);
        menu_reader::OnScreen(false, &s2_, 147000, read);  // back to s1 (pending)
        menu_reader::OnScreen(false, &s1_, 147100, read);  // s1 closes too
        Check(menu_reader::OnFrame(147400, read).empty(), "pending restore dropped when that screen closed");
        // The Exit Game dialog: Quit (after Cancel had the focus) -> "Exiting".
        int qd_ = 0;
        flash["_level0.cancelBtn.label"] = text("Cancel");
        ev(UiEvent::kFocusedSet, &qd_, "_level0.cancelBtn", 148000);
        ev(UiEvent::kNavigate, &qd_, "_level0.quitBtn", 148500);
        Check(!menu_reader::Exiting(), "not exiting before Quit");
        Check(ev(UiEvent::kChange, &qd_, "_level0.quitBtn", 149000) == "Exiting" && menu_reader::Exiting(),
              "Quit in the Exit Game dialog: Exiting");
        // The pause menu's own quitBtn (no cancelBtn there) is not an exit.
        menu_reader::Reset();
        ev(UiEvent::kFocusedSet, pz2, "_level0.resumeBtn", 150000);
        ev(UiEvent::kNavigate, pz2, "_level0.quitBtn", 150500);
        Check(ev(UiEvent::kChange, pz2, "_level0.quitBtn", 151000).empty() && !menu_reader::Exiting(),
              "the pause menu's Exit Game button: not an exit");
        // A probe gives up after kFocusProbeMs.
        int late_ = 0;
        menu_reader::OnScreen(true, &late_, 150000, read);
        Check(menu_reader::OnScreenTick(&late_, 151500, read, query).empty(), "probe expired: silent");
    }

    // N1 (overnight): the Weapons screen and outfits.
    {
        menu_reader::Reset();
        int wm_ = 0;
        void* wm = &wm_;
        flash["_level0.meleeTitleTxt.text"] = text("Chain Fists");
        flash["_level0.gunTitleTxt.text"] = text("Pistols");
        Check(ev(UiEvent::kFocusedSet, wm, "_level0.chainsBtn", 200000) == "Weapons. Chain Fists, equipped",
              "weapon: our name + equipped (matches the title field)");
        Check(ev(UiEvent::kNavigate, wm, "_level0.uziBtn", 200500) == "Uzi", "weapon not equipped");
        flash["_level0.uziBtn._disabled"] = boolean(true);
        Check(ev(UiEvent::kNavigate, wm, "_level0.shotgunBtn", 201000) == "Shotgun", "no disabled flag: available");
        Check(ev(UiEvent::kNavigate, wm, "_level0.uziBtn", 201500) == "Uzi, unavailable", "disabled via _disabled");
        flash.erase("_level0.uziBtn._disabled");
        // Choosing the Uzi: the game writes the gun title and body, then the click arrives.
        write("_level0.gunTitleTxt.text", "Micro Uzis", wm, 202000);
        write("_level0.gunBodyTxt.text", "Fast and light.", wm, 202000);
        Check(ev(UiEvent::kChange, wm, "_level0.uziBtn", 202001) == "Micro Uzis. Fast and light.",
              "choosing: the new title and description");
        flash["_level0.gunTitleTxt.text"] = text("Micro Uzis");
        Check(ev(UiEvent::kNavigate, wm, "_level0.gunsBtn", 202500) == "Pistols", "other gun: not equipped now");
        Check(ev(UiEvent::kNavigate, wm, "_level0.uziBtn", 203000) == "Micro Uzis, equipped",
              "the game's title learned as the name; equipped");
        Check(ev(UiEvent::kChange, wm, "_level0.gunsBtn", 204000).empty(), "a click without new text: silent");
        // Outfits: named by index; locked ones read as unavailable.
        int um_ = 0;
        flash["_level0.unlockBtn4.disabled"] = boolean(false);
        Check(ev(UiEvent::kFocusedSet, &um_, "_level0.unlockBtn4", 205000) == "Unlocks. Horror outfit", "outfit name");
        flash["_level0.unlockBtn2.disabled"] = boolean(true);
        Check(ev(UiEvent::kNavigate, &um_, "_level0.unlockBtn2", 205500) == "Spartan outfit, unavailable",
              "locked outfit");
        menu_reader::Reset();
    }

    // N2 (overnight): gameplay text.
    {
        menu_reader::Reset();
        int hud_ = 0;
        void* hud = &hud_;
        Check(write("_level0.hintText.text", "Hold guard to throw dogs aside", hud, 300000) ==
                  "Loading. Tip: Hold guard to throw dogs aside.",
              "loading tip");
        Check(write("_level0.tutorial.help.helpText.text", "Perform combos by switching weapons", hud, 301000) ==
                  "Tutorial: Perform combos by switching weapons.",
              "tutorial hint");
        Check(write("_level0.tutorial.help.helpText.text", "Perform combos by switching weapons", hud, 301016).empty(),
              "rewritten every frame: once");
        Check(write("_level0.tutorial.help.helpText.text", "Perform combos by switching weapons", hud, 340000) ==
                  "Tutorial: Perform combos by switching weapons.",
              "the same hint again after a quiet spell: spoken");
        Check(write("_level0.tutorial.help.helpText.text", "", hud, 341000).empty(), "cleared: silent");
        Check(write("_level0.HUD.unlockTxt.text", "You unlocked a new weapon!", hud, 342000) ==
                  "You unlocked a new weapon!",
              "unlock banner");
        Check(write("_level0.HUD.player1.grenadeTxt.text", "3", hud, 343000).empty(), "other fields: silent");
        // The new-costume pop-up: its text fields are read with its first focus.
        int cd_ = 0;
        flash["_level0.costumeName.text"] = text("Horror");
        flash["_level0.costumeChangeText.text"] = text("Change your costume under the Unlocks option in the Pause Menu.");
        flash["_level0.continueBtn.label"] = text("Continue");
        Check(ev(UiEvent::kFocusedSet, &cd_, "_level0.continueBtn", 344000) ==
                  "Horror. Change your costume under the Unlocks option in the Pause Menu. Continue",
              "costume pop-up: name and text before the button");
        flash.erase("_level0.costumeName.text");
        flash.erase("_level0.costumeChangeText.text");
        menu_reader::Reset();
    }

    // N3 (overnight): How to Play pages and the read-screen key.
    {
        menu_reader::Reset();
        int hp_ = 0;
        void* hp = &hp_;
        flash["_level0.nextBtn.label"] = text("next");
        flash["_level0.nameTxt.text"] = text("Air Combos");
        // Our own sample in the extracted-data format (the real file comes from the user's install).
        Check(ui_text::LoadFromString("# sample\n[howtoplayscreencombos.gfx]\nkey=Air Combos\n"
                                      "text=Hold down and attack\ntext=Switch weapons!\n[other.gfx]\nkey=Label\n") == 2,
              "ui_text: two sections parsed");
        Check(ev(UiEvent::kFocusedSet, hp, "_level0.nextBtn", 400000) ==
                  "How to play. Air Combos. Hold down and attack. Switch weapons! next",
              "How to Play opens: title, page name, the page's drawn text, button");
        flash["_level0.nameTxt.text"] = text("Grapples");  // the next frame shows another page
        Check(ev(UiEvent::kChange, hp, "_level0.nextBtn", 401000).empty(), "Next: nothing at once");
        Check(menu_reader::OnFrame(401100, read).empty(), "not yet (100 ms)");
        Check(menu_reader::OnFrame(401150, read) == "Grapples.", "150 ms later: the new page's name");
        Check(ev(UiEvent::kChange, hp, "_level0.nextBtn", 402000).empty(), "Next again");
        Check(menu_reader::OnFrame(402200, read).empty(), "same page name (last page): silent");
        // A page turn that opened another screen: the old page's name is not read (live test bug).
        int hp2_ = 0;
        Check(ev(UiEvent::kChange, hp, "_level0.nextBtn", 402500).empty(), "Next opens another screen");
        ev(UiEvent::kFocusedSet, &hp2_, "_level0.nextBtn", 402501);
        Check(menu_reader::OnFrame(402700, read).empty(), "the old page's delayed read is dropped");
        ev(UiEvent::kFocusedSet, hp, "_level0.nextBtn", 402800);  // back to the first page's movie
        // Read screen: title, the page text, the focus.
        menu_reader::RequestReadScreen();
        Check(menu_reader::OnFrame(403000, read) == "How to play. Grapples. Focus: next.", "read screen: How to Play");
        flash.erase("_level0.nameTxt.text");
        // Pause menu with stats.
        int pm2_ = 0;
        void* pm2 = &pm2_;
        flash["_level0.Stats.longestCombo.text"] = text("79");
        flash["_level0.Stats.grenadeKills.text"] = text("237");
        flash["_level0.Stats.weaponName0.text"] = text("Chainsaw Kills");
        flash["_level0.Stats.weaponKills0.text"] = text("17");
        flash["_level0.Stats.weaponName7.text"] = text(" Kills");
        flash["_level0.Stats.weaponKills7.text"] = text("0");
        ev(UiEvent::kFocusedSet, pm2, "_level0.resumeBtn", 404000);
        menu_reader::RequestReadScreen();
        Check(menu_reader::OnFrame(405000, read) ==
                  "Pause menu. Longest combo 79. Grenade kills 237. Chainsaw Kills 17. Focus: Resume Game.",
              "read screen: pause menu stats (empty weapon slots skipped)");
        // Nothing focused yet.
        menu_reader::Reset();
        menu_reader::RequestReadScreen();
        Check(menu_reader::OnFrame(406000, read) == "Nothing to read here", "read screen with no focus");
        menu_reader::Reset();
    }

    // N4 (overnight): list boxes (clearItems / addItem / setSelectedIndex), e.g. the Controls bindings.
    {
        menu_reader::Reset();
        int cm_ = 0;
        void* cm = &cm_;
        const std::string lb = "_level0.listBox";
        auto inv2 = [&](const char* m, const std::vector<std::string>& args, unsigned ms) {
            return menu_reader::OnInvoke(lb, m, args, "", ms, nullptr, cm);
        };
        inv2("clearItems", {}, 500000);
        inv2("addItem", {"Move Left", "A"}, 500000);
        inv2("addItem", {"Move Right", "D"}, 500000);
        inv2("addItem", {"Jump", "Space", "3"}, 500000);
        flash["_level0.btnPrevious.label"] = text("Previous Controller");
        ev(UiEvent::kFocusedSet, cm, "_level0.btnPrevious", 500100);
        Check(inv2("getItem", {"0"}, 500200).empty(), "getItem on a list box: silent, no polling");
        menu_reader::RequestReadScreen();
        Check(menu_reader::OnFrame(501000, read) ==
                  "Controls. List: Move Left: A; Move Right: D; Jump: Space. Focus: Previous Controller.",
              "read screen: the list's items");
        Check(inv2("setSelectedIndex", {"1"}, 502000) == "Move Right: D, 2 of 3", "the game selects an item: spoken");
        Check(inv2("setSelectedIndex", {"1"}, 502100).empty(), "same index again: silent");
        Check(inv2("setSelectedIndex", {"-1"}, 502200).empty(), "no selection (-1): silent");
        menu_reader::Reset();
    }

    // B1 (morning test fixes).
    {
        menu_reader::Reset();
        // B1f: the key bindings list: focus, then change("_level0.listBox", <row>) per arrow press.
        int km_ = 0;
        void* km = &km_;
        const std::string lb = "_level0.listBox";
        auto inv3 = [&](const char* m, const std::vector<std::string>& args, unsigned ms) {
            return menu_reader::OnInvoke(lb, m, args, "", ms, nullptr, km);
        };
        auto change = [&](int row, unsigned ms) {
            const FlashValue v = number(row);
            return menu_reader::OnEvent(UiEvent::kChange, km, lb, ms, read, &v);
        };
        inv3("clearItems", {}, 600000);
        inv3("addItem", {"controls/LEFT.png", "Move Left", "Left"}, 600000);
        inv3("addItem", {"controls/RIGHT.png", "Move Right", "Right"}, 600000);
        inv3("addItem", {"", "Jump", "Space"}, 600000);
        inv3("addItem", {"", "Previous Gun", "1"}, 600000);
        flash["_level0.btnPrevious.label"] = text("Previous Controller");
        ev(UiEvent::kFocusedSet, km, "_level0.btnPrevious", 600100);
        Check(ev(UiEvent::kFocusIn, km, lb.c_str(), 601000) == "Key bindings list", "focus on the list");
        Check(change(0, 601000) == "Key bindings list, Move Left: Left, 1 of 4",
              "its first row in the same instant: one utterance");
        Check(change(1, 602000) == "Move Right: Right, 2 of 4", "arrow down: the next row");
        Check(change(1, 602500).empty(), "same row again: silent");
        Check(change(3, 602600) == "Previous Gun: 1, 4 of 4", "a digit key is kept (B2)");
        Check(change(1, 602700) == "Move Right: Right, 2 of 4", "back to row 2");
        // A rebind: the game rebuilds the list with "-Select New Input-", then with the new key.
        inv3("clearItems", {}, 603000);
        inv3("addItem", {"controls/LEFT.png", "Move Left", "Left"}, 603000);
        inv3("addItem", {"controls/RIGHT.png", "Move Right", "-Select New Input-"}, 603000);
        inv3("addItem", {"", "Jump", "Space"}, 603000);
        Check(menu_reader::OnFrame(603050, read).empty(), "not yet");
        Check(menu_reader::OnFrame(603100, read) == "Move Right: -Select New Input-, 2 of 3", "rebind: waiting for input");
        inv3("clearItems", {}, 604000);
        inv3("addItem", {"controls/LEFT.png", "Move Left", "Left"}, 604000);
        inv3("addItem", {"controls/RIGHT.png", "Move Right", "D"}, 604000);
        inv3("addItem", {"", "Jump", "Space"}, 604000);
        Check(menu_reader::OnFrame(604100, read) == "Move Right: D, 2 of 3", "rebind: the new key");
        inv3("clearItems", {}, 605000);  // a rebuild with nothing changed: silent
        inv3("addItem", {"controls/LEFT.png", "Move Left", "Left"}, 605000);
        inv3("addItem", {"controls/RIGHT.png", "Move Right", "D"}, 605000);
        Check(menu_reader::OnFrame(605100, read).empty(), "rebuilt without change: silent");

        // B1b: choosing a weapon rewrites both slots; only its own is spoken.
        int wm2_ = 0;
        void* wm2 = &wm2_;
        flash["_level0.meleeTitleTxt.text"] = text("Chainsaw");
        flash["_level0.gunTitleTxt.text"] = text("Shotgun");
        ev(UiEvent::kFocusedSet, wm2, "_level0.sawBtn", 610000);
        write("_level0.gunTitleTxt.text", "Shotgun", wm2, 611000);
        write("_level0.gunBodyTxt.text", "Blow through opponents at short range.", wm2, 611000);
        write("_level0.meleeTitleTxt.text", "Chainsaw", wm2, 611000);
        write("_level0.meleeBodyTxt.text", "Default heavy weapon.", wm2, 611000);
        Check(ev(UiEvent::kChange, wm2, "_level0.sawBtn", 611001) == "Chainsaw. Default heavy weapon.",
              "choosing the chainsaw: only the melee slot");
        Check(menu_reader::LastLongMessage() == "Chainsaw. Default heavy weapon.", "F8: the description is repeatable");
        // B1b: opening the screen: the titles are written just after the focus -> "equipped" follows.
        int wm3_ = 0;
        void* wm3 = &wm3_;
        flash["_level0.meleeTitleTxt.text"] = text("");  // not written yet at focus time
        Check(ev(UiEvent::kFocusedSet, wm3, "_level0.chainsBtn", 620000) == "Weapons. Chain Fists", "focus first");
        Check(write("_level0.meleeTitleTxt.text", "Chain Fists", wm3, 620001) == "Weapons. Chain Fists, equipped",
              "the title arrives: re-announced with equipped");
        Check(write("_level0.gunTitleTxt.text", "Pistols", wm3, 620001).empty(), "the other slot: silent");
        Check(write("_level0.meleeTitleTxt.text", "Chain Fists", wm3, 620002).empty(), "equipped once");

        // B1e: F8 repeats long messages only.
        write("_level0.tutorial.help.helpText.text", "Block with caps lock", wm3, 630000);
        flash["_level0.controls.spBtn.label"] = text("Play the Story");
        ev(UiEvent::kFocusIn, wm3, "_level0.controls.spBtn", 630500);
        Check(menu_reader::LastLongMessage() == "Tutorial: Block with caps lock.",
              "F8: the tutorial, not the menu item spoken after it");
        menu_reader::Reset();
        flash.erase("_level0.meleeTitleTxt.text");
        flash.erase("_level0.gunTitleTxt.text");
    }

    // 2-3 level select: cells from AddCell, selection from SelectCell / SelectNext / SelectPrev.
    using Args = std::vector<std::string>;
    Check(menu_reader::CellName({"campaign_1a_wrestlingring", "The Ring", "levels/small.dds", "1", "0.5"}) == "The Ring",
          "cell name: first readable string");
    Check(menu_reader::CellName({"IDS_ONE", "x"}) == "First & best", "cell name: IDS key translated");
    Check(menu_reader::CellDetails({"Ride", "s.dds", "l.dds", "0", "45.51"}) == "completion time 46 seconds",
          "details: seconds only");
    Check(menu_reader::CellDetails({"Ride", "s.dds", "l.dds", "0", "60"}) == "completion time 1 minute",
          "details: exactly one minute");
    Check(menu_reader::CellDetails({"Ride", "s.dds", "l.dds", "0", "-1"}) == "no completion time", "details: -1");
    Check(menu_reader::CellDetails({"Ride", "s.dds", "l.dds", "1", "-1"}) == "locked", "details: locked flag");
    Check(menu_reader::CellDetails({"Ride", "s.dds"}).empty(), "details: other cell shapes: none");
    Check(menu_reader::CellName({"campaign_1a", "levels/a.dds"}) == "Campaign_1a", "cell name: fallback");
    std::string answer;  // what GetSelectedIndex returns
    const menu_reader::Asker ask = [&](const std::string& m) { return m == "GetSelectedIndex" ? answer : std::string(); };
    const std::string strip = "_level0.FilmStrip.LevelSelector";
    unsigned clock_ms = 30000;
    auto inv = [&](const char* method, const Args& args) {
        clock_ms += 200;
        return menu_reader::OnInvoke(strip, method, args, "", clock_ms, ask);
    };
    auto poll_at = [&](unsigned ms) { return menu_reader::OnInvoke(strip, "IsSelected", {}, "false", ms, ask); };
    Check(inv("SelectNext", {}).empty(), "no cells yet: silent");
    inv("Clear", {});
    inv("AddCell", {"Alpha Level", "levels/small_a.dds", "levels/a.dds", "0", "286.035"});
    inv("AddCell", {"Beta Level", "levels/small_b.dds", "levels/b.dds", "0", "-1"});
    inv("AddCell", {"Gamma Level", "levels/small_c.dds", "levels/c.dds", "0", "3725.4"});
    Check(inv("SelectCell", {"1", "1"}) == "Level select. Beta Level, no completion time, 2 of 3", "SelectCell: the argument's cell, with the screen title");
    answer = "2";
    Check(inv("SelectNext", {}) == "Gamma Level, completion time 1 hour 2 minutes 5 seconds, 3 of 3", "SelectNext: GetSelectedIndex's answer");
    answer = "2";
    Check(inv("SelectNext", {}).empty(), "SelectNext at the end: silent");
    answer = "2";  // GetSelectedIndex not updated yet: fall back to tracking
    Check(inv("SelectPrev", {}) == "Beta Level, no completion time, 2 of 3", "SelectPrev with a stale answer: tracked");
    answer = "";
    Check(inv("SelectPrev", {}) == "Alpha Level, completion time 4 minutes 46 seconds, 1 of 3", "SelectPrev with no answer: tracked");
    Check(inv("SelectPrev", {}).empty(), "SelectPrev at the start: silent");
    // Keyboard scrolling: no Select* call; the per-frame IsSelected poll asks GetSelectedIndex.
    answer = "0";
    Check(poll_at(40000).empty(), "poll: selection unchanged: silent");
    answer = "2";
    Check(poll_at(40150) == "Gamma Level, completion time 1 hour 2 minutes 5 seconds, 3 of 3", "poll: selection moved: spoken");
    answer = "1";
    Check(poll_at(40200).empty(), "poll: 50 ms later: not asked yet");
    Check(poll_at(40250) == "Beta Level, no completion time, 2 of 3", "poll: 100 ms later: spoken");
    answer = "undefined";
    Check(poll_at(40400).empty(), "poll: unusable answer: silent");
    answer = "1";
    Check(poll_at(40500).empty(), "poll: same cell again: silent");
    inv("Clear", {});
    Check(inv("SelectNext", {}).empty(), "after Clear: silent");
    Check(poll_at(41000).empty(), "after Clear: poll silent");

    if (argc > 1) {
        wchar_t root[MAX_PATH];
        MultiByteToWideChar(CP_ACP, 0, argv[1], -1, root, MAX_PATH);
        const size_t n = localization::Load(std::wstring(root) + L"\\data\\bootstrap\\localization\\localization_en.xml");
        printf("real file: %u strings\n", static_cast<unsigned>(n));
        Check(n >= 19, "real file: at least the 19 keys seen");
        const char* keys[] = {"IDS_CAMPAIGN", "IDS_MULTIPLAYER", "IDS_ACHIEVEMENTS", "IDS_HELPANDOPTIONS",
                              "IDS_DIFFICULTY_NORMAL", "IDS_DIFFICULTY_HARD", "IDS_DIFFICULTY_MADNESS"};
        bool all = true;
        for (const char* k : keys) {
            const std::string t = localization::Translate(k);
            printf("  %s -> %s\n", k, t.c_str());
            if (t == k || t.empty()) all = false;
        }
        Check(all, "real file: the menu keys seen in 1c-3 all translate");
    }
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
