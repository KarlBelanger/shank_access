// B10-2: the traversal graph for waypoint mode (host tool, never deployed; its output is: bin/shank_access_paths.txt).
// For every level in the geometry file: places (floors "s<id>", features "f<index>", each side of a pole
// "p<index>L/R", climbable walls "w<index>") and the moves between them:
//   - every modelled jump / fall from sampled spots (as traversal_audit: floors every 64 px, walking off drops, wall
//     clings, pole sides, swing release angles, bar hangs, wall-run rows; letting go of a hold), with the level's
//     walls, ceilings and floors in the way, onto features, climbable walls and floors;
//   - running up a climbable wall at a floor's end; climbing over a climbable wall's top onto the floor there;
//     steps and ledges up to 3 tiles (he climbs them himself);
//   - sliding / climbing down a pole to the floor below its bottom;
//   - the pole "bounce": jumping away from a pole with a wall close on that side lands him on its other side (1-c).
// One line per (from, to), the first move found: "edge <from> <to> <move> <x> <y> <R|L> <x_lo> <x_hi> <y_lo> <y_hi>"
// (where it starts; B10b: the range of sampled spots the same move works from).
// Usage: path_graph.exe <shank_access_geometry.txt> <out.txt> [level [--merge]]   (--merge: only that level, the others kept, B42-5)
#include <windows.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"

namespace {

using jump_model::Target;

enum Kind { kGround, kWalkOff, kCling, kPole, kSwing, kBar, kWallRun, kDrop, kSlide, kSlideOff, kRunUp };

// B12-1: a slippery slope's downhill way: +1 right, -1 left, 0 = not slippery.
// A surface tagged both ways (3-c's roof ridge) is left as a floor: the artifact has no per-segment tags.
int Downhill(const level_geometry::Surface& s) {
    const bool r = s.tags.find("slipperyright") != std::string::npos, l = s.tags.find("slipperyleft") != std::string::npos;
    return r == l ? 0 : r ? 1 : -1;
}

struct Origin {
    Kind kind;
    float x, y;
    bool right;
    std::string node;  // the place he's in
    int feature;       // the feature he's on (-1 = none): not a target from here
};

constexpr float kSample = 64.f;
constexpr float kMaxAcross = 1700.f;
constexpr float kMaxRise = 700.f;
constexpr bool kSlideIntercept = true;  // (B48d)
constexpr bool kDropThrough = false;  // B48d: dropping through a one-way floor does not exist in the game
constexpr float kClimbMaxPx = 3 * 64.f;  // steps and ledges he climbs himself (the user, B9b)
// B47c-1: the air warp onto a swing point off a floor's end (seen: 260..384 across, 227..320 up)
// (B48b: up to 480 across: the logs caught him to 476 at a run, 1-a s26 / s35 at a sprint; walking off slowly fell)
constexpr float kWarpSwingMinDx = 192.f, kWarpSwingMaxDx = 480.f, kWarpSwingMinUp = 192.f, kWarpSwingMaxUp = 352.f;
constexpr float kWarpWallMaxDx = 192.f, kWarpWallMaxUp = 128.f;  // B47c-6: the run off an edge into a climbable wall (seen: 128 across, bottom 64 up)

std::string S(int id) { return "s" + std::to_string(id); }
std::string F(int i) { return "f" + std::to_string(i); }
std::string P(int i, bool right) { return "p" + std::to_string(i) + (right ? "R" : "L"); }
std::string W(int i) { return "w" + std::to_string(i); }

bool ToTarget(const level_geometry::Feature& f, Target* t) {
    const auto& p = f.points;
    if (p.empty()) return false;
    const auto& q = p.size() > 1 ? p[1] : p[0];
    if (f.type == "swing_point") *t = Target{jump_model::kSwing, p[0].first, p[0].second, 0, 0};
    else if (f.type == "pole" || f.type == "slide_pole") *t = Target{jump_model::kPole, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "shimmy_line") *t = Target{jump_model::kShimmy, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "wallrun_zone") *t = Target{jump_model::kWallZone, p[0].first, p[0].second, q.first, q.second};
    else return false;
    t->slide = f.type == "slide_pole";
    return true;
}

std::vector<float> Steps(float a, float b) {
    std::vector<float> v;
    if (b < a) std::swap(a, b);
    for (float x = a; x < b; x += kSample) v.push_back(x);
    v.push_back(b);
    return v;
}

std::vector<Origin> Origins() {
    std::vector<Origin> o;
    for (const level_geometry::Surface& s : level_geometry::Surfaces()) {
        for (size_t i = 0; i + 1 < s.points.size(); ++i) {
            const auto& a = s.points[i];
            const auto& b = s.points[i + 1];
            if (b.first - a.first < 16.f) continue;
            for (float x : Steps(a.first + 8, b.first - 8)) {
                const float y = a.second + (x - a.first) / (b.first - a.first) * (b.second - a.second) + jump_model::kFeet;
                if (Downhill(s)) {  // B12-1: sliding: the long jump downhill only
                    o.push_back(Origin{kSlide, x, y, Downhill(s) > 0, S(s.id), -1});
                    continue;
                }
                o.push_back(Origin{kGround, x, y, true, S(s.id), -1});
                o.push_back(Origin{kGround, x, y, false, S(s.id), -1});
            }
        }
        if (s.points.size() < 2) continue;
        if (Downhill(s)) {  // B12-1: off the low end at the slide's speed; never off the high end
            const auto& e = Downhill(s) > 0 ? s.points.back() : s.points.front();
            const level_geometry::End& end = Downhill(s) > 0 ? s.right : s.left;
            if (end.type == level_geometry::End::kDrop)
                o.push_back(Origin{kSlideOff, e.first + 16.f * Downhill(s), e.second + jump_model::kFeet, Downhill(s) > 0, S(s.id), -1});
            continue;
        }
        if (s.left.type == level_geometry::End::kDrop)
            o.push_back(Origin{kWalkOff, s.points.front().first - 16, s.points.front().second + jump_model::kFeet, false, S(s.id), -1});
        if (s.right.type == level_geometry::End::kDrop)
            o.push_back(Origin{kWalkOff, s.points.back().first + 16, s.points.back().second + jump_model::kFeet, true, S(s.id), -1});
    }
    const auto& walls = level_geometry::Walls();
    for (size_t i = 0; i < walls.size(); ++i) {
        const level_geometry::Wall& w = walls[i];
        if (!w.climbable) continue;
        const float x = w.faces_left ? w.x - 32 : w.x + 32;
        for (float y : Steps(w.y1 + 32, w.y2)) {
            o.push_back(Origin{kCling, x, y, !w.faces_left, W(static_cast<int>(i)), -1});
            // B41d: the jump while running up it only as high as a run up gets (the live cue: only while running up)
            if (y - w.y1 <= jump_model::kRunUpMaxPx) o.push_back(Origin{kRunUp, x, y, !w.faces_left, W(static_cast<int>(i)), -1});
            o.push_back(Origin{kDrop, x, y, !w.faces_left, W(static_cast<int>(i)), -1});
        }
    }
    const auto& features = level_geometry::Features();
    for (size_t i = 0; i < features.size(); ++i) {
        Target t;
        if (!ToTarget(features[i], &t)) continue;
        const int id = static_cast<int>(i);
        switch (t.kind) {
            case jump_model::kPole:
                for (float y : Steps(t.y1, t.y2)) {
                    o.push_back(Origin{kPole, t.x1 - 80, y, false, P(id, false), id});
                    o.push_back(Origin{kPole, t.x1 + 80, y, true, P(id, true), id});
                    // B12-3: letting go (walldrop: Down + Jump, ON_WALL_REACTIONS, on poles and slide poles)
                    o.push_back(Origin{kDrop, t.x1 - 80, y, false, P(id, false), id});
                    o.push_back(Origin{kDrop, t.x1 + 80, y, true, P(id, true), id});
                }
                break;
            case jump_model::kSwing:
                for (int deg = -60; deg <= 60; deg += 20) {
                    const float a = deg * 3.14159265f / 180.f;
                    const float x = t.x1 + jump_model::kSwingRadius * std::sin(a);
                    const float y = t.y1 - jump_model::kSwingRadius * std::cos(a);
                    o.push_back(Origin{kSwing, x, y, true, F(id), id});
                    o.push_back(Origin{kSwing, x, y, false, F(id), id});
                    if (deg == 0) {
                        o.push_back(Origin{kDrop, x, y, true, F(id), id});
                        o.push_back(Origin{kDrop, x, y, false, F(id), id});
                    }
                }
                break;
            case jump_model::kShimmy: {
                const int n = std::max(1, static_cast<int>(std::hypot(t.x2 - t.x1, t.y2 - t.y1) / kSample));
                for (int k = 0; k <= n; ++k) {
                    const float u = static_cast<float>(k) / n;
                    const float x = t.x1 + u * (t.x2 - t.x1), y = t.y1 + u * (t.y2 - t.y1) - jump_model::kHangUp;
                    o.push_back(Origin{kBar, x, y, true, F(id), id});
                    o.push_back(Origin{kBar, x, y, false, F(id), id});
                    o.push_back(Origin{kDrop, x, y, true, F(id), id});
                }
                break;
            }
            case jump_model::kWallZone:
                for (float y = t.y1 + 64; y <= t.y2; y += 96) {
                    for (float x : Steps(t.x1, t.x2)) {
                        o.push_back(Origin{kWallRun, x, y, true, F(id), id});
                        o.push_back(Origin{kWallRun, x, y, false, F(id), id});
                    }
                }
                break;
            default:
                break;
        }
    }
    return o;
}

const char* JumpName(jump_model::Jump j) {
    switch (j) {
        case jump_model::kStanding: return "standing_jump";
        case jump_model::kLong: return "long_jump";
        case jump_model::kWallJump: return "wall_jump";
        case jump_model::kSwingJump: return "swing_jump";
        case jump_model::kBarJump: return "bar_jump";
        case jump_model::kPoleJump: return "pole_jump";
        case jump_model::kUpJump: return "jump_up";
        case jump_model::kRunUpJump: return "run_up_jump";
        case jump_model::kWallRunJump: return "wall_run_jump";
        case jump_model::kWalkOff: return "walk_off";
        default: return "";
    }
}

jump_model::Jump Try(const Origin& o, const Target& t) {
    switch (o.kind) {
        case kGround: return jump_model::Reach(t, o.x, o.y, o.right);
        case kWalkOff: return jump_model::ReachWalkingOff(t, o.x, o.y, o.right);  // (B41-6)
        case kDrop: return jump_model::ReachFalling(t, o.x, o.y, o.right) != jump_model::kNone ? jump_model::kWalkOff : jump_model::kNone;
        case kSlide: return jump_model::ReachSliding(t, o.x, o.y, o.right);
        case kSlideOff: return jump_model::ReachSlidingOff(t, o.x, o.y, o.right);
        case kCling: return jump_model::ReachFromWall(t, o.x, o.y, o.right);
        case kRunUp: return jump_model::ReachFromWallRunningUp(t, o.x, o.y, o.right);  // (B41d)
        case kPole: return jump_model::ReachFromPole(t, o.x, o.y, o.right);
        case kSwing: return jump_model::ReachFromSwing(t, o.x, o.y, o.right);
        case kBar: return jump_model::ReachFromBar(t, o.x, o.y, o.right);
        case kWallRun: {
            const jump_model::Jump j = jump_model::ReachFromWallRun(t, o.x, o.y, o.right);
            if (j != jump_model::kNone) return j;
            // B41d: the long jump only near the zone's end he's running toward (as the live cue: wallruntofall)
            Target zone;
            const auto& fs = level_geometry::Features();
            if (o.feature < 0 || o.feature >= static_cast<int>(fs.size()) || !ToTarget(fs[o.feature], &zone)) return jump_model::kNone;
            const float left_px = o.right ? std::max(zone.x1, zone.x2) - o.x : o.x - std::min(zone.x1, zone.x2);
            if (left_px > jump_model::kWallRunEndWindowPx) return jump_model::kNone;
            return jump_model::Reach(t, o.x, o.y, o.right) == jump_model::kLong ? jump_model::kLong : jump_model::kNone;
        }
    }
    return jump_model::kNone;
}

struct Edge {
    std::string move;
    float x, y;
    bool right;
    float x_lo, x_hi, y_lo, y_hi;  // B10b: every sampled spot this move (same way) was found from
};
using Edges = std::map<std::pair<std::string, std::string>, Edge>;

// B46 (the user: "Any walk off that only works at one specific speed should be considered extremely risky"): the speeds off
// a floor's end (a tap to a sprint) at which a walk-off reaches its target: (from, to) -> (lowest, highest, how many).
struct SpeedWindow {
    float lo = 0, hi = 0;
    int n = 0;
};
std::map<std::pair<std::string, std::string>, SpeedWindow> g_walk_windows;
// B47c-7: (from, slide pole node) -> the highest he catches the slide pole on that arrival
std::map<std::pair<std::pair<std::string, std::string>, std::string>, float> g_slide_catch;  // ((from, to), move) -> catch
constexpr float kSlideCatchSlackPx = 32.f;
constexpr float kWindowFromVx = 96.f, kWindowToVx = 768.f, kWindowStepVx = 32.f;  // START_WALK 1 MPS .. SPRINT 8 MPS

SpeedWindow WalkOffWindow(const Target& t, float x, float y, bool right) {
    SpeedWindow w;
    for (float v = kWindowFromVx; v <= kWindowToVx + 0.5f; v += kWindowStepVx) {
        bool pit = false;
        if (!jump_model::ReachAtSpeed(t, x, y, right ? v : -v, 0.f, &pit)) continue;
        if (!w.n) w.lo = v;
        w.hi = v;
        ++w.n;
    }
    return w;
}

// Moves on foot (no jump) are preferred over a jump between the same two places.
bool OnFoot(const std::string& move) {
    return move == "run_up_wall" || move == "climb" || move == "climb_over" || move == "slide_down" || move == "climb_down" ||
           move == "shimmy_along" || move == "run_across" || move == "run_off" ||  // (B47c-1)
           move == "climb_up" || move == "walk_off" || move == "slide_off" ||  // B15-10: no jump needed
           move == "switch_sides" || move == "drop_through";
}

void Add(Edges* e, const std::string& from, const std::string& to, const char* move, float x, float y, bool right) {
    if (from == to || !move || !*move) return;
    const auto key = std::make_pair(from, to);
    const auto it = e->find(key);
    if (it == e->end()) {
        e->emplace(key, Edge{move, x, y, right, x, x, y, y});
    } else if (OnFoot(move) && !OnFoot(it->second.move)) {
        it->second = Edge{move, x, y, right, x, x, y, y};
    } else if (std::strcmp(move, "drop") == 0 && from[0] == 'f' && !OnFoot(it->second.move) && it->second.move != "drop") {
        // (B41c: off a shimmy line, bar or swing point only; from a wall the wall jump is how he goes (1-c's w108 to the
        // shimmy line f21: "drop" there meant letting go and steering 350 px))
        // B41-3 (1-c mark 3: "jump up, then fall to a floor" from the shimmy line; the user: "no jump needed, went straight
        // from shimmy to wall slide to floor"): letting go beats a jump to the same place.
        it->second = Edge{move, x, y, right, x, x, y, y};
    } else if (it->second.right == right && (it->second.move == move || (!OnFoot(move) && !OnFoot(it->second.move)))) {
        // (any jump between the same places the same way widens where it starts: a plain wall jump higher up, a
        // run-up jump lower down)
        Edge& d = it->second;
        d.x_lo = std::min(d.x_lo, x);
        d.x_hi = std::max(d.x_hi, x);
        d.y_lo = std::min(d.y_lo, y);
        d.y_hi = std::max(d.y_hi, y);
    }
}

int FloorEndNear(float x, float y, float within);  // below

// The floor he climbs over onto at a climbable wall's top, or -1. B10b: only a floor on the wall's far (solid) side;
// one that sticks out over his side is a ceiling he meets climbing up (the B10 log: 1-c's wall under the health
// platform, x 16789, y 1600..2880).
int OverTop(const level_geometry::Wall& w, const std::vector<level_geometry::Surface>& surfaces) {
    const int top = FloorEndNear(w.x, w.y2, 100.f);
    for (const level_geometry::Surface& f : surfaces) {
        if (f.id != top || f.points.size() < 2) continue;
        if (w.faces_left ? f.points.back().first > w.x + 16.f : f.points.front().first < w.x - 16.f) return top;
    }
    return -1;
}

// The floor he stands on at (x, y position), or -1.
int FloorAt(float x, float y) {
    const level_geometry::Surface* s = level_geometry::SurfaceUnder(x, y);
    return s ? s->id : -1;
}

// The floor with an end point near (x, y) (a floor's y), or -1.
int FloorEndNear(float x, float y, float within) {
    int best = -1;
    float best_d = within;
    for (const level_geometry::Surface& s : level_geometry::Surfaces()) {
        if (s.points.size() < 2) continue;
        for (const auto& p : {s.points.front(), s.points.back()}) {
            const float d = std::hypot(p.first - x, p.second - y);
            if (d < best_d) {
                best_d = d;
                best = s.id;
            }
        }
    }
    return best;
}

Edges Build() {
    Edges edges;
    const std::vector<Origin> origins = Origins();
    const auto& features = level_geometry::Features();
    const auto& walls = level_geometry::Walls();
    const auto& surfaces = level_geometry::Surfaces();
    // Jumps and falls onto features, climbable walls and floors.
    struct Goal {
        Target t;
        int feature;     // -1 = not a feature
        int pole;        // a pole's feature index (its side depends on where he comes from), else -1
        std::string node;
    };
    std::vector<Goal> goals;
    for (size_t i = 0; i < features.size(); ++i) {
        Target t;
        if (!ToTarget(features[i], &t)) continue;
        goals.push_back(Goal{t, static_cast<int>(i), t.kind == jump_model::kPole ? static_cast<int>(i) : -1, F(static_cast<int>(i))});
    }
    for (size_t i = 0; i < walls.size(); ++i) {
        if (!walls[i].climbable) continue;
        goals.push_back(Goal{Target{jump_model::kWall, walls[i].x, walls[i].y1, walls[i].x, walls[i].y2}, -1, -1, W(static_cast<int>(i))});
    }
    for (const level_geometry::Surface& s : surfaces) {
        for (size_t k = 0; k + 1 < s.points.size(); ++k) {
            const auto& a = s.points[k];
            const auto& b = s.points[k + 1];
            if (b.first - a.first < 16.f || level_geometry::InPit((a.first + b.first) / 2, (a.second + b.second) / 2)) continue;
            Target land{jump_model::kLanding, a.first, a.second, b.first, b.second};
            land.oneway = s.tags.find("skinny") != std::string::npos;  // B12-2
            goals.push_back(Goal{land, -1, -1, S(s.id)});
        }
    }
    for (const Goal& g : goals) {
        const float lo_x = std::min(g.t.x1, g.t.kind == jump_model::kSwing ? g.t.x1 : g.t.x2);
        const float hi_x = std::max(g.t.x1, g.t.kind == jump_model::kSwing ? g.t.x1 : g.t.x2);
        const float lo_y = std::min(g.t.y1, g.t.kind == jump_model::kSwing ? g.t.y1 : g.t.y2);
        for (const Origin& o : origins) {
            if (g.feature >= 0 && o.feature == g.feature) continue;
            std::string to = g.node;
            if (g.pole >= 0) to = P(g.pole, o.x > (g.t.x1 + g.t.x2) / 2);  // he catches it on the side he comes from
            if (to == o.node) continue;
            const auto have = edges.find(std::make_pair(o.node, to));  // B10b: tried on for the move's range, unless on foot
            if (have != edges.end() && OnFoot(have->second.move)) continue;
            // A wall is only caught from its open side.
            if (g.t.kind == jump_model::kWall) {
                const level_geometry::Wall* w = nullptr;
                for (const auto& ww : walls) {
                    if (ww.x == g.t.x1 && ww.y1 == g.t.y1 && ww.y2 == g.t.y2) w = &ww;
                }
                if (w && (w->faces_left ? o.x > w->x : o.x < w->x)) continue;
            }
            const float gap = o.x < lo_x ? lo_x - o.x : o.x > hi_x ? o.x - hi_x : 0.f;
            if (gap > kMaxAcross || lo_y - o.y > kMaxRise) continue;
            // B15-7: every plain launch first; the platformup jump only when none reaches it
            jump_model::AllowPlatformUp(false);
            jump_model::Jump j = Try(o, g.t);
            jump_model::AllowPlatformUp(true);
            if (j == jump_model::kNone && g.t.oneway) j = Try(o, g.t);
            if (j == jump_model::kNone) continue;
            const char* move = o.kind == kDrop ? "drop" : o.kind == kSlideOff ? "slide_off" : JumpName(j);
            if (jump_model::LastWasPlatformUp()) move = "platform_up";  // B12-2
            Add(&edges, o.node, to, move, o.x, o.y, o.right);
            if (g.t.slide) {  // B47c-7: the highest he catches a slide pole on this arrival (he only slides down from there)
                const float lo = std::min(g.t.y1, g.t.y2), hi = std::max(g.t.y1, g.t.y2);
                float c = lo;
                for (float top = hi; top > lo; top -= 32.f) {  // (128 px pieces: a fast fall moves ~40 px a step)
                    Target piece = g.t;
                    piece.y1 = std::max(lo, top - 128.f);
                    piece.y2 = top;
                    piece.x2 = piece.x1;
                    piece.slide = false;  // (the slide pole rules held for the whole pole; a piece only says where)
                    if (Try(o, piece) != jump_model::kNone) {
                        c = top;
                        break;
                    }
                }
                float& best = g_slide_catch[std::make_pair(std::make_pair(o.node, to), std::string(move))];
                best = std::max(best, c);
            }
            if (o.kind == kWalkOff) {  // (B46)
                const auto key = std::make_pair(o.node, to);
                const SpeedWindow w = WalkOffWindow(g.t, o.x, o.y, o.right);
                auto it = g_walk_windows.find(key);
                if (it == g_walk_windows.end() || w.n > it->second.n) g_walk_windows[key] = w;
            }
            if (o.kind == kPole) {  // B10b: from the other side the jump goes through the pole (he's moved across first)
                const std::string other = P(o.feature, !o.right);
                if (to != other) Add(&edges, other, to, move, o.x, o.y, o.right);
            }
        }
    }
    // Floor ends: running up a climbable wall; steps and ledges he climbs himself.
    for (const level_geometry::Surface& s : surfaces) {
        if (s.points.size() < 2) continue;
        for (int side = 0; side < 2; ++side) {
            const auto& p = side ? s.points.back() : s.points.front();
            const level_geometry::End& e = side ? s.right : s.left;
            if (Downhill(s) && (Downhill(s) > 0) != (side == 1)) continue;  // B12-1: he can't get to a slope's high end
            if (e.type == level_geometry::End::kDrop && e.gap) {  // B15-6: running carries him over a narrow gap
                int across = -1;
                float best = 4 * 64.f + 1.f;
                for (const level_geometry::Surface& o : surfaces) {
                    if (o.id == s.id || o.points.size() < 2) continue;
                    const auto& q = side ? o.points.front() : o.points.back();
                    const float width = side ? q.first - p.first : p.first - q.first;
                    if (width > 0.f && width < best && q.second - p.second >= -64.f && q.second - p.second <= 64.f) {
                        best = width;
                        across = o.id;
                    }
                }
                if (across >= 0) Add(&edges, S(s.id), S(across), "run_across", p.first, p.second + 32.f, side == 1);
            }
            // B47c-1 (the user, B47 sessions 1-2: "successfully walked into swing point without jumping. Q called for a jump",
            // "another walkoff where path said jump"): running off a floor's end, the engine's air warp carries him up onto
            // a swing point just ahead and above (no jump sound; he rises at ~1100 px/s across): 1-c s39 (384 across, 320
            // up), 4-a s30 (260, 286), 4-a s49 (356, 227), all over deadly drops. Only within what was seen, with a margin.
            if (e.type == level_geometry::End::kDrop && !Downhill(s)) {
                for (size_t i = 0; i < features.size(); ++i) {
                    if (features[i].type != "swing_point" || features[i].points.empty()) continue;
                    const float dx = (features[i].points[0].first - p.first) * (side ? 1.f : -1.f);
                    const float up = features[i].points[0].second - p.second;
                    if (dx >= kWarpSwingMinDx && dx <= kWarpSwingMaxDx && up >= kWarpSwingMinUp && up <= kWarpSwingMaxUp) {
                        Add(&edges, S(s.id), F(static_cast<int>(i)), "run_off", p.first, p.second + 32.f, side == 1);
                    }
                }
                // B47c-6 (B47 session 2 mark 6, 4-a: "wall before last death could also walk into": Q "long jump to a
                // climbable wall, 4 tiles right" off s58's end (70720, 6464); he ran off it into w67 (x 70848, bottom
                // 6528) and up it, no jump): a climbable wall facing him just across the gap.
                for (size_t i = 0; i < walls.size(); ++i) {
                    const level_geometry::Wall& w = walls[i];
                    const float dx = (w.x - p.first) * (side ? 1.f : -1.f);
                    if (!w.climbable || w.faces_left != (side == 1) || dx <= 0.f || dx > kWarpWallMaxDx) continue;
                    if (w.y1 <= p.second + kWarpWallMaxUp && w.y2 >= p.second + 128.f) {
                        Add(&edges, S(s.id), W(static_cast<int>(i)), "run_across", p.first, p.second + 32.f, side == 1);
                    }
                }
            }
            if (e.type == level_geometry::End::kDrop) continue;
            if (e.climbable) {
                for (size_t i = 0; i < walls.size(); ++i) {
                    const level_geometry::Wall& w = walls[i];
                    if (w.climbable && std::fabs(w.x - p.first) <= 16.f && w.y1 <= p.second + 32.f && w.y2 >= p.second + 64.f) {
                        Add(&edges, S(s.id), W(static_cast<int>(i)), "run_up_wall", p.first, p.second + 32.f, side == 1);
                        // B15-10: holding forward into it runs him up and vaults him over the top (the B13b log: 4-tile
                        // walls in 1-a and 1-b train, runUpWall then ledgeClimb, no jump): one move on foot.
                        const int top = OverTop(w, surfaces);
                        if (top >= 0 && top != s.id) Add(&edges, S(s.id), S(top), "climb_up", p.first, p.second + 32.f, side == 1);
                    }
                }
            }
            if (e.value > 0 && e.value <= kClimbMaxPx) {
                const int top = FloorEndNear(p.first, p.second + e.value, 72.f);
                if (top >= 0) Add(&edges, S(s.id), S(top), "climb", p.first, p.second + 32.f, side == 1);
            }
        }
    }
    // A climbable wall's top: climbing over onto the floor there.
    for (size_t i = 0; i < walls.size(); ++i) {
        const level_geometry::Wall& w = walls[i];
        if (!w.climbable) continue;
        const int top = OverTop(w, surfaces);
        if (top >= 0) Add(&edges, W(static_cast<int>(i)), S(top), "climb_over", w.x, w.y2, !w.faces_left ? false : true);
    }
    // Poles: down to the floor below the bottom; and the bounce back onto the other side.
    for (size_t i = 0; i < features.size(); ++i) {
        Target t;
        if (!ToTarget(features[i], &t) || t.kind != jump_model::kPole) continue;
        const int id = static_cast<int>(i);
        const float px = (t.x1 + t.x2) / 2, bottom = std::min(t.y1, t.y2), top = std::max(t.y1, t.y2);
        for (int side = 0; side < 2; ++side) {
            const float x = px + (side ? 80.f : -80.f);
            float lx = 0, ly = 0;
            if (jump_model::Land(x, bottom + 64.f, 0.f, -100.f, &lx, &ly)) {
                const int floor = FloorAt(lx, ly);
                if (floor >= 0) Add(&edges, P(id, side == 1), S(floor), t.slide ? "slide_down" : "climb_down", x, bottom, side == 1);
            }
            // B11-1: holding toward the pole swings him round to its other side (pole_climb_switch).
            Add(&edges, P(id, side == 1), P(id, side == 0), "switch_sides", x, (bottom + top) / 2, side == 0);
            // A wall close on the away side (solid facing the pole) sends a pole jump back (1-c's pillar).
            for (const level_geometry::Wall& w : walls) {
                const bool faces = side ? w.faces_left : !w.faces_left;  // met moving away from the pole
                const float gap = side ? w.x - px : px - w.x;
                if (!faces || gap < 112.f || gap > 450.f || w.y2 < bottom || w.y1 > top) continue;
                Add(&edges, P(id, side == 1), P(id, side == 0), "bounce", x, std::max(bottom, std::min(top, w.y2 - 64.f)), side == 1);
                break;
            }
        }
    }
    // B12-3: path pieces joined end to end (1-c's slide pole into a bar, 3-c's and the villa's bar into bar): he
    // carries on from one to the next. A slide pole only takes him down: from its bottom onto what's there.
    for (size_t i = 0; i < features.size(); ++i) {
        Target a;
        if (!ToTarget(features[i], &a) || (a.kind != jump_model::kPole && a.kind != jump_model::kShimmy)) continue;
        for (size_t j = 0; j < features.size(); ++j) {
            Target b;
            if (j == i || !ToTarget(features[j], &b) || (b.kind != jump_model::kPole && b.kind != jump_model::kShimmy)) continue;
            bool joined = false, at_a_bottom = false;
            for (const auto& pa : {std::make_pair(a.x1, a.y1), std::make_pair(a.x2, a.y2)}) {
                for (const auto& pb : {std::make_pair(b.x1, b.y1), std::make_pair(b.x2, b.y2)}) {
                    if (std::hypot(pa.first - pb.first, pa.second - pb.second) > 24.f) continue;
                    joined = true;
                    at_a_bottom = pa.second <= std::min(a.y1, a.y2) + 1.f;
                }
            }
            if (!joined || (a.slide && !at_a_bottom)) continue;  // (up a slide pole: no)
            const int ia = static_cast<int>(i), ib = static_cast<int>(j);
            const char* move = a.slide ? "slide_down" : "shimmy_along";
            std::vector<std::string> from = a.kind == jump_model::kPole ? std::vector<std::string>{P(ia, false), P(ia, true)}
                                                                         : std::vector<std::string>{F(ia)};
            std::vector<std::string> to = b.kind == jump_model::kPole ? std::vector<std::string>{P(ib, false), P(ib, true)}
                                                                       : std::vector<std::string>{F(ib)};
            for (const auto& f : from) {
                for (const auto& t2 : to) Add(&edges, f, t2, move, a.x1, a.y1, true);
            }
        }
    }
    // B11-3: Down + Jump on a one-way (skinny) floor drops him through it onto the floor below. B48d: never confirmed, and
    // refuted (the user, 1-b train mark 7: "hold down and jump to drop through not working": three Down + Jump presses at
    // (31104, 1696), each a jump landing back on the same floor; no such transition in the stategraphs): off.
    if (kDropThrough)
    for (const level_geometry::Surface& s : surfaces) {
        if (s.tags.find("skinny") == std::string::npos || s.points.size() < 2) continue;
        if (Downhill(s)) continue;  // B12-1: sliding, Down + Jump is just the slide's jump
        for (float x : Steps(s.points.front().first + 16, s.points.back().first - 16)) {
            float fy = s.points.front().second;
            for (size_t k = 0; k + 1 < s.points.size(); ++k) {
                const auto& a = s.points[k];
                const auto& b = s.points[k + 1];
                if (x >= a.first && x <= b.first && b.first > a.first) fy = a.second + (x - a.first) / (b.first - a.first) * (b.second - a.second);
            }
            float lx = 0, ly = 0;
            if (!jump_model::Land(x, fy + jump_model::kFeet - 48.f, 0.f, -100.f, &lx, &ly)) continue;  // from just under it
            const int below = FloorAt(lx, ly);
            if (below >= 0 && below != s.id) Add(&edges, S(s.id), S(below), "drop_through", x, fy + jump_model::kFeet, true);
        }
    }
    // (B48b: running off a wall run's end onto a swing point (1-a f6 -> f3, mark 1) is left a jump: the user, "most, but
    // not all, wall runs in the game catch whatever's coming next without input, but a timed jump doesn't cause any
    // problems. I recommend against no jump wording except in specific cases where jumping will kill but not jumping
    // is safe.")
    // B47c-7 (B47 session 3, 3-c's covered walkway: 7 deaths): he caught slide pole p20 near its bottom off s28's slide
    // (~3570) and slid off it into the pit; the route jumped off it from 4029..4157, above where he can be. On a slide pole he
    // only goes down from where he caught it: a jump off it starts at or below the highest catch, and an arrival with no way
    // off below its catch is dropped.
    // (each arrival's catch: the stored edge's own move)
    auto catch_of = [&](const std::pair<std::string, std::string>& key, const std::string& move) {
        const auto c = g_slide_catch.find(std::make_pair(key, move));
        return c == g_slide_catch.end() ? -1.f : c->second;
    };
    std::map<std::string, float> top_catch;
    for (const auto& e : edges) {
        const float c = catch_of(e.first, e.second.move);
        if (c < 0.f || e.first.second[0] != 'p') continue;  // (slide poles only: a wall is reached higher by jumps too)
        float& t = top_catch[e.first.second];
        t = std::max(t, c);
    }
    int cut = 0;
    for (const auto& tc : top_catch) {
        for (auto it = edges.begin(); it != edges.end();) {
            if (it->first.first == tc.first && it->second.y_lo > tc.second + kSlideCatchSlackPx) {
                it = edges.erase(it);
                ++cut;
            } else {
                ++it;
            }
        }
    }
    for (auto it = edges.begin(); it != edges.end();) {
        const float c = catch_of(it->first, it->second.move);
        float lowest = 1e9f;
        if (c >= 0.f && it->first.second[0] == 'p') {
            for (const auto& e : edges) {
                if (e.first.first == it->first.second) lowest = std::min(lowest, e.second.y_lo);
            }
        }
        if (c >= 0.f && lowest > c + kSlideCatchSlackPx) {
            it = edges.erase(it);
            ++cut;
        } else {
            ++it;
        }
    }
    if (cut) printf("  (B47c-7: %d moves on or off slide poles above where he catches them, cut)\n", cut);
    return edges;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 3) {
        printf("usage: path_graph <shank_access_geometry.txt> <out.txt> [level]\n");
        return 2;
    }
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_path_graph.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);
    wchar_t wpath[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wpath, MAX_PATH);
    if (level_geometry::Load(wpath) == 0) {
        printf("no levels in %s\n", argv[1]);
        return 1;
    }
    // B42-5: "<level> --merge" rebuilds that level only and keeps every other level's section of the existing file.
    const bool merge = argc > 4 && std::strcmp(argv[4], "--merge") == 0;
    std::vector<std::pair<std::string, std::string>> kept;  // (level, its section's text) from the existing file
    if (merge) {
        FILE* old = nullptr;
        if (fopen_s(&old, argv[2], "r") == 0 && old) {
            char line[4096];
            std::string cur;
            while (fgets(line, sizeof line, old)) {
                if (line[0] == '[') {
                    cur = std::string(line + 1, std::strcspn(line + 1, "]"));
                    kept.emplace_back(cur, "");
                }
                if (!cur.empty()) kept.back().second += line;
            }
            fclose(old);
        }
    }
    FILE* out = nullptr;
    if (fopen_s(&out, argv[2], "w") != 0 || !out) {
        printf("can't write %s\n", argv[2]);
        return 1;
    }
    fprintf(out, "# shank-access traversal graph (generated by path_graph.exe from shank_access_geometry.txt;\n");
    fprintf(out, "# deployed as bin/shank_access_paths.txt; never commit).\n");
    fprintf(out, "# edge <from> <to> <move> <x> <y> <R|L> <x_lo> <x_hi> <y_lo> <y_hi>\n");
    for (const std::string& level : level_geometry::LevelNames()) {
        if (argc > 3 && level != argv[3]) {
            for (const auto& k : kept) {  // (B42-5: the other levels as they were)
                if (k.first == level) fputs(k.second.c_str(), out);
            }
            continue;
        }
        level_geometry::SetLevel(level);
        jump_model::SetObstacles(&level_geometry::Obstacles());
        std::vector<Target> swings;  // B27-5: they grab him in passing
        for (const level_geometry::Feature& f : level_geometry::Features()) {
            Target t;
            if ((f.type == "swing_point" || (kSlideIntercept && f.type == "slide_pole")) && ToTarget(f, &t)) swings.push_back(t);  // (B48d: slide poles)
        }
        jump_model::SetInterceptors(&swings);
        const DWORD t0 = GetTickCount();
        const Edges edges = Build();
        jump_model::SetInterceptors(nullptr);
        jump_model::SetObstacles(nullptr);
        fprintf(out, "[%s]\n", level.c_str());
        for (const auto& kv : edges) {
            fprintf(out, "edge %s %s %s %.0f %.0f %s %.0f %.0f %.0f %.0f", kv.first.first.c_str(), kv.first.second.c_str(),
                    kv.second.move.c_str(), kv.second.x, kv.second.y, kv.second.right ? "R" : "L", kv.second.x_lo, kv.second.x_hi,
                    kv.second.y_lo, kv.second.y_hi);
            const auto w = g_walk_windows.find(kv.first);
            if (kv.second.move == "walk_off" && w != g_walk_windows.end()) {  // B46: v <lowest> <highest> <how many of 22>
                fprintf(out, " v %.0f %.0f %d", w->second.lo, w->second.hi, w->second.n);
            }
            const auto c = g_slide_catch.find(std::make_pair(kv.first, kv.second.move));
            if (c != g_slide_catch.end()) fprintf(out, " c %.0f", c->second);  // B47c-7: c <the highest he catches the slide pole>
            fputc('\n', out);
        }
        g_walk_windows.clear();
        g_slide_catch.clear();
        printf("%-32s %5u edges (%.1f s)\n", level.c_str(), static_cast<unsigned>(edges.size()), (GetTickCount() - t0) / 1000.f);
    }
    fclose(out);
    return 0;
}
