# Test sessions

One entry per gameplay test the user runs, newest first. The PLAN.md work log gets a one-line summary. The full detail lives here, so nothing is lost between sessions:
- what was deployed;
- what the user was asked to do;
- what the user reported, in their own words where possible;
- what the logs showed;
- conclusions and follow-ups.

## How a test session runs
1. **Before.** Batches only at planned test points (CLAUDE.md). Commit the work. Regenerate `tools/levels/geometry.py` and `tools/ui_text/extract_ui_text.py` output, run `tools/luacheck50.py` (and `loadtest50.py` if Lua changed), the host tests, `tools/deploy.py plan`, then `deploy --yes` (only after the user says go; plain `deploy` waits on a prompt). Write the entry below with the status "awaiting user", including the exact instructions given to the user.
2. **Instructions to the user** always include:
   - the level and checkpoint;
   - what to do;
   - what to listen for;
   - what to report;
   - a reminder **not to relaunch the game before logs are collected**, because every launch overwrites them. Closing the game is safe.
   - **Live log checks work (confirmed 2026-09-24, 1a-1):** the user can alt-tab out; the game pauses on focus loss and does not lock its logs, so Claude can read them mid-session. No need to close the game between checks.
   - Deploying needs the game closed to take effect: the Lua loads at start or level load and the DLL at start. (Correction
     2026-10-01: `deploy.py` did **not** refuse while Shank.exe ran (B44c / B44d were deployed during play; the files were
     replaced on disk, the running game kept the old DLL). Check `tasklist` before deploying and say so if it's running.)
3. **After.**
   - Run `tools/collect_logs.py --label <short-name>`, then **`tools/session_report.py --latest`** (B42-3: marks, every
     death with the 6 s before it, the flights the jump model gets wrong, Too high, waypoint targets; also in
     build/logs/<session>/report.txt). Read it before the raw log.
   - Record the log folder, the findings from the logs and the user's report.
   - Mark the entry done.
   - Update PLAN.md (checkboxes, the In flight section, the Work log) and RE-NOTES.md (any engine facts that are now confirmed).

## Entry template
```
## YYYY-MM-DD — <short name> — <status: awaiting user | done | abandoned>
- Commit / deployed: <git hash>; files: <deploy.py status summary>
- Instructions given: <level, checkpoint, actions, what to listen for>
- User report: <what they heard/experienced>
- Logs: build/logs/<folder>; findings: <cue lines, errors, timings>
- Conclusions: <what we learned; hypotheses confirmed/refuted>
- Follow-ups: <tasks created in PLAN.md>
```

---

## 2026-09-26 — B10 batch (Phase 7: waypoint mode W, next move Q) — done (report and fixes: B10b; played again in the B13b session)
- **To deploy:** `bin/shank_access.dll`, the regenerated `bin/shank_access_geometry.txt` (now with checkpoints) and the new `bin/shank_access_paths.txt` (the traversal graph).
- **Pre-deploy:** `geometry.py`, then `path_graph.exe build/levels/shank_access_geometry.txt build/levels/shank_access_paths.txt`.
- **Instructions:** Meatpacking Plant from the start: press W ("Waypoint on. Run up the wall ..."), listen for the checkpoint chime and the single waypoint pluck/chirp, and follow them through the opening climb (end wall, swing point 1, swing point 2, ledge, tall pole's left side, wall-climb zone, wall, bar, platform, wall run, swing point). Try going back a step: the earlier object should come back. On the pole's right side, the "other side" chirp (jump off to the right and bounce back). Press Q any time for the next move. Try W in another level too. Don't relaunch before the logs are collected.
- **Log markers:** `paths: level ... moves`, `waypoint: at checkpoint`, `waypoint: <node> -> <target> (N moves)`, `waypoint: reached checkpoint`, `cues: jump now reaches ...`, `played in 5 s: ... waypoint`.
- **User report (2026-09-26):** "Got some new logs, and this has a bunch of stuff. I got inside the meat packing plant, and there's waypoint guiding me wrong, missed jump targets, slies not reporting as dangerous, etc. Have a look. The game is closed so deploy whatever fixes you find."
- **Later, before deploy (the user):** "look closely at the part where I climbed up and down the same wall and jumped on and off the nearby bar and swing point a lot. The system did not take into account that I needed to go to the opposite side of the bar, do a wall run, then jump back to the left and once more right before I could slide down to the health pickup and get to the checkpoint."
- **Logs:** `build/logs/20260926-215836-B10` (1-c from the start to Cold Storage). Findings, all fixed in B10b:
  - **Slides into grinders not dangerous:** deaths 21:52:37-21:55:39 near Enter Cold Storage were meat grinders (`Shank_DeathMeatgrinder`). Slippery surface 31 ends at x 20224 ("drop 7 tiles", safe); its grinder pit starts at x 20245, 21 px past where geometry.py looked (16 px), and he slid on to x 20532. Fix: a pit within his drift off an edge (up to 6 tiles, as far as run speed carries him before he falls to the pit's top) makes the end deadly.
  - **Paths through pits:** Q "jump to a floor, 44 tiles down" off 1-c's s18 (a deadly edge), "long jump to a floor, 14 tiles down" off s31 over the grinders (he died). Fix: pits are jump-model obstacles (a flight into one fails; `Land` returns nothing).
  - **Missed swing point / pole jumps:** on the cold-storage pole's right side he jumped left: the game moved him to the left side (x - 160) and jumped with a ~197 px rise (the wall jump, as scripted); the mod's pole jump rose 131 px and only went away from the pole, so jumps through the pole were never offered, and the "jump now" at 21:53:24.628 came after the jump started. The B5b "weaker" pole-top jump was a ceiling bump (the same launch, then a sudden turn down). Fixes: pole jump up 1140; from either side both ways; ceilings bump him down instead of ending the flight.
  - **The wall under the health platform (the user's report above, 21:48:30-21:50:51):** the graph said run up wall 36 (x 16789, y 1600-2880) and climb over its top onto s29, but s29 sticks out over his side: he hits its underside (he stalled at y ~2720, over and over). Also "w34 -> w91" before it: a jump starting inside the wall at a floor's end went through it. Fixes: climb over only onto a floor on the wall's far side; walls block from a launch spot within his body width; a body already through a ceiling at the start is blocked. The path from wall 34 is now the user's route: swing point, bar to its left end, floor, run up the wall, wall run, long jump right to the bar, up to the health platform, up the wall, over.
  - **"No path from here"** on s15 and s31 (floors that reach the checkpoint, far from it): Q now says "Walk N tiles right to <checkpoint>".
  - **Q wording:** "climb to a floor, 44 tiles right": now "walk 44 tiles right, then climb ..." (each move's launch range is in the graph); floors' heights on slopes (was "jump up to a floor, 5 tiles down"); a jump up that lands far below: "jump up, then fall".
  - 2-b: a pit with `applytoplayer` false (the "After Buildings" trigger is inside it) is not a pit for Shank; such pits are dropped.
  - Coverage after the fixes: 101 of 101 checkpoint legs have a path.

## How the user reports feedback (from B14, 2026-09-27)
- Play the whole session, press **F2** at each moment worth a note and type the comment (Enter saves, Escape skips); give a list at the end only for anything not marked. Report live only for blockers or crashes.
- **Release builds (0.1 on; PLAN 4c):** the logs are per session under `Documents\Shank Access\logs\<date_time>\`, not the game root. Collect with `collect_logs.py --documents --label <name>` (the newest session on this machine) or `--from <folder>` (a folder a tester sent); a11y_marks.log there holds that session's marks only.
- After the session: `collect_logs.py --label <batch>`, then read the newest session in `a11y_marks.log` first (each MARK line has the time and context), and look at a11y.log around each MARK's time.

## 2026-10-02 — B47 manual test plan (from the old logs against today's model and cue) — sessions 1-4 played 2026-10-02; B48b deployed 2026-10-02; plan cut by the one-safe-path rule (B48c); all played 2026-10-02 (B48d built from them): done
- **How it was made:** tools/movements.py (the corpus + timelines), movement_check (the model), cue_replay (today's jump-now
  cue along 1,696 real launches: kept 710, false 166 of which 43 strong (the flight passed the chirped spot and missed),
  missing 151), tools/levels/evidence.py (each route move: proven 18, contradicted 25, model-doubt 11, the rest untested of
  290; 54 with real attempts), tools/levels/test_plan.py (regenerate it after any model / route change). Fixes from it:
  PLAN B47-3 (deploy them before the sessions).
- **Sessions** (the user's rule: a level with many gaps is a session of its own; every level here has 15+): each a
  playthrough from the level's start with waypoint mode on following Q, then its key spots with directions from their
  checkpoint (build/levels/test_plan.txt has them in full): 1 Meatpacking Plant / The Butcher (47 gaps, 10 key spots);
  2 The Underworld / Leap of Faith (46, 8); 3 A Bad Confession / Bombs and Bells / Unjust Steward (29, 6); 4 Return Home
  (15, 5); 5 Ride (34, 3); 6 Venom of the Vipers / World of Warriors (38, 3); 7 Other side of the Tracks (18, 2); 8 On The
  Run (18, 0); 9 Fertile Ground / The Final Fight (27, 0). (Red Lights / A Good Fight: no route jumps.)
- **After each:** collect_logs, session_report.py, movements.py, movement_check, cue_replay, evidence.py, test_plan.py
  (the next session's plan shrinks as moves get proven).
- **Results:**
  - **Session 1 (2026-10-02, build/logs/20261002-061128-b47s1; Meatpacking Plant / The Butcher, waypoint mode on, 4 deaths):**
    the user: "Meat packing log is ready. Also, yes, climbable walls should be jump targets. Only a couple wording issues, and
    swing points still have outdated wording from when we thought shank's jump arc changed based on swing angle." Marks: (1)
    "checkpoint boundary blocks moving left" (the game's boundary after the Enter Packing Warehouse fight; the edge cue marked it
    as a wall); (2) "a couple points which said jump but walk off worked, one to the wall and one to a swing point" (the wall: a
    model bug, the jump to the wall under the floor he stood on; the swing point: his rise there looks like a jump pressed just
    after running off). Fixed in B47b (PLAN In flight): Q "face left and jump off the swing point"; walls chirp from every
    hold; a wall catch needs him at its face. Deaths (session_report, not yet analysed): Enter Packing 2 leg after a long jump
    toward a wall run; after a swing release toward a shimmy line; off a pole in Cold Storage; after the wall run before Cold
    Storage 2. Key spots not tried on purpose
    (1-c stays first in test_plan.txt).
  - **Session 2 (given in chat 2026-10-02, after deploying B47b):** The Underworld / Leap of Faith: a playthrough with waypoint
    mode on following Q, then 7 key spots (build/levels/test_plan.txt "Session 2"): the climbable wall's jump to the bar and
    the jump up after it (Big fire area checkpoint); the bar off the slide and the bar to the climbable wall (Start platforming
    final stretch); the long jump to the swing point (Halfway through final platforming stretch); the walk-off to the pole
    (Bottom of final platforming stretch); the bar to the wall run (Exit the level). **Played 2026-10-02**
    (build/logs/20261002-072306-b47s2; 6 marks, 12 deaths): the user: "next session done. deploy when finished.", then "The
    last several deaths in leap were execution issues, I don't believe any of them were mod failures." and "You shouldn't
    exclude any given death as a definitive execution issue on my word, but you should treat an execution issue as a
    possibility for all deaths." Marks and findings (PLAN B47c): (1) the wall jump to the sloped line by the Big fire area
    wall: tried from the wall's top band (falling jump), model agrees; (2), (5) swing points reached by running off the edge,
    no jump (the air warp) -> "run off the edge, no jump"; (3) the walk-off to the pole needed a sprint -> a long jump route;
    (4) the shaft's wall jump to the upper line: works only low on the wall (ceiling) -> shimmy-end and ceiling-width rules,
    Q aims inside the window; (6) the gap into the climbable wall -> "run across the gap". The last death: forward released
    on the wall run (execution likely). B47c deployed 2026-10-02.
  - **Session 3 (given in chat 2026-10-02, after deploying B47c):** A Bad Confession / Bombs and Bells / Unjust Steward: a
    playthrough with waypoint mode on following Q, then 6 key spots (build/levels/test_plan.txt "Session 3"): the long jump
    to the swing point (1st down slide right); the bar to the floor 18 right (Next to 1st fire hazard); the slide off onto
    the slide pole (covered walkway runthrough); the long jump to the wall run (Approaching the belltower platforming); the
    wall jump 14 right / 24 down and the long jump to the swing point (Final climb up to the Priest). **Played 2026-10-02**
    (build/logs/20261002-082729-b47s3; 3 marks, 24 deaths): the user: "Next session. Note there are many, many deaths that
    involve rockets in some way." 9 deaths were direct rocket hits (6 in the SWAT fight on the long slide floor); 7 were the
    slide pole on the covered walkway (the route jumped off it from above where he catches it); the rest: a slide jump not
    taken, a walk-off, the long jump to the shimmy line's end, combat, walking on past the Final climb checkpoint. Marks: (1)
    the waypoint pointed back at the start's cinematic (fixed), (3) no jump alert for the floor 29 tiles off the wall (fixed).
    B47d (PLAN In flight) built.
  - **Session 4 (given in chat 2026-10-02; B47d + B48 deployed: try F7 > Navigation > Speak each move):** Return Home: a playthrough with waypoint mode on following Q, then 5 key
    spots (build/levels/test_plan.txt "Session 4"): the two long jumps to swing points (1st Swing Point), the long jump to
    the swing point (Pre Bridge), the long jump to the wall run (Wall Run), the long jump to the swing point (Pre-Boss
    Runup). **Played 2026-10-02** (build/logs/20261002-112004-b47s4; 3 marks, 9 deaths): the user: "New session. A few combat deaths and some from experimenting. Found a lot of swing points in this level are reachable without jumping from sprints, but not from walks. There's a mark where I flagged one as a walk off, but then later corrected in another mark. Double check the flagged walk off points from the last session to make sure they aren't sprint only." Marks: (1) the
    wall run's end caught the swing point without a jump (left as a jump: the user's wording rule); (2), (3) the boss
    approach's swing point by running off, sprint only. B48b (PLAN In flight): run-offs worded as sprints, out to 480 across.
  - **B48c (2026-10-02, the user: "Deploy, and reconfirm which tests for future sessions are still necessary given our adjustments and the new rule."):** the remaining B47 tests (B48c, by the one-safe-path rule): (a) re-checks of routes changed after their level was played: [-] 3-c "covered walkway runthrough" move 3 (as you slide down, jump off slide pole p20 to swing point f7): **closed untested 2026-10-02**, the user: "Just mark the bad confession one done. There's so much chaos going on at that point that getting a reliable, reproduceable testing session is functionally impossible. Whether shot off by an enemy, blown off by a rocket, missing a cue due to surrounding chaos or just botching the timing because I'm panic mashing, there are just too many variables there."; and 4-a "Rocketlauncher vs shimmy" move 9 (s47: long jump to the climbable wall w49, 12 tiles right; replaced the sprint-only walk-off to the pole); (b) playthroughs of the unplayed levels with waypoint mode on: Ride + Other side of the Tracks (both train levels; key spots: Ride's three never-made moves, the Tracks' jump to the swing point at Final trainyard checkpoint), Venom of the Vipers / World of Warriors (its own session; 2 never-made moves at "2nd wall run"), On The Run (its own; no key spots: its one-speed walk-off is a full sprint), Fertile Ground / The Final Fight (its own; none); Red Lights / A Good Fight: no route jumps, no session. Dropped: the played levels' other key spots (Meatpacking, The Underworld / Leap of Faith, A Bad Confession / Bombs and Bells, Return Home: each played to its end following Q), every model-doubt / mixed spot (moves he has made; only the model or the alert disagreed), full-sprint one-speed walk-offs (his normal running).
    - [-] Re-check 1 (closed untested 2026-10-02: the user, too chaotic there to test reproducibly): A Bad Confession, checkpoint "covered walkway runthrough": (1) walk 31 tiles right, run up the wall and
      climb over onto the slope, sliding right; (2) slide off its end onto the slide pole's left side (6-7 tiles right);
      (3) as you slide down, jump off the pole to the swing point 7 tiles right, 5 up (listen for the jump alert); (4) face
      right and jump off it to the slope 8 tiles right, 3 down.
    - Re-check 2: The Underworld, checkpoint "Rocketlauncher vs shimmy": follow Q through the shaft (walk 18 right, run up
      and over 2 up; run up and over 3 up; run up onto the climbable wall; wall jump to the swing point 6 left; swing point
      to swing point 6 left; to the climbable wall 4 left; wall jump right to the shimmy line; off the bar to the floor 15
      right); then on that floor (x ~44600) the long jump right to the climbable wall 12 tiles right and climb over.
    - Then Ride + Other side of the Tracks, Venom, On The Run, Fertile Ground / The Final Fight (test_plan.txt).
    Results (2026-10-02, build/logs/20261002-122836-b48s1 + 20261002-145932-b48s2): every level played to its end; marks and
    fixes in PLAN In flight B48d (drop-through removed, slide poles catch him in passing, "drop, holding right,", "stop,
    then jump"). The B47 manual test plan is complete.

## 2026-10-02 — B46 (one-speed walk-offs) — done (the user: "That one was a bit hard to test due to the rain of grenades, but I think I've confirmed a sprint only works there."; the live log)
- **Results (the live log, 2-c / Venom of the Vipers, the Thumper leg's second edge, s41's end at x 44304):** his speed from
  the last footsteps before the edge: 00:43:24 ~573 px/s (a run) → the pit (44640, 1023); 00:45:12 ~762 → landed on the
  floor below (44673, 1888); 00:45:53 ~719-762 then no steps (he slowed) → the pit; 00:46:12 ~722-767 → landed; 00:47:07
  ~719 → landed. The one fall the tracker caught left at ~387 → the pit. The model's window (704..768) matches: only a
  sprint makes it.
- **To try:** **Venom of the Vipers** (the user corrected 2026-10-02: "The thumper checkpoint is in venom, not red light";
  our file campaign_2c_redlight is that chapter, "Red Lights" is campaign_2a_brothel), checkpoint **Thumper**, waypoint mode on: (1) walk about 20 tiles right and walk off the edge
  onto the floor below (about 5 right, 4 down); (2) press Q: it should say to walk off the next edge "at a full sprint (one
  speed only)"; run about 24 tiles right at full speed and off it: the floor about 6 right, 3 down. Then try it slower: the
  model says that misses. Elsewhere, routes avoid the other 22 one-speed walk-offs.

## 2026-10-01 — B44b session (1-c, 2-b, 1-a calibration; no marks) → B44g — deployed 2026-10-01, awaiting user
- **Logs:** build/logs/20261001-233209-B44b (the 23:13 copy build/logs/20261001-231349-B44 is its first part). Live reports
  during it: B44c (a pole behind him), B44d (Down on a bar), B44e / B44f (Up on a bar; Up stuck after a death), all
  deployed. After it (the user): "Check the logs for anything else recorded incorrectly" → B44g (false wall-run and pole
  catches; PLAN In flight). Calibration jumps in 1-a: RE-NOTES.
- **To try after B44g's deploy:** Meat Packing, checkpoint **Level Start**, the route to the last bar (TESTING B44 1b's
  steps 1-9), then let go onto the platform below and long jump right toward the wall run: the chirp should start only
  about 2 tiles further right than before (from where you jumped and died, nothing).

## 2026-10-01 — B44 (the chirp follows his input and speed; plucks hot / cold) — partly tested (the B44b session: the
  live reports above → B44c-f); awaiting user: the TESTING items below with B44c-g in
- **To try 1, Up on a swing point:** Meat Packing (1-c), checkpoint **Level Start**. (1) Run right about 72 tiles to the
  street's end wall and run up it; (2) about 6 tiles up, wall jump left onto the first swing point; (3) let go left onto
  the second. There, facing left: the chirp for the floor ahead (letting go lands on it). Hold Up: the chirp stops and the
  floor plucks instead (the jump up only falls back onto the point). Let go of Up: the chirp again.
- **To try 1b, the user's spot ("The last shimmy line before entering the plant proper fits this perfectly"):** Meat
  Packing, checkpoint **Level Start**, the route (path_check --to f31): (1) run right ~72 tiles, run up the end wall;
  (2) ~6 tiles up, wall jump left onto the first swing point; (3) let go left onto the second; (4) let go left onto the
  floor ahead (~6 tiles); (5) climb onto the floor above at its left end; (6) walk off its right end onto the tall pole;
  (7) low on the pole, pole jump left into the wall run; (8) wall-run jump left onto the climbable wall; (9) wall jump right
  onto the bar and shimmy to its right end. There: holding right, the platform below to the right only plucks; holding
  Up, it chirps (Up + Jump lands on it). (waypoint_test: 0 chirps holding right, 20 holding Up.) Note: the route map has
  that move as letting go (a drop steered right), so Q may say so there, and holding Down also chirps for it; the user
  says only Up works: listen for what Q says.
- **To try 2, standing vs running:** at any gap a long jump crosses but a standing jump doesn't: standing at the edge, the
  far side plucks; run at it and the chirp starts once he's moving.
- **To try 3, hot / cold:** walking toward a swing point or pole out of reach, its pluck should quicken as you near it
  (like the pickup beacons; 0.4 s close, slower far).
- **Log markers:** `cue: up_on` / `up_off` / `down_on` / `down_off` (the Lua reports).
- **Live report (2026-10-01, during play):** "I'm just past the first pole on the meat packing sequence, and a jump target
  is playing to my right even though I'm facing left." → B44c (a standing jump steered backwards counted).
- **Live report 2 (2-b):** "Holding down from my current position reports valid jump target, but as you can see from my
  last death it most definitely is not." → B44d (letting go steered too far). Log snapshot build/logs/20261001-231349-B44.
  B44c + B44d deployed while the game ran: they take effect at the next launch.
- **Live report 3 (2-b, the last bar before the end, (69460, 2929)):** "Holding up just before last death reported false
  jump target"; "Zero input jumps do not guarantee straight up, I released all directions and jumped from the same point
  and made it safely." → B44e (the jump up straight unless a direction is held; Lua reports forward / back) + B44f (what's
  held cleared at a death: Up had stayed "held" after he died holding it).

## 2026-10-01 — B43 (the jump-now chirp only for real jump targets) — deployed 2026-10-01 with B44, awaiting user
- **Reported (waypoint mode off):** climbing the street's end wall in Meat Packing, two jump-now chirps: the first swing
  point and "a landing", the street below (from the first steps up the wall). The user: "To be clear, this only happens with waypoint mode off. All objects nearby but not directly reachable should play the plucked string nearby target sound, not the direct jump alert tone."
- **To try:** Meat Packing (1-c), checkpoint **Level Start**, waypoint mode off. (1) Run right about 72 tiles to the wall at
  the street's end and run up it; climb slowly to its top. Listen: no chirp low on the wall; from about 7 tiles up to about
  15 the chirp for the first swing point only (one chirp, up and to the left); above that, nothing. (2) Elsewhere: on walls,
  poles, bars and swing points the floor below shouldn't chirp; other things nearby still pluck.

## 2026-10-01 — B42b (jump model from the movement corpus) + B42c — partly tested (the street swing points → B42c, deployed 2026-10-01); awaiting user: B42c at the street swing points, and wall / pole / swing jumps elsewhere
- **What changed:** wall and pole jumps rise ~9% lower in the model (the measured ~1045 px/s); the jump while running up a
  wall is no stronger than a wall jump; hanging just under a wall's top (at the ledge) the wall jump is modelled as falling
  away; swing points catch him falling faster (up to 2000 px/s). The jump-now chirps and waypoint routes follow.
- **Where to listen:** any level with wall jumps, pole jumps and swing points (1-c Meat Packing's street wall to the first
  swing point, and the stretch before the Butcher; 4-a; 3-c's walls). Listen for: chirps that come and then the jump misses
  (too optimistic) or real jumps with no chirp (too strict), especially near a wall's top and onto swing points. 63
  route moves that needed the old stronger run-up jump are gone: a route that now goes a longer way round is worth a mark.
- **To try, the jump up between the street's swing points** (the model's one new reach not seen in play; the user's rule:
  level, checkpoint, steps): Meat Packing (1-c), checkpoint **Level Start**. (1) Run right along the street about 72 tiles to
  the wall at its end and run up it. (2) About 6 tiles up, wall jump left: the first swing point (about 10 tiles left, 10
  up) catches him. (3) Swing and let go to the left: the second swing point, about 10 tiles further left. (4) On the second
  one, turn right (toward the first), and at the right end of the swing hold Up and press Jump. Expected now: he goes up
  and drops onto the first swing point from above (the jump-now chirp, "jump up", should sound for it there). Compare: the
  plain release to the right (no Up) still flies over it, as the user found in B5d.
- **Afterwards:** collect_logs, then movements.py + movement_check (the new session joins the corpus; compare with
  build/movements/check.txt).
- **Results (2026-10-01, the user, at the jump-up spot):** "There is one alert playing the whole time I'm facing right,
  which does not change at all. Jumping directly up from the second swing point is just landing directly back on it." →
  B42c (PLAN In flight): the release's claim for the first point was wrong (it flies over), the jump up falls back onto
  its own point. The rest of B42b not played yet. The user also let go of the second point straight down onto the street
  (log build/logs/20261001-172108-B42b): the model's drop gets it right (movement_check: reach ok, replay ok).
- **B42c (deployed 2026-10-01), to try:** Meat Packing (1-c), checkpoint **Level Start**: (1) run right about 72 tiles to the
  street's end wall and run up it; (2) about 6 tiles up, wall jump left onto the first swing point; (3) swing and let
  go left onto the second. There, facing right: **no jump-now chirp for the first point** (before: a steady one).
  Facing left on the first point: the chirp for the second should still come (the route). Elsewhere: swing-to-swing
  chirps should match where releases really go.

## 2026-10-01 — B41e session (1-c, 4-a, no new marks) → B41f — deployed 2026-10-01, awaiting user
- **Logs:** build/logs/20261001-134902-B41e. Findings: PLAN In flight B41f (a mid-air pole chirp; B41e's zone rule reverted; "Too high" below the window).

## 2026-10-01 — B41d session (1-c, 1 mark) → B41e — partly tested (the B41e session: "Too high" fires; its zone rule was wrong → B41f)
- **Logs:** build/logs/20261001-124840-B41d. Mark 1: "need to account for jumping too far above things and flying over them." Findings: PLAN In flight B41e.
- **To try:** with waypoints on, climb the pole / the wall past the jump window: "Too high"; the pole jump to the wall run chirps only from heights that enter its end.

## 2026-10-01 — B41b session (1-c, no marks) → B41c + B41d — partly tested (the B41d session: the slopes and the route before them played; overshoots from too high → B41e)
- **Logs:** build/logs/20261001-112607-B41b. The user: "The first slope definitely requires a jump, the second and third do not. Also look into the platforming section immediately before that." Findings and changes: PLAN In flight B41c.
- **To try:** Mid Cold Storage to the Butcher: Q's wording at the wall ("at the chirp"), the wall run to the wall on its left, the shimmy line; on the first slope, Q says to long jump, then slide off.

## 2026-10-01 — B41 session (1-c, 3 marks) → B41b — partly tested (B41b session: Cold Storage 2 and the slope turn not marked again; the slides' wording answered → B41c)
- **Logs:** build/logs/20261001-110115-B41. The user: "Better, a few more issues." Marks and fixes: PLAN In flight B41b.
- **To try:** from Cold Storage 2, Q: right, onto the slope, "turn left at once and long jump"; before the Butcher, Q on the first slope gives all three slides.

## 2026-10-01 — B40d session (1-c with waypoints; 5 marks) → B41 — partly tested (the B41 session: "Better"; marks 1-5's fixes not contradicted; the next problems → B41b)
- **Logs:** build/logs/20261001-082609-B40d. The user: "Controller stuff all seems to work well, but found more pathing issues in meat packing."
- **Marks:** 1 the last swing point before Enter Packing 2: "let go" led into the meat grinder → B41-2; 2 "correct path is to jump right and slide down the wall, not jump left which leads to the meat grinder" → the left route then worked; the right-hand shaft isn't modelled (asked); 3 "no jump needed, went straight from shimmy to wall slide to floor" → B41-3; 4 "missing jump target for that last jump" (asked which); 5 Cold Storage 2: six deaths after walking off onto the slope → B41-1.
- **To try after deploy:** from Cold Storage 2 follow Q (walk off left, the swing point, the wall); at the swing point before Enter Packing 2, Q says which way to swing.

## 2026-09-30 — B40 + B40b (right stick bindings, the mod menu by controller (Back opens it by default), the game's bindings refused) — done with B40c / B40d (the user 2026-10-01: "Controller stuff all seems to work well")
- **To try (with a controller):** press Back in play: the mod menu opens; DPad / left stick move, A selects, Back goes back and closes at the top; the game doesn't react meanwhile. Try binding Button A: "Button A is used by the game". Bind the right stick's directions to N / L / K and use them in play.
- **Log markers:** `hook XInputGetState: installed`, `game pads: N controller object(s) found`, `game pads: the game's bindings: ...` (should list the Controls screen's inputs; if it says the defaults are used, the memory layout needs a look).

## 2026-09-30 — B38 + B39 (the mod menu: order, wording, explainers, waypoint item, pause window; F11 off / on; controller bindings) — done (the menu and its pause window used in the B41b / B41e sessions; controllers: "Controller stuff all seems to work well"; F11: the user 2026-10-01, "I can confirm f11 works")
- **To try:**
  1. In a level, F7: the game pauses (a window titled "Shank Access mod menu" takes the focus; a sighted viewer sees the list with the selection highlighted). Move around: each setting and key says its explainer after its position. Sounds: Learn sounds first, then Cue volume, then Sound panning (relative to Shank / relative to camera). Navigation: Safe edges, Waypoint mode, then the keys. Close with F7 or Escape: "Mod menu closed", the game's own pause menu comes up (Resume Game).
  2. C: "Sound panning relative to camera / relative to Shank".
  3. F11 in play: "Shank Access off"; no cues, no speech, the keys do nothing, the game plays as vanilla; F11: "Shank Access on", cues back. Also F11 with the mod menu open.
  4. F7 from the game's pause menu: no window (already paused).
  5. B39: in a category, after its keys, "<name> controller button, not set" for each; Enter, then press a button (or hold Back and press another), let go: "... controller button, Back + Button A"; in play that chord does the key's job; Delete on it clears it; Escape while waiting cancels. Saved in shank_access_user.ini [pads].
- **Log markers:** `mod menu: the focus window has the focus`, `mod: off (F11)`, `mod: on (F11)`, `hotkeys: controller input through xinput1_3.dll`, `hotkeys: <id> controller binding ...`, `hotkey: ... (controller ...)`.

## 2026-09-30 — B36b (Mello not an enemy; enemies left in an arena always cued; checkpoint jump rescans) — deployed, awaiting user
- **Why:** the user after a Hard run with warps and god mode (build/logs/20260930-160615-hard2, no marks): "during the sweet love boss intro, the mod detects the boss but he is invulnerable and I'm guessing invisible so he shouldn't get a cue. The arena just before the final fight let me walk out of mod range of a rifle goon who was purched. I quickly found him by walking back left, but we should look into fixing this, maybe having enemies within an active arena boundry always sound no matter the distance or something."
- **Found:** the "boss" was Mello (boss_mello: his stategraph has only idle / walk / talk / phone states). 4-c: the rifle goon stood at x 79914, 318 px left of the arena (live x 80232..82604), about 2300 px from Shank (the cue reaches 1600); a target down played at 15:58:40 while he remained. 4-a: after a jump to "Exit the level" no bounds action ran, the simulation known from the last one read "", two jumps refused (15:53:48, 15:54:06).
- **Fix:** B36b-1 Mello never listed (`enemies::IsNonCombatant`); B36b-2 in an arena (live bounds not the level's default), no enemy within range: the nearest one inside the arena + 640 px is cued (slowest rate), and one left there counts as "on screen" for target down; B36b-3 a checkpoint jump whose simulation isn't at a checkpoint of the level scans for the live one before refusing. cues_test / enemies_test.
- **To try:** 2-b's bar before Denny: no boss cue for Mello; 4-c's arena before the Cesar fight: the perched rifle goon heard from anywhere in the arena; 4-a: jump to "Exit the level", then to another checkpoint.
- **Also checked in the log, fine:** the B36 rules ("no tone (the level unloading)" at every warp, "a boss leaving undefeated" for Mello and the Priest), bosses at 0 health, chapter names, the Hard start (`hardBtn`).

## 2026-09-30 — B36 (target down: quick successive kills, the level unloading, a boss walking off) — done (build/logs/20260930-160615-hard2: every warp's unload silent, Mello's and the Priest's exits silent, no burst of tones)
- **Why (the B35 session's log):** 2-c's final fight: three big goons shot within 125 ms gave three tones (each decided 400 ms after it left, when the others had left too); 2-b: after Denny's end video the level unloading gave two tones (the boss and a slave, the item manager lost); 3-c's start: the Priest walking off gave a tone (beyond the cue range).
- **Fix:** enemies still waiting to be decided count as on screen; no tone within 400 ms of the list being lost (`enemies::ListLostMs`); no tone for a boss leaving without his health bar at 0. cues_test B36-1.
- **To try:** the same as B31's target down; log lines `no tone (the level unloading)` / `no tone (a boss leaving undefeated)`.
- **Not changed:** 3-c's start also gave a tone for a grappler 1725 px away as the Priest left (likely killed in the scene: two death sounds near it).

## 2026-09-30 — B35 (a boss at 0 health keeps its open bell for the finisher) — done (the user: "Bosses at 0 health check out"; build/logs/20260930-153200-b35: the Butcher at 0 open, "Grapple now", the bell)
- **Why:** the user: "If a boss's health goes to 0 from weapons, grenades, etc the game waits in an infinite grapple now state until you initiate the qte ... the grapple now message played, the boss open cue did not."
- **To try:** bring a boss to 0 with guns or grenades: "Grapple now" and the fast open bell until you grapple.

## 2026-09-30 — B34b (Go to checkpoint in 1-b pre-train too; chapter starts named) — done (the user: "Everything seems to work"; on Hard a death after a warp reloads at the warped checkpoint)
- **To try:** 1-b pre-train (Other side of the Tracks): F7 > Go to checkpoint is there; 3-c: "Bell Tower entrance, the start of Bombs and Bells".
- **Log markers:** `checkpoint jump: simulation scan: N with the vtables, one at a checkpoint of this level`.

## 2026-09-30 — B34 (test mode: go to a checkpoint of the current level) — done (both 3-c jumps worked; 1-b pre-train had no menu: B34b)
- **To try:** F3 test mode on; in any level, F7 > Go to checkpoint: the level's checkpoints; Enter on one: "Loading <name>", the loading screen, then Shank at that checkpoint. Try one far ahead (3-c "Next to 1st fire hazard" for the rockets) and one behind.
- **Log markers:** `checkpoint jump: asked for ...; the simulation ... restarts at "..."`, `restart checkpoint now "..."; loading`, `checkpoint jump: the load request (...)` (its strings, for the cross-level step).

## 2026-09-30 — B31 (target down from list removal, the rockets' flight quieter, mid-level chapter names, startup volume log) — partly tested (target down in the B34 / hard sessions, the user: "That makes sense for the deaths"; the startup volume log used for the music tests); rockets heard in 3-c (build/logs/20260930-153200-b35; the user: "the rocket might be a bit quiet but I want to play more before I change anything there"); chapter names at a chapter's first checkpoint confirmed in the same log (2-b's Gimp Boss Fight -> Sweet Love, 2-c's final fight -> World of Warriors); awaiting user: whether the rockets stay at this volume (more play)
- **The B30 session (logs `build/logs/20260930-132503-B30`; 3-c; 4 marks):** findings in PLAN (B31).
- **To try:** any fight: the tone when the last enemy on screen dies, finishers and grapple kills included, before and after respawns; no tone when you die, or for enemies the rockets kill as they appear. 3-c: rockets (flight and explosions) quieter; "Bombs and Bells" when reaching the Bell Tower entrance. Launch the game and note whether the menu music is loud (the log now shows the first sounds with the game's music volume).
- **Log markers:** `cues: <enemy> died at ... -> target down | no tone (...)`, `cues: chapter <name>`, `sound: event <name> starts (its volume ..; the game's music volume .., effects ..)`.

## 2026-09-30 — B30 (target down by list removal, quiet only for cutscene videos, quieter rockets, 1-a's grenade tutorial) — done in part (the rockets "better"; target down → B31)
- **The B29 session (logs `build/logs/20260930-075301-B29`; 1-a, 1-b pre-train, 3-c; 5 marks):** the user: "The cue and level announcement fixes work. Target down on last enemy mostly doesn't. Also, cues should not stop on any video which doesn't also pause play. Several levels have short videos which play over gameplay. The rockets in bad confession are so loud they drown out most of the mod sounds." Findings: PLAN In flight (B30).
- **To try:** 1-a's fights: the tone when the last enemy on screen dies (locked or not); the short videos in 1-a (flashbacks over play) keep the cues on; 1-a after the first swing point (x ~13000): "Tutorial: Grenades ..."; 3-c's rocket section: the explosions about half as loud (tune `[sound] quieter=` in shank_access.ini).
- **Log markers:** `cues: <enemy> died at ... -> target down`, `cues: quiet while a video plays` only for cutscenes, `sound: <name> at N% volume`, `hook FMOD Event::start (quieter sounds) ... installed`, `tutorial: the grenade tutorial`.

## 2026-09-29 — B29 (target down by rule, chapter names, quiet cutscenes, cues end at death, end credits, story goals) — done in part (the user: "The cue and level announcement fixes work"; target down and videos → B30); still awaiting user: the end credits, the Priest's boss-fight goal
- **To try:**
  - Kill enemies without a lock: the target-down tone when the last one on screen dies, or one dies more than a screen away (blow one off a platform); none for one that falls screaming into a pit.
  - Loading any level: its chapter's name (e.g. "The Underworld"; "Leap of Faith" from that chapter) before any tutorial.
  - 1-c / 4-a starts: no cues during the opening video (and none during any cutscene video).
  - (the user: "the intermediate cutscenes at around 75% and 25% might be better options as it was very noticeable there") Cesar's mid-fight cutscenes at 75% and 25% (videos 4c_05, 4c_06): silent now.
  - A goon or boss killed: its cue stops at once; a boss's opening bell stops the moment you grapple.
  - Beat Cesar: the end credits are read (F8 repeats them).
  - W on, the Priest's chapter (Unjust Steward): Q says the way to "Boss fight"; entering it: "Checkpoint". Any level's last checkpoint: Q leads to "Level exit".
- **Log markers:** `cues: <enemy> died at ... -> target down|no tone`, `cues: <enemy> is falling to its death`, `cues: chapter <name>`, `cues: quiet while a video plays` / `the video ended`, `cues: Shank grapples: the opening bell ends`, `cues: the boss is defeated`, `menu: the end credits`, `waypoint: reached the <kind> trigger after checkpoint N`.

## 2026-09-29 — B28b (tracker checks relaxed; launcher grenades; checkpoints; taller gaps; T floors) — partly tested (the tracker through the B29-B34 sessions, no complaints); awaiting user: 2-c's items (launcher grenades, the stairstep checkpoint, the gap at x ~68736, T by the shimmy line), not replayed since
- **The B28 session (logs `build/logs/20260929-211354-B28`; 4-c: the Cesar fight, won; 2-c; 6 marks):** the user: "Had a successful cesar fight." Cesar: every "Parry now" (20) and "Grapple now" (2) spoken, the setup bell while he blocks, boss health; nothing missed. The tracker: 4-c tracked ~6 of ~16 min (107 losses), 2-c ~15 of ~23 (52): B28's checks dropped his real object after a grab's snap / (0, 0) finisher reads and banned it for the level. Marks: 1 checkpoint missed (tracker; 208 px trigger between two pings); 2 launcher grenades never reported (unpatched prop) + the slide pole jump to a swing point the model can't predict (open question); 3 grenade pickup silent outside the fight's live bounds (by design; now logged); 4 a 4-tile gap to a floor 3 up crossed without input (the user) had no gap sound; 5 the target-down tone only for locked kills (the user: "I hadn't heard it for most enemies"; question asked); 6 T didn't name the floor the chirp was for.
- **To try:** any fight with grabs and finishers: Q, edges and jump sounds keep matching Shank (`position: tracked address ... dropped` should be rare). 2-c: the grenade launcher goons' grenades warn in flight; "stairstep swing points" counts when running past; the gap before "Enter 2nd tall bldg" (x ~68736) plays the gap sound; hanging from the shimmy line near x 75500, T names the floor below.
- **Log markers:** `position: tracking` / `dropped: <why>`, `bounds: live x ...`, `cues: hazard grenade`, `waypoint: reached checkpoint 6 (stairstep swing points)`.

## 2026-09-29 — B28 (position tracker: no more wrong address; the scan off the sound thread) — done (played: it made tracking worse, fixed in B28b)
- **Why:** the B27 play session (below): the tracker followed a wrong address for 16 minutes (paths, edges and jump alerts from the wrong spot), and each memory scan froze our sounds ~140 ms.
- **To try:** any level, normal play, especially fights with grabs (4-a's start, the grappler) and tall wall climbs (4-a's pillar before "Last several set of fights with fire"): Q and the edge / jump sounds should keep matching where Shank is. Listen for stutters of our sounds when he's grabbed or respawns.
- **Log markers:** `position: tracking` (should mostly stay on one address), `position: tracked address ... dropped: <why>` (a bad address caught), `position: his own sound at ...` (a mismatch), `position: scanned ... (N stacks, ... left out)`.

## 2026-09-29 — B27 play session (4-a; audio stutters, pathing losing him) — done (findings → PLAN In flight; fix proposed)
- **The user:** "I was noticing some audio stutters and a few times it seemed like the pathing had lost me that I hadn't noticed before the last patch. It might just be my pc needs a reboot, but I want to check these logs before I do any more tests." Logs `build/logs/20260929-070621-B27play` (4-a from the start to past "Rocketlauncher vs shimmy", 06:33-06:52; no marks).
- **Frame rate:** ~60 fps all session (two dips on the first loading screens). Cue density normal (median 36 sounds per 5 s).
- **Stutters that are ours:** 3 memory scans for his position (~140 ms each) on the cue thread, 06:34-06:36. Anything else: not in the log (maybe the PC).
- **Pathing losing him:** the position tracker followed a wrong address from 06:36 on (RE-NOTES "Position tracker: a wrong address..."); e.g. the tall pillar climb at 06:51:42-06:52:10: Q "let go to a climbable wall" three times with no distance.
- The B27 fixes themselves (P routes, checkpoint goals, slide chirps, swing points, T) not judged from this session: no marks, and the tracker was wrong for most of it.

## 2026-09-29 — B27 (4-a / 4-c marks: pickup routes, checkpoint goals, slide chirps, swing interception, T wording) — deployed, awaiting user
- **The session (logs `build/logs/20260929-032434-B27`; 4-a wine cellar then 4-c villa; 5 marks):** all five addressed (PLAN B27 steps; DESIGN "B27").
- **To try:** P near a pickup on another floor (4-a start: the health above); 4-a after "Exit elevator shaft top": Q says the swing points to the right; 4-c slides: the jump chirps while sliding; 4-c swing point chains: Q goes to the next swing point; T while hanging / clinging / on a pole.

## 2026-09-28 — B26 (fewer, truer attack warnings) — partly tested (the B27 session's 4-a / 4-c fights and Toro: no marks about warnings); still awaiting user in the Priest fight
- **Why:** the user heard warnings for attacks out of range or that never came; the B25 log: ~1100 warnings in the Priest fight, ~10% followed by a hit (RE-NOTES "Wind-up reports that came to nothing").
- **To try:** any boss fight (the Priest, the Butcher, Toro): warnings mostly just before an attack you could be hit by, one per attack; none while you're caught in a finisher; none for a gunman's shot after his aiming whine.

## 2026-09-28 — B25b (the Priest: "Grapple now" only 300 px from the fire; "Wait" again if pushed back) — deployed with B26, awaiting user (the Priest fight not replayed since)
- **The B25 session (logs `build/logs/20260928-211915-B25`; the Priest fight 20:5x-21:13):** the user: "Still not successfull, ending up in the fire all the time when attempting the grapple opening". 10 stuns, 1 finisher. "Grapple now" came ~0.1 s after "Wait" (the flames reach farther than B25 assumed); after it Shank often kept hitting him, pushing him back toward the fire; the grapple lunge then ended in the flames.
- **To try:** after "Wait", stop attacking; grapple at "Grapple now" (about half a second later). If he's pushed back toward the fire you hear "Wait" again. Fight him from the arena side, not from the wall behind the trap.

## 2026-09-28 — B25 (the Priest: "Wait" in the flames, "Grapple now" once he's out) — done (B25b)
- **To try:** knock him into a fire trap: "Wait" at once (ignore his stun cry and stop attacking), then "Grapple now" with the fast bell when he has walked out toward you: grapple then.
- **Log markers:** `cues: prompt rt at (...): the Priest is in the flames -> say "Wait"`, `cues: the Priest is clear of the flames after N ms ... -> say "Grapple now"` (or `held too long`).

## 2026-09-28 — B24 (Priest fight: knock-back bell, flash-telegraph warnings; wall-run zone bottoms) — done (played in the B25 session: the setup bell ~105 times, the counter-kick warnings; the grapple problem it showed → B25 / B25b)
- **The Priest session (logs `build/logs/20260928-203512-priest`; 3-c from Bell Tower entrance, then the Priest fight 20:15-20:34; 1 mark):** mark 1 (3-c, the walk off into the wall run killed him; a jump worked): fixed (wall-run zone bottoms). The fight: 3 stuns, each Shank knocking him back into a trap (the bell came only 0.1-0.2 s before: it expected the trap between them); ~35 hits taken, ~10 of them with no warning: his block counter-kick (flash-telegraphed, not tagged as an attack). His health got to 50% at best.
- **To try:** 3-c after "Final climb up to the Priest": Q says long jump into the wall run. The Priest fight: the slow bell while he's near a trap with you on the other side; the heavy-attack buzz before his counter-kick when he blocks your hits.
- **Log markers:** `cues: boss_priest set up for an opening (lined up)`, `cue: en_windup_charge` from his block states.

## 2026-09-28 — B23b (the Gimp's bell with Shank up the walls) — deployed, awaiting user (2-b's Gimp fight not replayed since)
- **The B23 session (logs `build/logs/20260928-171636-B23`; 1-a fake Butcher, 2-b Gimp; no marks):** the user: "The fake butcher went flawlessly", the Gimp "definitely behaved at least most of the time, but there were a few situations where I wasn't sure". Log: 8 cuddles; 3 came with the slow bell first (Shank on the floor), 5 without (Shank clinging 11-13 tiles up the end walls: the bell required Shank on the Gimp's level). 20 bell periods, 17 without a cuddle right after (his grab cooldown, or he chose another attack).
- **Fix:** the Gimp's bell ignores Shank's height (a slave on the Gimp's level between them; Shank more than 4 tiles away, straight-line).
- **To try:** the Gimp fight from the walls: the slow bell when a slave is between him and your wall.

## 2026-09-28 — B23 (sound trims, the slow setup bell, boss alignments, Cesar) — done in part (fake Butcher: "flawlessly"; Gimp: B23b; Learn sounds used in the B23 session; the Priest's bell in the Priest and B25 sessions; Toro's bell in the B27 session). Still awaiting user (not reached yet): the Butcher's lowered-slab bell (1-c), Cesar's blocking bell (the final fight)
- **To try:**
  - F7 > Sounds > Learn sounds: one "Enemy behind you" entry; "Grenades or a weapon nearby"; "Target down"; "Boss set up for an opening" (the slow bell).
  - Lock on (L) a goon and kill it: the falling tone, no speech.
  - 1-a fake Butcher and 4-c Toro: the slow bell from his roar until he hits the wall, then the fast bell.
  - 1-c Butcher: shoot a slab down; stand so the lowered slab is between you and him (2-9 tiles from him, you 3-12): the slow bell; his hook throw then catches it: the fast bell.
  - 2-b Gimp: a slave between you and him, you more than 4 tiles away: the slow bell.
  - 3-c Priest: a burning fire trap between you and him: the slow bell.
  - 4-c Cesar: the slow bell while he blocks; "Parry now" when he grabs you.
- **Log markers:** `cues: <boss> set up for an opening (lined up)`, `cues: <boss> no longer set up`, `cue: en_setup` / `en_setup_end`, `enemies: target meatslab_low ...`, `cues: auto lock on meatslab_low`.

## 2026-09-28 — B22 (steady meat targets, louder shot-down tone, door broken tone) — partly tested (4-a's doors shot down with the tone in the B27 session); awaiting user in the Butcher fight (1-c not replayed since)
- **The B21 session (logs `build/logs/20260928-162113-B21`, 1-c Butcher fight then 2-a; no marks):** the auto lock works (the user); 11 blips where both slabs left the list for ~1 s during slow motion (fixed); 5 slabs shot down, 2 openings straight after (the Butcher must hook a lowered slab: RE-NOTES).
- **To try:** the Butcher fight: the lock stays on a slab through his slow-motion attacks; the shot-down tone is clear over gunfire. 4-a: the breakable doors play it when broken.
- **Log markers:** no `no longer shootable` without a `shot down` first; `enemies: target doorbreakopen ... shot down`.

## 2026-09-28 — B21 (Butcher fight: meat auto lock-on, shot-down tone) — done (the user: "The meat lock on works"; B22 fixes)
- **After B20 (the user):** "The cassandra pary prompt works now"; "The game closed properly this time" (B20-6); "The meat targeting does work now" (B19-1).
- **To try:** 1-c Butcher fight without pressing L: the hanging meat's lock tick starts by itself; shoot it (the in-line ting shows the aim): the falling tone, then the other slab is locked. L turns it off; it stays off until a slab comes back up.
- **Log markers:** `cues: auto lock on meatslab at (...)`, `enemies: target meatslab at (...) shot down`, `cues: played in 5 s: ... targetdown ...`.

## 2026-09-28 — B20 (louder turn whoosh, drops over jumps, drop-through hint, lock-on aims) — done (the user: the turn sound "definitely better"; "The game closed properly this time", and every session since ends with the exit line; 2-b's drop-through hint and the rope aims not replayed with W on, no marks on them)
- **To try:** turning: the whoosh is clearly audible. 2-b after Leaving Brothel with W on: "Drop through" only when near the spot, not repeated during fights. The first drop after Ground Floor: Q says walk off (twice), not a long jump. Hanging from a rope with enemies straight below: no ting; diagonal down ahead: ting.
- **Log markers:** `waypoint: hint` (rare now), `cues: locked enemy in line (aim N)` (no -90 while hanging).
- **B20-6 (exit hang):** quit with Alt+F4 as usual, several times across sessions; the process should always end. a11y.log's last line: `exit: handing over to the game's ExitProcess`.

## 2026-09-27 — B19 (hanging meat, turn whoosh, Cassandra's parry prompt, interactive props) — mostly done: the turn whoosh (B20-1 louder, "definitely better"), "The meat targeting does work now", "The cassandra pary prompt works now", 4-a's breakable doors listed and shot down (B27 session). Still awaiting user: the Masked Butcher's thrown barrels and the SWAT boss's flashbang as grenades (not reached)
- **The session before it (logs `build/logs/20260927-193424-B19`; no marks):** 1-c Butcher fight (19:08-19:12), then 2-a to the Cassandra fight (19:14-19:28). The Cassandra grapple's parry prompt showed ~110 times (`speedSlowDown` sounds) with nothing said; parries succeeded a few times (Parry_Enter). Nothing else odd.
- **To try:** 1-c Butcher fight: N and L list "hanging meat" while the slabs hang; shooting one drops it from the list. Any level: turning plays a soft whoosh on the new side. 2-a Cassandra: "Parry now" as she winds up her grapple (hold Block 2 as she lunges). 4-a: the breakable doors are listed as targets. Masked Butcher (barrels) and SWAT boss (flashbang): the grenade beeps.
- **Log markers:** `enemies: target meatslab at (...) can be shot` / `no longer shootable` / `can be shot again`, `enemies: target doorbreakopen ...`, `cues: Shank turned left|right`, `cues: prompt lt at ... -> say "Parry now"`, `cues: played in 5 s: ... turn ...`.

## 2026-09-27 — B18 (test mode on F3) — done (test mode on in every session of 2026-09-30, the startup movies skipped (`patch SkipLogoMovie ... applied`), F5 / F6 used)
- **Changed:** F3 turns test mode on and off live and saves it; F4/F5/F6/; do nothing while it's off; the startup movies are skipped only when test mode was on at start; the deployed ini now ships `test_mode=0`, so after the deploy test mode starts off until F3 is pressed once.
- **To try:** start the game (the movies play: test mode is off). F5 does nothing. F3: "Test mode on"; F5 toggles god mode. Restart: the movies are skipped and the greeting ends "Test mode on." F3 again: "Test mode off"; god mode is cleared. F7 > General lists "Test mode, F3".
- **Log markers:** `config: ... test_mode=N`, `test mode: on|off`, `test mode: God mode cleared`, `patch SkipLogoMovie ... applied` (only in test mode), `init complete: ... skip_logo=N skip_intro=N`.

## 2026-09-27 — B17 (F7 by category, Learn sounds grouped, F7 on menu reading) — done (the categories and Learn sounds used in the B23 session on the menu channel; no complaints)
- **The B16 session (logs `build/logs/20260927-092502-B16`, 1-a):** the user: "Sapi stuff works". Log: automatic messages in SAPI, 59-60 fps, no errors. Two deaths at 1-a's wall run: the first jumped at x ~25900, before the jump-now window; the second jumped with the chirp on, but at ~400 px/s (a standing jump steered forward, not the long jump's 720): the chirp means a long jump (hold forward as you press jump). Tutorials repeating after each respawn are the game's own.
- **To try:** F7: the categories; Enter into each, the settings and keys there, Escape back up; Sounds > Learn sounds in category order; the menu is spoken by the menu reading channel (set it to SAPI in Speech to hear the difference).

## 2026-09-27 — B16 (speech channels, our SAPI voice) — done (the user: "Sapi stuff works")
- **Deployed:** the DLL (no Lua changes).
- **To try:** F7, Down twice to "Speech settings", Enter. Set "Automatic messages" to SAPI, pick a voice with Left / Right (each change previews it), adjust rate and volume. Play: health warnings, pickups, tutorials and prompts should come in the SAPI voice and not be cut off by menu or key speech. Try the other channels too. Restart the game: the settings stay. F9 after an automatic message repeats it in SAPI. Mark anything off with F2.
- **Log markers:** `speech: our SAPI voice ready, N voices installed`, `say (menu|stats|auto[, SAPI]): ...`, `say (SAPI sample)`, `speech: <channel> channel -> SAPI`, `config: ... speech menu= stats= auto= voice= rate= volume=`.

## 2026-09-27 — data-pc override check — done (works)
- **What changed:** the 23 patched Lua files now live under data-pc/ as new files; the game's own data/ files are vanilla again. If the game didn't read data-pc first, every game-side report would be gone (position pings, beacons, hazards, wind-ups).
- **The check (the user asked for one specific thing):** start Return Home (1-a), take a few steps, press Q. It should name a move (e.g. "walk ... right, then ..."). "No position yet" = the override isn't being read.
- **Log markers:** `cue: pos_r` / `cue: pos_l` (the ping), `position: ...`; none = not read.
- **Result (logs `build/logs/20260927-083436-override`):** the user: "Everything seems to work with the new deploy mechanism." The log agrees: Q named moves, 267 pickup beacon reports, 46 enemy wind-up / aim reports, pickup messages. Also: "confirmed the skip cutscene prompt isn't working" → the B15-1 vtable was the wrapper's; now recognised by the movie's file (B15-1b). Tutorials were spoken (two opening together cut each other off → said together, B15-1b). B15-1b deployed 2026-09-27.

## 2026-09-27 — B15 (fixes from the marked session; B15-1b skip prompt fix) — done in later sessions (the skip prompt spoken, "Space to skip, Escape to pause."; Learn sounds; tutorials; the explosives hint; grenade flights; carrying 4-a's minigun gave no beacon following him; the rock clack in 4-a; gaps). Not replayed: 1-b's train (the gaps there, mark 9's spot)
- **Deployed:** the DLL; patches shank_transitions.lua, carryweapon_minigun.lua, carryweapon_flamethrower.lua (new); regenerated geometry (narrow gaps) and paths.
- **To try (press F2 on anything off):**
  - Cutscenes: Escape shows the skip prompt: "Space to skip, Escape to pause".
  - F7 > Learn sounds (the second item): Up / Down, Enter plays each sound; Escape back.
  - 1-a: the tutorial pop-ups (e.g. before the wall run): "Tutorial: Wall run. ..." (F8 repeats). 1-b pre-train: the first explosive in range: "Explosives nearby. Shoot them to hurt the enemies near them".
  - The minigun (1-b pre-train x ~24800): carry it around: no more minigun pickups appearing behind you. Pickups sound different by kind: health (the old notes), grenades (blips), weapons (chimes).
  - Grenades thrown from a distance: heard from the throw, following the grenade.
  - 1-b train gaps between cars: the new double-tock gap sound; safe edges doesn't stop you there; Q "run across the gap".
  - 1-b train x ~28600 (mark 9's spot) with W: the path now goes by the floor to the left, not up into the platform.
  - Falling rocks (4-a): the new clack.
  - Q: "run up the wall and climb over" / "walk off the edge" where the game does it for you.
- **Log markers:** `ui screen: ... = the cutscene skip prompt`, `menu: screen shown (movie ...) is <file>`, `settings: say`, `cues: hazard grenade`, `MARK`.

## 2026-09-27 — B13 session with marks (1-a, 1-b pre-train, 1-b train, 4-a) — logs `build/logs/20260927-073928-B13b`
- **The user:** "First testing session with plenty of marks is ready. Ask if anything needs clarification. Otherwise, game is closed so you can deploy any fixes."
- **Marks (the user's comments, verbatim; context lines in the log's a11y_marks.log):**
  - Mark 1 comment: First little thing to add. During cutscenes, pressing escape brings up a prompt to press space to skip. This needs to be spoken.
  - Mark 2 comment: targeting alert for for gun enemies works great. Also, we need a learn sounds item in the mod menu so players can learn all these beeps and chirps.
  - Mark 3 comment: Just before the wall run I just crossed, the game pauses for a second and plays the point of interest sound. Confirm what it's doing there and whether anything needs to be spoken.
  - Mark 4 comment: Grapple alert works. Missed announcements because I was too busy pushing buttons. Maybe an option to force sapi for game announcements? should investigate later. (Resolved: B16 added the SAPI channels, voice / rate / volume in F7 > Speech settings; deployed 2026-09-27.)
  - Mark 5 comment: Bug. picking up minigun starts causing the mod to see minigun pickups while walking and holding it. Also should have different pickup sounds for different items.
  - Mark 6 comment: The game highlights the explosives I just blew up before that last fight to illustrate how you can use them against enemies. Should see if we can translate these visual hints into spoken ones. Also explosives ranging works.
  - Mark 7 comment: We need to change the grenades from enemies to have the cue follow the flight path. As it is sometimes the cue only plays just before it detonates.
  - Mark 8 comment: Narrow gaps like this should have a slightly different sound. They're still lethal in the right circumstance, but Shank crosses them without input, so having a slightly different sound would make it clear they can be crossed normally.
  - Mark 9 comment: Had a bit of a pathing issue just before the last death. It was telling me to jump up into a platform while what I actually did was climb slightly and jump left onto the platform. There's a fairly narrow window there and jumping up from below didn't get me to it. The waypoint system didn't register the platform as an appropriate jump target, and the sound played only with waypoints off.
  - Mark 10 comment: Rock fall sound is no good. should be a sharp abrupt sound, something similar to rocks clacking toghether or an electrical snap.
- **Findings / fixes:** B15 (PLAN In flight).

## 2026-09-27 — B14 (F2 feedback marks) — done (marks work; B14b fixed mod keys firing while typing)
- **To deploy:** the DLL.
- **To try:** press F2 anywhere in play: the comment window should open with the edit box focused; type, Enter; the game comes back; "Mark 1 saved". Once more with Escape (no comment). Check the game didn't take the typed keys.
- **Log markers:** `MARK <n> at`, `MARK <n> comment:`, `input block: on/off`; the file `a11y_marks.log` in the game folder.
- **Result (2026-09-27, logs `build/logs/20260927-063212-B13`, 1-a):** the user: "test session and mark recorded, and also found a bug. The mod isn't letting go of keys on focus loss like the game." Mark 1 and its comment were written to both logs ("Marks should work. Game doesn't keep keys, but mod does. I'm getting status announcements as I type."). **Bug:** while typing in the mark window, mod hotkeys fired (L, E, K, H, W, G: "Safe edges on", "Waypoint on", ...): `GameIsForeground` counted any window of the game's process, and the mark window is one. **B14b fix:** our mark window class doesn't count as the game (hotkeys and cues are quiet while it's open). Deployed 2026-09-27.

## 2026-09-26 — B13 (Phase 2 leftovers, F7 settings, fire traps, gunmen aiming, cleanup) — done (played in the B13 / B13b sessions; marks → B15; the Credits / Achievements / Concept Art / About Us screens never opened in a logged session)
- **Deployed:** the DLL; patches: stategraphutil.lua (B13-4 aim reports), firetrap_stategraph.lua (new), pickup_common_actions.lua (beacon only once landed); regenerated geometry, paths, UI text.
- **To try (any order):**
  - Start-up: "Shank access loaded. F7 for settings."
  - F7 anywhere (best from the pause menu: the game keeps running otherwise): the settings list (Up / Down, Left / Right or Enter to change, Home / End, Escape or F7 closes). Change the cue volume and hear the cues after closing; turn an announcement off (e.g. Combo announcements) and check it stays quiet; rebind a key (e.g. Health to J) and use it; check the game didn't react to the keys pressed in the menu (Shank shouldn't move; the pause menu underneath shouldn't change); restart the game: the settings should be kept.
  - Help & Options: the title adds "Shank access settings: F7." once. Credits: the whole credits spoken (F8 repeats). Concept Art and About Us: titles.
  - 3-c Priest boss fight: the fire traps' crackle, faster as you get near them.
  - Pistol, AK and uzi gunmen (1-b, 2-c, anywhere with guns): a thin rising whine while one holds his gun out, stopping when he fires.
  - An enemy dropping a pickup: its beacon should start only once it lands.
- **Log markers:** `settings: say`, `config: settings saved to shank_access_user.ini`, `input block: on/off`, `hook GetRawInputData: installed`, `hotkeys: <id> is now <key>`, `menu: Credits opened`, `credits: N characters`, `cues: hazard fire at`, `cues: gunman aiming at`, `played in 5 s: ... hazardfire, enemyaim`.
- **Risks to watch:** a key held down as F7 opens should be released for the game; Escape closing the menu shouldn't also act on the pause menu underneath.

## 2026-09-26 — B12 (pathing audit) — done (played with B13)
- **To deploy:** the DLL, regenerated geometry (slide-speed drift at slopes' low ends) and paths (slopes, platformup, pole drops, joined pieces).
- **Pre-deploy:** `geometry.py`, `path_graph.exe`, `path_check.py --all` (101/101), all host tests.
- **To try:** slippery slopes (1-c's cold storage slides: only downhill jump targets while sliding; Q "slide N tiles"); a one-way platform the path needs the jump again for (Q / the waypoint hint "Jump up into the platform above, then jump again"; 62 such moves, e.g. 1-a from walls under platforms); 1-c's bar that leads onto the slide pole (x 10551). Don't relaunch before the logs are collected.
- **Log markers:** `waypoint: hint "..."`.

## 2026-09-26 — B10b + B11 (deployed together) — done (played in the B13 / B13b sessions)
- **Deployed:** the DLL, regenerated geometry (drift-to-pit deadly ends, player pits only) and paths (pits, pole jumps both ways, climb-over rule, launch ranges, B11 moves).
- **To try:** 1-c again with W and Q: the cold-storage slides should say deadly; Q on the pole; the wall-34 section; pole side switching (B11) and dropping through floors where Q says so. Don't relaunch before the logs are collected.
- **Log markers:** as B10, plus `waypoint: switch sides of pole`.

## 2026-09-26 — B9 batch (attack warnings for special attacks only; platform overhead) — done (B9b / B9c fixes; grab alerts, boss openings and prompts confirmed 2026-09-27)
- **Deployed:** the DLL and the stategraphutil.lua patch (attack kinds).
- **To try:** fights with big goons, grapplers, chargers, bosses (grab chirps: two harsh rising chirps; heavy buzz: a harsh falling tremolo); ordinary goons' attacks should now be silent. Walking under platforms you can jump up onto: one chirp as each comes in reach.
- **Platform-overhead spots given to the user (from `traversal_audit.exe <geometry> --overhead <level>`, the same logic as the cue):** Return Home (1-a, start x 712): a ledge 2 tiles up just left of the start (x 384-512, y 320), then the 2-tile step before the bar (x 2816-3200, y 320; reached from x ~2500). Venom of the Vipers (2-c, start x 1574): two ledges like stairs past the first fight (x 3968-4288 at y 320, then x 4288-4928 at y 448; from x ~3650 and ~3980).
- **Log markers:** `cues: grab attack from`, `cues: heavy attack from`, `cues: platform overhead in reach`, `played in 5 s: ... heavyattack, grabattack`.
- **User report (2026-09-26):** "These chirps are all firing for small ledges and steps that shank traverses without user input. Also, I was hanging from a swing point in the first level, and was able to shoot a dog below me. The enemy sound worked, but lock on either did not pick it up or the sound is close enough to the enemy sound that they blend. look into this."

## 2026-09-26 — B8 batch (enemy awareness; falling-hazard snap) — done (B8b-f deployed; B8f "blew away my expectations"; attack cues reworked in B9)
- **To deploy:** `bin/shank_access.dll`; patch to `data/stategraphs/stategraphutil.lua` (attack-start reports).
- **What's new:** DESIGN "Enemy cues", keys N and L; the falling-rock/ceiling warning is now a snap.
- **Instructions:** any level with fights (1-a's bar, 1-b pre-train, 2-c red light for girls, dogs where they appear). Listen for the nearest enemy's tick (does it lead you to it; is "behind" clear; can you tell goon / big goon / girl / dog / boss apart?), the whoosh before attacks (early enough to block or dodge?). Press N now and then. Try L on a gunman or a goon across a gap: face it and listen for the ting; try shooting when it tings (straight, diagonal up, etc.). Also: barrels at range (B7b) if convenient; any falling rocks (the snap). Don't relaunch before the logs are collected.
- **Log markers:** `enemies: N character names`, `enemies: scanned for the item manager`, `enemies: item manager at`, `enemies: Shank's team`, `enemies: <name> (<kind>) team`, `enemies: <name> gone`, `enemies: ... unknown attributes hash`, `cues: nearest enemy`, `cues: lock on`, `cues: locked enemy in line (aim N)`, `cues: played in 5 s: ... enemy*, windup, lockinline`.
- **User report (live, 2026-09-26):** sniping at range: "the mod said no enemies nearby" (→ B8b); "lock on should adjust its range ... based on the equipped ranged weapon" (→ B8b); a slide pole in 2-b chirping from below (→ B8c). After closing: full notes in DESIGN "The user after B8" (→ B8d).
- **Logs:** `build/logs/20260926-185946-B8` (1-a, 1-b pre-train, 1-c, 2-b). The reader worked (every goon named); enemies leave the list with the game's death sound; the checkpoint-restart gap; the slide pole (RE-NOTES).
- **Fixes deployed together (B8b + B8c + B8d):** see PLAN In flight and DESIGN "Enemy cues" / Hotkeys.
- **After B8d-f (the user, 2026-09-26):** game sounds around Shank (B8f): "This blew away my expectations. This is much closer to how blind gamers operate in other games"; attack cues "mostly useless" in busy fights (→ B9-1); "Otherwise I think enemies are good as is for now". Logs of that session: `build/logs/*-B8f`.

## 2026-09-26 — B7 batch (safe edges; hazard warnings) — done (B7b: rocket tracking "much better"; barrels at pistol range confirmed 2026-09-27, "explosives ranging works")
- **To deploy:** `bin/shank_access.dll`, `bin/shank_access.ini` (new `[edges] safe_edges=0`), patches to 7 hazard stategraphs (rockfall, breaking_ceiling, rocket, guidedmissile, grenade_timed, explosive_barrel, propane_tank).
- **What's new:** E toggles safe edges; hazard warnings (DESIGN "Hazard warnings", "E: safe edges").
- **Instructions:**
  - Safe edges: in any level press E ("Safe edges on"). Run at a drop or pit: he should stop and hop back; holding the direction keeps stopping him; release, then tap toward it again: he goes over. Small steps shouldn't stop him; jumps never. Press E again: off.
  - Hazards: 1b pre-train / 2b love hotel / 4a wine cellar for barrels and propane tanks (slow soft beeps near them) and grenade-throwing large/AK goons (fast beeps when a grenade lands near); 3c church for breaking ceilings and the rocket spawners on the covered walkway run-through; 4a's final platforming for falling rocks; the 1b train boss for guided missiles. Any subset is fine.
  - Report: whether the stop feels right and "another tap" works; whether each warning comes early enough and is distinguishable; anything too chatty. Don't relaunch before the logs are collected.
- **Log markers:** `edge guard: guarding / stopped / another tap`, `hook HasTag_ParseNode::Evaluate ... installed`, `cues: hazard <kind> at` / `gone`, `cues: played in 5 s: ... hazardfall / hazardprojectile / hazardexplosive`.
- **User report (2026-09-26):** "The edge stuff works perfectly. Stationary explosives need a significant range boost, as a frequent method of dealing with them is shooting them with the gun at range. Check the pistol's range and set the outer edge of the explosives detection to that, with proper checks to make sure a wall or boundry isn't in the way. For moving explosives, the grenade sounds work. For the rockets specifically, which is the last level I played, the audio cue lagged noticeably behind the panning of the rocket. One would go over shanks head and detonate or despawn way off in the distance but the audio cue would pan significantly slower than it and end up much closer. There's also something weird going on with health. I had god mode on but was still taking damage normally, where I don't think I was earlier. Also, it's reporting 0% boss health at all times, and it definitely wasn't doing that before. Game is closed now so you can deploy any fixes."
- **Logs:** `build/logs/20260926-165713-B7` (1a, 1b pre-train, 1b train, 3c church).
  - Safe edges: works (the user). Barrels: `hz_barrel` every 0.5 s as designed.
  - Rockets (3c): reports every 100 ms, ~1150-1530 px/s (~115-150 px apart); the warning played at the last report (up to 0.1 s behind) and lingered 0.4 s after the last report (explosion / despawn) = the lag the user heard. Some rockets report once at y 2960 (probably exploding at once).
  - Boss: the only boss was 1-a's scripted fake Butcher (`fakebutcher.png`): bar set to -650, then 0; the name is never cleared (the HUD's name reset happens only when it's first built), so H said "0 percent boss health" for the rest of the session.
  - God mode: health dropped with it on in **every** logged session since 1b-4 (2026-09-25 onward; 21-77 drops each), reaching 0 and below. The flag (0xae6539) is read in one place only (0x4c6f44, a team comparison inside what looks like damage handling). Not a B7 regression; retail god mode doesn't block damage.
- **B7b fixes (built 2026-09-26):** barrels and propane tanks warned out to the pistol's range (PISTOL_RANGE = 40 tiles, 2560 px) only with a clear line of fire (`level_geometry::LineClear` against walls, ceilings, floors; inside the bounds), fastest inside the blast; moving hazards carried on at their speed between reports (≤ 0.15 s), dropped 0.2 s after their last report, rockets flying away beyond 600 px silent; H leaves out a boss at 0 and a level load forgets the boss (`status::ForgetBosses`).

## 2026-09-26 — B6 batch (systematic traversal pass) — done (deployed 4890395)
- **To deploy:** `bin/shank_access.dll` and the regenerated `bin/shank_access_geometry.txt` (now with `pit` lines read by the DLL). No Lua changes.
- **What's new (DESIGN "B6-5", "Wall runs", "Slides", "B6-4"):**
  - jumps blocked by walls, ceilings and floors no longer chirp (should cut the "occasional extra chirps");
  - jump up (holding up) off swing points and bars; the stronger jump off a wall he's running up;
  - wall running: the run's end pulses ahead (deadly buzz or safe tock, from a simulated fall off the end), targets judged with the wall-run jump, and near the end the long jump;
  - sliding down a slide pole: its bottom pulses (centred), deadly or safe;
  - floors inside fatal pits (1-c's grinders) are never landing targets.
- **Instructions:** carry on in 1-c from where the user is (in the building), and try one wall run (1-c's, or 1-a's "Wall Run" checkpoint: deadly on both sides). Listen for: a pulse ahead during the wall run and whether deadly/safe is right; chirps for what the wall-run jump reaches; fewer chirps for things a jump can't reach; any slide pole's bottom. Report anything that chirps but can't be reached, or that is reachable with no chirp. Don't relaunch before the logs are collected.
- **Log markers:** `cues: edge ahead: ... surface -3` (wall-run end), `surface -4` (slide-pole bottom), `(jump up)`, `(wall-run jump)`, `(jump off the wall while running up it)`, `traj:`.
- **User report (2026-09-26):** "The latest round of testing is also done and looks good. It'll probably still need some fine tuning for certain geometries, but the concept is solid and functional. I played through a few stages to do a longer test." Also confirmed: boss health, both automatic and on H (B3). Pickup beacon: "the pickup beacon just needs a bit of fine tuning at some point since it does a couple odd things like detecting the actual falling item when an enemy is defeated and continues for a second or so after the pickup initiates, but we can handle those and a couple other random small things in a later cleanup pass."
- **Logs:** `build/logs/20260926-141120-B6` (1b train, then 1c; crash.log empty, no Lua errors).
  - Every new launch fired: 179 "jump now reaches" changes: long 51, swing 29, wall 27, running-up-wall 22, pole 18, jump up 15, standing 8, bar 6, wall-run 3.
  - 1-c's wall-climb zone (x 1478-2546) as a wall run: heading left its end is deadly (nothing below), heading right a 1912-1939 px drop onto a floor (safe). 219 edge-change lines.
  - `perf:` below 55 fps only at the two level loads (36-45 fps, as in B5d/B5e): B6 costs no frames.
  - Position tracker: 16 `lost` lines (B5e: 6), each re-found (17 `tracking`); mostly in 1b train (x 10270-19743). Not investigated (PLAN open question).
- **Conclusions:** the traversal model and cues work in general play; per-geometry tuning later as the user meets problems.
- **Follow-ups:** a cleanup pass (pickup beacon: dropped items heard while still falling, beacon continuing ~1 s after pickup; "a couple other random small things").

## 2026-09-26 — B5 batch (boundaries, jump targets, climbable walls, edge pulse) — deployed e9f07f6; played; B5b deployed 8646e8b; played; B5c deployed 5853a86; played; B5d deployed 87997a0; played; B5e deployed 9975d03; played (the user: "More progress. I got into the building, and navigated a bit. I'm still getting occasional extra chirps from stuff a jump angle won't reach, but it's not many."; logs `build/logs/20260926-130338-B5e`). B5 done; next B6
- **B5d result (the user):** "We're getting better. Second swing point after the first climb reports jumpable. Wall run section now chirps. Jump from first poll to second still doesn't. Facing right from the second swing point reports the first as jumpable, but I couldn't figure out an input to get back, I always fly over it. Lastly, look at whatever object I was on just before the last fatal jump..." Then: "It's from the poll to whatever I was on just before the wall run segment. I went back and forth across that a couple times." Logs `build/logs/20260926-123238-B5d`: see RE-NOTES (pole and pillar bounce, bar jump, swing flights above the point).
- **B5c, second report (the user):** at the top of 1-c's tall pole "No jump chirp is playing for either" (no pole jump in B5c's model); then "I made the next jump successfully, but then jumped too high for the wall run or whatever's next, and from the sound clipped the top of it and landed on a platform. No chirp played even when I was in the proper range." Logs `build/logs/20260926-122046-B5c`: the jump off the pole top matched B5b's successful one to the frame, but this time he fell through the zone (RE-NOTES "Wall-run zone entry"); the position tracker "lost" Shank mid-fall (the ping lags a frame; tolerance now grows with speed).
- **B5c result (the user, 1-c's first wall and swing points):** the second swing point never chirped (no swing-release jump in the model); some wall-jump angles that work had no chirp (measured ~600 px/s across vs the model's 548 top); the chirp too loud or harsh. Live log copied to a temp file (game still running).
- **B5b result (the user):** "1c is a little better, but the chirps still seem a bit off. Also undo half the volume change you did, they went from being a bit quiet to way too loud." Logs `build/logs/20260926-120012-B5b`: chirps now play (bursts of 20-30 in 5 s). Found: "reaches" flickering every few frames while bobbing at a climb's top (the bar at y 4181); the wall zone beside the wall he climbed (x 1478 vs 1376) chirped; mid-air "standing jump" chirps; the death at 11:58:31: the wall-run zone at x 3500 was reachable for 0.2 s before the edge, and he went off the edge without rising (too late).
- Logs: `build/logs/20260926-115445-B5`.
- **User reports (live, game still running):**
  - 1-a, hanging from a swing point: "The string sound only played once when approaching the ledge at speed, and the jump alert did not play, or triggered for such a short time that I couldn't hear it. Also of note, the new sounds do not stop when pausing or leaving a level... Also any alerts for an object should stop when you're interacting with it."
  - 1-c's wall climb: "found a few jump targets which played the strings but never played the chirp."
- **Log (live a11y.log, copied to a temp file):** 1-a: the long-jump window for the swing point at (14160, 1984) lasted ~0.26 s at running speed (one 250 ms chirp at most); "wall jump" flickers right after (mid-jump near a wall counted as clinging). 1-c: Shank climbed the wall at x 5344 from y 432 to ~1400, then slid down; the wall jump to the swing point at (4726, 1045) was judged reachable from y ~936 up, for 3.6 s. 10 long-jump arcs calibrated the model (RE-NOTES).
- **Built (host-tested: cues_test, jump_model_test, level_geometry_test with real 1-a/1-c data, level_hook_test, position_test; Python geometry tests):**
  - 5-1 the edge pulse follows distance when standing too.
  - 5-2 arena/checkpoint bounds read from the game (cSetBoundsAction hook → the simulation's bounds): a bound before an edge = a wall; pickups/features beyond it silent and out of P/T.
  - 5-3 jump model (standing, long, wall jumps; gravity and air steering guessed) + `traj:` logging of jump arcs for calibration.
  - 5-4 jump targets: pluck (nearby) / chirp (a jump now reaches it) for swing points, poles, bars, wall zones; the far side of deadly drops; wall-to-wall while clinging; climbable walls knock higher.
- **To check:** 1-a's wall run (chirp window x 25880-26296 by the model), 1-c's opening climb into the warehouse, Leap of Faith (4a's final stretch). Bounds: pickups/ledges beyond arena bounds silent. The `traj:` lines from any jumps (for calibration).

## 2026-09-26 — B4 batch (the geometry push: edge cue v2, position tracker, T key) — done
- **User report (2026-09-26):** "Edge ranging needs some work, as it was doing the slow pulse even when standing right next to it, and only sped up when I was. For deadly drops with jump targets, we should have a cue for when the target is in range. Check out the deadly drop near the wall run point in 1a, as I had several deaths trying to range that right. I also think artificial boundries should be a priority, as items and ledge sounds can sometimes play beyond arena or checkpoint boundries when they shouldn't." (Full text and the next-batch request in DESIGN.)
- **Logs:** `build/logs/20260926-091831-B4`. Level hook fired for every load (1-a, 1b pre-train, 4a). The position tracker scanned ~495 MB in about half a second, found Shank at the level start and after every respawn, and re-found the **same address** each time (stable within a level). Four deaths at 1-a's wall run (08:44), each after the deadly-drop cue at x 26304. Edge cues logged for the step, drops, walls, deadly ends as designed.
- **Built (host-tested: cues_test, position_test, level_geometry_test with the real 1-a data, level_hook_test, Python geometry tests; Lua load test):**
  - The level's own collision decoded offline (`tools/levels/slev.py`, `geometry.py`) → `bin/shank_access_geometry.txt`.
  - Level hook (LevelData::LoadSimData 0x495e30): the DLL knows which level loaded.
  - Position tracker: a memory scan finds Shank's live position after he stands still for half a second; then read every 15 ms.
  - Edge cue v2: safe drop tock, deadly drop buzz (new), wall knock (louder); range 12 tiles or 1.6 s ahead at his speed; steps he hops are silent.
  - T key: nearest swing points, poles, slide poles, shimmy lines, wall runs.
  - Lua: only the position ping remains in Shank's lists.
- **Instructions (to give):** level 1-a from Start. Stand still for a moment at the start (the tracker needs it). Run right: the step at the bar (x ~2800) should be silent or a short knock, the drop after it a tock, the long street should have no false edges, the wall at the end a knock. Near the bridge (Pre Bridge checkpoint) the gap should buzz (deadly); press T near swing points. The wall run and last pit too if there's time. Report: warning distance at speed, the three sounds distinguishable, anything wrong or missing (arena boundaries aren't cued yet).
- **Log checks:** `level: LoadSimData(...) name ...`, `geometry: level ... loaded`, `position: scanned N MB ... candidates`, `position: tracking ...`, `cues: edge ahead: ...`.

## 2026-09-26 — B3 batch (Phase 3 finished; Phase 4 cues v1) — done (lag fixed in B3b/B3c; edge cue replaced in B4)
- **Built (all host-tested; the Lua load-tested under real Lua 5.0):**
  - 3-2 pickups: "Picked up minigun" (etc.), "Picked up health, 80 percent health" (0.7 s later), "5 grenades".
  - 3-3 boss health at 75/50/25: "40 percent boss health"; H: "80 percent health, 73 percent boss health".
  - 3-4 combo: "12 hit combo" once a combo ends (the counter restarts, or 3 s without hits); 3+ hits only.
  - 4-1/4-2 our own cue player (XAudio2, synthesized sounds) and Shank's position ping.
  - 4-3 drop cue (low tock) and wall cue (soft knock), pulsing faster as they get nearer (1–4 tiles), panned to the side Shank faces.
  - 4-4 pickup beacon (two rising notes) relative to Shank: pan = left/right, pitch = above/below, faster and louder when near; "<kind> in reach" + a bright ping in the pickup box; **P** = pickups nearby. The Uzi_Arm beacon is gone.
  - `[cues] volume=80` in shank_access.ini.
  - B2's check rides along: "73 percent health"; Previous/Next Gun/Weapon rows say their keys.
- **Instructions given:**
  - Where: the first level (1-a, the wrestling ring / bar, "Start" checkpoint): pickups, edges, walls, pits and the Butcher boss fight. If there's time, the next level (1b pre-train): a shotgun near the start and a minigun further on.
  - Listen for: the drop tock approaching platform ends (does it speed up in time? does it warn before pits?), the wall knock at walls, the pickup chime (does its pan/pitch lead you to the pickup?), "in reach", pickup announcements, boss health, H during the boss fight, combos.
  - Try P now and then; try Block + Down on "in reach".
  - Report: is anything too loud/quiet/chatty; are the sounds distinguishable from game sounds; any drop that wasn't warned about; any cue that stuck or lagged.
  - Don't relaunch the game before the logs are collected.
- **Checks in the logs:** `cues: shank at (x, y) facing …` (facing true = right? y up?), `cue: drop_N`/`wall_N` lines before falls, `cues: pickup … gone` after collecting, `status:` lines for pickups/boss/combo, `audio: XAudio2 started`.
- **User report (first run, 2026-09-26):** "Something's polling too quickly or something, as the game is running noticeably slower." They quit after about a minute in 1-a (Start → Front of Bar).
- **Logs:** `build/logs/20260926-072331-B3-lag`. Nothing floods: position pings every 100 ms (616 of 650 gaps exactly 100 ms), beacons every 0.5 s, 1,593 a11y lines in total. No drop/wall reports at all in that stretch (flat street, y = 224 throughout). The ping lines were logged by mistake (the filter checked "pos", the names are "pos_r"/"pos_l"). The log can't show the frame rate, so the cause isn't identified.
- **B3b (built 2026-09-26):**
  - A frame-rate monitor: `perf: <fps> fps, game time <x> s per s, longest frame <ms> ms` every 5 s (from the SwfScreen::Update hook).
  - Test-mode **F4**: our cue audio engine off/on (XAudio2 StopEngine/StartEngine), to see if it costs frames.
  - Lua made cheaper whatever the cause: the drop/wall distance checks and the pickups' range probes now sit behind a gate (a CompoundTransition on the report countdown), so they're evaluated only when a report is due (every 0.15 s / 0.5 s / 0.25 s) instead of possibly every frame; distance bands are exclusive (one report per check). The beacon probe box was also 5× the area of the old one.
  - Position pings no longer logged.
- **B3b result (the user, 2026-09-26):** "If anything that was worse. Shank is now getting stuck on level geometry. Audio engine on/off didn't seem to make a difference. No lag was experienced in menus or loading screens." Logs: `build/logs/20260926-074221-B3b`.
  - `perf:` 59.6–59.8 fps and game time 1.00 s per s throughout, F4 on or off: **not a frame-rate problem**. Shank himself was hampered.
  - **The cause:** `cue: wall_3` logged **10 times in the same millisecond, every frame**. A firing transition makes the game re-check the list, apparently up to 10 times a frame. B3b's gate reset its countdown in a separate last child, which the re-checks never reached, so the report fired 10 times every frame. B3's first build fired about 10–17 times a second inside Shank's lists (pings every 0.1 s, reports every 0.15 s), which likely hampered him too.
- **B3c (built 2026-09-26):** every one of our transitions disarms itself in its own actions. Shank's lists: drop/wall reports only on a band change (counters `a11yDrop`/`a11yWall`), a refresh once a second, `<kind>_0` when the edge is gone or he leaves the ground (AIR_REACTIONS); position ping every 0.5 s. Pickup gates: each child resets the countdown. Native: a band lasts until `_0` or 1.5 s without a refresh. Plus a log-only probe of the sound event (does it point at Shank's game object? then his position could be read without pings).
- **B3c result (the user, 2026-09-26):** "Game runs normally now, but boundry walls still show up as edges, the wall clicks only happen when right on top of them, and edge detection range is way to short, especially at speed." Logs: `build/logs/20260926-075936-B3c`.
  - Movement fixed (rare, self-disarming reports).
  - Running speed about 770 px/s (a band change every ~83 ms per 64 px), so 4 tiles = 0.33 s of warning.
  - **False edge at a floor seam:** heading left at y 224 from x 5951, drop_4 … drop_1 then drop_0 at 5704 while Shank ran on at the same height. `disttoendofplatform` measures to the end of the current floor piece, even where the next continues flush.
  - A drop_3 held for 3 s at x 4325 (facing right, no wall report) before a fight: probably an arena boundary counted as a platform end.
  - Walls at x ~7300: wall_4 … wall_1 reported from 4 tiles (wall wins at equal bands), but the knock is quiet (volume 0.31 at 4 tiles) and slow.
  - A real (safe) drop: y 352 → 224 at x ~3200; a step up: y 224 → 352 at x ~2700 (reported as wall + drop, then both _0).
  - Combos, pickups ("Picked up health, 100 percent health"), "Health in reach", 75 percent health all spoken.
  - **Sound-event probe: negative.** No dword in the first 0x60 bytes of the sim sound event points at memory holding Shank's (x, y) within 0x800 bytes (3 pings; dumps in the log).

## 2026-09-26 — B2 (number-first health, bindings digits) — done ("75 percent health" in the B3c log; the digit-key rows not heard yet)
- **Fixes:**
  - "73 percent health" (drops and the H key).
  - Key bindings rows keep digit keys: "Previous Gun: 1". The first build dropped them as unreadable. Rows are (icon, action, key) and are read as "action: key".
- **Pre-checks:** `status_test` 36/36, `menu_reader_test` passes (a digit-key row added), `ui_hook_test`, `hook_test`, `proxy_smoketest` and the Python tests pass.
- **To check in the next batch:** health announcements and H say the number first; Previous/Next Gun/Weapon rows say their keys.

## 2026-09-26 — B1 batch (fixes from the morning test) — done (deployed 0bf3c7e)
- **User report:** "Control rebinding works great. I used grenades as an example, but all status readouts with numbers should read the number first. Fix health so it reads that way. Otherwise things looked god."
- **Logs:** `build/logs/20260926-061935-B1`; crash.log empty.
  - Key bindings list: "Key bindings list, Move Left: Left, 1 of 16", rows per arrow; a rebind "Block: -Select New Input-" → "Block: Tab". **But** "Previous Gun, 13 of 16" lost its "1" (digits failed the readable test) → fixed in B2.
  - How to Play pages read their drawn text. F8 repeated the loading tip and tutorial. H/G: "Health 100 percent", "3 grenades", "0 grenades".
  - Weapons: "Weapons. Machete, equipped" (late equipped); "Katana. A finely crafted instrument of death." (own slot only).
  - The Controls "Warning" dialog text was read. No grenade announcement on level load.
- **In the batch:**
  - the How to Play drawn text (36ec0fb, plus the new artifact `bin/shank_access_ui_text.txt`);
  - Weapons (own slot only; late "equipped");
  - grenades (not on level load; "3 grenades");
  - H/G keys;
  - F8 = repeat the last long message;
  - the key bindings list (rows, rebinds).
  - See DESIGN "B1 fixes" / Hotkeys.
- **Pre-checks:** `menu_reader_test` 165/165, `status_test` 36/36, `ui_hook_test`, `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings.
- **Instructions to give:**
  1. How to Play: each page's explanation after its title.
  2. Pause → View Weapons: "Weapons. Chain Fists, equipped". Choose weapons: only that weapon's title and description.
  3. Help & Options → Controls → up to the list: "Key bindings list, Move Left: Left, 1 of 16". Arrow through the rows. Rebind one: hear "-Select New Input-", then the new key. Rebind it back.
  4. A level: no "3 grenades" on load. H and G. F8 after a tutorial hint or tip repeats it, not the last menu item.

## Morning test plan (overnight push, 2026-09-25/26) — done (fixes in B1)
- **User report:** "I'm done playing. Most things work, though the weapon page feels a bit awkward and you should see why from the logs. When a new level loads it re-announces the grenade value, which cuts off anything else that might have been intended for that point. The number should read first, 3 grenades, not grenades 3. Split the health/grenades keys up to h/g respectively. Let's turn f8 into a repeat button which reads the last screen, tutorial message, etc that was spoken. It should not capture short text like menu items or status readouts. Finally, NVDA picked up on an unlabeled list box which appears to be for reassigning controls. Try to get that working." Earlier, mid-test: "only the how to play section's title is read, none of the actual how to play text."
- **Logs:** `build/logs/20260926-055945-morning-overnight`; crash.log empty.
  - **Worked:**
    - F8 read the Controls list (all 16 bindings, for keyboard and the 360 controller);
    - loading tips;
    - health drops at 75/50/25 ("Health 73 percent" …);
    - grenade pickups ("Grenades 4/5");
    - weapon names and descriptions;
    - outfits.
  - **Problems:**
    - choosing a weapon read both slots ("Shotgun. …, Chainsaw. …");
    - "equipped" missing on opening;
    - "Grenades 3" on every level load (with health 100 in the same ms);
    - How to Play explanations are drawn text;
    - the list box is navigable (change events with a row index) but was only "List box".
Built overnight while the user slept, **not deployed** (the game is on the tested 01639fc). In the morning: ask to deploy, then run these in order. Each item names its build step; fixes follow as usual.
- **N1, weapons and outfits (built in commit "N1: …"):**
  - Pause → View Weapons:
    - Expect "Weapons. Chain Fists, equipped" (or your equipped melee weapon).
    - Move between the weapons: each has a name, and "equipped" on the ones in use.
    - Choose a different weapon (Enter): its new title and description are read, e.g. "Uzi. …".
    - Names we guessed (Machete, Katana, Shotgun) are replaced by the game's own title once chosen. Tell me the names you hear.
  - Pause → View Unlocks: outfits by name ("Shank outfit", "Wildman outfit", "Horror outfit" …).
  - Log checks: `menu: … chosen -> description`, and whether `._disabled` or `.disabled` answered.
- **N2, in-game text (built):**
  - Start a level: while it loads, expect "Loading. Tip: <tip>".
  - Level 1-a: when the tutorial prompt appears, expect "Tutorial: <hint>" (once, not repeated while it stays up).
  - An unlock pop-up (new weapon or outfit), if one appears: its text before "Continue".
  - Log checks: `menu: … written -> say` lines; check that nothing repeats every frame.
- **N3, long pages and the F8 read-screen key (built):**
  - Help & Options → How to Play: expect "How to play. <move name>. next". Press Next/Prev: each new page's name is read (about 0.15 s later).
  - **F8 anywhere in the menus:** reads the screen title, its text, and "Focus: <item>". In the pause menu it also reads the stats: longest combo, kills, per-weapon kills. In level select: the selected chapter.
  - Credits: title/results text if present (the credits themselves look like a movie).
  - F8 with no menu focus: "Nothing to read here" (Phase 3 may change that).
- **N4, list boxes and the Controls screen (built; a new hook: InvokeMethodInternal 0x559920):**
  - Help & Options → Controls: press F8. Expect "Controls. List: <action>: <binding>; …. Focus: Previous Controller" if the game fills the list through `addItem`.
  - Try the arrow keys on the list, and rebinding: the log's `ui invoke2:` lines will show what the game calls.
  - Check that nothing broke in videos/cinematics (playVideo/stopVideo also go through this hook).
  - **This step is the most speculative.** The logs from this visit are what's needed to finish it.
- **N5, Phase 3 status (built; new module `status`):**
  - In a level, take damage: "Health <n> percent" when health drops below 75, 50 and 25 (once each; again after healing above that level or a new life).
  - Throw a grenade: silence. Pick one up: "Grenades <n>".
  - A boss fight: "Boss: <name>" when its health bar appears.
  - **F7 anywhere in play:** "Health <n> percent, grenades <m>".
  - Watch for: a false "Grenades 3" on a checkpoint reload or respawn (a count going up that isn't a pickup). The log line `status: grenades a -> b` will show it.
- **Live report during the morning test (2026-09-26, game running):** "only the how to play section's title is read, none of the actual how to play text."
  - Cause: each How to Play page is its own screen, and its explanations are **drawn text** (SWF DefineText glyph runs), which GetVariable can't read. Only `nameTxt` (the page title) is a field.
  - Also: the delayed page-name read spoke the old page ("Combos.") after Next had opened the Grapples screen.
  - **Fix built (not deployed yet, the game is running):** `tools/ui_text/extract_ui_text.py` decodes the drawn text from the installed .gfx files into `build/ui_text/shank_access_ui_text.txt`, deployed as `bin/shank_access_ui_text.txt` (never committed). `ui_text` loads it, and a page title now brings its text: "How to play. Combos. Juggle enemies by holding down and pressing attack. gun juggle. Alternate between your 3 different weapons to smoothly dispose of enemies. next". The stale page read is dropped when the focus has moved to another screen. `menu_reader_test` 150/150.
- **Order for the morning:** deploy → N3 (menus: How to Play, F8) → N1 (pause → Weapons, Unlocks) → N4 (Controls, F8) → N2 + N5 (a level: tip, tutorial, damage, grenades, F7, a boss if convenient). Collect the logs after.
- **Final overnight build:** 186d74d (`deploy.py plan`: only `bin/shank_access.dll` changes).

## 2026-09-25 — 2-5b-7 delayed back-announcements, "Exiting" at the Quit button — done (deployed 01639fc)
- **User report:** "Success. Everything works."
- **Logs:** `build/logs/20260925-225933-2-5b-7`; crash.log empty.
  - Escape from the in-level Help & Options: "back in movie … at _level0.helpOptionsBtn; announcing in 300 ms" → the pause menu closed 83–99 ms later → only "Resumed".
  - Quit: `menu: Quit pressed in the Exit Game dialog -> "Exiting"`, `say (final): Exiting`; the later restore was muted; ExitProcess found the message already handed to NVDA.
  - The first-entry probe answered again (`-> _level0.controls.howToPlayBtn`).
- **Conclusions: 2-5b (screen titles and screen transitions) is complete.**
- **Built:**
  - A "back on an earlier screen" announcement (after the focused screen hides) now waits 300 ms (`menu_reader::OnFrame`, driven by a kFrame event on every SwfScreen::Update). It is dropped if that screen closes meanwhile, or the focus moves.
  - "Resumed" also cancels it.
  - The Exit Game dialog's Quit (a click on `_level0.quitBtn` in a movie where `_level0.cancelBtn` had focus) says "Exiting" at once as the final message (`speech::SayFinal(…, 0)`: queue + mute). The ExitProcess hook then only waits (≤ 1.5 s) for it to reach NVDA.
- **Pre-checks:** `menu_reader_test` 115/115 (delay; drop on close; "Resumed" cancels; Quit → Exiting; the pause menu's quitBtn is not an exit), `ui_hook_test` 37/37, `speech_test`, `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings.
- **Instructions to give:**
  - Pause → Help and Options → Escape: only "Resumed".
  - Back out of a submenu normally: its screen announced after a short pause.
  - Main menu → Exit Game → Quit: only "Exiting".

## 2026-09-25 — 2-5b-6 "Resumed", "Exiting", first-entry focus probe — done (refined in 2-5b-7)
- **User report:** "Level select works and resumed/exiting also mostly work. When escaping out from help, the paused menu starts to read for a split second before resumed cuts it off. When exiting, main menu got rather more than a split second before it got cut off. The help screen also read properly from the pause menu on first entry."
- **Logs:** `build/logs/20260925-225625-2-5b-6`.
  - `hook ExitProcess: installed`; "Resumed" on each pause close.
  - **The first-entry probe worked:** `asked movie 1682E000 for its focus -> _level0.controls.howToPlayBtn`.
  - **Exit timing:** `click("_level0.quitBtn")` at 22:52:22.558 → the quit dialog hides → "Main menu. Exit Game" at once → **`ExitProcess(3)` 1.7 s later** → "Exiting" (handed to the screen reader).
- **The user's requests:** "Just use the word resumed when leaving the pause menu so that any excess announcements get overwritten. We also need something on program exit as it had just enough time to announce the main menu before the program closed. Please also fix the help and options first read issue. Deploy when done."
- **Built:**
  1. **"Resumed":** when a screen whose last focus is a pause-menu widget hides, speak "Resumed" (interrupting). That covers Resume, Escape, and Escape from the in-level Help & Options (which closes the pause 0.2 s later).
  2. **"Exiting":** ExitProcess is hooked (MinHook API hook on kernel32, installed only when speech is on). It says "Exiting", waits up to 1.5 s for the speech thread to hand it to the screen reader (`speech::SayFinal`), then mutes all later speech. Log: `ExitProcess(n): the game is closing`, `say (final): Exiting`, `speech: final message handed to the screen reader`.
  3. **First-entry focus probe:** a screen shown with no focus event and no history is asked for its focus on the next frames (kScreenTick, up to 20 frames / 1 s). `ui_hooks::QueryFocus` tries movie Invoke `Selection.getFocus` (vtable +0x5c), then GetVariable `_global.gfx.managers.FocusHandler._instance.currentFocus._target`. Log: `menu: asked movie … for its focus -> <path>`.
- **Pre-checks:** `menu_reader_test` 107/107, `ui_hook_test` 37/37, `speech_test` (Tolk + NVDA), `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings. The ExitProcess hook can only be tested in game.
- **Instructions to give:**
  - In a level: pause → Help and Options (first entry: expect "Help and options. <item>" without an arrow press) → Escape (expect "Resumed").
  - Pause → Resume Game ("Resumed").
  - Also check the level select opening (2-5b-5: "Level select. …" only).
  - Then quit via the main menu's Exit Game → Quit: expect "Exiting" and nothing after it. Collect logs (the game will have closed itself).

## 2026-09-25 — 2-5b-5 level select counts as the focused screen — done (the user: "Level select also behaved properly after returning to the main menu from the game")
- **User report (mid-test, game still running):** "something in your last fix broke the initial announcement on the level select screen. It now announces like I went back to the main menu rather than that I'm on the level select screen. Navigating level select does still work properly."
- **Live log (22:31:14):**
  - `say: Level select. Return Home…`, then in the same ms `ui screen: … movie 15368000 hidden` (the difficulty screen) → `focus restored in movie 11B44000 at _level0.controls.spBtn` → "Main menu. Play the Story".
  - Level select has no focus event, so the mod still thought the focus was on the difficulty screen.
- **Also seen:** on level start, the level select screen is destroyed without a "hidden" event (loading screen shown/hidden, then the game screen). No restore happened there.
- **Fix:** kInvoke events carry the widget's movie (identity only). When level select speaks a cell, its movie becomes the focused screen, so a screen hiding underneath is no longer "the focused screen closing". `menu_reader_test` 100/100.

## 2026-09-25 — 2-5b-4 crash fix: only restore into live movies — done (deployed 1542a3e)
- **User report:** "The pause menu is behaving better now. One thing I noticed, pressing escape from the help and options menu goes directly back to the game rather than to the pause menu. Using the actual back button, or escaping from other submenus goes back to the pause menu normally. I'm not sure if this could be something we introduced or just an odd quirk I never noticed. Level select also behaved properly after returning to the main menu from the game." No crash.
- **Logs:** `build/logs/20260925-224048-2-5b-4-pause`; crash.log empty.
  - Pause → Weapons/Unlocks → Escape: `navigate(undefined)`, the submenu hides, "Pause menu. View Weapons" / "View Unlocks" restored. Re-entering Help & Options: "Help and options. Controls/Settings" restored. The Back button: "Pause menu. Help and Options".
  - **Escape from the in-level Help & Options is native, not Flash:** no `navigate(undefined)`; the help screen hides, then the **pause screen hides 216 ms later** (the game resumes). A game quirk, not the mod (the hooks only read).
    - The mod announced "Pause menu. Help and Options" in that 216 ms gap (misleading). **Follow-up A.**
  - **First entry into the in-level Help & Options sends no focus event** (`screen shown … no earlier focus there, waiting for the game's focus`), so it's silent until the first arrow. **Follow-up B.**
  - Unlocks screen: `unlockBtn0..4` have no labels ("Unlock btn0") → step 2-4.
- **Conclusions:** the crash is fixed; restores work in the pause menu. Follow-ups A and B go to the user.
- **Fix:** `ui_hooks::MovieAlive(movie)` is true only if a SwfScreen::Update ran with that movie in the last 250 ms. `menu_reader` restores into a stored movie only if it's alive (via SetMovieAliveCheck), and the late slider value also requires it.
- **Pre-checks:** `menu_reader_test` 98/98 (replays the crash: a dead main-menu movie is never restored into), `ui_hook_test` 37/37; other tests pass; no warnings.
- **Instructions to give:** repeat the crash path (in a level: pause → Help and Options → back → back in → out, several times; also the Weapons screen). Then the main-menu round trips. Report any crash or odd speech. Quit without relaunching.

## 2026-09-25 — 2-5b-3 screen shown/hidden → restored focus announced — CRASHED (fixed in 2-5b-4)
- **User report:** "We have a crash. Everything behaved beautifully until I went into the pause menu. It initially worked, but going into help and options, back out, and back in again crashed the game."
- **Logs:** `build/logs/20260925-222733-2-5b-3-crash`. crash.log is empty (the game's handler didn't catch it). The a11y.log ends at `menu: screen hidden (movie 16800000) -> focus restored in movie 11B4A000 at _level0.controls.spBtn`.
- **Cause:**
  - The pause screen hid (state 0). OnScreen picked the most recent other movie marked "shown": the **main menu movie 11B4A000**, destroyed when the level loaded.
  - Destroyed screens never report "hidden" (their Update just stops). Reading its label through the freed movie crashed the game.
- **What worked before the crash (confirmed):**
  - Main menu submenus are re-announced on back-out through the "hidden" path. **The main menu screen stays "shown" underneath its submenus**, and each submenu's screen goes shown → hidden.
  - Re-entering Help & Options gives "shown (state 2)" → restore.
  - The in-level pause menu's Help & Options is a different movie (16876000) from the main menu's (1536F000).
  - Pause → Weapons → back restored "Pause menu. View Weapons"; Help → back restored "Pause menu. Help and Options".
  - The user: "Everything behaved beautifully until I went into the pause menu."
- **Built:** a fourth UI hook on **SwfScreen::Update 0x553d50** (byte-checked). Each screen's state `+0x3c` (1/2 shown, 0/3 hidden) is watched, and transitions are logged as `ui screen: <screen> movie <m> shown|hidden (state s, visible byte v)`.
  - `menu_reader::OnScreen`: when a screen is shown and the focus isn't already there, it re-announces the widget last focused in that movie, with the title.
  - When the focused screen is hidden, it re-announces the most recent other shown screen with a focus history.
  - Not within 250 ms of a game-reported focus in another screen (the pause menu's hidden Help screen).
- **Pre-checks:** `ui_hook_test` 37/37 (Update stand-in: shown/hidden once each, foreign movie not reported), `menu_reader_test` 97/97 (back out, re-enter, stray guard, never-focused screen, hiding a screen without focus); other tests pass; no warnings.
- **Instructions to give:** go into and back out of menus several times: Help & Options and its sub-screens, difficulty, the quit dialog (Cancel), and the pause menu twice. Each arrival should say the title and the item, without an arrow press. Report anything spoken twice, wrong, or at odd moments. Quit without relaunching.
- **Unknowns the log will answer:** does a screen underneath a submenu or dialog get "hidden"? Does the pause menu's hidden Help screen get "shown"?

## 2026-09-25 — 2-5b-2 title rule + sentence fix — done (restores → 2-5b-3)
- **User report:** "The exit game dialog and difficulty bug are fixed, title reading is better but still not there yet. Now, the title reads properly the first time entering any menu, but transitioning to any menu other than settings or level select doesn't read the menu title until the first arrow is pressed to navigate, then it reads both the title and the newly selected item. This behavior is very consistent."
- **Logs:** `build/logs/20260925-221749-2-5b-2-titles`.
  - Backing out sends only `navigate(undefined)`; re-entering an already-built submenu sends only `click`. CLIK restores the previous focus with no event.
  - The following arrow press then got the title ("Main menu. Multiplayer Campaign").
  - Settings (focused-set on every entry) and level select (SelectCell on every entry) were fine.
- **Fixes from the 2-5b test (below):**
  1. **Titles:** announced when the focus enters another movie (any event type, including the navigate that backing out sends), or with a game-set focus (kFocusedSet) after ≥ 1.5 s in the same movie (reopening the pause menu). Arrow presses in a screen never get one.
  2. **Sentence():** line breaks become spaces and whitespace is trimmed before checking the final punctuation. That fixes "exit the game?." (the SWF text ends in a line break).
- **Side effect (intended):** returning from a dialog to a screen now says its title again, e.g. "Main menu. Exit Game".
- **Pre-checks:** `menu_reader_test` 87/87, `ui_hook_test` 34/34; other tests pass; no warnings.
- **Instructions to give:** as for 2-5b. Go into and back out of several menus (a title each time), arrow around the difficulty screen with pauses (no title), open and close the pause menu twice, and check that the Exit Game prompt has no extra period.

## 2026-09-25 — 2-5b screen titles (+ 2-5a-2 quit dialog text) — done (fixes in 2-5b-2)
- **User report:** "Restore worked perfectly, screen titles is definitely mixed. They read the first time, but when backing out of a menu or going back in no title is read. Additionally it was inconsistently reading choose difficulty when arrowing between them. I did not check the pause menu because of these issues. The exit game and leave multiplayer session dialogs now read, but nvda was reading the exit game dialog as if there was an extra . at the end of the sentence so there may be an issue with how that text is formed. You can directly deploy any fixes."
- **Logs:** `build/logs/20260925-220847-2-5b-titles`; crash.log empty.
  - Backing out to the main menu, and re-entering Help & Options, arrive as **`navigate("<path>")` into another movie**, not as a game-set focus. So no title (the rule excluded navigate).
  - **On the difficulty screen every arrow press sends `focusIn` before `navigate`** (other screens send navigate first). After a ≥ 1.5 s pause, the old rule treated that focusIn as a screen opening: "Choose difficulty. Hard".
  - The quit dialog was spoken as "Are you sure you want to exit the game?. Cancel": the SWF text has a trailing line break, so Sentence() added a period.
  - The Settings late slider re-announce kept its title: "Settings. Music volume, slider, 15".
  - "Leave Session" was read through the static read (its text was written about 4 s earlier, when the lobby opened).
  - Credits, Concept Art, Controls and How to Play weren't visited.
- **The user:** "Since this is such a small test, let's do 2-5B and fold this in with its testing." So one build and one test cover both.
- **2-5b built:** screen titles from the focused widget (DESIGN "2-5b"). The Settings late slider re-announce now keeps the title.
- **Pre-checks:** `menu_reader_test` 83/83 (titles: game-set focus only, not on arrows, not for dialog buttons, not repeated when back from a dialog, again after a pause, level select), `ui_hook_test` 34/34; other tests pass; no warnings.
- **Instructions to give:**
  1. Launch: expect "Main menu. Play the Story".
  2. Exit Game: expect "Are you sure you want to exit the game? Cancel" (2-5a-2), then Cancel.
  3. Help & Options: "Help and options. How to Play". Open Settings: "Settings. Music volume, slider, <n>", then close it. Visit Controls and How to Play. Optionally Credits / Concept Art (probably no title yet; tell me what they are).
  4. Back out to the main menu (title again), then Play the Story: "Choose difficulty. Normal", then pick one: "Level select. <chapter>…".
  5. In a level, pause: "Pause menu. Resume Game". Resume, pause again later: the title again.
  6. Report missing, wrong or doubled titles, and any names you'd rather have. Quit without relaunching.

## 2026-09-25 — 2-5a-2 static dialog text (quit dialog) — built, tested with 2-5b
- **Fix for the main menu's Exit Game prompt.** `quitdialog.gfx` keeps its message in the SWF: `bodyTxt` "Are you sure you want to exit the game?", no headerTxt; buttons `quitBtn` "Quit", `cancelBtn` "Cancel". The game never writes the text.
  - Now, on the first focus in a movie different from the previous focus, when no dialog text was just written, `menu_reader` reads `<parent>.headerTxt.text` / `<parent>.bodyTxt.text` via GetVariable and speaks them first.
  - A scan of every `data*/ui/*.gfx` found these fields only in dialog SWFs: modaldialog and newconceptartdialog (header and body), quitdialog (body only), busydialog (no buttons). creditsscreen has `titleTxt` (not used).
- **Pre-checks:** `menu_reader_test` 73/73, `ui_hook_test` 34/34; no warnings.
- **Instructions to give:** main menu → Exit Game: expect "Are you sure you want to exit the game? Cancel", then "Quit" / "Cancel" when moving. Choose Cancel.

## 2026-09-25 — 2-5a dialog text — done (except the main menu Exit Game prompt → 2-5a-2)
- **User report:** "The exit game prompt does not read its dialog, but it seems like the others do."
- **Logs:** `build/logs/20260925-215233-2-5a-dialogs`; crash.log empty.
  - Spoken correctly:
    - "Unsaved Changes. Are you sure you want to close? Yes"
    - "Erase Save Data. You are about to erase … do this? Cancel"
    - "Save Data Erased. Your saved data was successfully erased. OK"
    - pause menu Exit Game: "Are you sure? Quitting the game will result … continue? Cancel"
    - pause menu Load Last Checkpoint: "Are you sure? Loading the last checkpoint … continue? Cancel"
  - The main menu Exit Game is a different dialog (quitdialog.gfx, movie 154DE000, `cancelBtn`/`quitBtn`). There were no headerTxt/bodyTxt writes, so only "Cancel" was spoken.

## 2026-09-25 — 2-5a dialog text — deployed 1d15d43
- **Deployed 2026-09-25 (1d15d43, pre-approved: "Start 2-5a and deploy when done"):** `bin/shank_access.dll`. When a dialog opens, it speaks "<header>. <body> <first button>" (DESIGN "2-5a").
  - kValueSet events now carry the widget's movie (compared only).
  - Log line: `menu: focused=true _level0.thirdBtn (movie …) -> say "Erase Save Data. You are about … Cancel"`.
- **Pre-checks:** `menu_reader_test` 71/71 (dialog text first, spoken once, cleared busy text, lobby parent excluded, other movie, too late, header only); `ui_hook_test` 34/34; `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings.
- **Checked against every dialog in the logs so far:** Unsaved Changes, Writing Game Results (busy), Are you sure? (quit), Leave Session (lobby), Load Last Checkpoint (its header wasn't in the change-only log, but the write happens), Graphics Mode Changed, Reload, Erase Save Data, Save Data Erased.
- **Instructions to give:**
  - Open a few dialogs: Exit Game from the main menu, Settings then Close after changing something (Unsaved Changes), Load Last Checkpoint or Exit Game from the pause menu.
  - Each should speak its title and message, then the focused button. Then move between the buttons (buttons only).
  - Report anything missing, doubled or cut off. Quit without relaunching.

## 2026-09-25 — Menu re-announce on unmoved key press (+ 2-3c locked) — done (deployed 8b83bea)
- **Built:** `navigate` to the already-focused widget re-speaks it (not within 50 ms of the last spoken focus), as the user asked. It also carries the 2-3c `locked` detail, though the user says locked chapters can never be selected, so that won't be heard.
- **Pre-checks:** `menu_reader_test` 63/63, `ui_hook_test` 34/34; other tests pass; no warnings.
- **Instructions to give:**
  - Main menu: press down past Exit Game (the last item). "Exit Game" should be read again on each press.
  - Open a Yes/No dialog and press arrows on it.
  - In Settings, change a slider and a selector. Only the value should be spoken, with no extra re-read.
- **The user's answers (2026-09-25):**
  - "As for locked chapters, they can never gain focus, only the latest unlocked chapter is navigable."
  - On the "Save Data Erased" dialog: "I pressed arrows and escape, but I don't think I actually pressed enter at any point." So the dialog stayed open as expected (Escape doesn't close it). No game bug.
- **User report:** "Nothing doubled, everything's good."
- **Logs:** `build/logs/20260925-214110-reannounce`: 135 spoken lines; re-reads on quitBtn, the dialog buttons and others; 2 same-press duplicates dropped; crash.log empty. **Passed.**

## 2026-09-25 — 2-3c level select completion time — done (deployed b731eae; locked follow-up built)
- **Built:** each chapter is spoken as `"<name>, completion time 4 minutes 46 seconds, <n> of 20"`, from AddCell args[4] (seconds; the game sends ms/1000), or `"no completion time"` when the game sends -1 (const 0x847f38 used when there's no time).
- **Pre-checks:** `menu_reader_test` 61/61; other tests pass; no warnings.
- **Originally untestable:** "All chapters have been completed at least once on my save", so the -1 case couldn't be heard.
- **The user's plan for this pass (2026-09-25):** "there's a wipe save option in the game, so I'll just use that when needed. I actually plan to do that and beat the first level so I can test how level select behaves on a newer save on this pass."
  - The full save is backed up in `saves/2026-09-25-all-chapters-complete/` for restoring afterwards; ask before copying it back.
- **Instructions given:** open level select and scroll a few chapters; each should say its completion time. Does it match the screen (which shows the time for the selected chapter; OCR was garbled)?
- **What to look for in the log after the fresh-save pass:**
  - Chapter count: are locked chapters listed at all?
  - The time: -1 → "no completion time".
  - args[3] (the unexplained flag; hypothesis: marks the current chapter).
  - The SelectCell index on opening.
  - What Erase Save Data sounds like: the confirmation dialog text isn't read yet (step 2-5a).
- **User report:** "Had an accidental restart which likely cleared some of the logs, but I did wipe my save and confirmed the no completion time message works. One very odd bug, after accepting the Ok prompt on the erase save prompt, the mod stops speaking entirely. I did confirm that it comes back when the game is restarted after I wiped my save the first time". Then: "The ok definitely worked as I can confirm my save was actually wiped."
- **Logs:** `build/logs/20260925-212958-2-3c-fresh-save` (the second session only; the first was overwritten by the restart). crash.log empty; the game log ends with "Quitting the game NOW!" at 21:27:46.
  - **Level select on a fresh save (after beating 1-a and A Big Show):**
    - All 20 chapters are listed.
    - `AddCell` args[3] = **1 for locked chapters** (Ride onward), 0 for open ones.
    - Times: Return Home "308.689", A Big Show "140.242"; "Other side of the Tracks" has "0", "-1" (open, no time).
    - The screen opens on the first unfinished chapter: `SelectCell("2")` → "Other side of the Tracks, no completion time, 3 of 20".
    - The spoken times match the game's own `UpdateLevelCompletionTime … 308689 ms` / `140242 ms`.
  - **The "mod stops speaking" report: speech did not stop.** The sequence:
    1. click(eraseSaveDataBtn) sets `headerTxt` "Erase Save Data" and `bodyTxt` "You are about to erase all your saved data…"; the focus "Cancel", then navigate → "OK".
    2. `click("_level0.secondBtn")` at 21:27:29.447 **erases the save** (4× SaveSaveData of 12 bytes) and immediately opens a **second dialog** in another movie (154BB000): `headerTxt` "Save Data Erased", `bodyTxt` "Your saved data was successfully erased.", only `thirdBtn` "OK" visible. Spoken "OK".
    3. For 17 s after that, only `navigate("_level0.thirdBtn")` arrived (29 onfocus sounds, no click). menu_reader's "navigate to the already-focused widget = silent" rule kept quiet, which to the user was indistinguishable from the mod dying. No click on that OK was ever logged.
  - **Conclusions:**
    - 2-3c works (times and "no completion time" confirmed).
    - The "silence" is a UX gap, not a crash. **Fixes:**
      - 2-5a (speak dialog title + body when a dialog opens, so "Save Data Erased…" would have been heard);
      - consider re-announcing the focus on a repeated navigate after a pause (asked the user).
    - Open: why the second OK never clicked (not investigated; ask the user what they pressed).
- **2-3c follow-up built (not deployed):** `locked` spoken for flag 1 chapters. `menu_reader_test` 62/62.

## 2026-09-25 — 2-3b level select polling — done
- **User report:** "Level selector works now. It looks like completion time is shown for the selected level, but the ocr was rather garbled. Beat a couple of bosses for fun while I was at it."
- **Logs:** `build/logs/20260925-210548-2-3b-level-poll`; crash.log empty.
  - `GetSelectedIndex` answered the right index on each poll ("0", "1", "2", …), and every move, including back-and-forth, was spoken once, e.g. `-> cell 4 via poll … -> say "Gears and Grenades, 5 of 20"`.
  - One `(200 lines dropped by the rate limit)` at 21:00:58 during the pause menu: logging only, no effect on speech. Not investigated (off task).
- **Conclusions:** 2-3b passed.

## 2026-09-25 — 2-3b level select polling — deployed 4d8f337 (deployed 4d8f337; the user: "clear to deploy when done"; verify ok)
- **Fix for 2-3 (below):** the selection is polled. On the game's per-frame `IsSelected`/`IsLoadingImage` calls on a widget with cells (at most every 100 ms), `GetSelectedIndex` is asked (through the original InvokeV, not re-hooked), and a change is spoken as `"<name>, n of total"`. `GetSelectedIndex` answers are logged when they change (`menu: … GetSelectedIndex -> "…" (polled on …)`).
- **Pre-checks:** `menu_reader_test` 57/57 (poll: unchanged / moved / throttled / unusable answer / after Clear), `ui_hook_test` 34/34, `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings.
- **Instructions to give:** as for 2-3. Level select: scroll through several chapters and both ends. Each chapter should be spoken once as it's selected.
- **Risk:** if `GetSelectedIndex` answers "undefined" or lags, the log shows it; the fallback would be reading a Flash variable of the strip.

## 2026-09-25 — 2-3 level select — done (selection changes silent → 2-3b)
- **User report:** "The first level appears to read correctly when the menu opens, but nothing reads as the selection changes. From doing OCR on the screen there appears to be some information on the completion status or other details which should be looked into after fixing the level select."
- **Logs:** `build/logs/20260925-205356-2-3-level-select`; crash.log empty; the InvokeV hook installed and worked.
  - `Clear`, then 20 `AddCell` calls, e.g. `AddCell("Return Home", "levels/small_0002_wrestlingring.dds", "levels/_0002_wrestlingring.dds", "0", "286.035")`, then `SelectCell("0", "1")` → spoken "Return Home, 1 of 20". **The name is args[0]** (the heuristic picked it).
  - **While scrolling: no `SelectNext`/`SelectPrev`/`GetSelectedIndex` calls at all, and no Flash → game events.** Only `IsSelected() -> "false"` polled every frame. So keyboard scrolling is handled inside the Flash film strip. (The native SelectNext/SelectPrev path at 0x791f60 is probably analog-stick only.)
  - The 20 chapters, in order: Return Home, A Big Show, Other side of the Tracks, Ride, Gears and Grenades, Meatpacking Plant, The Butcher, Red Lights, A Good Fight, On The Run, Sweet Love, Venom of the Vipers, World of Warriors, A Bad Confession, Bombs and Bells, Unjust Steward, The Underworld, Leap of Faith, Fertile Ground, The Final Fight.
  - AddCell args[3] was "0" for all; args[4] varies (45.5 … 2522.8), probably the best time in seconds. **Follow-up (the user's request):** read the completion status and details shown per chapter → PLAN 2-3c.

## 2026-09-25 — 2-3 level select — deployed 3077ddb (first build)
- **Deployed 2026-09-25 (3077ddb, pre-approved: "build and deploy 2-3"; `deploy.py verify` ok):** `bin/shank_access.dll` with a third UI hook, on **SwfSymbol::InvokeV 0x559b50** (native → Flash method calls; byte-checked).
  - It logs `ui invoke: <widget>.<method>(<args>) -> "<result>"`; an identical line is logged at most every 2 s (IsLoadingImage/IsSelected are polled every frame).
  - `menu_reader::OnInvoke` keeps each widget's cells from `Clear`/`AddCell`. On `SelectCell` it uses the index argument. On `SelectNext`/`SelectPrev` it asks the widget `GetSelectedIndex`, falling back to its own tracking if the answer is unchanged or missing.
  - It speaks `"<name>, <n> of <total>"`, silent when the selection didn't move. `<name>` is a **guess**: the first AddCell string that isn't a path, file or all-lower-case identifier. The log line `menu: … -> cell N via … [all | args] -> say …` shows all the arguments, so the next round can pick the right one.
- **Pre-checks:** `ui_hook_test` 34/34 (stand-in InvokeV: args parsed per format, result passed through, InvokeMethod calls the original directly), `menu_reader_test` 52/52; `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings.
- **Instructions to give:**
  1. Main menu → Play the Story → pick a difficulty. You reach level select (it has never made a sound before).
  2. Listen: the selected chapter should be spoken, with "n of total".
  3. Scroll left and right through several chapters, including to both ends, then back out (or start a level if you like).
  4. Report what's spoken: is it a good name, the right chapter, anything doubled or missing? Quit without relaunching.
- **Risks:** the name may be the wrong string (e.g. a code name). If `GetSelectedIndex` lags the animation, tracking takes over; wrap-around at the ends (if any) would confuse tracking. The log will show both.

## 2026-09-25 — 2-2b Settings fixes (slider opening value, checkboxes, doubled values) — done
- **Deployed 2026-09-25 (c156a60; the user: "You're clear to deploy once you've finished"; `deploy.py verify` ok):** `bin/shank_access.dll` with three fixes from the 2-2 round below.
  1. **Checkboxes:** the toggle event `select("<path>")` is now handled. The state is read from `.selected`, then `._selected` (CLIK's backing field). The log line lists what each attempt gave, e.g. `.selected gave nothing;`.
  2. **Slider value when Settings opens:** SetVariable writes of `text`/`value` are reported with the value being written (`kValueSet`). If the focused slider's value source (`musicVolumeTxt.text`) is written within 500 ms of the focus announcement, the focus is re-announced with that value (`menu: late value …`).
  3. **Doubled values:** the same value for the same widget within 20 ms is spoken once (spinners send change + stepperChange).
- **Pre-checks:** `ui_hook_test` 28/28, `menu_reader_test` 41/41, `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings.
- **Instructions given:** open Settings (expect "Music volume, slider, <the real number>"), move to each checkbox (expect "checked"/"not checked"), toggle one and back, change a selector once (value spoken once). Report; quit without relaunching.
- **User report:** "done testing. All good now."
- **Logs:** `build/logs/20260925-203839-2-2b-settings-fixes`; crash.log empty.
  - `focused=true musicSlider -> "Music volume, slider, 00"`, then in the same ms `late value _level0.musicVolumeTxt.text = "15" -> "Music volume, slider, 15"`.
  - Checkboxes on arrival: `.selected gave nothing; …_selected -> "Fullscreen, checkbox, checked"` (all four).
  - Toggles: `select` → `change … (from .selected) -> "checked"/"not checked"`, alternating correctly. So `.selected` **is** readable after a user toggle, but not before.
  - Spinner changes spoken once each.
- **Conclusions:** 2-2 passed. Settings is fully readable.

## 2026-09-25 — 2-2 Settings dialog focus and values — done (fixes in 2-2b)
- **User report:** "Mostly good. Sliders don't read their initial value but do when updating, selectors do read their initial value. The biggest issue is the checkboxes for full screen, bloom etc do not report their state either initially or on change."
- **Logs:** `build/logs/20260925-203206-2-2-settings`; crash.log empty.
  - Settings open: `focused=true _level0.musicSlider … -> "Music volume, slider, 00"`. The text field still held its default; the game writes "15" right after setting focus.
  - Spinner values come from `.textField.text` (rumble "ON"/"OFF", "1920x1080 (16:9)", "16:9", "(1) AMD Radeon Graphics"). Every spinner change was spoken twice (change + stepperChange in the same ms).
  - Checkboxes: `.selected` gave no bool (spoken "Fullscreen, checkbox"). Toggling sends `select("<path>")`, which wasn't handled. The game doesn't write `selected` after a toggle (it only writes all four at dialog open).
  - Slider held at 100 repeats "100" on each change (fine: it's feedback that it's at the maximum).
  - Other labels: resetBtn "Undo Changes", defaultsBtn "Reset to Defaults".
  - At startup, `spBtn.focused = true` came before any callback, so it was "not reported" (no movie vtable known yet); the focusIn right after covered it.
- **Deployed 2026-09-25 (2d3108f, pre-approved: "Build and deploy 2-2"; `deploy.py verify` ok):** `bin/shank_access.dll`, see DESIGN.md "2-2" for the behaviour.
  - `ui_hooks` now sends events (focusIn before the game handles it; navigate, change, stepperChange and click after) and `<widget>.focused = true` sets. The movie for the latter comes from `[[symbol+8]+0x38]`, used only if its vtable matches the callbacks' movies.
  - `ReadValue()` reads bools, numbers and text by path. `menu_reader::OnEvent` holds the focus rules, names, roles and values.
- **Pre-checks:** `ui_hook_test` 27/27; `menu_reader_test` 31/31 (incl. the real localization file); `hook_test`, `proxy_smoketest` and the Python tests pass; no warnings.
- **Risks to watch in the log:**
  - When Settings opens, "Music volume" may be read before the game fills in its number (stale or missing value).
  - Unknown which spinner member holds the displayed value; the log line says `value from <member>`.
  - Unlabelled widgets elsewhere (weapon buttons, list boxes) are now spoken by their readable widget name instead of staying silent.
- **Instructions to give:**
  1. Main menu → Help & Options → Settings. You should hear "Music volume, slider, <number>".
  2. Move through every control. Change the music volume a few steps, change one selector (e.g. aspect ratio or resolution) and toggle one checkbox, then change them back. Listen for the new values.
  3. Close Settings (answer the unsaved-changes dialog if it appears).
  4. Quick regression: main menu and pause menu still read as before. Optionally open View Weapons.
  5. Report anything wrong, missing, doubled or cut off. Quit without relaunching.

## 2026-09-25 — 2-1 speak focused menu labels — done
- **Deployed 2026-09-25 (bcb2d72, user said "deploy"; `deploy.py verify` ok):** `bin/shank_access.dll` with `localization.cpp` and `menu_reader.cpp`, and a focus listener in `ui_hooks.cpp`.
  - On each focusIn with a readable label, it speaks the label (interrupting), with `IDS_*` translated from the game's `localization_en.xml`.
  - A second focus within 50 ms is ignored.
  - Log lines: `localization: N strings loaded`, `menu: focus <path> (movie p) -> say "…"`, `menu: ignored focus …`, plus the usual `say:` lines.
- **Pre-checks:**
  - `menu_reader_test` 13/13, including the real file: 19 strings; IDS_CAMPAIGN → "Play the Story", IDS_HELPANDOPTIONS → "Help & Options", IDS_DIFFICULTY_MADNESS → "Charles Norris" (odd; ask the user what the screen shows).
  - `ui_hook_test` 20/20; `hook_test` and `proxy_smoketest` pass; no warnings.
  - `deploy.py plan`: only `bin/shank_access.dll` changes.
- **Instructions to give:**
  1. Launch. You should hear the main menu's first item as soon as the menu appears.
  2. Move through the main menu, Help & Options and the difficulty screen (back out without starting if you like).
  3. Start or continue a level, pause, and move through the pause menu. The first thing heard should be "Resume Game", not "How to Play".
  4. Open a Yes/No dialog (e.g. Exit Game) and move between its buttons.
  5. Report anything spoken wrong, missing, doubled or cut off. Does "Shank access loaded" still get through? What does the hardest difficulty say? Quit without relaunching.
- **Known gaps (expected silent):** Settings controls, level select, dialog body text, slider and spinner values.
- **User report:** "Looks good. Hard difficulty is just called hard. Logs are ready." Nothing spoken wrong, doubled or cut off was reported.
- **Logs:** `build/logs/20260925-201526-2-1-menu-labels`: `localization: 19 strings loaded`; about 130 focus events spoken; crash.log empty; no drops.
  - The start-up "Shank access loaded. Test mode on." was spoken at 20:07:46.8, and the first menu focus came 4 s later, so no clash.
  - Main menu: "Play the Story", "Multiplayer Campaign", "Achievements", "About Us", "Help & Options", "Exit Game".
  - Help & Options: How to Play, Controls, Settings, Credits, Erase Save Data, Concept Art, "BACK". How to Play pages: "next"/"back". Controls: Previous Controller, Next Controller, Reset to Defaults, Save, Undo Changes, Close. Settings: only its Apply/Close buttons.
  - Difficulty: "Normal", "Hard", "Back". Madness never appeared, probably locked, so "Charles Norris" is untested.
  - Multiplayer lobby: `player0/1.readyBtn` "JOIN", "Back". Dialogs: Yes/No, OK/Cancel.
  - Pause: Resume Game, View Unlocks, View Weapons, Help and Options, Exit Game, Load Last Checkpoint.
  - **The 50 ms rule worked:** `ignored focus _level0.controls.howToPlayBtn (movie 135BA000), 0 ms after … (movie 149E3000)`. The stray focus comes from a **different movie**.
- **Gaps found (silent):**
  - **Weapons screen** (`View Weapons`): `sawBtn`, `gunsBtn`, `macheteBtn`, `swordBtn`, `uziBtn`, `shotgunBtn`, `chainsBtn` have no label (icon buttons). The screen sets `meleeTitleTxt`/`meleeBodyTxt`/`gunTitleTxt`/`gunBodyTxt` ("Chainsaw" / "Default heavy weapon." / "Pistols" / "Default gun weapons.") on opening; these did not change while moving focus (change-only log).
  - **Controls screen:** `_level0.listBox` (the binding list) has no label; the game immediately moved focus to btnPrevious. `controlTxt.text` = "Keyboard" (the current device).
- **Conclusions:** 2-1 passed. Remaining work goes to later Phase 2 steps (PLAN).

## 2026-09-25 — 1c-3 focus label reading (silent) — done
- **Deployed 2026-09-25 (ef881c0, user said "deploy"; `deploy.py verify` ok):** `bin/shank_access.dll` with the 1c-3 addition in `native/core/ui_hooks.cpp`.
  - On each `focusIn("<path>")`, it calls the movie's GetVariable (vtable +0x44) for `<path>.label`, falling back to `<path>.textField.text`.
  - It logs `ui label: <path> = "<text>"` or `(none)`. Managed values are released via 0x5c7620. SEH-guarded; the game's own handling is unchanged.
  - Install also byte-checks 0x5c7620 now.
- **Pre-checks:** `ui_hook_test` 19/19 (fake movie: managed label read and released once, textField fallback, (none), no read for navigate or without a movie); `hook_test` and `proxy_smoketest` pass; no compiler warnings. `deploy.py plan`: only `bin/shank_access.dll` changes.
- **Nothing new is audible.**
- **Instructions to give:**
  1. Launch. In the main menu, move through every item once, slowly.
  2. Open Help & Options, move through its items, and open Settings and move through a few.
  3. Start a level, pause, and move through the pause menu. Answer a Yes/No dialog if one comes up.
  4. Quit (no relaunch). Report anything odd, especially a crash or hang when moving between menu items.
- **Questions for the log:**
  - Does GetVariable work with the callback's movie pointer (labels appear for main menu buttons)?
  - Does `.label` resolve through the CLIK getter, or do we need the `textField.text` fallback?
  - What do the Settings controls give (they only send navigate(undefined))?
- **User report:** "Logs are ready, menu navigation, settings changes plus I beat the first level and boss for fun." No problems reported.
- **Logs:** `build/logs/20260925-195726-1c-3-focus-labels`: 182 `ui call`, **41 `ui label`** (every focusIn got a label), 0 dropped, crash.log empty; all four hooks installed.
- **Conclusions:** see RE-NOTES "1c-3 runtime findings".
  - GetVariable via movie vtable +0x44 works: answers questions 1 and 2 (`.label` resolves; the fallback wasn't needed).
  - Main-menu labels are `IDS_*` localization keys, so they need translating.
  - Settings still gives no focusIn (question 3), so that moves to Phase 2.
  - **1c-3 passed; Phase 1c gate passed.**

## 2026-09-25 — 1c-2 UI logging (silent) — done
- **Deployed 2026-09-25 (d5fa5fb, pre-approved: "build and deploy 1c2"; `deploy.py verify` ok):** a rebuilt `bin/shank_access.dll` with `native/core/ui_hooks.cpp`.
  - Hook A on `SwfExternalInterface::Callback` 0x5534d0 logs `ui call: <method>(<args>)`.
  - Hook B on `SwfSymbol::SetVariableInternal` 0x559a50 logs `ui set: <widget>.<member> = <value>`, only when the value changes.
  - Rate limit 60 lines/s; SEH-guarded reads; pass-through.
- **Pre-checks:**
  - `ui_hook_test` 11/11: stand-ins with the same conventions; originals see their inputs; `al` return passes through; stack and registers preserved; change-only logging; managed strings decoded; a bad pointer is logged as `?` without crashing. One stand-in struct bug in the test itself was fixed.
  - `hook_test` and `proxy_smoketest` pass.
- **Nothing new is audible.**
- **Instructions given:**
  1. Launch. In the main menu, move up and down through every item slowly (about 1 s each), remembering the order.
  2. Open Help & Options / Settings and move through a few items, including changing a slider or spinner.
  3. Start 1-a, pause, and move through the pause menu.
  4. Play briefly: take damage, throw a grenade, pick up something.
  5. Say "check now" at any point; quit when done (no relaunch). Report the order of the menu items you heard or saw.
- **Questions for the log:**
  - What method names do focus events use, and do their args name the widget?
  - Are button labels set through SetVariable (so we see the text), or baked into the SWF?
  - Which HUD members carry health and grenades?
- **User report:** "I went through the main menu slowly, adjusted the music volume, then scrolled through level select. I started the first level and threw exactly one grenade and played a bit." No problems reported.
- **Logs:** `build/logs/20260925-073537-1c-2-ui-logging`: 216 `ui call`, 336 `ui set`, 0 dropped; both hooks installed.
- **Conclusions:** see RE-NOTES "1c-2 runtime findings".
  - focusIn names the widget path.
  - Main-menu labels are baked into the SWFs, so they must be read.
  - The HUD, dialog and tutorial text flow through SetVariable (grenades 3 → 2 matched the single grenade throw).
  - Gaps: Settings focus (navigate(undefined)) and level-select scrolling (no events).
  - **1c-2 passed.**

## 2026-09-25 — 1b-4 test mode + announcement delay — done (SAPI check confirmed 2026-09-30, the user: "the startup reading from sapi test that has been open forever works and can be resolved")
- **Deployed 2026-09-25 (1c5737a, `deploy.py verify` ok):**
  - a rebuilt `bin/shank_access.dll`;
  - new `bin/shank_access.ini` (`[test] test_mode=1`).
- **Contents:**
  1. Start-up announcement deferred until the game window is visible, plus 1.5 s (the 1b-3 SAPI clipping fix).
  2. Config loading (`config.cpp`).
  3. Test mode (`test_mode.cpp`): F5 flips god mode (byte 0xae6539), F6 flips super speed (0xae653a). Each is spoken ("God mode on/off", "Super speed on/off").
  4. `hotkeys::Add` API.
- **Pre-checks:** clean build (after fixing another C4129 escaping bug); `hook_test` and `proxy_smoketest` pass. The config and test-mode paths run after the exe check, so only the game exercises them.
- **Hypothesis under test:** the retail game still honours the god mode and super speed debug flags.
- **Instructions given:**
  1. Launch. Expect "Shank access loaded. Test mode on." with no clipping (try SAPI too if convenient).
  2. In 1-a, press F5: hear "God mode on". Take damage (e.g. from an enemy) and check whether health drops or you can't die. Press F5 again: "God mode off".
  3. Press F6: "Super speed on". Does the game run faster? F6 again: off.
  4. Report; say "check now" if something's off; quit (no relaunch).
- **User report:**
  - "God mode and super speed both work perfectly."
  - The SAPI start-up announcement: works (confirmed 2026-09-30, the user: "the startup reading from sapi test that has been open forever works and can be resolved").
- **Logs:** not collected (nothing to diagnose).
- **Conclusions:**
  - **1b-4 passed.** The retail game honours the debug-settings flags (god mode +9, super speed +0xA). The config file works.
  - **Open:** confirm the deferred announcement is no longer clipped under SAPI.

## 2026-09-24 — 1b-3 speech (Tolk) — done
- **Deployed 2026-09-24 (af6e713, pre-approved by the user; `deploy.py status` all ok):**
  - a rebuilt `bin/shank_access.dll` (speech thread plus the F9 hotkey);
  - new in `bin/`: `Tolk.dll` (built from vendored source, x86), `nvdaControllerClient32.dll`, `SAAPI32.dll`, `dolapi32.dll` (Tolk's x86 client DLLs).
- **Pre-checks:**
  - Clean build.
  - `hook_test` passes.
  - `proxy_smoketest` (with `SHANK_ACCESS_SILENT=1`) passes and logs the mismatch message as `say:`.
  - `speech_test` (silent) reports **"screen reader: NVDA; has speech: 1"** on the user's machine. The bundled 32-bit NVDA client works with their NVDA.
- **Instructions given:**
  1. Launch the game. Expect to hear **"Shank access loaded."** through NVDA shortly after launch, during loading.
  2. Press **F9** (in game, any time): it should repeat the message.
  3. Report: did you hear both? Any clash with NVDA's own speech? Does F9 do anything in the game itself?
  4. Say "check now" if anything's off. Quit when done (no relaunch).
- **User report:**
  - "It works." The announcement is heard and F9 repeats it.
  - One oddity: **with SAPI specifically, the first word was cut off** on the initial read ("access loaded"). F9 presses read it properly.
- **Logs:** not collected (nothing to diagnose in them).
- **Conclusions:**
  - **1b-3 passed.** Speech works via NVDA and via the SAPI fallback; F9 works.
  - The SAPI clipping is most likely the start-up announcement coinciding with the game opening its audio device (FMOD init). Follow-up: delay the announcement until the game window exists, plus about 1.5 s.

## 2026-09-24 — 1b-2 sound hooks (log only) — done
- **Deployed 2026-09-24 (7f2ecd4, `deploy.py status` ok):** a rebuilt `bin/shank_access.dll` (and an unchanged proxy). It includes:
  - **Side task (user request):** an in-memory patch that skips the startup logo movie (`patches::SkipIntroMovie`, NOP at 0x792cf2). Check: time from launch to the title screen, and anything odd such as a black screen or a hang.
  - MinHook v1.3.4 hooks on 0x55ab90 (PlaySoundAt) and 0x55ab10 (PlaySound). Pass-through only; every sound still plays as before.
  - Each call is logged to `a11y.log` as `sound at: <name> pos=(x, y) listener=(x, y) half=(w, h) pan=p` or `sound 2d: <name>`. Rate limit 40 lines/s; drops are reported.
  - Hooks install only if the exe hash and the function's first bytes match.
  - Also includes the live-readable log fix.
- **Pre-checks:**
  - `hook_test.exe`: 10/10. Stand-ins with the same esi convention; the original sees the caller's esi and pos; esi/ebx/edi and esp preserved; log line and pan correct.
  - `proxy_smoketest.exe` passes, including the live log read.
  - Clean build.
- **Questions to answer from the log:**
  1. Is the listener the camera (x follows Shank in follow-cam sections, fixed in arenas)?
  2. Are pickup beacon positions the pickup's position?
  3. What pan values do typical sounds get?
  4. Does anything use the 2d path besides menus?
- **Nothing new is audible.**
- **Instructions given:**
  0. On launch: does the logo movie still play? How long until the title screen? Any black screen or hang?
  1. Launch 1-a and play normally for a few minutes: an open walking section, near the first health pickup (beacon), and one arena fight (after Front of Bar).
  2. Say "check now" whenever you like (the log is readable live now).
  3. Report anything odd with sound: missing sounds, stutter, crashes.
  4. Quit when done (no relaunch).
- **User report:**
  - "Everything else works properly."
  - The logo skip **missed**: it skipped the second, already skippable movie. The unskippable first sequence, with its own music, still plays.
- **Logs:** `build/logs/20260924-233114-1b-2-sound-hooks`.
  - `a11y.log`: hooks and patch installed.
  - 474 `sound at` lines and **0** `sound 2d` lines. Menu clicks also go through PlaySoundAt, with pos (0,0) and listener (0,0) half (0,0).
  - No rate-limit drops.
- **Findings:**
  - **The listener is the camera.** Its x follows Shank about 100 px ahead (footstep pan about -0.06 while walking). Half-extents are a constant **(1600, 900)**, about 25 × 14 tiles. So the game's pan = offset from the camera centre ÷ 1600 px.
  - When the camera locks (e.g. listener stuck at x ≈ 3785 while Shank walks on to x = 4596), Shank's footsteps pan up to 0.72. That's the user's "tight arena panning".
  - **The Uzi beacon** plays at the pickup's exact position (4669, 208); the level data says (4669, 226) with PlaceOnGround. Pan 0.55 when about 880 px right of the camera centre.
  - **The Lua probes arrive with the emitter's position:** `a11y/edge_far`/`wall_ahead` at Shank's position, `a11y/pickup_beacon` at the pickup's. The native layer gets positions for every Lua-requested cue, which confirms the architecture.
  - The game itself plays `pointOfInterest` 5 times: 4 at pos (0,0) (pan far off-scale), 1 at a real position. Not investigated (noted only).
- **Conclusions:**
  - **1b-2 passed.** The hooks are stable, and positions and listener make sense.
  - Remaining: the logo skip must target the first sequence (a follow-up).

## 2026-09-24 — 1b-1 native proxy (log only) — done
- **Deployed 2026-09-24** (built from 626b229; `deploy.py status` ok): two new files in `bin/`:
  - `dinput8.dll` (proxy; forwards to the system DLL; loads the mod on a thread after start-up or on the first `DirectInput8Create`);
  - `shank_access.dll` (writes `a11y.log` in the game root, checks the Shank.exe SHA-256).
  - Both are built from `native/` (x86, static CRT; imports only KERNEL32 and bcrypt). The Lua patches stay as they are.
- **Pre-checks:**
  - Clean build, no warnings. Exports are exactly the dinput8 names.
  - `proxy_smoketest.exe`: the proxy returns a real IDirectInput8W, `shank_access.dll` loads, and it reports an exe MISMATCH and disables itself (the test exe isn't Shank).
  - 11 unit tests pass (including the new artifact tests).
- **Nothing new is audible.** The pickup beacon (Uzi) is still there.
- **Instructions given:**
  1. Launch the game as usual and check it starts normally.
  2. Play a minute of 1-a using the controls you normally use (keyboard and/or controller). Check that input works normally.
  3. Alt-tab and say "check now". Claude reads `a11y.log` (expect `exe sha256 OK` and `init complete: enabled=1`).
  4. Quit (no relaunch).
  - If the game doesn't start or input is broken: close it and say so. `deploy.py uninstall` removes both DLLs.
- **Live check (23:12):**
  - The user: "Things seem good, and the item beacon still plays." The game started normally and input works.
  - `game.log` starts at 23:10:11. `a11y.log` exists (322 bytes, written 23:10:09, before the game's own start-up lines, so the loader thread runs early).
  - **But `a11y.log` couldn't be read while the game ran** (sharing violation). My bug: `_wfopen_s` opens files unshared. Fixed in `log.cpp` (`_wfsopen(..., _SH_DENYWR)`), and `proxy_smoketest` now also checks the log is readable while open. The fix ships with the next deploy.
- **User report:** the game started and played normally; input fine; the beacon still plays.
- **Logs:** `build/logs/20260924-231445-1b-1-proxy`. `a11y.log`:
  - `shank_access 626b229 starting` at 23:10:09.463 (loader thread, before the game's own 23:10:11 start-up lines);
  - `module base 00400000`;
  - `exe sha256 OK`;
  - `init complete: enabled=1`.
- **Conclusions:** the proxy loads and forwards input correctly, the mod runs early, the exe build matches, and there's no ASLR at runtime (base 0x400000). **1b-1 passed.** The only issue was the log lock bug, fixed for the next deploy.

## 2026-09-24 — combined round: wall-vs-drop probes + 1a-2 pickup beacon — done
- **Deployed 2026-09-24, commit c424067** (`deploy.py status`: both ok). It replaced the 1a-1 patch and added one file:
  - `data/stategraphs/shank/shank_transitions.lua`: probes after `noFall` in `REACTIONS`, rate-limited to 1/s, log only.
    - `a11y/edge_far` (< 4 tiles to platform end) and `a11y/edge_near` (< 1.5 tiles), as before.
    - **New:** `a11y/wall_ahead` (`lookingatledgewall` and `distancetoledgewall` < 4 tiles).
    - **New:** `a11y/wall_low` (the same, plus `lookingatledgewallheight` ≤ 3 tiles, the auto hop-up height).
    - `facingedge` removed.
    - Analysis rule: an edge probe with no wall probe in the same second = a drop.
  - `data/stategraphs/props/pickup_common_actions.lua` (shared by all 9 pickup types' idle state):
    - **Audible beacon:** the pickup itself plays `pointOfInterest` (existing FMOD event with `pan`) plus the log marker `a11y/pickup_beacon`. At most every 1.5 s, only while the player is inside a 1600×700 px Probe box around the pickup (about ±12 tiles if centred).
    - Log only: `a11y/pickup_inreach` when the player is inside the game's own pickup-prompt box (300×64).
- **Pre-checks:**
  - `luacheck50.py` OK (2 files).
  - `loadtest50.py`: the Shank stategraph passes with `check_edge_probes.lua` (4 probes, after noFall). All 9 pickup stategraphs pass with `check_pickup_beacon.lua`.
  - The undefined-global lists are identical to vanilla.
- **Hypotheses under test:**
  1. `PlaySound` from a prop's stategraph is positional and panned by the engine.
  2. The Probe box is centred on the pickup.
  3. `pointOfInterest` is a usable beacon sound.
  4. The wall valsources separate walls from drops.
- **Instructions given:**
  1. Load Chapter 1-a.
  2. **Beacon:** the first health pickup is about 62 tiles right of the start, before the "Front of Bar" checkpoint (x ≈ 4,670). Within about 12 tiles it should play the `pointOfInterest` sound every 1.5 s, from the pickup's direction. Walk past it and back, and stand on each side.
     - Report: what the sound is like; whether it comes from the correct side; whether it changes with distance; whether it helps find and collect the pickup; whether it's annoying; whether pickups you can't reach (above or below) are heard.
  3. **Walls vs drops:** stand facing the small climbable wall for about 5 s, and at a drop or ledge (e.g. the Pre Bridge pit) for about 5 s.
  4. Say "check now" (alt-tab) whenever you like. Quit when done, and don't relaunch.
- **Live report 1 (22:40):**
  - The beacon plays at the first health pickup, but **doesn't pan** relative to the user's position.
  - The user explained the game's panning: centred on open paths; only crates or walls being shot pan; tight panning in arenas.
  - Log: 37 `pickup_beacon` markers, several `pickup_inreach`, no `pointOfInterest` failures.
  - The user will keep testing more scenarios.
- **Live report 2:**
  - The user thinks the sound itself may be a problem: `pointOfInterest` is "a very long, distinctive thud with stereo effects".
  - They asked to switch to a weapon-ready sound. The patch now uses `Sounds/Attacks/Uzi/Uzi_Arm` (commit 0699ce1): luacheck OK, all 9 pickups load OK. **Not deployed yet**; the user is still playing the current build.
  - Wall probes so far: one wall moment (22:35:18) with edge + wall_ahead + wall_low in the same second; 7 edge-only seconds (drop-like). Promising.
- **Live report 3 (22:47):**
  - The user said "edge probe works, wall probe doesn't" while standing at the base of a small climbable wall: "nothing is playing", but "as soon as I get to the top, the edge sound plays".
  - Log: at the wall base (22:45:43 to 22:46:10), `wall_ahead` fires **every second together with edge_far + edge_near**. So the wall probe works; it's silent (log only), like the edge probes.
  - `wall_low` **never fired** at this wall. Either the wall is taller than 3 tiles (climbed, not hopped), or `lookingatledgewallheight` isn't what I assumed. Needs checking.
  - The sound at the top was the **pickup beacon** (`pickup_beacon` markers 22:46:00 to :03). A pickup above is only within the beacon's Probe box (700 px tall, about 5 tiles above and below) once the user is up top. At 22:46:04 there's an edge-only second (a drop) on top.
  - Lesson: the user can't tell which probes are silent. Say clearly in instructions what is audible. The pointOfInterest thud is easily mistaken for an edge sound.
- **User report (final):**
  - The beacon plays reliably, and "plays twice when two items are visible".
  - **No detectable panning, even in enemy arenas where footsteps do pan.**
- **Logs:** `build/logs/20260924-225258-combined-v1` (293 a11y lines).
- **Conclusions:**
  - The beacon trigger works (per pickup, rate-limited, range-gated).
  - A stategraph `PlaySound` from a prop is **not** panned, even where the engine's positional panning is clearly active. So it most likely takes the non-positional path (0x55ab10). Investigating statically.
  - `wall_ahead` separates walls from drops. `wall_low` never fired.
- **Follow-ups:** beacon v2 (Uzi_Arm) deployed 2bd8d78 right after this session; panning investigation.

## 2026-09-24 — 1a-1 edge probes (log only) — done
- **Commit / deployed:** 5ba09f1, deployed 2026-09-24 (`deploy.py status`: ok). There's one patch, `data/stategraphs/shank/shank_transitions.lua`: three NullTransitions appended to `REACTIONS`, right after the game's `noFall` rule. Each is rate-limited to once per second:
  - `a11y/edge_far`: on ground, `disttoendofplatform` < 4 tiles (256 px).
  - `a11y/edge_near`: on ground, `disttoendofplatform` < 1.5 tiles (96 px).
  - `a11y/facingedge`: on ground, `facingedge` true.
- **Pre-checks:**
  - `luacheck50.py` OK.
  - `loadtest50.py --check tests/lua/check_edge_probes.lua`: LOAD OK. 65 files loaded, the probes are in REACTIONS/STANDING/RUNNING/SPRINTING, and the undefined-global list is identical to vanilla.
- **Nothing is audible.** The game writes `Could not play Shank/Character/a11y/<name>` to `sound.log`, with second-resolution timestamps.
- **Instructions given:**
  1. Play 1-a (Load Chapter). At the start, stand still for about 5 s (baseline).
  2. At each ledge or drop you know, walk up to the very edge, stand still for about 5 s, turn around, and stand still another 5 s.
  3. Once, walk into a wall and stand facing it for about 5 s (tells a wall apart from a drop).
  4. At the **Pre Bridge** checkpoint area (a deadly pit right ahead, x 18,019–19,923), approach the gap and stand at its edge for about 5 s.
  5. Report the order of what you did, and whether movement felt any different (hitches, getting stuck, a jump not registering).
  6. Live-log check: at some point, stand somewhere safe, alt-tab and say "check now". Claude reads `sound.log` while the game runs.
  7. Quit the game (don't relaunch) and tell Claude.
- **Reading the results:** a 5-second stand at an edge should show about 5 identical lines, one per second. Compare the patterns with the reported sequence.
- **Interim live check (22:04:30, game running; the user was alt-tabbed, standing in front of a small climbable wall after the first enemy waves, not yet at the pit):**
  - `sound.log` was readable while the game ran, so the game doesn't lock it.
  - 14 a11y lines. Two clusters:
    - 22:01:50–52: edge_far → edge_near → facingedge (an approach).
    - 22:03:24–27: all three together every second (at the wall).
  - Each cue line is preceded by `FMOD error! (37) An invalid parameter was passed to this function.` (the unknown event).
  - The newest line (22:03:27) matches the file's last-write time; nothing after, because **the game pauses when it loses focus (confirmed by the user)**. Buffering: no sign of it.
  - **Early finding:** at a climbable wall, all three probes fire. So `disttoendofplatform` and `facingedge` treat a wall as "end of platform". They can't tell a wall from a drop without another condition (candidates: `lookingatledgewall`, `wallhasledgeattop`).
- **Second live check (22:18, game paused):** the user reached the pit area. They found the pit by falling in once while running, then walked up very slowly until they died. They can't position exactly at the edge without seeing it.
  - `game.log` marks deaths as `cApp::RestartGame` followed by `Checkpoint::Activate -- Activated checkpoint '<name>'`. This is useful for lining up deaths with cues.
  - Pre Bridge activated 22:11:37. Deaths at 22:11:47, 22:12:09, 22:12:18, 22:13:28, 22:14:50.
  - Wall Run activated 22:16:12. Deaths at 22:16:18, 22:16:43 (the second pit, x 26,049–28,557).
  - **The clearest case is the slow walk-up to the death at 22:16:43:** edge_far every second from 22:16:32 to :38 (about 7 s within 4 tiles), then edge_near + facingedge at :39 and :40, then death about 3 s later (including the fall).
  - Death at 22:16:18: far at :13 and :14, all three at :15, death about 3 s later.
  - Pre Bridge deaths:
    - most have all three probes 2–6 s before;
    - the 22:12:09 death had only edge_far beforehand (the last at 12:03). Possibly a run or a jump, since the probes only run in grounded states;
    - right after each respawn all three fire, because the spawn (x 17,912) is about 1.7 tiles from the pit edge (x 18,019).
  - `facingedge` almost always fires together with `edge_near`. In this data it adds little beyond `disttoendofplatform` < 1.5 tiles.
- **Extra run (user's design, started after 22:16:43, at the Wall Run pit):** the question is whether running explains a death with no near warning.
  1. Back up and **run** at the pit until dying.
  2. Approach **moderately slowly** until dying.
  3. **Jump** across properly to the next safe point.

  Expect deaths as `cApp::RestartGame` + `Activated checkpoint 'Wall Run'` in game.log.
- **Extra run results (read live at 22:25):** 6 deaths at the Wall Run pit. The user failed the jump several times. The Wall Run spawn is about 8 tiles from the pit edge (x 25,532 vs 26,049).
  - 22:23:39: far ×3 (:34–:36), near+facing at :37, death 2 s later. Likely the run-in.
  - 22:23:54: far at :51, all three at :52, death 2 s later. A fast approach, so the near warning **does** fire when running.
  - 22:24:06: far ×5 (:58–:03), all three at :04, death. The moderate approach.
  - 22:24:19: far ×8 (:09–:16), near+facing at :17, death. Slow.
  - 22:24:24 and 22:24:30: **no probes at all** between respawn and death. Jump attempts: Shank leaves the ground before reaching 4 tiles, and the probes only run on the ground.
  - After 22:24:30: far at :32–:34, then (in the air) far at :40. That's the successful crossing, landing on the next safe ground near its edge.
  - Conclusion: **running doesn't suppress the warning.** The earlier no-near-warning death (22:12:09) was most likely a jump. Ground-edge probes can't warn during a jump. Warning about a deadly landing zone while in the air needs a separate cue (see PLAN follow-ups).
- **User report:**
  - Movement felt completely normal throughout, including many jumps. No hitches, sticking or ignored inputs.
  - The game pauses on focus loss.
  - The user can't position precisely at an edge without seeing it. They found the pit by falling in once while running.
- **Logs:** `build/logs/20260924-222835-1a-1-edge-probes` (326 a11y cue lines in sound.log).
- **Conclusions:**
  - `disttoendofplatform` (in the facing direction) gives a graded, reliable warning before a drop, walking or running. On a slow approach there are about 2–3 s of warning between edge_near and the death event.
  - It also fires at walls. `facingedge` adds nothing beyond edge_near.
  - Ground probes can't warn during jumps.
  - **NullTransitions in `REACTIONS` don't disturb movement** (user report). **Gate 1a passed** for the edge values.
  - Live log reading works; the game pauses on focus loss.
- **Follow-ups:**
  - Wall-vs-drop probes, deployed together with 1a-2 (the user's choice).
  - An in-air pit warning (PLAN follow-up).
  - A continuous distance-paced cue in Phase 4.
  - Drop `facingedge`.

## 2026-09-24 — retail debug keys — done
- **Deployed:** nothing (vanilla game).
- **Instructions given:** in any level, try Ctrl+U (super speed), Ctrl+J (god mode + super speed) and Ctrl+N (previous checkpoint). Avoid Ctrl+D, K, W and F.
- **User report:** none of the combinations did anything. They played a short session in 1-a.
- **Logs:** read directly from the game folder (not collected). `lua.log` has only `Current Level: campaign_1a_wrestlingring`, with no `loading autoexec.lua`.
- **Conclusions:** the retail game never loads `data/autoexec.lua`. The debug functions still exist in the exe (addresses in RE-NOTES).
- **Follow-ups:** Phase 1b test mode in our DLL.
