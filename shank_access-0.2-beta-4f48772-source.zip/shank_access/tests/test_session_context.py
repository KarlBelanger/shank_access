"""Guards the SessionStart briefing: if PLAN.md headings change, the briefing must not silently lose sections."""
import os
import subprocess
import sys
import unittest

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class SessionContextTest(unittest.TestCase):
    def test_briefing_finds_all_sections(self):
        out = subprocess.run([sys.executable, os.path.join(REPO, "tools", "session_context.py")],
                             capture_output=True, encoding="utf-8", check=True).stdout
        self.assertNotIn("(section not found)", out)
        for marker in ("--- PLAN.md Status ---", "--- PLAN.md In flight ---", "Current task:",
                       "--- Recent work log ---", "--- git log --oneline -8 ---"):
            self.assertIn(marker, out)


if __name__ == "__main__":
    unittest.main()
