-- Run by tools/loadtest50.py after loading any goon stategraph (Lua 5.0), B24:
--   .venv/Scripts/python tools/loadtest50.py stategraphs/goon/boss_toro/toro_stategraph.lua --check tests/lua/check_flash_windups.lua
-- A goon state that starts the game's special-attack flash warns as a wind-up whatever its tags: the Priest's block
-- counter (his stategraph doesn't load in the harness: a stubbed damage constant, priest_STATES.lua 643), SWAT's
-- anti-pounce, Cesar's block attack; a flash-less block state stays silent.
local priest = "@C:/x/data-pc/stategraphs/goon/boss_priest/priest_STATES.lua"
local cases = {
  { { name = "block_counter_pre", tags = "blocking blockingshot blockingback", on_enter = { GenEvent("special_attack_flash_start") } }, priest, "charge" },
  { { name = "close_kick_pre", tags = "blocking blockingshot blockingback", on_enter = { GenEvent("special_attack_flash_start") } }, priest, "charge" },
  { { name = "swat_grapple_anti_pounce_pre", tags = "busy aircounter", on_enter = { GenEvent("special_attack_flash_start") } },
    "@C:/x/data/stategraphs/goon/boss_swat/swat_attacks.lua", "grab" },
  { { name = "block_atk_pre", tags = "blocking", at_time = { AtTime(0, GenEvent("special_attack_flash_start")) } },
    "@C:/x/data/stategraphs/goon/boss_cesar/cesar_states.lua", "charge" },
  { { name = "block", tags = "blocking blockingshot blockingback", on_enter = { GenEvent("priest_block") } }, priest, nil },
}
local problems = {}
for i, c in ipairs(cases) do
  local got = A11Y_WindupKind(c[1], c[2])
  if got ~= c[3] then table.insert(problems, c[1].name .. ": " .. tostring(got) .. " (want " .. tostring(c[3]) .. ")") end
end
print("  flash wind-up cases: " .. table.getn(cases) .. ", problems " .. table.getn(problems))
if table.getn(problems) > 0 then error(table.concat(problems, "; ")) end
return true
