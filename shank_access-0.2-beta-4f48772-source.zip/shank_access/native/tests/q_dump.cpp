// B42-6: every checkpoint leg's route as Q says it (host tool, never deployed), for reviewing the wording in bulk.
// For each level and checkpoint: Shank at the checkpoint's spawn with waypoint mode on, Q; then at the start of each move of
// the route (walked there in short hops, so the cue code sees no respawn), Q again. The text is cues::NextMove's own.
// Usage: q_dump.exe <shank_access_geometry.txt> <shank_access_paths.txt> <out.txt> [level]
#include <windows.h>

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include "../core/cues.h"
#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"
#include "../core/pathing.h"

namespace {

position::Pos At(float x, float y, bool right) {
    position::Pos p;
    p.known = p.live = true;
    p.x = x;
    p.y = y;
    p.facing_right = p.ping_facing_right = right;
    return p;
}

unsigned g_t = 1000;

// Ticks the cue code at p for a moment (the path is recomputed every kWaypointPathMs).
void Settle(const position::Pos& p) {
    for (int k = 0; k < 40; ++k, g_t += 10) cues::Tick(g_t, p);
}

// Moves him from a to b in hops shorter than a respawn jump, ticking on the way.
void WalkTo(position::Pos* at, float x, float y, bool right) {
    const float d = std::hypot(x - at->x, y - at->y);
    const int hops = static_cast<int>(d / 600.f) + 1;
    for (int h = 1; h <= hops; ++h) {
        *at = At(at->x + (x - at->x) / (hops - h + 1), at->y + (y - at->y) / (hops - h + 1), right);
        for (int k = 0; k < 3; ++k, g_t += 10) cues::Tick(g_t, *at);
    }
    *at = At(x, y, right);
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 4) {
        printf("usage: q_dump <shank_access_geometry.txt> <shank_access_paths.txt> <out.txt> [level]\n");
        return 2;
    }
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_q_dump.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);
    wchar_t w1[MAX_PATH], w2[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, argv[1], -1, w1, MAX_PATH);
    MultiByteToWideChar(CP_ACP, 0, argv[2], -1, w2, MAX_PATH);
    if (level_geometry::Load(w1) == 0 || pathing::Load(w2) == 0) {
        printf("can't load %s / %s\n", argv[1], argv[2]);
        return 1;
    }
    FILE* out = nullptr;
    if (fopen_s(&out, argv[3], "w") != 0 || !out) {
        printf("can't write %s\n", argv[3]);
        return 1;
    }
    fprintf(out, "# B42-6 Q along every checkpoint leg (q_dump.exe; derived, never commit). \"at\": where he stands for each Q.\n");
    int legs = 0, empty = 0, no_path = 0;
    for (const std::string& level : level_geometry::LevelNames()) {
        if (argc > 4 && level.find(argv[4]) == std::string::npos) continue;
        level_geometry::SetLevel(level);
        pathing::SetLevel(level);
        fprintf(out, "\n[%s]\n", level.c_str());
        const std::vector<level_geometry::Checkpoint> cps = level_geometry::Checkpoints();
        for (size_t c = 0; c + 1 < cps.size(); ++c) {
            cues::Reset();
            // (spawn points sit a little above the floor: on the floor below, as when he lands there)
            float sx = cps[c].spawn_x, sy = cps[c].spawn_y;
            jump_model::SetObstacles(&level_geometry::Obstacles());
            float lx = 0, ly = 0;
            if (jump_model::Land(sx, sy, 0.f, -50.f, &lx, &ly)) sy = ly;
            position::Pos at = At(sx, sy, true);
            Settle(at);
            if (!cues::WaypointOn()) cues::ToggleWaypoint(at);
            Settle(at);
            ++legs;
            const std::string first = cues::NextMove(at);
            std::string chapter;  // (the game's chapter name: what the player sees, not our level file's)
            for (const level_geometry::Chapter& ch : level_geometry::Chapters()) {
                if (ch.checkpoint <= cps[c].order) chapter = ch.name;
            }
            fprintf(out, "%s, checkpoint \"%s\":\n  at the spawn (%.0f, %.0f): %s\n", chapter.c_str(), cps[c].name.c_str(), at.x, at.y,
                    first.c_str());
            if (first.empty()) ++empty;
            if (first.find("No path") != std::string::npos) ++no_path;
            const std::vector<pathing::Step> route = cues::WaypointPath();
            for (size_t i = 1; i < route.size() && i < 60; ++i) {
                // (a walk-off or slide-off starts past the floor's end, in the air: stand just before it)
                float mx = route[i].x;
                if (!route[i].from.empty() && route[i].from[0] == 's' && (route[i].move == "walk_off" || route[i].move == "slide_off")) {
                    mx += route[i].right ? -24.f : 24.f;
                }
                WalkTo(&at, mx, route[i].y, route[i - 1].right);
                Settle(at);
                const std::string q = cues::NextMove(at);
                fprintf(out, "  move %u at (%.0f, %.0f) [%s]: %s\n", static_cast<unsigned>(i + 1), at.x, at.y, route[i].from.c_str(), q.c_str());
                if (q.empty()) ++empty;
            }
        }
        printf("%-28s done\n", level.c_str());
    }
    fprintf(out, "\n# %d legs; %d empty, %d \"No path\" at the spawn\n", legs, empty, no_path);
    fclose(out);
    printf("%d legs; %d empty Q, %d \"No path\" at the spawn -> %s\n", legs, empty, no_path, argv[3]);
    return 0;
}
