# Porting shank-access to Shank 2: assessment (first look, 2026-10-03)

The user asked (2026-10-03): "examine how this game is built, and develop an assessment of what it would take to
port the mod to shank 2. I know we would need fresh geometry for the levels, but how much will it take to adapt the
other aspects?"

Install: `C:\Program Files (x86)\Steam\steamapps\common\Shank 2` (1.6 GB, Klei / EA, January 2012). This is a
static first look of about an hour: no game launch and no code written. Points marked **(hypothesis)** are
unconfirmed. Points marked **(seen)** were read directly from the files.

## Verdict

Shank 2 runs on the same Klei engine, one generation later. The mod's outer shell carries over almost unchanged:
the injection, speech, our own audio, hotkeys, the settings menu, marks, logs, deploy and the setup. So do the
methods: the level data pipeline, waypoint pathing, the movement corpus and the test procedure.

Three of the mod's foundations do not carry over and must be rebuilt:
1. **The menus are not Scaleform any more.** Klei replaced it with its own UI system ("Chui"). All menu reading
   (ui_hooks + menu_reader, about 2,300 lines plus tests) has to be rewritten. The new system looks easier to read.
2. **The game's scripts ship compiled.** They are Lua 5.1 bytecode with debug info stripped, not Lua 5.0 source. Our
   approach of patching 29 game scripts to send cues (pickup beacons, hazards, attack wind-ups, button prompts,
   "got" messages, the position ping) cannot simply be repeated. Those features have to come from native hooks.
3. **Shank's movement is no longer in script.** In Shank 1, the player stategraph called `Jump(...)` 152 times,
   and that is how we learned every launch. Shank 2's player stategraph is one 1.1 MB compiled file that is
   almost all data (`Jump` appears twice). Movement logic is in C++ (classes `cAcrobaticsComponent`, `Wallrun`,
   `SwingPoint`, `ShimmyTrack`, `cPredictedTrajectory`). The jump model must be re-measured from scratch from
   play logs. That means a lot of the user's play time, as in Shank 1's B42-B47.

Rough size: less than the Shank 1 project, because about 40% of the code and all the tools and methods carry over.
But it is not a quick port. In Shank 1 batch terms:
- a working mod with menus, speech and status: about 6-10 batches;
- positional cues, enemies and safe edges: about 8-12 more;
- the jump model and waypoints good enough for blind play of all 8 levels: the long tail, as in Shank 1.

## What is the same (seen)

- **Process and injection.** 32-bit, imports `DINPUT8.dll!DirectInput8Create` (so our `dinput8.dll`
  proxy loads the same way), `USER32!GetRawInputData` / `RegisterRawInputDevices` (input_block's hook works),
  XInput 1.3, `KERNEL32!ExitProcess`, Steam API. Executable: `bin\shank2.exe`, 4.1 MB, SHA-256
  `3cd7aeb0d9f135dc82c4bba491463ecb85fec9aa33b9189ab2cee5160dd045d3`.
- **File system.** PhysFS mounts `../data` and `../data-pc` (plus the two bootstrap folders), as in Shank 1, so our
  "override in data-pc, keep the game's files vanilla" deploy should work. **(hypothesis)** The order is still
  data-pc first; check with one test file.
- **Sound.** FMOD Designer events (`shank.fev`) plus FSB banks, and `fmod_event.dll` / `fmodex.dll`. KleiSound is
  still the wrapper (RTTI `cSingleton<KleiSound>`). The FEV is a newer version (RIFF "FEV FMT" instead of "FEV1").
  `tools/re/sounds.py` still finds event names (e.g. `/Movement/Jumping/JumpFromGround`). Its wave linking needs
  rechecking.
- **Levels.** Same "Shanker" tool and layout: `data-pc/levels/<name>/<name>.lua` (source Lua: `Actions`,
  `Checkpoints` with `Initial`, `Next` chains, `SpawnLocation0`, `StartAnim`), `.slev`, `.vlev`, `data.zip`,
  `tiles.zip`. Level scripts are still **plain source**, so extract_levels.py's approach works. The object
  spawns changed from `spawnprop` / `spawncharacter` to `spawngameobject` with a `name`, e.g.
  `militia_med_machete`, `weapon_grenade`, `health_pickup_large`, `wolf_basic`.
- **Collision `.slev`** ("LVEL" version 12; Shank 1 is 7). Our decoder's segment and swing-point layouts read
  Shank 2's files unchanged (checked on Through the Fire and The Dark Road Home: 214 and 167 segments, sensible
  coordinates). Tags are still sdbm hashes. The new tags are **surface materials** (wood, dirt, metal, tin) plus
  climbable, slideable, pushwall, rickety and slowmo. The old ones (noclimb, nosplat, bg) are still used.
- **Engine classes worth hooking are still there by name:** `LevelData::LoadSimData`, the HasTag condition (our
  safe-edge mechanism), `setbounds`, `Checkpoint` / `CheckpointTrigger`, `cDeathEvent`, `cDamageEvent`,
  `cHealEvent`, `cComboCountChangedEvent`, `cPickupConsumableEvent`, `cCheckPointEvent`, `BossUI`. The RTTI is
  richer than Shank 1's: 962 classes versus 763.

## What changed, area by area

Each area gives the Shank 1 module, what happens to it, and a size estimate.

1. **Shell (reuse, small).** proxy, `speech`, `audio`, `hotkeys`, `mod_menu`, `config`, `marks`,
   `session_logs`, `input_block`, `focus_window`, `mod_state`, plus deploy.py, the setup, make_public.py,
   collect_logs.py and the session tools.
   - Changes: game paths, the exe hash, and the window / focus-pause behaviour (re-check).
   - Size: one batch.
2. **Addresses (redo, medium).** Everything in `game.h` is new.
   - Shank 2 shares Shank 1's code base and keeps the same error strings ("Wrong level version",
     `LoadSimData`, HasTag, ...). So most hooks can be found again by string cross-reference with tools/re/pe.py,
     which reads shank2.exe through `SHANK_EXE`.
   - Size: spread over the batches below.
3. **Menus (rewrite; maybe easier).** Shank 2's UI is "Chui": 34 `.chui` screen files (main menu, pause, settings,
   level select, loadout, death screen, how to play, weapon get, ...). Typed widgets: ChuiButton, ChuiLabel,
   ChuiCheck, ChuiSpinner, ChuiNumericSpinner, ChuiListBox, ChuiScrollList, ChuiGrid, ChuiProgressBar.
   - **(seen)** The screen files hold each widget's name, its **English text** and its neighbour links. For
     example pausedialog.chui has resumeBtn "Resume", loadoutBtn "Change Loadout", helpOptionsBtn "Options",
     statsBtn "Player Stats", quitBtn "Exit Game".
   - The engine has explicit `UIEvent_FocusGained`, `UIEvent_ValueChanged`, `UIEvent_ListSelect` and
     `UIEvent_GridSelect` event classes.
   - **(hypothesis)** One hook on focus-gained (or on the screen manager's event dispatch) gives the focused
     widget directly. That would replace Shank 1's heuristics over Flash variable writes.
   - Size: about 2-4 batches, against Shank 1's whole Phase 2.
4. **Status readouts (rewrite, small-medium).** Health, grenades, boss health, combo and pickups came from HUD
   writes to Scaleform plus Lua "got_" messages. Shank 2 has game event classes for these (damage, heal, combo,
   pickup, checkpoint, death, money and collectible). **(hypothesis)** Hooking the event dispatch gives them all
   at one point.
   - Size: 1-2 batches.
5. **Cues from patched scripts (rewrite as native hooks, medium-large).** 29 patched game scripts sent
   `a11y/...` cue messages: pickup beacons and "in reach"; hazards (grenades, missiles, barrels, fire,
   ceilings, rocks); boss and goon wind-ups (`make_windup_patch.py`); button prompts; the position ping.
   - The compiled scripts can't be patched as text.
   - Options, best first:
     - Hook the native state change (`cGoToStateAction`, StateGraph's state entry) and match state names
       against a table we build offline. The state names are readable as constants in the bytecode.
     - Wrap Lua globals at run time from a small source Lua file of our own (Lua 5.1 makes this easy). Levels
       and `autoexec.lua` are still source, so a load point exists.
     - Decompile on the player's machine: fragile. Shipping decompiled Klei code is ruled out by our
       "never ship Klei assets" rule.
   - Our Lua 5.0 tooling (luacheck50, loadtest50 and the Lua 5.0 hard rules in CLAUDE.md) would need 5.1
     versions, or isn't needed at all.
   - Size: 3-5 batches.
6. **Position (redo, small).** Shank 1 seeded a memory scan from a Lua ping. Shank 2 needs a native route
   instead, e.g. the player's game item → physics component position.
   - Size: 1 batch.
7. **Enemies (redo, medium).** `cGameItemManager` is gone by that name (Shank 2 has `cScrappersGameItem`,
   `cScrappersSimulation`, `cCombatManager`). Character attributes (640 files) are compiled, but their names are
   readable strings.
   - The AI is now behaviour graphs (`cBehaviourGraph`, 26 files), so wind-up detection must be redone (see 5).
   - New enemy kinds: wolves, boars, crocodiles, shield and grappler militia, cult girls, and more.
   - Size: 2-3 batches.
8. **Level data and geometry (redo the decoding; the method carries over).**
   - The `.slev` decoder needs v12's changed path records (poles, slide poles, shimmy lines) and the large new
     tail section. That tail is about 97% of each file (e.g. 185 KB of Through the Fire's 190 KB).
     **(hypothesis)** It is the AI navigation graph (`cNavGraph`) or placed traversal objects. Either would be
     valuable: a ready-made walk graph from Klei.
   - extract_levels.py needs the `spawngameobject` names.
   - Size: 2-3 batches before geometry.py's output is trustworthy.
9. **Movement model, traversal graph, waypoints (re-measure; the largest part).** The code
   (jump_model, path_graph, pathing, Q, the cue thread, movements.py, movement_check, cue_replay, evidence,
   test_plan) carries over, but every number in it is Shank 1's.
   - Shank 2's moveset differs. From the state constants: back roll, wall climbing and sliding, shimmy lunge,
     push walls, heavy objects, grapples and counters, a shovel.
   - Calibration needs fresh `traj:` logs from the user's play, level by level: a long tail of test sessions,
     as in Shank 1.
   - The new surface tags give a bonus: footstep-style material cues (wood, metal, dirt) come for free.
10. **New game features with no Shank 1 counterpart.**
    - The weapon loadout screen (menus).
    - Counter / grapple prompts during fights: needs a cue, like Shank 1's button prompts.
    - Heavy objects to carry and throw.
    - Corina as the playable character in Human Cargo (`playercharacteroverride`).
    - Collectibles.
    - Survival mode: online co-op waves, three maps. **Recommend out of scope**, like Shank 1's co-op.

## The campaign (seen)

8 levels, 107 checkpoints (Shank 1: 10 levels).

| Level | Name | Checkpoints |
|---|---|---|
| 1 | The Dark Road Home | 10 |
| 2 | Through the Fire | 10 |
| 3 | Dirty Docks | 13 |
| 4 | Lost in Ruins | 15 |
| 5 | Rumble in the Jungle | 16 |
| 6 | Human Cargo (as Corina) | 11 |
| 7 | The Last Resort | 18 |
| 8 | Deconstruction | 14 |

## Decisions the user would need to make before starting

1. **Repository layout.** Recommended: one repo with a shared core and a per-game layer (`game.h`, the hooks,
   the data tools taking a `--game` flag). This keeps fixes to the shared parts (speech, menu, pathing) in one
   place. The alternative is a fork into a new repo: simpler at first, but the two would drift apart.
2. **Scope.** The campaign only. Survival and co-op are out.
3. **Order.** Recommended: shell and menus first, so the game is playable with speech. Then status, then level
   data and position, then cues and enemies, then the movement model with test batches level by level.

## First steps if the user goes ahead (each its own batch)

1. Bootstrap: build the proxy and core against shank2.exe's hash, log only, speech says "Shank 2 Access loaded";
   check the data-pc override with one harmless file.
2. Chui: find the focus-gained dispatch and log every focused widget's name and text while the user walks the
   menus.
3. Decode the rest of slev v12 and the level scripts; produce the first Shank 2 geometry file.
