// B47-1: today's jump-now cue replayed along the old movements (host tool, never deployed).
// For every real launch in movements.txt (tools/movements.py) of a kind the cue judges (ground, slope, wall, run-up, pole,
// swing, bar, wall run): the 1.5 s before it is fed through cues::Tick from the session's timeline (his positions: traj
// samples and his ground sounds, linearly between them, every 30 ms; his facing; the keys he held, where logged), waypoint
// mode off. What chirped (cues::ReachableNow) in the last 400 ms before the launch is compared with how the flight really
// ended:
//   kept      a chirp named what he really reached
//   false     a chirp named something else, by the jump he made, his way, and he didn't get there (a false alert)
//   missing   he reached a swing point, pole, bar, wall-run zone or wall (or, from a hold, a floor) with no chirp for it
//   quiet     no chirp, and nothing the cue chirps for was reached (a ground jump onto a floor, a death with no chirp)
//   -         not judged (no positions before it, or not a kind the cue judges)
// Output: one line per launch, then totals per level and kind. Usage:
//   cue_replay.exe <geometry.txt> <paths.txt> <movements.txt> <timelines folder> <out.txt>
#include <windows.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include "../core/cues.h"
#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"
#include "../core/pathing.h"

namespace {

std::string g_trace;  // --trace <session:t>: print every tick of that launch's replay

struct Launch {
    std::string key, session, level, kind, dir, how, ttype;
    unsigned t = 0;
    float x0 = 0, y0 = 0, ex = 0, ey = 0, tx1 = 0, ty1 = 0, tx2 = 0, ty2 = 0;
};

struct Ev {
    unsigned t;
    char type;  // L, P, G, F, H
    float x = 0, y = 0;
    std::string text;
};

bool Judged(const std::string& kind) {
    return kind == "ground" || kind == "slide" || kind == "cling" || kind == "run_up" || kind == "pole" || kind == "swing" ||
           kind == "bar" || kind == "wall_run";
}

// The jump kind a chirp names vs the launch he made.
bool SameJump(int jump, const std::string& kind) {
    switch (static_cast<jump_model::Jump>(jump)) {
        case jump_model::kLong:
        case jump_model::kStanding: return kind == "ground" || kind == "slide" || kind == "wall_run";
        case jump_model::kWallJump:
        case jump_model::kRunUpJump: return kind == "cling" || kind == "run_up";
        case jump_model::kPoleJump: return kind == "pole";
        case jump_model::kSwingJump: return kind == "swing";
        case jump_model::kBarJump: return kind == "bar";
        case jump_model::kUpJump: return kind == "bar" || kind == "swing";
        case jump_model::kWallRunJump: return kind == "wall_run";
        default: return false;
    }
}

float DistanceTo(const Launch& m, float x, float y) {
    if (m.ttype == "swing") return std::hypot(x - m.tx1, y - m.ty1);
    if (m.ttype == "wallzone") {
        const float dx = std::fmax(0.f, std::fmax(m.tx1 - x, x - m.tx2)), dy = std::fmax(0.f, std::fmax(m.ty1 - y, y - m.ty2));
        return std::hypot(dx, dy);
    }
    const float vx = m.tx2 - m.tx1, vy = m.ty2 - m.ty1, len2 = vx * vx + vy * vy;
    float u = len2 > 0 ? ((x - m.tx1) * vx + (y - m.ty1) * vy) / len2 : 0.f;
    u = std::fmax(0.f, std::fmin(1.f, u));
    return std::hypot(m.tx1 + u * vx - x, m.ty1 + u * vy - y);
}

bool Reached(const Launch& m) {
    return m.how != "death" && m.ttype != "pit" && m.ttype != "-" && m.how != "lost" && m.how != "relaunch";
}

bool ChirpIsEnd(const Launch& m, const cues::ReachInfo& c) {
    // B47b-2: a ledge grab at a chirped wall (he came up to its top and climbed it) reached it
    if (c.what == "a wall" && m.how == "ledge" && std::fabs(m.ex - c.x) <= 96.f && std::fabs(m.ey - c.y) <= 400.f) return true;
    if (!Reached(m)) return false;
    if (std::hypot(m.ex - c.x, m.ey - c.y) <= 200.f) return true;
    return DistanceTo(m, c.x, c.y) <= 96.f;
}

std::vector<Ev> LoadTimeline(const std::string& path) {
    std::vector<Ev> out;
    std::ifstream in(path);
    std::string line;
    while (std::getline(in, line)) {
        std::istringstream s(line);
        Ev e;
        std::string type;
        s >> type >> e.t;
        if (type.empty()) continue;
        e.type = type[0];
        if (e.type == 'P' || e.type == 'G') s >> e.x >> e.y;
        else s >> e.text;
        out.push_back(e);
    }
    return out;
}

position::Pos At(float x, float y, float vx, float vy, bool right) {
    position::Pos p;
    p.known = p.live = true;
    p.x = x;
    p.y = y;
    p.vx = vx;
    p.vy = vy;
    p.facing_right = p.ping_facing_right = right;
    return p;
}

struct Verdict {
    std::string v = "-", detail;
};

// The 1.5 s before the launch through today's cue code; what chirped in its last 400 ms.
Verdict Replay(const Launch& m, const std::vector<Ev>& tl) {
    Verdict out;
    const unsigned from = m.t > 1500 ? m.t - 1500 : 0;
    // the state at the window's start: facing, keys held; the positions in the window (and the last one before it)
    bool right = m.dir == "R";
    std::map<std::string, bool> held;
    std::vector<const Ev*> pos;
    const Ev* before = nullptr;
    for (const Ev& e : tl) {
        if (e.t > m.t) break;
        if (e.type == 'F') right = e.text == "R";
        if (e.type == 'H') {
            const std::string& h = e.text;
            held[h.substr(0, h.find('_'))] = h.size() > 3 && h.compare(h.size() - 3, 3, "_on") == 0;
        }
        if (e.type == 'P' || e.type == 'G') {
            if (e.t < from) before = &e;
            else pos.push_back(&e);
        }
    }
    if (before) pos.insert(pos.begin(), before);
    if (pos.size() < 2 || m.t - pos.back()->t > 600) {
        out.detail = "no positions just before it";
        return out;
    }
    cues::Reset();
    for (const auto& h : held) {
        if (h.second) cues::OnCue(h.first + "_on", m.x0, m.y0, from);
    }
    // facing at each tick: the last F before it (rebuilt per tick from the timeline)
    std::vector<cues::ReachInfo> heard;
    size_t k = 0;
    for (unsigned t = from; t + 20 <= m.t; t += 30) {
        while (k + 1 < pos.size() && pos[k + 1]->t <= t) ++k;
        const Ev* a = pos[k];
        const Ev* b = k + 1 < pos.size() ? pos[k + 1] : pos[k];
        float x = a->x, y = a->y, vx = 0, vy = 0;
        if (b != a && b->t > a->t) {
            const float u = std::fmin(1.f, std::fmax(0.f, static_cast<float>(t - a->t) / (b->t - a->t)));
            x = a->x + u * (b->x - a->x);
            y = a->y + u * (b->y - a->y);
            vx = (b->x - a->x) * 1000.f / (b->t - a->t);
            vy = (b->y - a->y) * 1000.f / (b->t - a->t);
            if (b->t - a->t > 700) vx = vy = 0;  // (a long gap: he stood still somewhere in it)
        }
        bool face = right;
        for (const Ev& e : tl) {
            if (e.t > t) break;
            if (e.type == 'F') face = e.text == "R";
        }
        cues::Tick(t, At(x, y, vx, vy, face));
        if (!g_trace.empty() && g_trace == m.key) {
            printf("  t-%4u pos (%.0f, %.0f) v (%.0f, %.0f) %s:", m.t - t, x, y, vx, vy, face ? "R" : "L");
            for (const cues::ReachInfo& r : cues::ReachableNow()) printf(" [%s (%.0f, %.0f) j%d]", r.what.c_str(), r.x, r.y, r.jump);
            printf("\n");
        }
        if (m.t - t <= 400) {
            for (const cues::ReachInfo& r : cues::ReachableNow()) {
                bool dup = false;
                for (const auto& h : heard) dup = dup || (h.what == r.what && std::fabs(h.x - r.x) < 64 && std::fabs(h.y - r.y) < 64);
                if (!dup) heard.push_back(r);
            }
        }
    }
    char buf[256];
    for (const auto& c : heard) {
        snprintf(buf, sizeof buf, "%s%s at (%.0f, %.0f)", out.detail.empty() ? "chirped: " : "; ", c.what.c_str(), c.x, c.y);
        out.detail += buf;
    }
    bool kept = false, same_way_other = false;
    for (const auto& c : heard) {
        if (ChirpIsEnd(m, c)) kept = true;
        else if (SameJump(c.jump, m.kind) && ((c.x > m.x0) == (m.dir == "R") || std::fabs(c.x - m.x0) < 64)) same_way_other = true;
    }
    const bool catchable = m.ttype == "swing" || m.ttype == "pole" || m.ttype == "shimmy" || m.ttype == "wallzone" || m.ttype == "wall" ||
                           ((m.ttype == "landing" || m.ttype == "ledge") && m.kind != "ground" && m.kind != "slide");
    if (kept) out.v = "kept";
    else if (same_way_other) out.v = "false";
    else if (Reached(m) && catchable) out.v = "missing";
    else out.v = "quiet";
    snprintf(buf, sizeof buf, "%sended: %s %s at (%.0f, %.0f)", out.detail.empty() ? "" : " | ", m.how.c_str(), m.ttype.c_str(), m.ex, m.ey);
    out.detail += buf;
    return out;
}

struct Tally {
    int n = 0, kept = 0, falsec = 0, missing = 0, quiet = 0, none = 0;
    void Add(const std::string& v) {
        ++n;
        kept += v == "kept";
        falsec += v == "false";
        missing += v == "missing";
        quiet += v == "quiet";
        none += v == "-";
    }
};

void Print(FILE* f, const char* name, const Tally& t) {
    fprintf(f, "  %-26s %5d  kept %4d  false %3d  missing %3d  quiet %4d  not judged %4d\n", name, t.n, t.kept, t.falsec, t.missing,
            t.quiet, t.none);
}

}  // namespace

int main(int argc, char** argv) {
    for (int i = 6; i + 1 < argc; ++i) {
        if (std::strcmp(argv[i], "--trace") == 0) g_trace = argv[i + 1];
    }
    if (argc < 6) {
        printf("usage: cue_replay <geometry.txt> <paths.txt> <movements.txt> <timelines folder> <out.txt>\n");
        return 2;
    }
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_cue_replay.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);
    wchar_t w1[MAX_PATH], w2[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, argv[1], -1, w1, MAX_PATH);
    MultiByteToWideChar(CP_ACP, 0, argv[2], -1, w2, MAX_PATH);
    if (level_geometry::Load(w1) == 0 || pathing::Load(w2) == 0) {
        printf("can't load the geometry / paths\n");
        return 1;
    }
    std::vector<Launch> launches;
    {
        std::ifstream in(argv[3]);
        std::string line;
        while (std::getline(in, line)) {
            std::istringstream s(line);
            std::string tag, scale, flags, x_resid, fx, fy, vx, vy, extra;
            Launch m;
            s >> tag >> m.key >> m.level >> m.kind >> m.x0 >> m.y0 >> m.dir >> vx >> vy >> scale >> x_resid >> fx >> fy >> flags >> m.how >>
                m.ex >> m.ey >> m.ttype >> m.tx1 >> m.ty1 >> m.tx2 >> m.ty2 >> extra;
            if (!s || tag != "m") continue;
            if (flags != "-") continue;  // (warps, super speed, slow motion, an odd time scale: not a fair replay)
            const size_t colon = m.key.rfind(':');
            m.session = m.key.substr(0, colon);
            m.t = static_cast<unsigned>(std::stoul(m.key.substr(colon + 1)));
            launches.push_back(m);
        }
    }
    FILE* out = nullptr;
    if (fopen_s(&out, argv[5], "w") != 0 || !out) {
        printf("can't write %s\n", argv[5]);
        return 1;
    }
    fprintf(out, "# B47-1 today's jump-now cue replayed along the old launches (cue_replay.exe; derived, never commit)\n");
    fprintf(out, "# rp <session>:<t> <level> <kind> <x0> <y0> <verdict> | <chirped> | <ended>\n");
    std::map<std::string, Tally> by_level, by_kind;
    Tally all;
    std::string session_now, level_now;
    std::vector<Ev> tl;
    for (const Launch& m : launches) {
        if (!Judged(m.kind)) continue;
        if (m.session != session_now) {
            session_now = m.session;
            tl = LoadTimeline(std::string(argv[4]) + "\\" + m.session + ".txt");
        }
        if (m.level != level_now) {
            level_now = m.level;
            level_geometry::SetLevel(m.level);
            pathing::SetLevel(m.level);
        }
        const Verdict v = Replay(m, tl);
        fprintf(out, "rp %s %s %s %.0f %.0f %s | %s\n", m.key.c_str(), m.level.c_str(), m.kind.c_str(), m.x0, m.y0, v.v.c_str(), v.detail.c_str());
        all.Add(v.v);
        by_level[m.level].Add(v.v);
        by_kind[m.kind].Add(v.v);
    }
    for (FILE* f : {out, stdout}) {
        fprintf(f, "%sBy kind:\n", f == out ? "# " : "");
        for (const auto& kv : by_kind) Print(f, kv.first.c_str(), kv.second);
        fprintf(f, "%sBy level:\n", f == out ? "# " : "");
        for (const auto& kv : by_level) Print(f, kv.first.c_str(), kv.second);
        Print(f, "all", all);
    }
    fclose(out);
    return 0;
}
