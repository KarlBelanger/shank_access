#pragma once
// Phase 4: positioned cue sounds, rendered relative to Shank (DESIGN "Sound vocabulary": pan = left/right
// of Shank, pitch = height, pulse rate / volume = distance). Pure logic: the caller plays what Tick returns
// (audio::Play) and passes Shank's position (position::Current).
//   - Edge cue v2 (B4 G6): from the level geometry (level_geometry::EdgeAhead): the real end of the surface
//     Shank stands on, in the direction he faces, with what's there (safe drop, deadly drop, wall). Steps he
//     hops up (1 tile or less) are silent.
//   - Pickups (4-4): Lua messages from each pickup (sound_hooks cue listener):
//       beacon_<kind>   a pickup within about a screen of Shank, every 0.5 s, at the pickup
//       inreach_<kind>  Shank within the pickup's prompt box, every 0.25 s
#include <string>
#include <vector>

#include "audio.h"
#include "pathing.h"
#include "position.h"

namespace cues {

struct PlayCmd {
    audio::Sound sound;
    float pan;        // -1 … 1
    float semitones;  // pitch shift
    float volume;     // 0 … 1
};

struct Output {
    std::vector<PlayCmd> plays;
    std::string say;  // speech, queued (e.g. "Health in reach"); "" = none
    std::string say_now;  // B9c: urgent speech (a boss's button prompt), interrupting
    std::string chapter;  // B29-2: the chapter's name once a level has loaded (spoken first, before a tutorial then)
};

// Edge cue v2 timing (pixels; a tile is 64 px; Shank runs about 770 px/s, B3c).
constexpr float kEdgeRangePx = 12 * 64.f;     // cues start this far from the edge, or earlier when moving:
constexpr float kEdgeRangeSeconds = 1.6f;     // this long before reaching it at his speed (running: ~19 tiles)
constexpr unsigned kEdgeFastestMs = 70;       // pulse gap at the edge
constexpr unsigned kEdgeSlowestMs = 520;      // pulse gap at the start of the range
constexpr float kWallTouchPx = 24.f;          // at a wall: silent (he's against it)
constexpr float kShankRadius = 32.f;          // Physics Radius 0.5 tile: he stops this far from a bound
constexpr float kEdgePan = 0.5f;              // the edge is ahead: this far to Shank's facing side
constexpr float kClimbableWallSemitones = 5.f;  // B5: a wall he can run up knocks this much higher

// B5-4 jump targets (the user: "jump targets should have one sound for nearby, and another when you can
// directly jump to it"): swing points, poles, bars, wall zones within kTargetRangePx pluck (kTarget; the
// nearest kTargetsSounded); any a jump started now reaches chirps instead (kJumpNow, every kJumpNowGapMs).
// The far side of a deadly drop ahead is a landing target: it only chirps (the edge buzz marks the drop).
// Clinging to a climbable wall (1-c's climb): the jump judged is the wall jump away from it; other climbable
// walls on that side chirp too when a wall jump now catches them (the nearest one).
constexpr float kTargetRangePx = 12 * 64.f;
// B47 (the old launches replayed through the cue: swing releases caught swing points ~16 tiles off and landed on floors up
// to ~20 tiles off with no chirp: they were never judged): the jump-now chirp is judged this far; the pluck stays at 12 tiles.
constexpr float kJumpJudgeRangePx = 25 * 64.f;
constexpr size_t kTargetsSounded = 2;
constexpr unsigned kTargetGapMs = 700;        // (before B44-4: + up to 600 ms when far; now PluckGap, the pickups' timing)
// The pickup beacons' repeat (B44-4: the plucks too; the user: "use the speed values for the pickup sounds. Enemy and edge
// sounds get too fast."): kPickupFastestMs close, + up to kPickupSpanMs at kPickupSpanPx.
constexpr unsigned kPickupFastestMs = 400, kPickupSpanMs = 800;
constexpr float kPickupSpanPx = 1600.f;
// B44-2: on the ground the jump judged is the long jump once he runs his facing way at least this fast, else the standing jump.
constexpr float kLongJumpMinVx = 250.f;
constexpr unsigned kJumpNowGapMs = 150;       // B5b: 250 ms let a 0.26 s window at running speed pass unheard
constexpr float kInUsePx = 96.f;              // hanging from it / in it: silent (the user, B5)
constexpr float kSwingBandPx = 40.f;          // on a swing point: within this of the measured swing radius
constexpr float kZoneBesidePx = 150.f;        // a wall zone this close beside him counts as in use
constexpr float kSlideFootPx = 3 * 64.f;       // B8c: below a slide pole's bottom + this, it's silent
constexpr float kOverheadMinUpPx = 96.f;      // B9-2 platform overhead (B9b: one he's under): at least this far above his feet...
constexpr float kOverheadMaxUpPx = 520.f;     // ...at most this (well over a jump's reach)
constexpr float kOverheadAsidePx = 320.f;     // ...and within this to either side
constexpr unsigned kOverheadForgetMs = 1000;  // out of reach this long: announced again when back
constexpr float kLandingAsidePx = 8.f;        // a landing he has to jump to: not directly under him (B5e; 1-c's platform starts 23 px past the bar's end)
constexpr float kOnBarMaxVx = 450.f;  // B48e: faster than this across, he is not hanging from a shimmy line (shimmying ~290)
constexpr float kWallFromHoldMinDxPx = 128.f;  // B47b-2: a wall as a jump target from a bar, swing point, pole or wall run: at least this far across
constexpr float kPoleSideMinPx = 50.f;       // on a pole: this far to one side of it (PoleClimbOffset 80)...
constexpr float kPoleSideMaxPx = 110.f;       // ...at most this
constexpr unsigned kReachHoldMs = 200;        // "a jump now reaches it" held this long after the model stops saying so
constexpr float kGroundedMaxVy = 150.f;       // on the ground only if not moving up/down faster than this (px/s)
constexpr float kClingMaxVx = 80.f;           // clinging to a wall means not moving sideways (px/s)
// B6-2 wall runs (wallrun.lua: level at 8 MPS = 768 px/s while holding forward, inside a wall-run zone).
constexpr float kWallRunMinVx = 450.f;        // wall running: at least this fast along the zone...
constexpr float kWallRunMaxVy = 300.f;        // ...and about level
constexpr float kWallRunZoneMarginPx = 64.f;  // his y within the zone's box, give or take this
constexpr float kSlideMinVy = 120.f;          // B6-3: on a slide pole, sliding down at least this fast (slowest slide 2 MPS)
constexpr float kPathJoinPx = 48.f;           // a slide pole whose bottom meets another pole/rope piece: no fall there
constexpr float kWallRunLongWindowPx = 96.f;  // this close to the zone's end, the long jump (wallruntofall: 7 frames) counts
                                              // (= jump_model::kWallRunEndWindowPx, which the graph uses: B41d)
// The countdown: running toward a jump window, the pluck speeds up (gap kLeadInFastestMs + kLeadInSpanMs x
// seconds left / kLeadInSeconds) until the chirp.
constexpr float kLeadInSeconds = 1.0f;
constexpr float kLeadInStep = 0.05f;
constexpr float kLeadInMinSpeed = 100.f;
constexpr unsigned kLeadInFastestMs = 90;
constexpr unsigned kLeadInSpanMs = 400;
constexpr float kLandingSearchPx = 900.f;     // how far past the edge a far side is looked for
constexpr float kLandingMaxRisePx = 300.f;    // ...at most this much higher
constexpr float kLandingMaxDropPx = 800.f;    // ...or this much lower
constexpr float kLandingStretchPx = 320.f;    // the part of the far side counted as the landing

// Pickups.
constexpr unsigned kPickupStaleMs = 800;    // no beacon report (every 0.5 s) for this long: gone (B8d: was 1.5 s; the user:
                                            // "the delayed stop is a common problem across sounds")
constexpr float kPickupMatchPx = 64.f;      // a report this close to a known pickup of the same kind is that pickup
constexpr float kPanRangePx = 1200.f;       // |dx| at which a pickup is fully left/right
constexpr float kPixelsPerSemitone = 96.f;  // 1.5 tiles above = one semitone higher
constexpr unsigned kReachRepeatMs = 1500;   // "in reach" again only after being out of reach this long

// B7 hazard warnings (Lua reports "hz_<kind>": rock, ceiling, rocket, missile, grenade, barrel).
constexpr unsigned kHazardStaleMs = 200;        // a moving hazard not reported for this long: gone (reports every 0.1 s;
                                                // B7b: 400 left a rocket sounding where it had exploded)
constexpr float kHazardExtrapolateSeconds = 0.15f;  // B7b: between reports, moving ones carried on at their speed this long at most
constexpr unsigned kBarrelStaleMs = 800;        // barrels report every 0.5 s (B8d: was 1.5 s)
constexpr float kHazardMatchPx = 160.f;         // a report this close to where a known hazard of the kind should be is it
constexpr size_t kHazardsSounded = 3;           // the nearest few only
constexpr float kFallColumnPx = 160.f;          // a falling rock/ceiling: in its path within this of its x (300-320 px wide + his radius)
constexpr float kFallWarnPx = 400.f;            // ...warned from this far to the side
constexpr float kProjectileWarnPx = 1000.f;     // rockets and missiles: warned within this distance...
constexpr float kProjectileWarnSeconds = 1.5f;  // ...the pulse follows the time until it gets to him (this = slowest)
constexpr float kProjectileMinSpeed = 300.f;    // (a speed not yet known counts as this)
constexpr unsigned kProjectileSpanMs = 220;     // their pulse gap: kHazardFastestMs + up to this (they're fast)
constexpr float kBlastPx = 210.f;               // grenade / barrel blast (350 x 350) + his radius
constexpr float kGrenadeWarnPx = 500.f;
// B15-5 (the user: "change the grenades from enemies to have the cue follow the flight path. As it is sometimes the
// cue only plays just before it detonates"): a grenade still flying is heard from this far, following it.
constexpr float kGrenadeFlightWarnPx = 1600.f;
constexpr float kGrenadeFlyingSpeed = 150.f;  // px/s: faster than this = still in the air
constexpr float kBarrelWarnPx = 40 * 64.f;      // B7b: the pistol's range (PISTOL_RANGE, 40 tiles; the user: they're shot at range),
                                                // only with a clear line of fire (no wall, ceiling or floor between; inside the bounds)
constexpr unsigned kLineCheckMs = 150;          // the line-of-fire check is redone this often per barrel
constexpr float kProjectileAwayPx = 600.f;      // B7b: a rocket moving away and this far off: no longer a threat
// B13-3 fire traps (firetrap_stategraph.lua: a player within 60 +- 60 px across and 180 px up is burned and knocked
// back, 5 damage (15 on hard) every frame he's in it).
constexpr float kFireBurnPx = 2 * 64.f;      // on him: the fastest pulse
constexpr float kFireWarnPx = 8 * 64.f;      // heard from this far across
constexpr float kFireLevelPx = 3 * 64.f;     // ...when he's within this of its height (not on a floor far above or below)
constexpr unsigned kHazardFastestMs = 80;       // the pulse gap when it's on him
constexpr unsigned kHazardSpanMs = 450;         // + this at the edge of the warning range

void OnCue(const std::string& name, float x, float y, unsigned now_ms);

// B5-2: the area Shank can be in (the current arena/checkpoint bounds, level_hooks::CurrentBounds). The
// user: "if shank cannot reach something, the mod should act like it doesn't exist": pickups and
// traversal features outside it are silent and left out of P and T; a bound between Shank and an edge
// ahead counts as a wall. Unknown (known = false) until the level's first bounds action.
struct Area {
    bool known = false;
    float min_x = 0, min_y = 0, max_x = 0, max_y = 0;
    bool arena = false;  // B36b-2: an arena's bounds (not the level's default ones)
};
void SetArea(const Area& area);
constexpr float kAreaMarginPx = 32.f;  // a pickup this close outside the bounds still counts (it sits on the line)

// Call often (every 10–20 ms). Returns the sounds to play now and any speech.
Output Tick(unsigned now_ms, const position::Pos& shank);

// How far into the edge range Shank is: 1 at the start of the range, 0 at the edge; > 1 = out of range.
// (Exposed for tests.)
float EdgeCloseness(float distance, float speed_toward);

// Spoken summary of the pickups being tracked, nearest first, for a hotkey:
// "Health, 5 tiles right. Grenades, 12 tiles left, 3 above." / "No pickups nearby".
std::string PickupSummary(unsigned now_ms, const position::Pos& shank);

// B4 G7 (first version): the nearest traversal features from the level geometry (swing points, poles,
// slide poles, shimmy lines, wall-run zones), up to 3 within kTraversalRangePx, nearest first:
// "Swing point, 5 tiles right, 4 above. Pole, 8 tiles left." / "Nothing to climb or swing on nearby".
constexpr float kTraversalRangePx = 30 * 64.f;
std::string TraversalSummary(const position::Pos& shank);

// Spoken name of a pickup kind ("grenadelauncher" -> "Grenade launcher").
std::string KindName(const std::string& kind);

// B7: the hazards being tracked (for tests and the log).
size_t HazardCount();

// B8 enemy cues (DESIGN "Enemy cues"): the nearest enemy (or the locked one) ticks with its class's sound,
// muffled when it's behind Shank; wind-ups whoosh from where they start.
constexpr float kEnemyRangePx = 1600.f;       // the nearest enemy within this (about a screen) is cued
constexpr float kArenaEnemyMarginPx = 640.f;  // B36b-2: ...or, in an arena, the nearest one within its bounds and this margin
constexpr float kScreenHalfWPx = 1600.f;      // B29-1: "on screen": within this of Shank sideways (the view is 3200 x 1800)...
constexpr float kScreenHalfHPx = 900.f;       // ...and this up or down
constexpr float kGrappleSoundPx = 320.f;      // B29-4: Shank's grapple sound this close to him is his
constexpr unsigned kFinisherBlockMs = 3000;   // ...and no opening bell for this long (the finisher)
constexpr float kDeathMatchPx = 192.f;        // B29-1: a death sound this close to an enemy is its death
constexpr float kFallMatchPx = 256.f;         // ...a falling scream (he's already moving)
constexpr unsigned kDeathDecideMs = 400;      // B31-1: an enemy that left the list is decided this long after
constexpr unsigned kSpawnKillMs = 1000;       // ...no tone if it had been listed less than this (a fresh spawn killed)
constexpr size_t kMassLeaveCount = 3;         // ...nor if this many left at once (a despawn)
constexpr unsigned kDeathConfirmMs = 500;     // B30-1: a death sound this close in time to an enemy leaving the list
constexpr unsigned kDeadForgetMs = 15000;     // marks kept this long (a fall to a pit takes a few seconds)
constexpr unsigned kEnemyFastestMs = 60;      // its tick gap when close... (B8d: faster; the user: "a faster base pulse,
                                              // then nearly a continuous tone once the enemy is on top of me")
constexpr unsigned kEnemySpanMs = 450;        // ...+ up to this at the edge of the range
constexpr float kEnemyOnTopPx = 150.f;        // this close: nearly continuous
constexpr unsigned kEnemyOnTopMs = 45;
constexpr float kEnemyPanPx = 400.f;          // B8d: full left/right at this (1200 made one 100 px away sound centred)
constexpr float kEnemyPassPx = 400.f;         // an enemy this close crossing to his other side: the pass whoosh
constexpr float kEnemyPassSlackPx = 24.f;     // (it must get this far past him)
constexpr unsigned kEnemyPassGapMs = 400;     // (not more often than this per enemy)
// B19-2 (the user, 2026-09-27: "a slight woosh sound for whenever shank turns, that pans to the direction he is facing"):
// the Lua reports turn_r / turn_l once per turn; the whoosh plays this far to the new facing side, this loud.
constexpr float kTurnPan = 0.35f;
constexpr float kTurnVolume = 1.0f;  // B20-1 (the user: "Shank's turning sound needs to be louder"; was 0.6, sample 0.2 -> 0.35)
constexpr float kEnemyBehindPx = 32.f;       // behind = more than this on the side he isn't facing
// B13-4 gunmen aiming: heard within a pistol's range; repeated while the reports keep coming (the aiming state is
// re-entered about every 0.6 s); a shot (an attack report at the same spot) ends it.
constexpr float kAimRangePx = 40 * 64.f;
constexpr float kAimMatchPx = 160.f;
constexpr unsigned kAimRepeatMs = 350;
constexpr unsigned kAimHoldMs = 800;
constexpr float kWindupRangePx = 1400.f;      // wind-ups heard within this (charges; B26: grabs and the rest nearer)
constexpr float kWindupGrabRangePx = 900.f;   // B26: a grab / grapple / pounce
constexpr float kWindupStdRangePx = 800.f;    // B26: any other attack by a big goon or a boss
constexpr unsigned kWindupMergeMs = 500;      // reports from the same spot within this = one attack (a combo)
constexpr float kWindupMergePx = 120.f;
constexpr float kWindupSelfPx = 40.f;         // none at Shank's own position
constexpr float kAttackerMatchPx = 200.f;     // B9-1: the enemy this close to an attack report is the attacker
// B9c boss openings (the user: "a stunned or vulnerable state where ... grapple or pounce triggers a highly damaging
// cinematic attack"): a boss showing the grapple prompt, or in a "canbegrappled" state (en_vuln report, refreshed as
// its loop re-enters), is open: it's the cued enemy, and its tick becomes an energetic bell.
constexpr unsigned kOpeningHoldMs = 1500;     // an en_vuln report keeps the boss open this long
constexpr float kOpeningMatchPx = 400.f;      // the boss this close to a report / prompt is the one
constexpr unsigned kOpeningGapMs = 140;       // the bell's pace
// B23-4 (the user, 2026-09-28: "use a slow opening bell for all situations which lead to the open state"): a boss set
// up for an opening gets the slow bell (kEnemySetup: two strikes per play), cued first like an open boss, over a lock too.
constexpr unsigned kSetupGapMs = 660;         // one kEnemySetup play (two strikes 330 ms apart) this often
constexpr unsigned kSetupMaxMs = 12000;       // an en_setup report (Toro's charge) without its en_setup_end: at most this
// The Butcher (B23-5): his hook catches a lowered slab 100-600 px in front of him; he throws it only with Shank 200-800 px
// in front (RE-NOTES "How the Butcher gets stunned"). A little inside those, so the bell doesn't promise the edges.
constexpr float kHookSlabMinPx = 120.f, kHookSlabMaxPx = 580.f;
constexpr float kHookShankMinPx = 220.f, kHookShankMaxPx = 780.f;
constexpr float kSameLevelPx = 200.f;         // Shank and the boss (and the Gimp's slave, the Priest's trap) this close in y
// The Gimp (B23-6): he charges with Shank more than 4 tiles away and grabs the first character in his way.
constexpr float kGimpChargeMinPx = 4 * 64.f + 32.f;
// The Priest (B23-7): a fire trap between him and Shank within this far of him, or right beside him.
constexpr float kFireLureMaxPx = 10 * 64.f;
constexpr float kFireBesidePx = 2 * 64.f;
constexpr float kFireBehindMaxPx = 6 * 64.f;  // B24: a trap behind him (Shank on the other side): knock him back into it
// B25 (the user: grappling the Priest at once put Shank in the fire; "his stun audio plays immediately, which is mostly
// what I was reacting too"): his grapple prompt while he's this close to a burning trap (its flames reach 96 px, plus
// Shank's body and a margin) says "Wait"; "Grapple now" (and the fast bell) once he has walked clear, or after this long.
// B25b (the next session: "Grapple now" came 80-125 ms after "Wait", him only ~70 px out: the trap's burn area is
// off-centre and reaches ~160 px on the arena side, and the grapple lunge carries Shank a little past him; and Shank's
// hits after the stun knocked him back toward the fire): clear = this far from the trap; pushed back inside
// kFireDangerPx again = "Wait" again (the bell stops); no time limit (grappling him near the fire burns Shank).
constexpr float kFireClearPx = 300.f;
constexpr float kFireDangerPx = 240.f;
constexpr unsigned kWaitRepeatMs = 1000;
constexpr unsigned kPromptRepeatMs = 3000;    // the same prompt spoken again only after this
constexpr float kScanRangePx = 3200.f;        // the scan key lists enemies within this
// B8-6 lock-on: the locked enemy is cued instead of the nearest; "in line" when a pistol shot would hit it.
constexpr unsigned kInLineGapMs = 250;
// B8b (the user: "lock on should adjust its range independently from the main radar based on the equipped
// ranged weapon"): the gun Shank last armed, from the game's arm sounds at his position; pistols until then.
struct Gun {
    const char* name;
    float range_px;       // its RANGE constant (stategraphs/shank/constants.lua)
    float tolerance_deg;  // its ATTACK_ARC, each side of the aim (B9b)
};
Gun CurrentGun();
void OnGameSound(const char* name, float x, float y, unsigned now_ms);  // game thread; quick
void OnBossHealth(float value);  // B29-4: the HUD's single boss bar (enemyBoss.healthBar.value)
// B8d: L (special_only false) / K (true): the first press locks onto the nearest enemy within the gun's range;
// each further press moves to the next one out; after the farthest, "Lock off". Returns what to say.
std::string LockNext(const position::Pos& shank, bool special_only);

// B10 waypoint mode (W; the user: "only the next required one along the path through the level is heard"): the
// path through the level's traversal graph (pathing) from where Shank is to the next checkpoint; its next object
// (a swing point, pole side, bar, wall-run zone or climbable wall) is the only traversal target cued, audible much
// further (inside the bounds); a landing only if the next move is a jump onto that floor; the checkpoint chimes.
// Recomputed as he moves, so backtracking brings the earlier objects back. No path: the normal cues.
constexpr float kWaypointRangePx = 3000.f;       // the waypoint object is cued this far away
constexpr unsigned kWaypointPathMs = 200;        // the path is recomputed this often
constexpr float kWaypointHintNearPx = 6 * 64.f;   // B20-3: a move's hint (drop through, ...) only this close to its spots
constexpr unsigned kWaypointHintRepeatMs = 20000; // B20-3: the same hint not again sooner
constexpr float kCheckpointGrowPx = 320.f;       // floors / holds this close to the trigger rectangle reach it
                                                 // (B27-3: floors sideways only; vertically Shank must overlap it)
constexpr float kShankHeightPx = 160.f;          // B27-3: his collision height (2.5 tiles)
constexpr float kRespawnJumpPx = 1200.f;         // a jump this far between ticks: a respawn (snap to a checkpoint)
constexpr int kGoalOrderBase = 1000;             // B29-6: story goals' pseudo checkpoint numbers
constexpr float kSpawnSnapPx = 600.f;            // ...to the checkpoint whose spawn is this close
constexpr unsigned kChimeFastestMs = 700;        // the checkpoint chime's gap near it...
constexpr unsigned kChimeSpanMs = 1100;          // ...+ this far away
constexpr float kBounceWindowPx = 320.f;         // on the pole within this of where the bounce works: its chirp
bool ToggleWaypoint(const position::Pos& shank);  // returns the new state
bool WaypointOn();
// Q: the next move, spoken: "run up the wall to a climbable wall, 3 tiles right. Next checkpoint: Enter Packing
// Warehouse" / "No path from here" / "No next checkpoint".
std::string NextMove(const position::Pos& shank);
// B42-6 (host tools: q_dump): a copy of the waypoint path as it is now (empty when off or no path).
std::vector<pathing::Step> WaypointPath();
// B47-1 (host tools: cue_replay): what the jump-now cue says a jump reaches this tick (the chirps): its name ("Swing point",
// "a landing", ...), the point the cue sounds at, and the jump. Before B47 only T read these.
struct ReachInfo {
    std::string what;
    float x = 0, y = 0;
    int jump = 0;  // a jump_model::Jump
};
std::vector<ReachInfo> ReachableNow();
// B8e (test mode ;): the enemy tick, wind-up whoosh and lock-on ting pan like the game's own sounds (by the camera)
// instead of relative to Shank; the pass whoosh stays Shank-relative. camera: the game's pan for an x (false = unknown).
using CameraPanFn = bool (*)(float x, float* pan);
void SetCameraPan(CameraPanFn camera);
bool ToggleEnemyCameraPan();  // returns true when the camera pan is on
void SetEnemyCameraPan(bool on);  // B37-1: test mode off, the enemy cues follow C (camera pan when C pans by the camera)
bool EnemyCameraPan();
// B8d: Shank collected a pickup ("got_<kind>" at x, y): stop its beacon at once.
void OnPickedUp(const std::string& kind, float x, float y);
// The scan key (B8d, shorter): "5 enemies. Nearest knife goon, 4 tiles left, 2 above." / "No enemies nearby".
std::string EnemySummary(const position::Pos& shank);

void Reset();

}  // namespace cues
