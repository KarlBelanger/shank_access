// B6-6: offline traversal audit (host tool, never deployed). For every level in the geometry file, tries
// every launch the jump model knows from sampled starting points (standing on floors, walking off drops,
// clinging to climbable walls, on poles, swinging, hanging from bars, wall running) against every traversal
// feature, with the level's walls, ceilings and floors in the way. Per feature: which launches reach it.
// Features nothing reaches come first: either the model misses a way there (a gap to fix) or the way
// there isn't a modelled launch (ledge climbs, vaults, scripted moves).
// Usage: traversal_audit.exe <shank_access_geometry.txt> [out_dir]   (writes <out_dir>/<level>.audit.txt)
#include <windows.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"

namespace {

using jump_model::Target;

enum Kind { kGround, kWalkOff, kCling, kPole, kSwing, kBar, kWallRun, kKinds };
const char* const kKindNames[kKinds] = {"ground", "walking off", "wall cling", "pole", "swing", "bar", "wall run"};

struct Origin {
    Kind kind;
    float x, y;
    bool right;     // facing / jumping this way
    int feature;    // the feature he's on (-1 = none): not a target from here
};

constexpr float kSample = 64.f;
constexpr float kMaxAcross = 1700.f;  // no launch goes further in kMaxSeconds
constexpr float kMaxRise = 700.f;     // ...or higher (the jump up: ~350 + the grab reach)

bool ToTarget(const level_geometry::Feature& f, Target* t) {
    const auto& p = f.points;
    if (p.empty()) return false;
    const auto& q = p.size() > 1 ? p[1] : p[0];
    if (f.type == "swing_point") *t = Target{jump_model::kSwing, p[0].first, p[0].second, 0, 0};
    else if (f.type == "pole" || f.type == "slide_pole") *t = Target{jump_model::kPole, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "shimmy_line") *t = Target{jump_model::kShimmy, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "wallrun_zone") *t = Target{jump_model::kWallZone, p[0].first, p[0].second, q.first, q.second};
    else return false;
    t->slide = f.type == "slide_pole";  // B8c
    return true;
}

// Samples from a to b, every kSample, ends included.
std::vector<float> Steps(float a, float b) {
    std::vector<float> v;
    if (b < a) std::swap(a, b);
    for (float x = a; x < b; x += kSample) v.push_back(x);
    v.push_back(b);
    return v;
}

std::vector<Origin> Origins() {
    std::vector<Origin> o;
    for (const level_geometry::Surface& s : level_geometry::Surfaces()) {
        for (size_t i = 0; i + 1 < s.points.size(); ++i) {
            const auto& a = s.points[i];
            const auto& b = s.points[i + 1];
            if (b.first - a.first < 16.f) continue;
            for (float x : Steps(a.first + 8, b.first - 8)) {
                const float y = a.second + (x - a.first) / (b.first - a.first) * (b.second - a.second) + jump_model::kFeet;
                o.push_back(Origin{kGround, x, y, true, -1});
                o.push_back(Origin{kGround, x, y, false, -1});
            }
        }
        if (s.points.size() < 2) continue;
        if (s.left.type == level_geometry::End::kDrop)
            o.push_back(Origin{kWalkOff, s.points.front().first - 16, s.points.front().second + jump_model::kFeet, false, -1});
        if (s.right.type == level_geometry::End::kDrop)
            o.push_back(Origin{kWalkOff, s.points.back().first + 16, s.points.back().second + jump_model::kFeet, true, -1});
    }
    for (const level_geometry::Wall& w : level_geometry::Walls()) {
        if (!w.climbable) continue;
        const float x = w.faces_left ? w.x - 32 : w.x + 32;  // on the open side
        for (float y : Steps(w.y1 + 32, w.y2)) o.push_back(Origin{kCling, x, y, !w.faces_left, -1});
    }
    const auto& features = level_geometry::Features();
    for (size_t i = 0; i < features.size(); ++i) {
        Target t;
        if (!ToTarget(features[i], &t)) continue;
        const int id = static_cast<int>(i);
        switch (t.kind) {
            case jump_model::kPole:
                for (float y : Steps(t.y1, t.y2)) {
                    o.push_back(Origin{kPole, t.x1 - 80, y, false, id});
                    o.push_back(Origin{kPole, t.x1 + 80, y, true, id});
                }
                break;
            case jump_model::kSwing:
                for (int deg = -60; deg <= 60; deg += 20) {
                    const float a = deg * 3.14159265f / 180.f;
                    const float x = t.x1 + jump_model::kSwingRadius * std::sin(a);
                    const float y = t.y1 - jump_model::kSwingRadius * std::cos(a);
                    o.push_back(Origin{kSwing, x, y, true, id});
                    o.push_back(Origin{kSwing, x, y, false, id});
                }
                break;
            case jump_model::kShimmy: {
                const int n = std::max(1, static_cast<int>(std::hypot(t.x2 - t.x1, t.y2 - t.y1) / kSample));
                for (int k = 0; k <= n; ++k) {
                    const float u = static_cast<float>(k) / n;
                    const float x = t.x1 + u * (t.x2 - t.x1), y = t.y1 + u * (t.y2 - t.y1) - jump_model::kHangUp;
                    o.push_back(Origin{kBar, x, y, true, id});
                    o.push_back(Origin{kBar, x, y, false, id});
                }
                break;
            }
            case jump_model::kWallZone:
                for (float y = t.y1 + 64; y <= t.y2; y += 96) {
                    for (float x : Steps(t.x1, t.x2)) {
                        o.push_back(Origin{kWallRun, x, y, true, id});
                        o.push_back(Origin{kWallRun, x, y, false, id});
                    }
                }
                break;
            default:
                break;
        }
    }
    return o;
}

jump_model::Jump Try(const Origin& o, const Target& t) {
    switch (o.kind) {
        case kGround: return jump_model::Reach(t, o.x, o.y, o.right);
        case kWalkOff: return jump_model::ReachFalling(t, o.x, o.y, o.right);
        case kCling: {
            const jump_model::Jump j = jump_model::ReachFromWall(t, o.x, o.y, o.right);
            return j != jump_model::kNone ? j : jump_model::ReachFromWallRunningUp(t, o.x, o.y, o.right);
        }
        case kPole: return jump_model::ReachFromPole(t, o.x, o.y, o.right);
        case kSwing: return jump_model::ReachFromSwing(t, o.x, o.y, o.right);
        case kBar: return jump_model::ReachFromBar(t, o.x, o.y, o.right);
        case kWallRun: {
            const jump_model::Jump j = jump_model::ReachFromWallRun(t, o.x, o.y, o.right);
            return j != jump_model::kNone ? j : jump_model::Reach(t, o.x, o.y, o.right) == jump_model::kLong ? jump_model::kLong : jump_model::kNone;
        }
        default: return jump_model::kNone;
    }
}

}  // namespace

// B9-2 check: where on the floors a jump reaches a platform overhead (the same window and jump model as
// cues.cpp OverheadCue). Prints each platform once per level: the first floor spot (by x) it's reached from.
void Overhead(const std::string& level) {
    level_geometry::SetLevel(level);
    jump_model::SetObstacles(&level_geometry::Obstacles());
    std::vector<int> seen;
    for (const level_geometry::Surface& s : level_geometry::Surfaces()) {
        for (size_t i = 0; i + 1 < s.points.size(); ++i) {
            const auto& a = s.points[i];
            const auto& b = s.points[i + 1];
            if (b.first - a.first < 16.f) continue;
            for (float x : Steps(a.first + 8, b.first - 8)) {
                const float feet = a.second + (x - a.first) / (b.first - a.first) * (b.second - a.second);
                const float y = feet + jump_model::kFeet;
                for (const level_geometry::Surface& f : level_geometry::Surfaces()) {
                    if (f.id == s.id) continue;
                    for (size_t k = 0; k + 1 < f.points.size(); ++k) {
                        const auto& c = f.points[k];
                        const auto& d = f.points[k + 1];
                        if (x < c.first + 32.f || x > d.first - 32.f) continue;  // B9b: only a platform he's under
                        const float nx = x;
                        const float ny = d.first > c.first ? c.second + (nx - c.first) / (d.first - c.first) * (d.second - c.second) : c.second;
                        if (ny - feet < 96.f || ny - feet > 520.f) continue;
                        const Target t{jump_model::kLanding, c.first, c.second, d.first, d.second};
                        if (jump_model::Reach(t, x, y, true) == jump_model::kNone && jump_model::Reach(t, x, y, false) == jump_model::kNone) continue;
                        if (std::find(seen.begin(), seen.end(), f.id) != seen.end()) continue;
                        seen.push_back(f.id);
                        printf("  platform %d (x %.0f..%.0f, y %.0f, %s): reached from the floor at (%.0f, %.0f), %.0f px up\n", f.id,
                               f.points.front().first, f.points.back().first, ny, f.tags.empty() ? "solid" : f.tags.c_str(), x, feet,
                               ny - feet);
                    }
                }
            }
        }
    }
    jump_model::SetObstacles(nullptr);
}

int main(int argc, char** argv) {
    if (argc >= 4 && std::string(argv[2]) == "--overhead") {  // traversal_audit.exe <geometry.txt> --overhead <level>
        wchar_t wpath[MAX_PATH];
        MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wpath, MAX_PATH);
        level_geometry::Load(wpath);
        Overhead(argv[3]);
        return 0;
    }
    if (argc < 2) {
        printf("usage: traversal_audit <shank_access_geometry.txt> [out_dir]\n");
        return 2;
    }
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_traversal_audit.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);
    wchar_t wpath[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wpath, MAX_PATH);
    if (level_geometry::Load(wpath) == 0) {
        printf("no levels in %s\n", argv[1]);
        return 1;
    }
    const std::string out_dir = argc > 2 ? argv[2] : "";
    if (!out_dir.empty()) CreateDirectoryA(out_dir.c_str(), nullptr);
    int total = 0, total_unreached = 0;
    for (const std::string& level : level_geometry::LevelNames()) {
        level_geometry::SetLevel(level);
        jump_model::SetObstacles(&level_geometry::Obstacles());
        const std::vector<Origin> origins = Origins();
        const auto& features = level_geometry::Features();
        std::string unreached, reached;
        int n = 0, missing = 0;
        for (size_t i = 0; i < features.size(); ++i) {
            Target t;
            if (!ToTarget(features[i], &t)) continue;
            ++n;
            const float lo_x = std::min(t.x1, t.kind == jump_model::kSwing ? t.x1 : t.x2);
            const float hi_x = std::max(t.x1, t.kind == jump_model::kSwing ? t.x1 : t.x2);
            const float lo_y = std::min(t.y1, t.kind == jump_model::kSwing ? t.y1 : t.y2);
            int count[kKinds] = {};
            const Origin* example[kKinds] = {};
            for (const Origin& o : origins) {
                if (o.feature == static_cast<int>(i)) continue;
                const float gap = o.x < lo_x ? lo_x - o.x : o.x > hi_x ? o.x - hi_x : 0.f;
                if (gap > kMaxAcross || lo_y - o.y > kMaxRise) continue;
                if (Try(o, t) == jump_model::kNone) continue;
                if (!count[o.kind]++) example[o.kind] = &o;
            }
            char head[160];
            snprintf(head, sizeof head, "  %s at (%.0f, %.0f)%s", features[i].type.c_str(), t.x1, t.y1,
                     t.kind == jump_model::kSwing ? "" : "");
            std::string line = head;
            if (t.kind != jump_model::kSwing) {
                snprintf(head, sizeof head, " to (%.0f, %.0f)", t.x2, t.y2);
                line += head;
            }
            bool any = false;
            std::string how;
            for (int k = 0; k < kKinds; ++k) {
                if (!count[k]) continue;
                snprintf(head, sizeof head, "%s%s x%d (e.g. from (%.0f, %.0f) %s)", any ? "; " : "", kKindNames[k], count[k],
                         example[k]->x, example[k]->y, example[k]->right ? "right" : "left");
                how += head;
                any = true;
            }
            if (any) {
                reached += line + ": " + how + "\n";
            } else {
                unreached += line + "\n";
                ++missing;
            }
        }
        total += n;
        total_unreached += missing;
        printf("%-32s features %3d  unreached %3d  (origins %zu)\n", level.c_str(), n, missing, origins.size());
        if (!out_dir.empty()) {
            const std::string path = out_dir + "/" + level + ".audit.txt";
            FILE* f = nullptr;
            if (fopen_s(&f, path.c_str(), "w") == 0 && f) {
                fprintf(f, "Traversal audit: %s (tools: traversal_audit.exe, B6-6)\n", level.c_str());
                fprintf(f, "%d features, %d reached by no modelled launch\n\nNot reached:\n%s\nReached:\n%s", n, missing,
                        unreached.empty() ? "  (none)\n" : unreached.c_str(), reached.c_str());
                fclose(f);
            }
        }
        jump_model::SetObstacles(nullptr);
    }
    printf("total: %d features, %d unreached\n", total, total_unreached);
    return 0;
}
