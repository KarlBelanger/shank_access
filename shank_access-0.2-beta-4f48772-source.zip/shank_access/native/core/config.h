#pragma once
// shank_access.ini, next to Shank.exe (deployed from mod/files/bin/shank_access.ini). Every
// option has a safe default in code, so a missing file means "all optional features off".
// B13-2: the F7 settings menu saves the player's choices to shank_access_user.ini beside it (written by the
// mod, never deployed, so a redeploy keeps them); it is read after shank_access.ini and overrides it.
#include <map>
#include <string>

namespace config {

struct Settings {
    bool test_mode = false;  // [test] test_mode=1: developer hotkeys and the movie skips (B18: F3 toggles and saves it)
    int cue_volume = 80;     // [cues] volume=0..100: our cue sounds (Phase 4), percent
    bool safe_edges = false; // [edges] safe_edges=1: start with safe edges on (B7; E toggles it)
    bool pan_around_shank = true;  // [sound] pan_around_shank=0: game sounds pan by the camera (B8f; C toggles it)
    std::map<std::string, bool> announce;  // [announce] <announce::IniKey>=0/1 (B13-2); missing = on
    std::map<std::string, int> keys;       // [keys] <hotkey id>=<virtual-key code> (B13-2); missing = the default
    // B39 [pads] <hotkey id>=<controller buttons mask>; missing / 0 = the default (B40b: Back for the mod menu, else not
    // set); -1 = cleared by the player (kept here as 0)
    std::map<std::string, unsigned> pads;
    // B16 [speech]: each channel's engine (menu=, stats=, auto=: 0 screen reader, 1 SAPI) and our SAPI voice.
    int speech_engine[3] = {0, 0, 0};
    std::string sapi_voice;  // voice= (a SAPI voice's name; "" = the Windows default)
    int sapi_rate = 0;       // rate= -10..10
    int sapi_volume = 100;   // volume= 0..100
    // B30-3 [sound] quieter=<name part>:<percent>,...: game sounds played quieter (the user: 3-c's rockets drown the cues)
    std::string quieter = "RocketLauncher_Fly:35,RocketLauncher_Explode:40,RocketLauncher_Gibs:50,GameItems/rubbleBreakLong:50";
};

// Reads ini_path, then user_path (either may be missing).
Settings Load(const std::wstring& ini_path, const std::wstring& user_path);
// Writes the player's settings (test mode, volume, pan, safe edges at start, announcements, keys, speech) to user_path.
bool Save(const std::wstring& user_path, const Settings& s);

}  // namespace config
