#pragma once
// Developer test mode. Registers hotkeys that flip the game's own debug flags, which the retail build
// still contains: F5 = god mode, F6 = super speed (docs/DESIGN.md "Hotkeys"; addresses in docs/RE-NOTES.md).
// B18 (2026-09-27): F3 turns it on and off while playing and the choice is saved (shank_access_user.ini);
// the keys are always registered but do nothing while it's off. The startup movie skips also follow it.
namespace test_mode {

void SetOn(bool on);  // off also clears god mode and super speed
bool On();

void RegisterHotkeys();

}  // namespace test_mode
