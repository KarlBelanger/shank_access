#include "ui_text.h"

#include <windows.h>

#include <cctype>
#include <cstdio>
#include <map>
#include <sstream>
#include <vector>

namespace ui_text {
namespace {

SRWLOCK g_lock = SRWLOCK_INIT;
std::map<std::string, std::string> g_by_key;  // key (e.g. "Combos") -> the section's text as sentences
std::map<std::string, std::vector<std::string>> g_by_file;  // B51b: "unlockshotgun.gfx" -> its text lines as drawn

std::string Sentence(std::string s) {
    while (!s.empty() && (s.back() == ' ' || s.back() == '\r')) s.pop_back();
    if (s.empty()) return s;
    const char last = s.back();
    return (last == '.' || last == '?' || last == '!' || last == ':') ? s : s + ".";
}

}  // namespace

size_t LoadFromString(const std::string& content) {
    std::map<std::string, std::string> by_key;
    std::map<std::string, std::vector<std::string>> by_file;
    std::string file;
    std::vector<std::string> keys;
    std::string text;
    size_t sections = 0;
    auto flush = [&]() {
        for (const std::string& k : keys) {
            if (!text.empty() && by_key.find(k) == by_key.end()) by_key[k] = text;
        }
        keys.clear();
        text.clear();
    };
    std::istringstream in(content);
    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        if (line[0] == '[') {
            flush();
            ++sections;
            file = line.substr(1, line.find(']') == std::string::npos ? std::string::npos : line.find(']') - 1);
        } else if (line.compare(0, 4, "key=") == 0) {
            keys.push_back(line.substr(4));
        } else if (line.compare(0, 5, "text=") == 0) {
            if (!file.empty()) by_file[file].push_back(line.substr(5));
            const std::string t = Sentence(line.substr(5));
            if (!t.empty()) text = text.empty() ? t : text + " " + t;
        }
    }
    flush();
    AcquireSRWLockExclusive(&g_lock);
    g_by_key.swap(by_key);
    g_by_file.swap(by_file);
    ReleaseSRWLockExclusive(&g_lock);
    return sections;
}

size_t Load(const std::wstring& path) {
    FILE* f = nullptr;
    if (_wfopen_s(&f, path.c_str(), L"rb") != 0 || !f) return 0;
    std::string content;
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) content.append(buf, n);
    fclose(f);
    return LoadFromString(content);
}

std::string PageText(const std::string& key) {
    AcquireSRWLockShared(&g_lock);
    auto it = g_by_key.find(key);
    std::string out = it != g_by_key.end() ? it->second : std::string();
    ReleaseSRWLockShared(&g_lock);
    return out;
}

namespace {

std::string Lower(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

std::string Trim(std::string s) {
    while (!s.empty() && (s.back() == ' ' || s.back() == '\r')) s.pop_back();
    size_t i = 0;
    while (i < s.size() && s[i] == ' ') ++i;
    return s.substr(i);
}

}  // namespace

std::string UnlockText(const std::string& file) {
    AcquireSRWLockShared(&g_lock);
    auto it = g_by_file.find(Lower(file));
    const std::vector<std::string> lines = it != g_by_file.end() ? it->second : std::vector<std::string>();
    ReleaseSRWLockShared(&g_lock);
    if (lines.empty()) return std::string();
    // The drawn lines come in no fixed order ("new move:" and "to equip:" are labels drawn beside their text): the first
    // line is the weapon's name; a "cycle through" line is how to equip it; with a "new move:" label, the remaining line
    // that isn't a sentence (no full stop) is the move; the rest describe the weapon.
    std::string name = Trim(lines[0]), equip, move, about;
    bool has_move = false;
    std::vector<std::string> rest;
    for (size_t i = 1; i < lines.size(); ++i) {
        std::string l = Trim(lines[i]);
        const std::string low = Lower(l);
        if (low == "new move:") {
            has_move = true;
            continue;
        }
        if (low == "to equip:") continue;
        if (low.compare(0, 9, "to equip:") == 0) l = Trim(l.substr(9));
        if (Lower(l).find("cycle through") != std::string::npos) {
            equip = l;
            continue;
        }
        rest.push_back(l);
    }
    for (const std::string& l : rest) {
        if (has_move && move.empty() && !l.empty() && l.back() != '.') move = l;
        else about = about.empty() ? Sentence(l) : about + " " + Sentence(l);
    }
    // (one drawn run joins two words: "shootwhile")
    const size_t glued = move.find("shootwhile");
    if (glued != std::string::npos) move.replace(glued, 10, "shoot while");
    if (!name.empty()) name = name.substr(0, 1) + Lower(name.substr(1));
    std::string out = "New weapon: " + Sentence(name);
    if (!about.empty()) out += " " + about;
    if (!move.empty()) out += " New move: " + Sentence(move);
    if (!equip.empty()) out += " To equip, " + Sentence(Lower(equip.substr(0, 1)) + equip.substr(1));
    return out;
}

}  // namespace ui_text
