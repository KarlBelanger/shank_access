-- Run by tools/loadtest50.py after loading a boss stategraph (Lua 5.0), B9c. Asserts that the patched State()
-- puts PlaySound("a11y/en_vuln") in the on_enter of every "canbegrappled" state, and in no other.
local with, problems = {}, {}
for _, st in ipairs(StateGraph.States) do
  local has = false
  if type(st.on_enter) == "table" then
    for i = 1, table.getn(st.on_enter) do
      local a = st.on_enter[i]
      if type(a) == "table" and a.Type == "playsound" and a.sound == "a11y/en_vuln" then has = true end
    end
  end
  local open = type(st.tags) == "string" and string.find(st.tags, "canbegrappled", 1, true)
  if has then table.insert(with, st.name) end
  if has ~= (open ~= nil) then table.insert(problems, st.name .. " (" .. tostring(st.tags) .. ")") end
end
print("  opening reports in " .. table.getn(with) .. " states: " .. table.concat(with, ", "))
if table.getn(problems) > 0 then error("wrong states: " .. table.concat(problems, "; ")) end
if table.getn(with) == 0 then error("no opening reports") end
return true
