"""B42-4: the risky moves on every checkpoint leg's route, per level, with directions to each from the checkpoint before it
(the user's rule: the level, the checkpoint, the steps), so one session with Go to checkpoint can test them all.

A move on a route is risky when:
  - it works from one spot only (its start range under 64 px: "at the chirp, a narrow window");
  - it lands on a small floor (under 4 tiles) with a deadly edge;
  - it's a long fall (a drop, walk-off or slide-off of 10+ tiles);
  - it lands on a feature near its end (a bar or wall-run zone caught within a tile of its end);
  - the corpus has trouble there: real deaths, false catches or broken chirps (tools/movements.py + movement_check) from
    launches within 2 tiles of the move's start.
Reads build/levels/ (geometry, paths), build/movements/ (movements.json, check.txt; run movements.py and movement_check
first for the corpus part). Writes build/levels/risky_moves.txt and prints a summary.

Usage: risky_moves.py [<level>]
"""
import contextlib
import io
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
import path_check  # noqa: E402

LEVELS = os.path.join(ROOT, "build", "levels")
MOVES = os.path.join(ROOT, "build", "movements")
TILE = 64.0
NAMES = {"long_jump": "long jump", "standing_jump": "jump", "wall_jump": "wall jump", "run_up_jump": "jump off the wall",
         "pole_jump": "jump off the pole", "swing_jump": "jump off the swing point", "bar_jump": "jump off the bar", "jump_up": "jump up",
         "wall_run_jump": "jump off the wall run", "walk_off": "walk off the edge", "slide_off": "slide off the end",
         "platform_up": "jump up into the platform, then jump again", "shimmy_along": "shimmy along",
         "run_across": "run across the gap", "run_off": "sprint off the edge", "climb_up": "run up the wall and climb over", "drop": "drop",
         "run_up_wall": "run up the wall", "climb": "climb", "climb_over": "climb over the top", "slide_down": "slide down",
         "climb_down": "climb down", "bounce": "jump off and bounce back to the other side",
         "switch_sides": "switch sides (hold toward the pole)", "drop_through": "drop through (hold down and jump)"}
KIND_NAMES = {"swing_point": "a swing point", "pole": "a pole", "slide_pole": "a slide pole", "shimmy_line": "a bar",
              "wallrun_zone": "a wall run"}


def target_point(node, x, y, surfaces, features, walls):
    """Where a move lands on its target, roughly (for distances in tiles)."""
    if node[0] == "s":
        pts = surfaces[node]
        best = min(pts, key=lambda p: abs(p[0] - x))
        for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
            if x1 <= x <= x2 and x2 > x1:
                return x, y1 + (x - x1) / (x2 - x1) * (y2 - y1) + 32
        return best[0], best[1] + 32
    if node[0] in "fp":
        kind, pts = features[int(node[1:].rstrip("LR"))]
        if kind == "wallrun_zone":
            (x1, y1), (x2, y2) = pts[0], pts[-1]
            return min(max(x, x1), x2), min(max(y, y1), y2)
        if len(pts) > 1 and kind == "shimmy_line":  # (B47: the bar's nearest point, not its first end)
            (x1, y1), (x2, y2) = pts[0], pts[-1]
            lx, hx = min(x1, x2), max(x1, x2)
            px = min(max(x, lx), hx)
            py = y1 + (px - x1) / (x2 - x1) * (y2 - y1) if x2 != x1 else y1
            return px, py - 192  # (where he hangs: 3 tiles under it)
        if len(pts) > 1 and kind != "swing_point":
            (x1, y1), (x2, y2) = pts[0], pts[-1]
            lo, hi = min(y1, y2), max(y1, y2)
            return pts[0][0], min(max(y, lo), hi)
        return pts[0]
    w = walls[int(node[1:])]
    return w[1], min(max(y, w[2]), w[3])


def target_name(node, surfaces, features, walls):
    if node[0] == "s":
        return "a floor"
    if node[0] in "fp":
        kind, _ = features[int(node[1:].rstrip("LR"))]
        side = {"L": ", its left side", "R": ", its right side"}.get(node[-1], "") if node[0] == "p" else ""
        return KIND_NAMES.get(kind, kind) + side
    return "a climbable wall"


def tiles(v):
    n = int(round(abs(v) / TILE))
    return "%d tile%s" % (n, "" if n == 1 else "s")


def describe(step, prev_x, surfaces, features, walls):
    """One move in player terms: 'wall jump left onto a swing point, 10 tiles left, 4 up'."""
    frm, to, move, x, y, side = step
    base = move.rstrip("!")
    tx, ty = target_point(to, x, y, surfaces, features, walls)
    dx, dy = tx - x, ty - y
    walk = ""
    if frm[0] == "s" and prev_x is not None and abs(x - prev_x) >= TILE:
        walk = "walk %s %s, then " % (tiles(x - prev_x), "right" if x > prev_x else "left")
    where = []
    if abs(dx) >= TILE / 2:
        where.append("%s %s" % (tiles(dx), "right" if dx > 0 else "left"))
    if abs(dy) >= TILE / 2:
        where.append("%s %s" % (tiles(dy), "up" if dy > 0 else "down"))
    facing = "" if base in ("climb", "climb_over", "climb_down", "slide_down", "run_up_wall", "climb_up", "switch_sides",
                            "drop_through", "shimmy_along") else (" facing right" if side == "R" else " facing left")
    return "%s%s%s onto %s%s" % (walk, NAMES.get(base, base), facing, target_name(to, surfaces, features, walls),
                                 (", " + ", ".join(where)) if where else "")


def leg_routes(level):
    """[(checkpoint from, checkpoint to, the route's steps)] for every leg of the level (as path_check --all)."""
    every = path_check.load(level)[3]
    checkpoints = [c for c in every if not c[7].startswith("goal ")]
    legs = list(zip(checkpoints, checkpoints[1:]))
    legs += [(checkpoints[g[0]], g) for g in every if g[7].startswith("goal ")]
    out = []
    for a, b in legs:
        with contextlib.redirect_stdout(io.StringIO()):
            try:
                r = path_check.main(["", level, str(a[1]), str(a[2]), b[7]])
            except Exception:
                r = 2
        if r == 0:
            out.append((a, b, list(path_check.LAST_ROUTE)))
    return out


def corpus_trouble(level):
    """Launch spots in this level with trouble in the corpus: [(x, y, what)]."""
    spots = []
    mj = os.path.join(MOVES, "movements.json")
    if os.path.exists(mj):
        for r in json.load(open(mj, encoding="utf-8")):
            if r.get("level") == level and r["end"].get("how") == "death" and "x0" in r:
                spots.append((r["x0"], r["y0"], "a real death"))
    ck = os.path.join(MOVES, "check.txt")
    if os.path.exists(ck):
        keys = {}
        mt = os.path.join(MOVES, "movements.txt")
        for line in open(mt, encoding="utf-8"):
            f = line.split()
            if f and f[0] == "m" and f[2] == level:
                keys[f[1]] = (float(f[4]), float(f[5]))
        for line in open(ck, encoding="utf-8"):
            f = line.split()
            if not f or f[0] != "mv" or f[1] not in keys:
                continue
            x, y = keys[f[1]]
            if len(f) > 7 and f[7] == "FALSE":
                spots.append((x, y, "a false catch"))
            if f[6] == "broken":
                spots.append((x, y, "a chirp that didn't get him there"))
            if f[4] == "MISS":
                spots.append((x, y, "a real move the model can't do"))
    return spots


def chapters(level):
    """The game's chapter names for the level's checkpoints (geometry `chapter <checkpoint> <name>` lines): what the player
    sees (the level select, Go to checkpoint), not our file names (campaign_2c_redlight is "Venom of the Vipers")."""
    out = []
    for f in path_check.section(os.path.join(LEVELS, "shank_access_geometry.txt"), level):
        if f[0] == "chapter":
            out.append((int(f[1]), " ".join(f[2:])))
    return sorted(out)


def chapter_of(chs, order):
    name = ""
    for start, n in chs:
        if start <= order:
            name = n
    return name


def walk_windows(level):
    """B46: the walk-offs' speed windows from the paths file: (from, to) -> (lowest, highest, how many of 22)."""
    out = {}
    for f in path_check.section(os.path.join(LEVELS, "shank_access_paths.txt"), level):
        if f[0] == "edge" and f[3] == "walk_off" and len(f) >= 15 and f[11] == "v":
            out[(f[1], f[2])] = (float(f[12]), float(f[13]), int(f[14]))
    return out


def risks(step, surfaces, features, walls, geo, trouble, windows=None):
    frm, to, move, x, y, side = step
    base = move.rstrip("!")
    why = []
    w = (windows or {}).get((frm, to))
    if base == "walk_off" and w and 0 < w[2] < 5:  # (B47c-2: 4 samples, 96 px/s, counts too)
        # B46 (the user: "Any walk off that only works at one specific speed should be considered extremely risky")
        why.append("EXTREMELY RISKY: a walk-off that works at one speed only (%s)" % (
            "a slow step off" if w[1] <= 224 else "a full sprint" if w[0] >= 704 else
            "about %d tiles a second" % round((w[0] + w[1]) / 2 / TILE)))
    elif move.endswith("!"):
        why.append("one spot only (a narrow window)")
    if to[0] == "s" and base not in ("climb", "climb_over", "run_up_wall", "climb_up"):
        s = next((s for s in geo["surfaces"] if "s%d" % s["id"] == to), None)
        if s and s["points"][-1][0] - s["points"][0][0] < 4 * TILE and (s["left"].get("deadly") or s["right"].get("deadly")):
            why.append("a small floor with a deadly edge")
    if base in ("drop", "walk_off", "slide_off"):
        tx, ty = target_point(to, x, y, surfaces, features, walls)
        if y - ty >= 10 * TILE:
            why.append("a long fall (%s)" % tiles(y - ty))
    if to[0] == "f":
        kind, pts = features[int(to[1:])]
        if kind in ("shimmy_line", "wallrun_zone"):
            tx, ty = target_point(to, x, y, surfaces, features, walls)
            ends = [pts[0][0], pts[-1][0]]
            # the side he comes from: the end nearer his start
            near_end = min(ends, key=lambda e: abs(e - x))
            reach_x = tx
            if abs(reach_x - near_end) < TILE and abs(x - near_end) <= abs(x - tx) + TILE:
                why.append("caught near its end")
    counts = {}
    for tx, ty, what in trouble:
        if math.hypot(tx - x, ty - y) <= 2 * TILE:
            counts[what] = counts.get(what, 0) + 1
    for what, n in sorted(counts.items()):
        why.append("%d× %s in the logs" % (n, what))
    return why


def level_report(level):
    surfaces, features, walls, _, _ = path_check.load(level)
    gpath = os.path.join(LEVELS, level + ".geometry.json")
    geo = json.load(open(gpath, encoding="utf-8")) if os.path.exists(gpath) else {"surfaces": []}
    trouble = corpus_trouble(level)
    windows = walk_windows(level)
    chs = chapters(level)
    lines, n = [], 0
    seen = set()
    for a, b, route in leg_routes(level):
        found = []
        for k, st in enumerate(route):
            why = risks(st, surfaces, features, walls, geo, trouble, windows)
            key = (st[0], st[1], st[2])
            if why and key not in seen:
                seen.add(key)
                found.append((k, why))
        if not found:
            continue
        lines.append("  %s, checkpoint \"%s\" -> \"%s\":" % (chapter_of(chs, a[0]), a[7], b[7]))
        for k, why in found:
            n += 1
            lines.append("    risky move %d of %d: %s  [%s]" % (k + 1, len(route), "; ".join(why),
                                                                "%s at (%.0f, %.0f)" % (route[k][2].rstrip("!"), route[k][3], route[k][4])))
            prev_x = a[1]
            for j in range(k + 1):
                lines.append("      %d. %s" % (j + 1, describe(route[j], prev_x, surfaces, features, walls)))
                prev_x = target_point(route[j][1], route[j][3], route[j][4], surfaces, features, walls)[0]
    return n, lines


def main(argv):
    levels = [l.strip()[1:-1] for l in open(os.path.join(LEVELS, "shank_access_geometry.txt"), encoding="utf-8") if l.startswith("[")]
    if argv:
        levels = [l for l in levels if argv[0] in l]
    out = ["# B42-4 risky moves on the checkpoint routes (tools/levels/risky_moves.py; derived, never commit)",
           "# Each: why, then the directions from the checkpoint (Go to checkpoint), move by move."]
    summary = []
    for level in levels:
        n, lines = level_report(level)
        extreme = sum(1 for l in lines if "EXTREMELY RISKY" in l)
        summary.append("%-28s %3d risky move(s)%s" % (level, n, (", %d extremely" % extreme) if extreme else ""))
        out.append("")
        out.append("[%s: %s] %d risky move(s)" % (level, " / ".join(c[1] for c in chapters(level)), n))
        out.extend(lines)
    path = os.path.join(LEVELS, "risky_moves.txt" if not argv else "risky_moves_%s.txt" % argv[0])
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")
    print("\n".join(summary))
    print("written:", path)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
