#pragma once
// B10 waypoint mode: the traversal graph of each level (bin/shank_access_paths.txt, generated offline by
// native/tests/path_graph.cpp from the level geometry and the jump model) and shortest paths through it.
// Places: floors "s<id>", features "f<index>", pole sides "p<index>L" / "p<index>R", climbable walls "w<index>"
// (indices as in level_geometry's Features() / Walls()). A move: "edge <from> <to> <move> <x> <y> <R|L>".
#include <limits>
#include <set>
#include <string>
#include <vector>

namespace pathing {

struct Step {
    std::string from, to, move;  // move: long_jump, swing_jump, drop, run_up_wall, climb, bounce, ...
    float x = 0, y = 0;          // where it starts (a spot the model found it works from)
    bool right = true;           // facing / jumping this way
    float x_lo = 0, x_hi = 0, y_lo = 0, y_hi = 0;  // B10b: the range of spots it was found from (default: x, y)
    // B46: a walk-off's speeds off the edge that reach (px/s; v_n of the 22 tried from a tap, 96, to a sprint, 768; 0 = not
    // known). Under kWalkOffWindowSamples of them: it works at one speed only (OneSpeedWalkOff).
    float v_lo = 0, v_hi = 0;
    int v_n = 0;
    // B47c-7: onto a slide pole: the highest he catches it (he only slides down from there); < 0 = not a slide pole arrival
    float catch_y = -1.f;
};
// (B47c-2, the user, 4-a: "needs a jump at that death. walking doesn't reach": s47 -> p24L worked at 672..768 only, 4
// samples, and he walked off at ~560: under 5 now)
constexpr float kSlideCatchSlackPx = 32.f;  // B47c-7: a move off a slide pole up to this far above where he caught it
constexpr int kWalkOffWindowSamples = 5;  // 5 x 32 px/s = a window under 160 px/s (2.5 tiles a second)
inline bool OneSpeedWalkOff(const Step& s) { return s.move == "walk_off" && s.v_n > 0 && s.v_n < kWalkOffWindowSamples; }

size_t Load(const std::wstring& path);
size_t LoadFromString(const std::string& text);
bool SetLevel(const std::string& game_name);  // as level_geometry::SetLevel

// The shortest path (fewest jumps; moves on foot count half) from `from` to any of `goals`; empty if none, or if
// `from` is a goal.
// B27-3: from_x = his x on the start floor (NaN: unknown); walking along floors then costs kWalkPxPerCost px per unit.
// B47c-7: from_c = his height when he starts on a slide pole (-1: not on one): no move off it from higher up.
std::vector<Step> Path(const std::string& from, const std::set<std::string>& goals,
                       float from_x = std::numeric_limits<float>::quiet_NaN(), float from_c = -1.f);
constexpr float kWalkPxPerCost = 40 * 64.f;  // 40 tiles walked = one jump
bool HasNode(const std::string& node);

// Spoken name of a move: "long jump", "run up the wall", "climb", "bounce off the wall", ...
std::string MoveName(const std::string& move);
bool OnFootMove(const std::string& move);  // no jump needed (climbing, walking off, sliding off ...)

}  // namespace pathing
