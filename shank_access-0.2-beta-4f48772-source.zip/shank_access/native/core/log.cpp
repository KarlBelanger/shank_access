#include "log.h"

#include <windows.h>



#include <cstdarg>
#include <cstdio>
#include <share.h>

namespace alog {
namespace {
FILE* g_file = nullptr;
SRWLOCK g_lock = SRWLOCK_INIT;
}  // namespace

void Open(const wchar_t* path) {
    AcquireSRWLockExclusive(&g_lock);
    // Share for reading (_SH_DENYWR) so the log can be read live while the game runs. Note:
    // _wfopen_s opens files unshared, which locked the 1b-1 build's log until the game exited.
    if (!g_file) g_file = _wfsopen(path, L"w", _SH_DENYWR);
    ReleaseSRWLockExclusive(&g_lock);
}

void Write(const char* fmt, ...) {
    char msg[1024];
    va_list args;
    va_start(args, fmt);
    vsnprintf(msg, sizeof msg, fmt, args);
    va_end(args);

    SYSTEMTIME t;
    GetLocalTime(&t);
    AcquireSRWLockExclusive(&g_lock);
    if (g_file) {
        fprintf(g_file, "[%02u:%02u:%02u.%03u] %s\n", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds, msg);
        fflush(g_file);
    }
    ReleaseSRWLockExclusive(&g_lock);
}

}  // namespace alog
