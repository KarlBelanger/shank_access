"""Look up Shank's FMOD sounds: event -> sound definition -> wave file -> sample format.

Usage (repo root):
  .venv/Scripts/python tools/re/sounds.py EVENT_OR_SUBSTRING [...]
  e.g.  tools/re/sounds.py pointOfInterest Uzi_Arm
Prints, for each matching sound definition in shank.fev, the wave files it plays, and each
file's channel count, sample rate and duration from the FSB4 banks. Useful when choosing
game sounds for cues (e.g. to prefer in-world events over GUI ones).
The FEV is only scanned for strings, not fully parsed: the definition -> wave link relies
on the wave names directly following the definition path, which held for every case checked.
"""
import os
import re
import struct
import sys

SOUND_DIR = os.path.join(os.environ.get("SHANK_GAME_DIR", r"C:/Program Files (x86)/Steam/steamapps/common/Shank"),
                         "data-pc", "bootstrap", "sound")


def fsb4_samples(path):
    """{sample name: (channels, freq_hz, seconds)} from an FSB4 bank's sample headers."""
    with open(path, "rb") as f:
        head = f.read(48)
        magic, n, shdr_size = struct.unpack_from("<4sII", head, 0)
        if magic != b"FSB4":
            raise ValueError("%s: not FSB4" % path)
        d = f.read(shdr_size)
    out, o = {}, 0
    for _ in range(n):
        size = struct.unpack_from("<H", d, o)[0]
        name = d[o + 2:o + 32].split(b"\0")[0].decode("latin-1")
        length, _comp, _ls, _le, _mode, freq = struct.unpack_from("<IIIIIi", d, o + 32)
        channels = struct.unpack_from("<H", d, o + 62)[0]
        out[name] = (channels, freq, length / freq if freq else 0.0)
        o += size
    return out


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1
    with open(os.path.join(SOUND_DIR, "shank.fev"), "rb") as f:
        fev = f.read()
    toks = [m.group().decode("latin-1") for m in re.finditer(rb"[\x20-\x7e]{3,}", fev)]
    banks = {}
    for bank in ("effects.fsb", "streaming_bank.fsb"):
        for name, info in fsb4_samples(os.path.join(SOUND_DIR, bank)).items():
            banks[name.lower()] = (bank, info)
    for query in argv[1:]:
        hits = [i for i, t in enumerate(toks) if t.startswith("/") and query.lower() in t.lower()]
        if not hits:
            print("%s: no sound definition found" % query)
        for i in hits:
            print(toks[i])
            j = i + 1
            while j < len(toks) and not toks[j].startswith("/"):
                t = toks[j]
                if re.search(r"\.(wav|ogg|mp3|aif+)$", t, re.I):
                    base = t.replace("\\", "/").split("/")[-1]
                    bank, (ch, freq, secs) = banks.get(base.lower()[:29], banks.get(base.lower(), ("?", (0, 0, 0))))
                    print("    %-50s %s  %s  %d Hz  %.2f s" % (t, bank, "mono" if ch == 1 else "stereo" if ch == 2 else "ch=%s" % ch, freq, secs))
                j += 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
