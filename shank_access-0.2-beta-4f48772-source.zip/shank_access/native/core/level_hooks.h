#pragma once
// B4 G4: tells the mod which level just loaded. Hooks LevelData::LoadSimData (0x495e30, the .slev
// collision loader); after the game's own load it asks the level for its name (0x4323e0) and passes it
// to the listener (game thread). The game behaves exactly as before.
namespace level_hooks {

using LevelListener = void (*)(const char* name);
void SetListener(LevelListener listener);

// B5-2: arena bounds. The bounds action (cSetBoundsAction::Execute 0x4eb940) is hooked to learn the
// simulation object that holds the current bounds; after that they're read directly (any thread), so
// every later change counts (checkpoint restores too). Unknown until the first bounds action of a level.
struct Bounds {
    bool known = false;
    float min_x = 0, min_y = 0, max_x = 0, max_y = 0;
    bool is_default = false;  // the level's default bounds (no arena in force)
};
Bounds CurrentBounds();
void ForgetBounds();  // a level load: the old simulation may be gone
void* Simulation();   // B34: the simulation learnt from the bounds action (nullptr until then)

// Checks the loader's first bytes, then hooks it. False (logged) if anything doesn't match.
bool Install();

// For native/tests: hooks a stand-in loader and name getter of the same conventions, no byte check.
bool InstallAt(unsigned load_sim_data, unsigned level_name, unsigned set_bounds_execute = 0);

}  // namespace level_hooks
