// Host-side test of the level geometry queries (never deployed). With a path argument it also loads the
// real generated file (build/levels/shank_access_geometry.txt) and checks known spots in level 1-a
// (B3c log: Shank at y 224 on the floor at 192; the step at x 2816, the drop at 3200, the wall at 7296).
// Exit 0 = pass.
#include <windows.h>

#include <cmath>
#include <cstdio>
#include <string>

#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

bool Near(float a, float b) { return std::fabs(a - b) < 0.5f; }

}  // namespace

int main(int argc, char** argv) {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_level_geometry_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    const std::string text =
        "# test\n"
        "[levelA]\n"
        "surface 0 - wall 128 0 drop 128 0 3 0 192 1000 192 1500 320\n"   // a floor, then a slope up
        "surface 1 skinny drop -1 1 step 64 0 2 2000 192 2600 192\n"
        "feature swing_point 1 1800 900\n"
        "feature pole 2 2500 300 2500 900\n"
        "[levelB]\n"
        "surface 0 - wall 64 0 wall 64 0 2 0 0 100 0\n";
    Check(level_geometry::LoadFromString(text) == 2, "two levels");
    Check(level_geometry::SurfaceUnder(500, 224) == nullptr, "no level selected: nothing");
    Check(level_geometry::SetLevel("levels/levelA/levelA.slev"), "level chosen by the game's path");
    Check(!level_geometry::SetLevel("nope"), "unknown level");
    level_geometry::SetLevel("levelA");
    const level_geometry::Surface* s = level_geometry::SurfaceUnder(500, 224);
    Check(s && s->id == 0, "standing on the floor (feet = y - 32)");
    Check(level_geometry::SurfaceUnder(500, 300) == nullptr, "well above the floor: in the air");
    s = level_geometry::SurfaceUnder(1250, 256 + 32);
    Check(s && s->id == 0, "on the slope");
    level_geometry::Ahead a = level_geometry::EdgeAhead(500, 224, true);
    Check(a.found && Near(a.distance, 1000) && a.end.type == level_geometry::End::kDrop && Near(a.end.value, 128),
          "facing right: the drop at the far end of the slope");
    a = level_geometry::EdgeAhead(500, 224, false);
    Check(a.found && Near(a.distance, 500) && a.end.type == level_geometry::End::kWall, "facing left: the wall");
    a = level_geometry::EdgeAhead(2100, 224, false);
    Check(a.found && a.end.deadly && a.end.value < 0, "deadly drop into nothing");
    Check(s && level_geometry::SurfaceUnder(2100, 224)->tags == "skinny", "tags");
    a = level_geometry::EdgeAhead(1800, 1500, true);
    Check(!a.found, "in the air: no edge");
    Check(level_geometry::Features().size() == 2 && level_geometry::Features()[1].type == "pole", "features");
    level_geometry::SetLevel("levelB");
    Check(level_geometry::Features().empty(), "features per level");

    if (argc > 1) {
        wchar_t wpath[MAX_PATH];
        MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wpath, MAX_PATH);
        Check(level_geometry::Load(wpath) >= 10, "real file: every campaign level");
        Check(level_geometry::SetLevel("campaign_1a_wrestlingring"), "real file: 1-a");
        a = level_geometry::EdgeAhead(2560, 224, true);  // B3c: Shank at (2560, 224) facing right
        Check(a.found && Near(a.end_x, 2816) && a.end.type == level_geometry::End::kWall && Near(a.end.value, 128),
              "1-a: the 2-tile step at x 2816");
        a = level_geometry::EdgeAhead(3100, 352, true);
        Check(a.found && Near(a.distance, 100) && a.end.type == level_geometry::End::kDrop && Near(a.end.value, 128) &&
                  !a.end.deadly, "1-a: the safe 2-tile drop at x 3200");
        a = level_geometry::EdgeAhead(5951, 224, false);  // B3c's false edge at 5704
        Check(a.found && Near(a.end_x, 3200), "1-a: heading left from 5951 the floor runs on to x 3200");
        a = level_geometry::EdgeAhead(7046, 224, true);
        Check(a.found && Near(a.end_x, 7296) && a.end.type == level_geometry::End::kWall, "1-a: the wall at x 7296");
        a = level_geometry::EdgeAhead(2560, 224, true);
        Check(a.end.climbable, "1-a: the step at x 2816 is climbable");
        // 1-c: the street's end wall at x 5376 is climbable from y 384 to 1600, then noclimb to 1792.
        Check(level_geometry::SetLevel("campaign_1c_meatpacking"), "real file: 1-c");
        const level_geometry::Wall* w = level_geometry::WallBeside(5376 - 32, 1000);
        Check(w && Near(w->x, 5376) && w->climbable && w->faces_left, "1-c: clinging to the end wall");
        Check(!level_geometry::WallBeside(5376 - 32, 1700), "1-c: the noclimb stretch at the top: not a wall to cling to");
        Check(!level_geometry::WallBeside(5376 - 200, 1000), "1-c: 200 px away: not clinging");
        Check(level_geometry::Walls().size() > 20, "1-c: walls listed");
        // B6-4: with the real walls, ceilings and floors blocking, the jumps the user made still count.
        Check(level_geometry::Obstacles().size() > 100, "1-c: obstacles built");
        jump_model::SetObstacles(&level_geometry::Obstacles());
        const jump_model::Target swing1{jump_model::kSwing, 4725.5f, 1044.6f, 0, 0};
        const jump_model::Target swing2{jump_model::kSwing, 4109.9f, 1158.3f, 0, 0};
        Check(jump_model::ReachFromWall(swing1, 5344, 1082, false) == jump_model::kWallJump,
              "1-c (blocking on): the wall jump from y 1082 to swing point 1");
        Check(jump_model::ReachFromSwing(swing2, 4670, 955, false) == jump_model::kSwingJump,
              "1-c (blocking on): swing 1 to swing 2");
        const jump_model::Target zone{jump_model::kWallZone, 1477.94f, 2939.28f, 2545.94f, 3343.28f};
        Check(jump_model::ReachFromPole(zone, 2849.9f, 3553.f, false) == jump_model::kPoleJump,
              "1-c (blocking on): the pole top (left side) to the wall-climb zone");
        const jump_model::Target platform{jump_model::kLanding, 2624, 3904, 3328, 3904};
        // (B41-4: with the pull-up, over it, as the B5 log shows: jump_model_test)
        Check(jump_model::ReachFromBar(platform, 2601, 3996, true) != jump_model::kBarJump,
              "1-c (blocking on): off the bar's end: over the platform (the B5 log)");
        const jump_model::Target pole{jump_model::kPole, 2929.94f, 1481.f, 2929.94f, 3557.57f};
        Check(jump_model::Reach(pole, 2640, 1952, true) != jump_model::kNone,
              "1-c (blocking on): from the ledge at y 1920 onto the pole");
        // Through the pillar (walls x 3200/3264, y 1856..3840): from the pole's right side, the wall-run zone
        // on the far side (3500..4568, y 3977+) can't be reached by going through it.
        const jump_model::Target zone2{jump_model::kWallZone, 3499.94f, 3977.28f, 4567.94f, 4381.28f};
        Check(jump_model::ReachFromPole(zone2, 3009.9f, 3000, true) == jump_model::kNone,
              "1-c (blocking on): not through the pillar");
        // B10-1: checkpoints in play order, with their trigger rectangles.
        level_geometry::SetLevel("campaign_1c_meatpacking");
        const auto& cps = level_geometry::Checkpoints();
        Check(cps.size() == 9 && cps[0].name == "Level Start" && !cps[0].has_region, "1-c: 9 checkpoints, from Level Start");
        Check(cps.size() > 1 && cps[1].name == "Enter Packing Warehouse" && cps[1].has_region && Near(cps[1].rx, 4928) &&
                  Near(cps[1].rh, 904) && Near(cps[1].spawn_x, 5285),
              "1-c: the next is Enter Packing Warehouse, its trigger at x 4928");
        Check(cps.size() == 9 && cps[8].name == "Enter Butcher Fight", "1-c: the last is Enter Butcher Fight");
        // B6-2: 1-a's wall run (zone x 26428..27612, y 2286..2600) over the pit (x 26049..28557): falling off
        // its right end at running speed doesn't make the far side.
        level_geometry::SetLevel("campaign_1a_wrestlingring");
        jump_model::SetObstacles(&level_geometry::Obstacles());
        Check(!level_geometry::Pits().empty(), "1-a: pit zones loaded");
        float lx = 0, ly = 0;
        const bool lands = jump_model::Land(27612, 2450, 768, 0, &lx, &ly);
        printf("  (1-a run end: lands %d at (%.0f, %.0f))\n", lands, lx, ly);
        Check(!lands || level_geometry::PitAcross(lx, 2450, ly - 32), "1-a: off the wall run's end: deadly");
        jump_model::SetObstacles(nullptr);
    }
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
