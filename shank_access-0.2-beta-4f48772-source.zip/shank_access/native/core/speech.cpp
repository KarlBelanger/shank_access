#include "speech.h"

#include <windows.h>
#include <sapi.h>

#include <deque>
#include <memory>

#include "log.h"
#include "mod_state.h"

namespace speech {
namespace {

std::wstring Widen(const std::string& utf8) {
    if (utf8.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), nullptr, 0);
    std::wstring out(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), out.data(), n);
    return out;
}

std::string Narrow(const wchar_t* w) {
    if (!w) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr);
    std::string out(n > 0 ? n - 1 : 0, '\0');
    if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w, -1, out.data(), n, nullptr, nullptr);
    return out;
}

// Tolk (LGPL-3.0), loaded dynamically so a missing Tolk.dll only disables screen reader speech.
class TolkSpeech {
public:
    explicit TolkSpeech(std::wstring dir) : dir_(std::move(dir)) {}

    bool Init() {
        dll_ = LoadLibraryW((dir_ + L"\\Tolk.dll").c_str());
        if (!dll_) {
            alog::Write("speech: Tolk.dll not loaded (error %lu)", GetLastError());
            return false;
        }
        load_ = reinterpret_cast<void(__cdecl*)()>(GetProcAddress(dll_, "Tolk_Load"));
        try_sapi_ = reinterpret_cast<void(__cdecl*)(bool)>(GetProcAddress(dll_, "Tolk_TrySAPI"));
        detect_ = reinterpret_cast<const wchar_t*(__cdecl*)()>(GetProcAddress(dll_, "Tolk_DetectScreenReader"));
        output_ = reinterpret_cast<bool(__cdecl*)(const wchar_t*, bool)>(GetProcAddress(dll_, "Tolk_Output"));
        if (!load_ || !output_) {
            alog::Write("speech: Tolk.dll is missing expected exports");
            return false;
        }
        if (try_sapi_) try_sapi_(true);  // fall back to SAPI when no screen reader is running
        load_();                          // initialises COM on this (the speech) thread
        return true;
    }

    void Output(const std::wstring& text, bool interrupt) {
        if (!output_(text.c_str(), interrupt)) alog::Write("speech: Tolk_Output failed (no screen reader or SAPI?)");
    }

    std::string Describe() {
        const wchar_t* sr = detect_ ? detect_() : nullptr;
        return "Tolk: " + (sr ? Narrow(sr) : std::string("no screen reader detected (SAPI fallback)"));
    }

private:
    std::wstring dir_;
    HMODULE dll_ = nullptr;
    void(__cdecl* load_)() = nullptr;
    void(__cdecl* try_sapi_)(bool) = nullptr;
    const wchar_t*(__cdecl* detect_)() = nullptr;
    bool(__cdecl* output_)(const wchar_t*, bool) = nullptr;
};

// B16: our own SAPI voice (Tolk's SAPI driver has no voice / rate / volume). Speech-thread only.
class SapiSpeech {
public:
    ~SapiSpeech() {
        for (ISpObjectToken* t : tokens_) t->Release();
        if (voice_) voice_->Release();
    }

    bool Init() {
        if (FAILED(CoCreateInstance(CLSID_SpVoice, nullptr, CLSCTX_INPROC_SERVER, IID_ISpVoice, reinterpret_cast<void**>(&voice_)))) {
            alog::Write("speech: SAPI voice not created");
            voice_ = nullptr;
            return false;
        }
        ISpObjectTokenCategory* cat = nullptr;
        if (SUCCEEDED(CoCreateInstance(CLSID_SpObjectTokenCategory, nullptr, CLSCTX_INPROC_SERVER, IID_ISpObjectTokenCategory,
                                       reinterpret_cast<void**>(&cat))) &&
            SUCCEEDED(cat->SetId(SPCAT_VOICES, FALSE))) {
            IEnumSpObjectTokens* en = nullptr;
            if (SUCCEEDED(cat->EnumTokens(nullptr, nullptr, &en))) {
                ISpObjectToken* tok = nullptr;
                while (en->Next(1, &tok, nullptr) == S_OK) {
                    wchar_t* desc = nullptr;
                    if (SUCCEEDED(tok->GetStringValue(nullptr, &desc)) && desc) {
                        names_.push_back(Narrow(desc));
                        tokens_.push_back(tok);
                        CoTaskMemFree(desc);
                    } else {
                        tok->Release();
                    }
                }
                en->Release();
            }
        }
        if (cat) cat->Release();
        return true;
    }

    const std::vector<std::string>& Names() const { return names_; }

    void Apply(const std::string& voice, int rate, int volume) {
        if (!voice_) return;
        if (voice != applied_voice_) {
            ISpObjectToken* tok = nullptr;
            for (size_t i = 0; i < names_.size(); ++i) {
                if (names_[i] == voice) tok = tokens_[i];
            }
            voice_->SetVoice(tok);  // nullptr = the default voice
            applied_voice_ = voice;
        }
        voice_->SetRate(rate);
        voice_->SetVolume(static_cast<USHORT>(volume));
    }

    void Speak(const std::wstring& text, bool interrupt) {
        if (!voice_) return;
        DWORD flags = SPF_ASYNC | SPF_IS_NOT_XML;
        if (interrupt) flags |= SPF_PURGEBEFORESPEAK;
        voice_->Speak(text.c_str(), flags, nullptr);
    }

    void WaitDone(unsigned ms) {
        if (voice_) voice_->WaitUntilDone(ms);
    }

    bool Ok() const { return voice_ != nullptr; }

private:
    ISpVoice* voice_ = nullptr;
    std::vector<std::string> names_;
    std::vector<ISpObjectToken*> tokens_;
    std::string applied_voice_ = "\x01";  // (nothing applied yet)
};

struct Message {
    std::wstring text;
    bool interrupt;
    int target;             // B16: 0 screen reader, 1 SAPI (the channel's engine when queued), 2 SAPI sample
    HANDLE done = nullptr;  // signalled once the text has been handed to the backend (SayFinal)
};

SRWLOCK g_lock = SRWLOCK_INIT;
CONDITION_VARIABLE g_cv = CONDITION_VARIABLE_INIT;
std::deque<Message> g_queue;
std::wstring g_last;
Channel g_last_channel = kStats;
bool g_started = false;
bool g_muted = false;  // set by SayFinal: nothing else is spoken
// B20-6 (the user: "the shank process hangs on exit, and I have to go into task manager"): never destroyed. As
// unique_ptrs, their destructors ran in our DLL's PROCESS_DETACH, under the loader lock after ExitProcess had killed
// every other thread, and ~SapiSpeech Released the SAPI voice there: COM teardown that can wait forever on threads that
// no longer exist. The process is ending; Windows reclaims all of it.
TolkSpeech* g_tolk = nullptr;
SapiSpeech* g_sapi = nullptr;
// B16 settings (under g_lock).
Engine g_engine[kChannelCount] = {kScreenReader, kScreenReader, kScreenReader};
std::string g_voice;
int g_rate = 0, g_volume = 100;
std::vector<std::string> g_voice_names;
bool g_sapi_ok = false;

DWORD WINAPI SpeechThread(LPVOID) {
    const bool ok = g_tolk->Init();
    alog::Write("speech: %s", ok ? g_tolk->Describe().c_str() : "screen reader output unavailable");
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);  // (Tolk did already if it loaded; harmless again)
    const bool sapi_ok = g_sapi->Init();
    AcquireSRWLockExclusive(&g_lock);
    g_voice_names = g_sapi->Names();
    g_sapi_ok = sapi_ok;
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("speech: our SAPI voice %s, %u voices installed", sapi_ok ? "ready" : "unavailable",
                static_cast<unsigned>(g_sapi->Names().size()));
    for (;;) {
        AcquireSRWLockExclusive(&g_lock);
        while (g_queue.empty()) SleepConditionVariableSRW(&g_cv, &g_lock, INFINITE, 0);
        Message m = std::move(g_queue.front());
        g_queue.pop_front();
        const std::string voice = g_voice;
        const int rate = g_rate, volume = g_volume;
        ReleaseSRWLockExclusive(&g_lock);
        const bool use_sapi = m.target != 0 && sapi_ok;
        if (use_sapi) {
            g_sapi->Apply(voice, rate, volume);
            g_sapi->Speak(m.text, m.interrupt);
            if (m.done) g_sapi->WaitDone(1500);  // (the final message: let it finish before the game exits)
        } else if (ok) {
            g_tolk->Output(m.text, m.interrupt);  // (also the fallback when SAPI didn't start)
        }
        if (m.done) SetEvent(m.done);
    }
}

void Enqueue(std::wstring text, bool interrupt, int target) {
    AcquireSRWLockExclusive(&g_lock);
    if (g_started && !g_muted) {
        g_queue.push_back({std::move(text), interrupt, target});
        WakeConditionVariable(&g_cv);
    }
    ReleaseSRWLockExclusive(&g_lock);
}

int TargetOf(Channel c) {  // call with g_lock held
    return c >= 0 && c < kChannelCount && g_engine[c] == kSapi ? 1 : 0;
}

const char* const kChannelNames[kChannelCount] = {"menu", "stats", "auto"};

}  // namespace

void Start(const std::wstring& dll_dir) {
    AcquireSRWLockExclusive(&g_lock);
    const bool first = !g_started;
    if (first) {
        g_tolk = new TolkSpeech(dll_dir);  // (B20-6: never deleted)
        g_sapi = new SapiSpeech();
        g_started = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (!first) return;
    if (HANDLE t = CreateThread(nullptr, 0, SpeechThread, nullptr, 0, nullptr)) CloseHandle(t);
}

void Say(const std::string& utf8, bool interrupt, Channel channel) {
    if (!mod_state::Active()) return;  // B38-3: the mod is off (F11)
    std::wstring text = Widen(utf8);
    AcquireSRWLockExclusive(&g_lock);
    g_last = text;
    g_last_channel = channel;
    const int target = TargetOf(channel);
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("say (%s%s): %s", kChannelNames[channel < kChannelCount ? channel : kStats], target ? ", SAPI" : "", utf8.c_str());
    Enqueue(std::move(text), interrupt, target);
}

namespace {

BOOL CALLBACK FindVisibleGameWindow(HWND w, LPARAM found) {
    DWORD pid = 0;
    GetWindowThreadProcessId(w, &pid);
    if (pid == GetCurrentProcessId() && IsWindowVisible(w)) {
        *reinterpret_cast<bool*>(found) = true;
        return FALSE;
    }
    return TRUE;
}

struct Deferred {
    std::string text;
    Channel channel;
};

DWORD WINAPI DeferredSayThread(LPVOID param) {
    std::unique_ptr<Deferred> d(static_cast<Deferred*>(param));
    for (int waited = 0; waited < 30000; waited += 100) {  // up to 30 s for the game window
        bool found = false;
        EnumWindows(FindVisibleGameWindow, reinterpret_cast<LPARAM>(&found));
        if (found) break;
        Sleep(100);
    }
    Sleep(1500);  // let the game finish opening its audio device
    Say(d->text, true, d->channel);
    return 0;
}

}  // namespace

void SayWhenGameReady(const std::string& utf8, Channel channel) {
    auto* d = new Deferred{utf8, channel};
    if (HANDLE t = CreateThread(nullptr, 0, DeferredSayThread, d, 0, nullptr)) {
        CloseHandle(t);
    } else {
        delete d;
        Say(utf8, true, channel);
    }
}

void SayFinal(const std::string& utf8, unsigned timeout_ms) {
    if (!mod_state::Active()) return;  // B38-3
    // The first call queues the message and mutes; any later call (the ExitProcess hook after the
    // Quit button already said it) only waits for that first message to reach the screen reader.
    // The event is never closed: this is the end of the process.
    static HANDLE s_final_done = nullptr;
    AcquireSRWLockExclusive(&g_lock);
    HANDLE wait_on = nullptr;
    bool first = false;
    if (!g_muted) {
        first = true;
        g_muted = true;
        if (g_started) {
            s_final_done = CreateEventW(nullptr, TRUE, FALSE, nullptr);
            if (s_final_done) {
                g_queue.clear();  // anything still waiting is stale now
                g_queue.push_back({Widen(utf8), true, TargetOf(kMenu), s_final_done});
                WakeConditionVariable(&g_cv);
            }
        }
    }
    wait_on = s_final_done;
    ReleaseSRWLockExclusive(&g_lock);
    if (first) alog::Write("say (final): %s", utf8.c_str());
    if (wait_on && timeout_ms) {
        const DWORD r = WaitForSingleObject(wait_on, timeout_ms);
        alog::Write("speech: final message %s", r == WAIT_OBJECT_0 ? "handed over" : "timed out");
    }
}

std::string Last() {
    AcquireSRWLockExclusive(&g_lock);
    const std::wstring text = g_last;
    ReleaseSRWLockExclusive(&g_lock);
    return Narrow(text.c_str());
}

void RepeatLast() {
    AcquireSRWLockExclusive(&g_lock);
    std::wstring text = g_last;
    const int target = TargetOf(g_last_channel);
    ReleaseSRWLockExclusive(&g_lock);
    if (!text.empty()) Enqueue(std::move(text), true, target);
}

void SetEngine(Channel channel, Engine engine) {
    if (channel < 0 || channel >= kChannelCount) return;
    AcquireSRWLockExclusive(&g_lock);
    g_engine[channel] = engine;
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("speech: %s channel -> %s", kChannelNames[channel], engine == kSapi ? "SAPI" : "screen reader");
}

Engine EngineOf(Channel channel) {
    AcquireSRWLockShared(&g_lock);
    const Engine e = channel >= 0 && channel < kChannelCount ? g_engine[channel] : kScreenReader;
    ReleaseSRWLockShared(&g_lock);
    return e;
}

std::vector<std::string> SapiVoices() {
    AcquireSRWLockShared(&g_lock);
    const std::vector<std::string> v = g_voice_names;
    ReleaseSRWLockShared(&g_lock);
    return v;
}

void SetSapiVoice(const std::string& name) {
    AcquireSRWLockExclusive(&g_lock);
    g_voice = name;
    ReleaseSRWLockExclusive(&g_lock);
}

std::string SapiVoice() {
    AcquireSRWLockShared(&g_lock);
    const std::string v = g_voice;
    ReleaseSRWLockShared(&g_lock);
    return v;
}

void SetSapiRate(int rate) {
    AcquireSRWLockExclusive(&g_lock);
    g_rate = rate < -10 ? -10 : (rate > 10 ? 10 : rate);
    ReleaseSRWLockExclusive(&g_lock);
}

int SapiRate() {
    AcquireSRWLockShared(&g_lock);
    const int r = g_rate;
    ReleaseSRWLockShared(&g_lock);
    return r;
}

void SetSapiVolume(int volume) {
    AcquireSRWLockExclusive(&g_lock);
    g_volume = volume < 0 ? 0 : (volume > 100 ? 100 : volume);
    ReleaseSRWLockExclusive(&g_lock);
}

int SapiVolume() {
    AcquireSRWLockShared(&g_lock);
    const int v = g_volume;
    ReleaseSRWLockShared(&g_lock);
    return v;
}

void SaySapiSample(const std::string& utf8) {
    alog::Write("say (SAPI sample): %s", utf8.c_str());
    Enqueue(Widen(utf8), true, 2);
}

bool SapiAvailable() {
    AcquireSRWLockShared(&g_lock);
    const bool ok = g_sapi_ok;
    ReleaseSRWLockShared(&g_lock);
    return ok;
}

}  // namespace speech
