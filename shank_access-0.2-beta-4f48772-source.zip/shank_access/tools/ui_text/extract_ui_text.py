"""Extract the static (drawn) text of Shank's UI files into a data file the mod reads at runtime.

Some screens draw their text as glyphs (SWF DefineText): the How to Play pages' explanations are
not in any text field, so the game's GetVariable can't read them (overnight test, 2026-09-26).
This tool decodes those glyph runs with the embedded fonts' code tables.

The output holds Klei text, so it goes to build/ (gitignored) and is deployed into the user's own
game folder by tools/deploy.py (mod/artifacts.json); it is never committed.

Usage (repo root):
  .venv/Scripts/python tools/ui_text/extract_ui_text.py [--game DIR] [--out FILE]

Output format (UTF-8), one section per .gfx file:
  [howtoplayscreencombos.gfx]
  key=Combos                      <- initial text of its editable text fields (e.g. the nameTxt page title)
  text=Juggle enemies by holding down and pressing attack
"""
import argparse
import glob
import os
import struct
import sys
import zlib

DEFAULT_GAME = r"C:\Program Files (x86)\Steam\steamapps\common\Shank"
DEFAULT_OUT = os.path.join(os.path.dirname(__file__), "..", "..", "build", "ui_text", "shank_access_ui_text.txt")
PLACEHOLDERS = {"textField", "Button", "button", "Button Label", "KButtonLabel360"}


class Bits:
    def __init__(self, data, byte_pos):
        self.d = data
        self.p = byte_pos * 8

    def u(self, n):
        v = 0
        for _ in range(n):
            v = (v << 1) | ((self.d[self.p >> 3] >> (7 - (self.p & 7))) & 1)
            self.p += 1
        return v

    def s(self, n):
        v = self.u(n)
        return v - (1 << n) if n and v & (1 << (n - 1)) else v

    def align(self):
        self.p = (self.p + 7) & ~7

    def byte(self):
        return self.p >> 3


def skip_rect(bits):
    n = bits.u(5)
    for _ in range(4):
        bits.s(n)
    bits.align()


def skip_matrix(bits):
    if bits.u(1):
        n = bits.u(5)
        bits.u(n)
        bits.u(n)
    if bits.u(1):
        n = bits.u(5)
        bits.u(n)
        bits.u(n)
    n = bits.u(5)
    bits.u(n)
    bits.u(n)
    bits.align()


def swf_body(path):
    """The uncompressed SWF data after the header, and the position of the first tag."""
    raw = open(path, "rb").read()
    data = zlib.decompress(raw[8:]) if raw[:3] in (b"CFX", b"CWS") else raw[8:]
    nbits = data[0] >> 3
    return data, (5 + 4 * nbits + 7) // 8 + 4


def parse(path):
    """Returns (keys, texts): editable-field initial texts and decoded static texts, in tag order."""
    data, pos = swf_body(path)
    fonts, texts, keys = {}, [], []

    def walk(pos, end, depth):
        while pos < end:
            v = struct.unpack_from("<H", data, pos)[0]
            pos += 2
            code, ln = v >> 6, v & 0x3F
            if ln == 0x3F:
                ln = struct.unpack_from("<I", data, pos)[0]
                pos += 4
            body = data[pos:pos + ln]
            if code in (48, 75):  # DefineFont2 / DefineFont3: glyph index -> character code
                fid, flags = struct.unpack_from("<HB", body, 0)
                p = 5 + body[4]
                count = struct.unpack_from("<H", body, p)[0]
                p += 2
                codes = []
                if count:
                    if flags & 0x08:
                        code_off = struct.unpack_from("<I", body, p + 4 * count)[0]
                    else:
                        code_off = struct.unpack_from("<H", body, p + 2 * count)[0]
                    cp = p + code_off
                    if flags & 0x04:
                        codes = [struct.unpack_from("<H", body, cp + 2 * i)[0] for i in range(count)]
                    else:
                        codes = list(body[cp:cp + count])
                fonts[fid] = codes
            elif code in (11, 33):  # DefineText / DefineText2
                bits = Bits(body, 2)
                skip_rect(bits)
                skip_matrix(bits)
                p = bits.byte()
                gbits, abits = body[p], body[p + 1]
                p += 2
                font, chars = None, []
                while p < len(body):
                    flags = body[p]
                    p += 1
                    if flags == 0:
                        break
                    if flags & 0x08:
                        font = struct.unpack_from("<H", body, p)[0]
                        p += 2
                    if flags & 0x04:
                        p += 4 if code == 33 else 3
                    if flags & 0x01:
                        p += 2
                    if flags & 0x02:
                        p += 2
                    if flags & 0x08:
                        p += 2
                    n = body[p]
                    p += 1
                    bb = Bits(body, p)
                    table = fonts.get(font, [])
                    for _ in range(n):
                        g = bb.u(gbits)
                        bb.u(abits)
                        chars.append(chr(table[g]) if g < len(table) else "")
                    bb.align()
                    p = bb.byte()
                texts.append("".join(chars).strip())
            elif code == 37:  # DefineEditText: keep the initial text (e.g. a page title)
                bits = Bits(body, 2)
                skip_rect(bits)
                p = bits.byte()
                f1, f2 = body[p], body[p + 1]
                p += 2
                if f1 & 0x01:
                    p += 2
                if f2 & 0x80:
                    p = body.index(b"\0", p) + 1
                if f1 & 0x01:
                    p += 2
                if f1 & 0x04:
                    p += 4
                if f1 & 0x02:
                    p += 2
                if f2 & 0x20:
                    p += 9
                p = body.index(b"\0", p) + 1  # variable name
                if f1 & 0x80:
                    e = body.index(b"\0", p)
                    t = body[p:e].decode("utf-8", "replace").strip()
                    if t and t not in PLACEHOLDERS:
                        keys.append(t)
            elif code == 39:  # DefineSprite: nested tags
                walk(pos + 4, pos + ln, depth + 1)
            pos += ln
            if code == 0 and depth > 0:
                break

    walk(pos, len(data), 0)
    return keys, texts


def meaningful(text):
    """Drop fragments: separators and single characters."""
    return sum(ch.isalpha() for ch in text) >= 2


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument("--game", default=DEFAULT_GAME)
    ap.add_argument("--out", default=DEFAULT_OUT)
    args = ap.parse_args(argv)
    files = sorted(glob.glob(os.path.join(args.game, "data*", "ui", "*.gfx")))
    if not files:
        print("no .gfx files under", args.game)
        return 1
    lines = ["# Generated by tools/ui_text/extract_ui_text.py from the game's own UI files. Local only: never commit."]
    sections = 0
    for path in files:
        try:
            keys, texts = parse(path)
        except Exception as e:  # a file we can't parse is skipped, not fatal
            print("skipped", os.path.basename(path), e)
            continue
        texts = [t for t in texts if meaningful(t)]
        if not texts:
            continue
        sections += 1
        lines.append("[%s]" % os.path.basename(path).lower())
        lines += ["key=" + k for k in keys]
        lines += ["text=" + t for t in texts]
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print("wrote", os.path.abspath(args.out), "with", sections, "sections")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
