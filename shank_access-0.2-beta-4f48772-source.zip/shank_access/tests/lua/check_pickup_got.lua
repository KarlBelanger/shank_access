-- Run by tools/loadtest50.py after loading a pickup stategraph (Lua 5.0).
-- Asserts that exactly one PlaySound("a11y/got_<kind>") (3-2: the pickup announcement message)
-- sits in the stategraph, inside the "collected" event or the "consumed" state.
local found = {}
local function walk(t, where, seen)
  if type(t) ~= "table" or seen[t] then return end
  seen[t] = true
  if t.Type == "playsound" and type(t.sound) == "string" and string.find(t.sound, "^a11y/got_") then
    table.insert(found, t.sound .. " in " .. where)
  end
  for k, v in pairs(t) do
    local here = where
    if type(v) == "table" and type(v.name) == "string" then here = where .. "/" .. v.name end
    if type(v) == "table" and type(v.event) == "string" then here = where .. "/event " .. v.event end
    walk(v, here, seen)
  end
end
for _, st in ipairs(PropStates) do walk(st, st.name, {}) end
if table.getn(found) ~= 1 then error("expected one a11y/got_ sound, found " .. table.getn(found)) end
local where = found[1]
if not (string.find(where, "collected") or string.find(where, "consumed")) then error("misplaced: " .. where) end
print("  " .. where)
return true
