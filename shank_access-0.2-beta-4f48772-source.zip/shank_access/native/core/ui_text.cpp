#include "ui_text.h"

#include <windows.h>

#include <cstdio>
#include <map>
#include <sstream>
#include <vector>

namespace ui_text {
namespace {

SRWLOCK g_lock = SRWLOCK_INIT;
std::map<std::string, std::string> g_by_key;  // key (e.g. "Combos") -> the section's text as sentences

std::string Sentence(std::string s) {
    while (!s.empty() && (s.back() == ' ' || s.back() == '\r')) s.pop_back();
    if (s.empty()) return s;
    const char last = s.back();
    return (last == '.' || last == '?' || last == '!' || last == ':') ? s : s + ".";
}

}  // namespace

size_t LoadFromString(const std::string& content) {
    std::map<std::string, std::string> by_key;
    std::vector<std::string> keys;
    std::string text;
    size_t sections = 0;
    auto flush = [&]() {
        for (const std::string& k : keys) {
            if (!text.empty() && by_key.find(k) == by_key.end()) by_key[k] = text;
        }
        keys.clear();
        text.clear();
    };
    std::istringstream in(content);
    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        if (line[0] == '[') {
            flush();
            ++sections;
        } else if (line.compare(0, 4, "key=") == 0) {
            keys.push_back(line.substr(4));
        } else if (line.compare(0, 5, "text=") == 0) {
            const std::string t = Sentence(line.substr(5));
            if (!t.empty()) text = text.empty() ? t : text + " " + t;
        }
    }
    flush();
    AcquireSRWLockExclusive(&g_lock);
    g_by_key.swap(by_key);
    ReleaseSRWLockExclusive(&g_lock);
    return sections;
}

size_t Load(const std::wstring& path) {
    FILE* f = nullptr;
    if (_wfopen_s(&f, path.c_str(), L"rb") != 0 || !f) return 0;
    std::string content;
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) content.append(buf, n);
    fclose(f);
    return LoadFromString(content);
}

std::string PageText(const std::string& key) {
    AcquireSRWLockShared(&g_lock);
    auto it = g_by_key.find(key);
    std::string out = it != g_by_key.end() ? it->second : std::string();
    ReleaseSRWLockShared(&g_lock);
    return out;
}

}  // namespace ui_text
