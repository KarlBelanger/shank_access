#include "test_mode.h"

#include <atomic>

#include "log.h"

namespace test_mode {
namespace {

std::atomic<bool> g_on{false};

}  // namespace

// (B66, the user, 2026-10-18: "Unbind f5 and f6 ... Detach the cheats menu and everything in it from test mode": god
// mode and super speed are cheats now (cheats.h), with their own bindings.)
void SetOn(bool on) {
    g_on = on;
    alog::Write("test mode: %s", on ? "on" : "off");
}

bool On() { return g_on; }

}  // namespace test_mode
