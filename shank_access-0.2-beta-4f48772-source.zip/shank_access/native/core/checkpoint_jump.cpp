#include "checkpoint_jump.h"

#include <windows.h>

#include <cstdio>
#include <vector>

#include "game.h"
#include "log.h"

namespace checkpoint_jump {
namespace {

// thiscall (ecx = sim, name, position; ret 8) called as fastcall (edx unused): the same stack clean-up.
using SetRestartFn = void(__fastcall*)(void* sim, void* edx, const char* name, const void* position);
using LoadToLastFn = int(__cdecl*)(void* sim);

SRWLOCK g_lock = SRWLOCK_INIT;
void* g_pending_sim = nullptr;
std::string g_pending_name;
void* g_found_sim = nullptr;  // B34b
DWORD g_scan_failed_ms = 0;   // (a scan that found none: not again for kRescanMs; the menu asks on every key)
constexpr DWORD kRescanMs = 5000;
bool g_pending = false;

// MSVC std::string as the game uses it: capacity at +0x18 (>= 16: heap pointer at +4, else inline at +4), size at +0x14.
bool ReadChars(const unsigned char* str, char* buf, size_t bufsize) {
    __try {
        const unsigned size = *reinterpret_cast<const unsigned*>(str + 0x14);
        const unsigned cap = *reinterpret_cast<const unsigned*>(str + 0x18);
        if (cap < 15 || cap > 4096 || size > cap) return false;
        const char* p = cap >= 16 ? *reinterpret_cast<const char* const*>(str + 4) : reinterpret_cast<const char*>(str + 4);
        const unsigned n = size < bufsize - 1 ? size : static_cast<unsigned>(bufsize - 1);
        for (unsigned i = 0; i < n; ++i) {
            buf[i] = p[i];
            if (static_cast<unsigned char>(buf[i]) < 32 && buf[i] != 0) return false;  // not text
        }
        buf[n] = 0;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool ReadString(const unsigned char* str, std::string* out) {
    char buf[256];
    if (!ReadChars(str, buf, sizeof buf)) return false;
    *out = buf;
    return true;
}

bool LooksLikeSim(const unsigned* p) {
    __try {
        return p[0] == game::kShankSimVtable && p[1] == game::kShankSimVtable2;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

}  // namespace

std::string CurrentName(void* sim) {
    std::string name;
    if (!sim || !ReadString(static_cast<const unsigned char*>(sim) + game::kSimRestartCheckpoint, &name)) return std::string();
    return name;
}

std::string Request(void* sim, const std::string& name, const std::vector<std::string>& valid_names) {
    if (!sim) return "Not in a level yet";
    std::string current = CurrentName(sim);
    bool trusted = false;
    for (const std::string& v : valid_names) trusted = trusted || v == current;
    if (!trusted) {
        // B36b-3 (the hard2 log, 4-a: after a jump to "Exit the level" no bounds action ran, the simulation known from
        // the last one read "" and two jumps were refused): look for the live simulation before refusing.
        alog::Write("checkpoint jump: the simulation %p restarts at \"%s\", not one of this level's checkpoints: scanning", sim,
                    current.c_str());
        AcquireSRWLockExclusive(&g_lock);
        g_found_sim = nullptr;
        ReleaseSRWLockExclusive(&g_lock);
        g_scan_failed_ms = 0;
        if (void* alt = FindSimulation(valid_names)) {
            sim = alt;
            current = CurrentName(sim);
            for (const std::string& v : valid_names) trusted = trusted || v == current;
        }
    }
    alog::Write("checkpoint jump: asked for \"%s\"; the simulation %p restarts at \"%s\"%s", name.c_str(), sim, current.c_str(),
                trusted ? "" : " (not one of this level's checkpoints: refused)");
    if (!trusted) return "Can't go to a checkpoint here";
    AcquireSRWLockExclusive(&g_lock);
    g_pending_sim = sim;
    g_pending_name = name;
    g_pending = true;
    ReleaseSRWLockExclusive(&g_lock);
    return "Loading " + name;
}

void OnGameFrame() {
    AcquireSRWLockExclusive(&g_lock);
    const bool go = g_pending;
    void* sim = g_pending_sim;
    const std::string name = g_pending_name;
    g_pending = false;
    ReleaseSRWLockExclusive(&g_lock);
    if (!go) return;
    reinterpret_cast<SetRestartFn>(game::kSetRestartCheckpoint)(sim, nullptr, name.c_str(),
                                                                reinterpret_cast<const void*>(game::kZeroVector));
    const std::string now = CurrentName(sim);
    alog::Write("checkpoint jump: restart checkpoint now \"%s\"; loading", now.c_str());
    if (now != name) {
        alog::Write("checkpoint jump: the name didn't take; not loading");
        return;
    }
    reinterpret_cast<LoadToLastFn>(game::kLoadToLastCheckpoint)(sim);
}

void OnLevel() {
    AcquireSRWLockExclusive(&g_lock);
    g_found_sim = nullptr;
    ReleaseSRWLockExclusive(&g_lock);
    g_scan_failed_ms = 0;
}

void* FindSimulation(const std::vector<std::string>& valid_names) {
    AcquireSRWLockShared(&g_lock);
    void* cached = g_found_sim;
    ReleaseSRWLockShared(&g_lock);
    if (cached) return cached;
    if (g_scan_failed_ms && GetTickCount() - g_scan_failed_ms < kRescanMs) return nullptr;
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    const unsigned char* p = static_cast<const unsigned char*>(si.lpMinimumApplicationAddress);
    const unsigned char* end = static_cast<const unsigned char*>(si.lpMaximumApplicationAddress);
    MEMORY_BASIC_INFORMATION mbi;
    void* found = nullptr;
    int seen = 0;
    while (!found && p < end && VirtualQuery(p, &mbi, sizeof mbi) == sizeof mbi) {
        const unsigned char* next = static_cast<const unsigned char*>(mbi.BaseAddress) + mbi.RegionSize;
        const DWORD prot = mbi.Protect & 0xff;
        if (mbi.State == MEM_COMMIT && mbi.Type == MEM_PRIVATE && !(mbi.Protect & (PAGE_GUARD | PAGE_NOCACHE)) &&
            (prot == PAGE_READWRITE || prot == PAGE_EXECUTE_READWRITE)) {
            const unsigned* w = static_cast<const unsigned*>(mbi.BaseAddress);
            const size_t n = mbi.RegionSize / 4;
            for (size_t i = 0; i + 1 < n && !found; ++i) {
                if (!LooksLikeSim(w + i)) continue;
                ++seen;
                const std::string current = CurrentName(const_cast<unsigned*>(w + i));
                for (const std::string& v : valid_names) {
                    if (v == current) found = const_cast<unsigned*>(w + i);
                }
            }
        }
        if (next <= p) break;
        p = next;
    }
    alog::Write("checkpoint jump: simulation scan: %d with the vtables, %s", seen, found ? "one at a checkpoint of this level" : "none usable");
    if (found) {
        AcquireSRWLockExclusive(&g_lock);
        g_found_sim = found;
        ReleaseSRWLockExclusive(&g_lock);
    }
    g_scan_failed_ms = found ? 0 : (GetTickCount() | 1);
    return found;
}

}  // namespace checkpoint_jump
