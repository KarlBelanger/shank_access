#pragma once
// Static (drawn) UI text, extracted from the game's own .gfx files by
// tools/ui_text/extract_ui_text.py into bin/shank_access_ui_text.txt (generated at build time from
// the user's install, deployed with the mod, never committed). Needed where a screen draws its text
// as glyphs that GetVariable can't read: the How to Play pages' explanations.
#include <cstddef>
#include <string>

namespace ui_text {

// Parses the file format ("[file.gfx]", "key=…", "text=…" lines). Replaces any previous data;
// returns the number of sections.
size_t LoadFromString(const std::string& content);

// Reads and parses the file. Returns the number of sections (0 if it can't be read).
size_t Load(const std::wstring& path);

// The static text of the section whose key matches (e.g. the How to Play page title "Combos"), as
// sentences: "Juggle enemies by holding down and pressing attack. …". "" if unknown.
std::string PageText(const std::string& key);

}  // namespace ui_text
