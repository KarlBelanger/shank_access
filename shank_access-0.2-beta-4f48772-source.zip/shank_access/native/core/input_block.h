#pragma once
// B13-2: hides the keyboard from the game while our settings menu is open. The game reads keys only through
// raw input (GetRawInputData; RE-NOTES "Mod settings in the game's menus"), so a hook on it turns keyboard
// records into releases while blocking: keys the game saw go down get their release (so Shank doesn't keep
// running), every other key becomes a release of an unused code. Our own hotkeys read GetAsyncKeyState and
// still see every key.
#include <windows.h>

namespace input_block {

bool Install();              // hooks user32!GetRawInputData (MinHook)
void SetBlocking(bool on);   // any thread

// The record rewrite, testable without the hook: `down` = the keys the game has seen pressed (updated here).
void Filter(RAWKEYBOARD* k, bool blocking, bool down[256]);
// B40-2: the pad's buttons as the game gets them: hidden while blocking; after it, those held then stay hidden until
// released. Returns the buttons still hidden.
WORD PadFilter(WORD* buttons, bool blocking, bool was_blocking, WORD hidden);

}  // namespace input_block
