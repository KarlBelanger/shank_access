#pragma once
// Shank.exe addresses and layouts. Valid ONLY for the build checked in exe_check.h
// (see docs/RE-NOTES.md for the evidence behind each one).
#include <cstdint>

namespace game {

// Sound (RE-NOTES "Sound system").
// PlaySoundAt: esi = event name (char*), [esp+4] = const float* pos (x, y); caller cleans the stack.
inline constexpr uintptr_t kPlaySoundAt = 0x55ab90;
// PlaySound (non-positional; only the UI "playsound" callback uses it): esi = event name.
inline constexpr uintptr_t kPlaySound = 0x55ab10;

// Pan listener, set together at 0x55b157: half-extents and centre (camera view, presumably).
// Four consecutive floats starting here: half-width 0xae6860, half-height 0xae6864, x 0xae6868, y 0xae686c.
inline constexpr uintptr_t kListenerHalfW = 0xae6860;
// B8f: the per-frame sound update that copies the camera's half-size (esi) and centre (edi) into those globals;
// dt on the stack (caller cleans); returns nothing used. Called once, from 0x521009.
inline constexpr uintptr_t kSoundUpdate = 0x55b0d0;
// B31-3: the game's category volumes as it holds them (floats; set by 0x55a920(name, volume); RE-NOTES "Sound system").
inline constexpr uintptr_t kGameVolume = 0x8899f8;
inline constexpr uintptr_t kMusicVolume = 0x8899fc;
inline constexpr uintptr_t kVolumeScale = 0x889a00;    // B32: both categories are set to setting × this (0x55a920)
inline constexpr uintptr_t kEventSystemPtr = 0xadfdf0; // the FMOD EventSystem* (RE-NOTES "Sound system")
// B34 checkpoint jump (RE-NOTES "Checkpoint jump"): NextCheckPoint's setter and the debug LoadToLastCheckpoint.
inline constexpr uintptr_t kSetRestartCheckpoint = 0x406b80;  // thiscall(sim, const char* name, const vec2* pos), ret 8
inline constexpr uintptr_t kLoadToLastCheckpoint = 0x781580;  // cdecl(cSimulation*)
inline constexpr uintptr_t kZeroVector = 0xae10e0;            // the position NextCheckPoint passes
inline constexpr uintptr_t kSimRestartCheckpoint = 0x38;      // sim+0x38: std::string, the restart checkpoint's name
inline constexpr uintptr_t kShankSimVtable = 0x837d80;         // cShankSimulation (RTTI: COL 0x849a2c, offset 0)
inline constexpr uintptr_t kShankSimVtable2 = 0x837db0;        // ...its second base at +4 (COL 0x849a18)

// Debug-settings block (fixed global; 0x529ec0 returns its address). Byte flags the retail game
// still honours, as far as we know (RE-NOTES). Used by test mode only.
inline constexpr uintptr_t kDebugSettings = 0xae6530;
inline constexpr uintptr_t kDebugGodMode = kDebugSettings + 0x09;
inline constexpr uintptr_t kDebugSuperSpeed = kDebugSettings + 0x0a;

// Levels (RE-NOTES "Levels"). LevelData::LoadSimData: thiscall(level, stream) -> bool, ret 4; reads the
// .slev collision. LevelData name getter: thiscall(level) -> const char* (c_str of a std::string at +0x10).
inline constexpr uintptr_t kLoadSimData = 0x495e30;
inline constexpr uintptr_t kLevelName = 0x4323e0;

// Arena bounds (RE-NOTES "Arena bounds"). cSetBoundsAction::Execute: thiscall(action; ctx) ret 4, the
// target simulation = *ctx. The current bounds are floats in the simulation: min x/y, max x/y, and a
// byte "default bounds in force".
inline constexpr uintptr_t kSetBoundsExecute = 0x4eb940;

// B7 safe edges (RE-NOTES "Tag conditions and the anti-fall rule"). HasTag_ParseNode::Evaluate:
// thiscall(node, ctx) -> 0/1 in eax, ret 4; tag hash at node+0x20, nott byte at +0x24, source hash at +0x28.
inline constexpr uintptr_t kHasTagEvaluate = 0x4f92c0;
inline constexpr uintptr_t kSimBoundsMinX = 0xb0;
inline constexpr uintptr_t kSimBoundsDefault = 0xc0;

}  // namespace game
