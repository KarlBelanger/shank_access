#include "pathing.h"

#include <windows.h>

#include <algorithm>
#include <cmath>
#include <fstream>
#include <limits>
#include <map>
#include <queue>
#include <sstream>
#include <utility>

#include "log.h"

namespace pathing {
namespace {

struct Level {
    std::map<std::string, int> ids;
    std::vector<std::string> names;
    std::vector<std::vector<std::pair<int, Step>>> out;  // node -> (to, step)
};

SRWLOCK g_lock = SRWLOCK_INIT;
std::map<std::string, Level> g_levels;
const Level* g_level = nullptr;
std::string g_current;

int Id(Level* l, const std::string& name) {
    const auto it = l->ids.find(name);
    if (it != l->ids.end()) return it->second;
    const int id = static_cast<int>(l->names.size());
    l->ids[name] = id;
    l->names.push_back(name);
    l->out.emplace_back();
    return id;
}

std::string BaseName(const std::string& name) {
    std::string s = name;
    const size_t slash = s.find_last_of("/\\");
    if (slash != std::string::npos) s = s.substr(slash + 1);
    const size_t dot = s.find('.');
    if (dot != std::string::npos) s = s.substr(0, dot);
    return s;
}

bool OnFoot(const std::string& move) {
    return move == "run_up_wall" || move == "climb" || move == "climb_over" || move == "slide_down" || move == "climb_down" ||
           move == "shimmy_along" || move == "run_across" || move == "run_off" ||  // (B47c-1)
           move == "climb_up" || move == "walk_off" || move == "slide_off" ||  // B15-10: no jump needed
           move == "switch_sides" || move == "drop_through";
}

// B15-7: a jump again inside a one-way platform that works only from one sampled spot (1-b train: the top 32 px of a
// wall) is too fine to rely on: it counts as three jumps, so a longer plain route wins when there is one.
float Cost(const Step& s) {
    // B20-2 (the user: "Pathing called for long jump, drop worked fine"; 2-b, two walk-offs tied with one long jump):
    // stepping off an edge needs no input at all, so it beats a jump even twice over.
    // B46 (the user: "Any walk off that only works at one specific speed should be considered extremely risky"): as hard as
    // a one-spot jump.
    if (OneSpeedWalkOff(s)) return 2.5f;
    if (s.move == "walk_off" || s.move == "slide_off") return 0.3f;
    if (OnFoot(s.move)) return 0.5f;
    if (s.move == "platform_up" && s.x_hi - s.x_lo < 64.f && s.y_hi - s.y_lo < 64.f) return 3.f;
    // B41c (the user, 1-c before the slopes: "The vertical windows for those maneuvers are very narrow"): a jump off a
    // wall, wall run, pole, swing point or bar that works from only one sampled spot (w53's run-up jump at y 1760 only;
    // the wall run's long jump from its very end) is hard to hit: it counts as 2.5 jumps, so a steadier way wins.
    if (!s.from.empty() && s.from[0] != 's' && s.move != "drop" && s.x_hi - s.x_lo < 64.f && s.y_hi - s.y_lo < 64.f) return 2.5f;
    return 1.f;
}

}  // namespace

bool OnFootMove(const std::string& move) { return OnFoot(move); }

size_t LoadFromString(const std::string& text) {
    std::map<std::string, Level> levels;
    Level* cur = nullptr;
    std::istringstream lines(text);
    std::string line;
    int bad = 0;
    while (std::getline(lines, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        if (line[0] == '[') {
            cur = &levels[line.substr(1, line.find(']') - 1)];
            continue;
        }
        if (!cur) continue;
        std::istringstream in(line);
        std::string kind, side;
        Step s;
        if (in >> kind && kind == "edge" && in >> s.from >> s.to >> s.move >> s.x >> s.y >> side) {
            s.right = side == "R";
            if (!(in >> s.x_lo >> s.x_hi >> s.y_lo >> s.y_hi)) {  // (older files: the one spot)
                s.x_lo = s.x_hi = s.x;
                s.y_lo = s.y_hi = s.y;
            }
            std::string tag;  // B46: a walk-off's speed window (v lo hi n); B47c-7: a slide pole's catch height (c y)
            while (in >> tag) {
                if (tag == "v" && !(in >> s.v_lo >> s.v_hi >> s.v_n)) s.v_n = 0;
                if (tag == "c" && !(in >> s.catch_y)) s.catch_y = -1.f;
            }
            const int a = Id(cur, s.from), b = Id(cur, s.to);
            cur->out[a].emplace_back(b, s);
        } else {
            ++bad;
        }
    }
    AcquireSRWLockExclusive(&g_lock);
    g_levels.swap(levels);
    const auto it = g_levels.find(g_current);
    g_level = it != g_levels.end() ? &it->second : nullptr;
    const size_t n = g_levels.size();
    ReleaseSRWLockExclusive(&g_lock);
    if (bad) alog::Write("paths: %d unreadable lines", bad);
    return n;
}

size_t Load(const std::wstring& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        alog::Write("paths: no traversal graph file (waypoint mode has no paths)");
        return 0;
    }
    std::stringstream ss;
    ss << f.rdbuf();
    const size_t n = LoadFromString(ss.str());
    alog::Write("paths: %u levels loaded", static_cast<unsigned>(n));
    return n;
}

bool SetLevel(const std::string& game_name) {
    const std::string name = BaseName(game_name);
    AcquireSRWLockExclusive(&g_lock);
    g_current = name;
    const auto it = g_levels.find(name);
    g_level = it != g_levels.end() ? &it->second : nullptr;
    const bool ok = g_level != nullptr;
    const size_t edges = ok ? [&] {
        size_t n = 0;
        for (const auto& o : g_level->out) n += o.size();
        return n;
    }() : 0;
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("paths: level %s: %s", name.c_str(), ok ? (std::to_string(edges) + " moves").c_str() : "no graph");
    return ok;
}

bool HasNode(const std::string& node) {
    AcquireSRWLockShared(&g_lock);
    const bool has = g_level && g_level->ids.count(node);
    ReleaseSRWLockShared(&g_lock);
    return has;
}

std::vector<Step> Path(const std::string& from, const std::set<std::string>& goals, float from_x, float from_c) {
    std::vector<Step> path;
    AcquireSRWLockShared(&g_lock);
    const Level* l = g_level;
    if (!l || goals.count(from)) {
        ReleaseSRWLockShared(&g_lock);
        return path;
    }
    const auto start = l->ids.find(from);
    if (start == l->ids.end()) {
        ReleaseSRWLockShared(&g_lock);
        return path;
    }
    const size_t n = l->names.size();
    std::vector<float> dist(n, 1e30f);
    std::vector<int> prev(n, -1);
    std::vector<const Step*> via(n, nullptr);
    // B27-3: walking along a floor costs too (4-a: a route walking ~150 tiles back and over the top had beaten three
    // swing jumps): from where he got onto the floor (his x at the start; else the move that brought him, approximately)
    // to the nearest spot the next move starts from, kWalkPxPerCost px per unit (a jump = 1).
    std::vector<float> arrive_x(n, std::numeric_limits<float>::quiet_NaN());
    arrive_x[start->second] = from_x;
    // B47c-7: arrived on a slide pole at this height: no move off it from higher up (he only slides down)
    std::vector<float> arrive_c(n, -1.f);
    arrive_c[start->second] = from_c;
    using Item = std::pair<float, int>;
    std::priority_queue<Item, std::vector<Item>, std::greater<Item>> q;
    dist[start->second] = 0;
    q.push(Item(0.f, start->second));
    int reached = -1;
    while (!q.empty()) {
        const Item it = q.top();
        q.pop();
        if (it.first > dist[it.second]) continue;
        if (goals.count(l->names[it.second])) {
            reached = it.second;
            break;
        }
        const bool floor = !l->names[it.second].empty() && l->names[it.second][0] == 's';
        const float ax = arrive_x[it.second];
        const float ac = arrive_c[it.second];
        for (const auto& e : l->out[it.second]) {
            if (ac >= 0.f && e.second.y_lo > ac + kSlideCatchSlackPx) continue;
            float walk = 0.f;
            if (floor && !std::isnan(ax)) {
                const float lo = std::min(e.second.x_lo, e.second.x), hi = std::max(e.second.x_hi, e.second.x);
                walk = std::max(0.f, std::max(lo - ax, ax - hi)) / kWalkPxPerCost;
            }
            const float nd = it.first + Cost(e.second) + walk;
            if (nd < dist[e.first]) {
                dist[e.first] = nd;
                prev[e.first] = it.second;
                via[e.first] = &e.second;
                arrive_c[e.first] = e.second.catch_y;
                arrive_x[e.first] = std::max(std::min(e.second.x_lo, e.second.x), std::min(std::max(e.second.x_hi, e.second.x),
                                                                                           std::isnan(ax) ? e.second.x : ax));
                q.push(Item(nd, e.first));
            }
        }
    }
    for (int v = reached; v >= 0 && via[v]; v = prev[v]) path.push_back(*via[v]);
    ReleaseSRWLockShared(&g_lock);
    std::vector<Step> ordered(path.rbegin(), path.rend());
    return ordered;
}

std::string MoveName(const std::string& move) {
    static const struct {
        const char* move;
        const char* name;
    } kNames[] = {{"long_jump", "long jump"},         {"standing_jump", "jump"},        {"wall_jump", "wall jump"},
                  {"run_up_jump", "jump off the wall"}, {"pole_jump", "jump off the pole"}, {"swing_jump", "jump off the swing point"},
                  {"bar_jump", "jump off the bar"},  {"jump_up", "jump up"},           {"wall_run_jump", "jump off the wall run"},
                  {"walk_off", "walk off the edge"}, {"slide_off", "slide off the end"},
                  {"platform_up", "jump up into the platform, then jump again"}, {"shimmy_along", "shimmy along"}, {"run_across", "run across the gap"}, {"run_off", "sprint off the edge"},
                  {"climb_up", "run up the wall and climb over"}, {"drop", "drop"},                 {"run_up_wall", "run up the wall"},
                  {"climb", "climb"},                {"climb_over", "climb over the top"}, {"slide_down", "slide down"},
                  {"climb_down", "climb down"},      {"bounce", "jump off and bounce back to the other side"},
                  {"switch_sides", "switch sides: hold toward the pole"}, {"drop_through", "drop through: hold down and jump"}};
    for (const auto& k : kNames) {
        if (move == k.move) return k.name;
    }
    return move;
}

}  // namespace pathing
