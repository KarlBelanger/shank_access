"""Build the Shank 2 handoff zip for a second developer (2026-10-04).

Usage (repo root):  .venv/Scripts/python tools/make_handoff.py [--out <folder>]
Default output: %USERPROFILE%/Downloads/shank-access-handoff-<date>-<rev>.zip

What goes in (from the committed HEAD only; commit first, uncommitted changes are left out):
  shank-access/            a fresh clone with its full history, the origin remote removed
  shank-access/README-FIRST.md, START-PROMPT.txt   copies of handoff/ at the folder's top
  shank-access/claude-memory/    Claude's per-machine memory notes for this project (pointers only)
build/, .venv/ and every gitignored file stay out (they regenerate; Klei-derived data is never shipped).
"""
import datetime
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MEMORY = os.path.join(os.path.expanduser("~"), ".claude", "projects", "C--Users-karlb-shank-access", "memory")


def git(*args, cwd=REPO):
    return subprocess.run(["git"] + list(args), cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()


def main(argv):
    out_dir = os.path.join(os.path.expanduser("~"), "Downloads")
    if "--out" in argv:
        out_dir = argv[argv.index("--out") + 1]
    if git("status", "--porcelain"):
        print("warning: uncommitted changes are not included (the zip is built from HEAD)")
    rev = git("rev-parse", "--short", "HEAD")
    name = "shank-access-handoff-%s-%s.zip" % (datetime.date.today().isoformat(), rev)
    tmp = tempfile.mkdtemp(prefix="handoff-")
    try:
        root = os.path.join(tmp, "shank-access")
        git("clone", "--quiet", "--no-local", REPO, root, cwd=tmp)
        for ref in git("branch", "-r", "--format=%(refname:short)", cwd=root).split():
            if "/" not in ref:  # "origin" alone is origin/HEAD
                continue
            local = ref.split("/", 1)[1]  # origin/release/0.1 -> release/0.1: keep every branch locally
            if local not in ("HEAD", "main"):
                git("branch", local, ref, cwd=root)
        git("remote", "remove", "origin", cwd=root)
        git("gc", "--quiet", cwd=root)
        for src, dst in (("handoff/README.md", "README-FIRST.md"), ("handoff/START-PROMPT.txt", "START-PROMPT.txt")):
            shutil.copyfile(os.path.join(root, src), os.path.join(root, dst))
        with open(os.path.join(root, ".git", "info", "exclude"), "a", encoding="utf-8") as f:
            f.write("/README-FIRST.md\n/START-PROMPT.txt\n/claude-memory/\n")  # the zip's extras stay out of git status
        if os.path.isdir(MEMORY):
            shutil.copytree(MEMORY, os.path.join(root, "claude-memory"))
        else:
            print("warning: no Claude memory folder at %s" % MEMORY)
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, name)
        n = 0
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for d, _, files in os.walk(root):
                z.write(d, os.path.relpath(d, tmp))  # folders too: git needs its empty .git/refs folders
                for f in files:
                    full = os.path.join(d, f)
                    z.write(full, os.path.relpath(full, tmp))
                    n += 1
        print("%s: %d files, %.1f MB (HEAD %s)" % (path, n, os.path.getsize(path) / 1e6, rev))
    finally:
        shutil.rmtree(tmp, onexc=lambda fn, p, e: (os.chmod(p, 0o666), fn(p)))  # git objects are read-only
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
