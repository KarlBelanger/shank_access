#include "exe_check.h"

#include <windows.h>
#include <bcrypt.h>

#include <vector>

std::string Sha256File(const wchar_t* path) {
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (file == INVALID_HANDLE_VALUE) return {};

    std::string result;
    BCRYPT_ALG_HANDLE alg = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    if (BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0)) &&
        BCRYPT_SUCCESS(BCryptCreateHash(alg, &hash, nullptr, 0, nullptr, 0, 0))) {
        std::vector<unsigned char> buf(1 << 16);
        DWORD read = 0;
        bool ok = true;
        while (ReadFile(file, buf.data(), static_cast<DWORD>(buf.size()), &read, nullptr) && read > 0) {
            if (!BCRYPT_SUCCESS(BCryptHashData(hash, buf.data(), read, 0))) { ok = false; break; }
        }
        unsigned char digest[32];
        if (ok && BCRYPT_SUCCESS(BCryptFinishHash(hash, digest, sizeof digest, 0))) {
            static const char hex[] = "0123456789abcdef";
            for (unsigned char b : digest) {
                result += hex[b >> 4];
                result += hex[b & 15];
            }
        }
    }
    if (hash) BCryptDestroyHash(hash);
    if (alg) BCryptCloseAlgorithmProvider(alg, 0);
    CloseHandle(file);
    return result;
}
