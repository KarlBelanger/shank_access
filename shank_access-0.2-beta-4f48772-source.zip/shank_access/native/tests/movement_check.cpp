// B42-2: the jump model against every real movement Shank made (host tool, never deployed).
// Input: the level geometry and build/movements/movements.txt (tools/movements.py, B42-1: every airborne movement cut
// out of the collected logs: where it started, its kind, its fitted launch speeds, what it really ended on).
// For each movement:
//   reach   the launch's model (the same Reach* call as path_graph's Try for that origin kind) from where he really
//           launched, toward what he really ended on: "ok" (the model can do it), "MISS" (it can't: a real move the
//           cues and the graph don't know), "-" (no model for the kind, no known end, a death)
//   replay  his real launch speeds through the model's one flight (ReachAtSpeed; Land for deaths): does it end where he
//           really did? "ok", "WRONG", "-" (he steered, slow motion, too short to fit, no known end)
//   claim   a jump-now claim in effect at the launch: "kept" (he got there), "broken" (he didn't), "-"
// Output: one line per movement, then totals per kind and per level. With --baseline <an earlier output>, the
// movements whose verdicts changed (what a model change newly breaks or fixes): run it before deploying a model change.
// Usage: movement_check.exe <shank_access_geometry.txt> <movements.txt> <out.txt> [--baseline <old out.txt>]
#include <windows.h>

#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"

namespace {

using jump_model::Target;

struct Move {
    std::string key, level, kind, dir, flags, how, ttype, textra;
    float x0 = 0, y0 = 0, vx = 0, vy = 0, x_resid = 0, fx = 0, fy = 0, ex = 0, ey = 0;
    bool has_scale = false;
    float scale = 1;
    float tx1 = 0, ty1 = 0, tx2 = 0, ty2 = 0;
    int dur_ms = 0;  // how long the real flight lasted (to its end), real ms
    bool has_claim = false;
    std::string claim_what, claim_kind;
    float claim_x = 0, claim_y = 0;
};

struct Verdict {
    std::string reach = "-", replay = "-", claim = "-", phantom = "-", detail;
};

bool ParseMove(const std::string& line, Move* m) {
    std::istringstream in(line);
    std::string tag, scale;
    in >> tag >> m->key >> m->level >> m->kind >> m->x0 >> m->y0 >> m->dir >> m->vx >> m->vy >> scale >> m->x_resid >> m->fx >>
        m->fy >> m->flags >> m->how >> m->ex >> m->ey >> m->ttype >> m->tx1 >> m->ty1 >> m->tx2 >> m->ty2 >> m->textra;
    if (!in || tag != "m") return false;
    in >> m->dur_ms;  // (older files: none)
    m->has_scale = scale != "-";
    if (m->has_scale) m->scale = static_cast<float>(atof(scale.c_str()));
    return true;
}

// "claim <what> | <kind> <x> <y>"
void ParseClaim(const std::string& line, Move* m) {
    std::istringstream in(line);
    std::string tag, bar;
    in >> tag >> m->claim_what >> bar >> m->claim_kind >> m->claim_x >> m->claim_y;
    m->has_claim = static_cast<bool>(in);
}

// What he really ended on, as the model's target. False: no target (a death, nothing known).
bool ToTarget(const Move& m, Target* t) {
    if (m.ttype == "landing" || m.ttype == "ledge") {
        *t = Target{jump_model::kLanding, m.tx1, m.ty1, m.tx2, m.ty2};
        t->oneway = m.textra == "1";
    } else if (m.ttype == "swing") {
        *t = Target{jump_model::kSwing, m.tx1, m.ty1, 0, 0};
    } else if (m.ttype == "pole") {
        *t = Target{jump_model::kPole, m.tx1, m.ty1, m.tx2, m.ty2};
        t->slide = m.textra == "1";
    } else if (m.ttype == "shimmy") {
        *t = Target{jump_model::kShimmy, m.tx1, m.ty1, m.tx2, m.ty2};
    } else if (m.ttype == "wallzone") {
        *t = Target{jump_model::kWallZone, m.tx1, m.ty1, m.tx2, m.ty2};
    } else if (m.ttype == "wall") {
        *t = Target{jump_model::kWall, m.tx1, m.ty1, m.tx2, m.ty2};
    } else {
        return false;
    }
    return true;
}

// The launch's model, as path_graph's Try uses it for that origin kind. *modelled = false: no model for the kind.
jump_model::Jump TryKind(const Move& m, const Target& t, bool* modelled) {
    const bool right = m.dir == "R";
    *modelled = true;
    if (m.kind == "ground") return jump_model::Reach(t, m.x0, m.y0, right);
    if (m.kind == "walk_off") return jump_model::ReachWalkingOff(t, m.x0, m.y0, right);
    if (m.kind == "drop") return jump_model::ReachFalling(t, m.x0, m.y0, right);
    if (m.kind == "slide") return jump_model::ReachSliding(t, m.x0, m.y0, right);
    if (m.kind == "slide_off") return jump_model::ReachSlidingOff(t, m.x0, m.y0, right);
    if (m.kind == "cling") return jump_model::ReachFromWall(t, m.x0, m.y0, right);
    if (m.kind == "run_up") return jump_model::ReachFromWallRunningUp(t, m.x0, m.y0, right);
    if (m.kind == "pole") return jump_model::ReachFromPole(t, m.x0, m.y0, right);
    if (m.kind == "swing") return jump_model::ReachFromSwing(t, m.x0, m.y0, right);
    if (m.kind == "bar") return jump_model::ReachFromBar(t, m.x0, m.y0, right);
    if (m.kind == "wall_run") return jump_model::ReachFromWallRun(t, m.x0, m.y0, right);
    *modelled = false;  // fall, hop, air, wall_run_off: no launch model (replay only)
    return jump_model::kNone;
}

bool Died(const Move& m) { return m.how == "death" || m.ttype == "pit"; }

// An end we know: a landing, a catch, a death (not "lost": the tracker lost him; not "relaunch": he jumped again).
bool KnownEnd(const Move& m) {
    return Died(m) || m.how == "land" || m.how == "ledge" || m.how == "cling" || m.how == "bar" || m.how == "wall_run" ||
           m.how == "hit_wall" || m.how == "run_up" || (m.how == "deviated" && m.ttype != "-");
}

// How far (x, y) is from what the movement really ended on (a point, a segment, a box).
float DistanceTo(const Move& m, float x, float y) {
    if (m.ttype == "swing") return std::hypot(x - m.tx1, y - m.ty1);
    if (m.ttype == "wallzone") {
        const float dx = std::fmax(0.f, std::fmax(m.tx1 - x, x - m.tx2)), dy = std::fmax(0.f, std::fmax(m.ty1 - y, y - m.ty2));
        return std::hypot(dx, dy);
    }
    const float vx = m.tx2 - m.tx1, vy = m.ty2 - m.ty1, len2 = vx * vx + vy * vy;
    float u = len2 > 0 ? ((x - m.tx1) * vx + (y - m.ty1) * vy) / len2 : 0.f;
    u = std::fmax(0.f, std::fmin(1.f, u));
    return std::hypot(m.tx1 + u * vx - x, m.ty1 + u * vy - y);
}

// Did he make the launch the claim named (cues.cpp's JumpName wording, spaces as _), toward its point?
bool ClaimMatches(const Move& m) {
    const std::string& c = m.claim_kind;
    bool kind = false;
    if (c == "long_jump" || c == "standing_jump") kind = m.kind == "ground" || m.kind == "slide";
    else if (c == "wall_jump" || c == "jump_off_the_wall_while_running_up_it") kind = m.kind == "cling" || m.kind == "run_up";
    else if (c == "pole_jump") kind = m.kind == "pole";
    else if (c == "bar_jump") kind = m.kind == "bar";
    else if (c == "swing_jump") kind = m.kind == "swing";
    else if (c == "jump_up") kind = m.kind == "bar" || m.kind == "swing";
    else if (c == "wall-run_jump") kind = m.kind == "wall_run";
    if (!kind) return false;
    if (std::fabs(m.claim_x - m.x0) < 64.f || c == "jump_up") return true;
    // he steered back to where he started (back onto the same wall): not an attempt at the claim
    if (std::fabs(m.ex - m.x0) < 100.f && std::fabs(m.claim_x - m.x0) > 200.f) return false;
    return (m.claim_x > m.x0) == (m.dir == "R");
}

// B44g: the level's swing points, poles, bars and wall-run zones as targets (as path_graph's ToTarget).
bool FeatureTarget(const level_geometry::Feature& f, Target* t) {
    const auto& p = f.points;
    if (p.empty()) return false;
    const auto& q = p.size() > 1 ? p[1] : p[0];
    if (f.type == "swing_point") *t = Target{jump_model::kSwing, p[0].first, p[0].second, 0, 0};
    else if (f.type == "pole" || f.type == "slide_pole") *t = Target{jump_model::kPole, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "shimmy_line") *t = Target{jump_model::kShimmy, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "wallrun_zone") *t = Target{jump_model::kWallZone, p[0].first, p[0].second, q.first, q.second};
    else return false;
    t->slide = f.type == "slide_pole";
    return true;
}

// How far (x, y) is from a pole / bar (a segment), a zone (a box) or a swing point.
float TargetDistance(const Target& t, float x, float y) {
    if (t.kind == jump_model::kSwing) return std::hypot(x - t.x1, y - t.y1);
    if (t.kind == jump_model::kWallZone) {
        const float dx = std::fmax(0.f, std::fmax(t.x1 - x, x - t.x2)), dy = std::fmax(0.f, std::fmax(t.y1 - y, y - t.y2));
        return std::hypot(dx, dy);
    }
    const float vx = t.x2 - t.x1, vy = t.y2 - t.y1, len2 = vx * vx + vy * vy;
    float u = len2 > 0 ? ((x - t.x1) * vx + (y - t.y1) * vy) / len2 : 0.f;
    u = std::fmax(0.f, std::fmin(1.f, u));
    return std::hypot(t.x1 + u * vx - x, t.y1 + u * vy - y);
}

bool SameTarget(const Move& m, const Target& t) {
    return std::fabs(t.x1 - m.tx1) < 1.f && std::fabs(t.y1 - m.ty1) < 1.f;
}

Verdict Check(const Move& m) {
    Verdict v;
    Target t;
    const bool has_target = !Died(m) && KnownEnd(m) && ToTarget(m, &t);
    // (B44g: back onto the pole, bar or zone he left: not a jump target the graph or the cues use)
    const bool own_hold = has_target && m.kind != "ground" && m.kind != "slide" && m.kind != "walk_off" && m.kind != "slide_off" &&
                          t.kind != jump_model::kLanding && t.kind != jump_model::kWall && TargetDistance(t, m.x0, m.y0) < 240.f;
    if (has_target && !own_hold) {
        bool modelled = false;
        const jump_model::Jump j = TryKind(m, t, &modelled);
        if (modelled) v.reach = j != jump_model::kNone ? "ok" : "MISS";
    }
    // Replay: only his real speeds (unsteered, normal game speed, a fit long enough to have a time scale).
    const bool clean = m.flags == "-" && m.has_scale && m.scale >= 0.9f && m.scale <= 1.1f && m.x_resid <= 16.f;
    if (clean && KnownEnd(m)) {
        char buf[160];
        if (Died(m)) {
            float lx = 0, ly = 0;
            if (jump_model::Land(m.fx, m.fy, m.vx, m.vy, &lx, &ly)) {
                v.replay = "WRONG";
                snprintf(buf, sizeof buf, "died; the model lands him at (%.0f, %.0f)", lx, ly);
                v.detail += buf;
            } else {
                v.replay = "ok";
            }
        } else if (has_target) {
            bool pit = false;
            if (jump_model::ReachAtSpeed(t, m.fx, m.fy, m.vx, m.vy, &pit)) {
                v.replay = "ok";
            } else {
                v.replay = "WRONG";
                float lx = 0, ly = 0;
                if (pit) snprintf(buf, sizeof buf, "the model dies in a pit");
                else if (jump_model::Land(m.fx, m.fy, m.vx, m.vy, &lx, &ly)) snprintf(buf, sizeof buf, "the model lands at (%.0f, %.0f)", lx, ly);
                else snprintf(buf, sizeof buf, "the model reaches nothing");
                v.detail += buf;
            }
        }
    }
    // B44g (the user: "Check the logs for anything else recorded incorrectly"; the B44b session, 1-c: a long jump passed the
    // wall-run zone's corner ~70 px above its bottom and fell through it, the model had claimed it): with his real speeds, does
    // the model catch something (a swing point, pole, bar, wall-run zone) before his real flight ended, that he didn't?
    // "FALSE" (a phantom catch: a jump target that isn't), "ok", "-" (not checked).
    if (clean && m.dur_ms > 0 && (KnownEnd(m) || m.how == "lost")) {
        v.phantom = "ok";
        for (const level_geometry::Feature& f : level_geometry::Features()) {
            Target t;
            if (!FeatureTarget(f, &t)) continue;
            const float tx = t.kind == jump_model::kSwing ? t.x1 : (t.x1 + t.x2) / 2, ty = t.kind == jump_model::kSwing ? t.y1 : (t.y1 + t.y2) / 2;
            if (std::hypot(tx - m.fx, ty - m.fy) > 2500.f) continue;
            if (std::hypot(t.x1 - m.x0, t.y1 - m.y0) < jump_model::kInterceptSkipPx && t.kind == jump_model::kSwing) continue;  // (his own)
            if (t.kind != jump_model::kSwing && TargetDistance(t, m.x0, m.y0) < 240.f) continue;  // (the pole, bar or zone he leaves)
            if (m.ttype != "-" && m.ttype != "pit" && m.ttype != "landing" && m.ttype != "ledge" && SameTarget(m, t)) continue;
            bool pit = false;
            float secs = 0;
            if (!jump_model::ReachAtSpeed(t, m.fx, m.fy, m.vx, m.vy, &pit, &secs)) continue;
            if (secs * 1000.f >= m.dur_ms - 40.f) continue;  // (later than his flight ended: it ended on something else)
            v.phantom = "FALSE";
            char buf[160];
            snprintf(buf, sizeof buf, "%sthe model catches a %s at (%.0f, %.0f) after %.0f ms; he went on", v.detail.empty() ? "" : "; ",
                     f.type.c_str(), tx, ty, secs * 1000.f);
            v.detail += buf;
            break;
        }
    }
    // The jump-now claim: did he get to the place it named? (a landing claim at (0, 0) names no place.) Only when he did
    // the jump it named, toward it: else "other" (he chose something else).
    if (m.has_claim && !(m.claim_x == 0 && m.claim_y == 0) && KnownEnd(m) && !ClaimMatches(m)) {
        v.claim = "other";
    } else if (m.has_claim && !(m.claim_x == 0 && m.claim_y == 0) && KnownEnd(m)) {
        // there: he ended on the thing the claim named (its point is one spot on it: a wall run's end, a line's
        // nearest point), or within 200 px of the point
        bool there = false;
        if (!Died(m)) {
            if (std::hypot(m.ex - m.claim_x, m.ey - m.claim_y) <= 200.f) there = true;
            if (m.ttype != "-" && DistanceTo(m, m.claim_x, m.claim_y) <= 96.f) there = true;
        }
        v.claim = there ? "kept" : "broken";
        if (!there) {
            char buf[200];
            snprintf(buf, sizeof buf, "%sclaimed %s at (%.0f, %.0f) by %s", v.detail.empty() ? "" : "; ", m.claim_what.c_str(), m.claim_x,
                     m.claim_y, m.claim_kind.c_str());
            v.detail += buf;
        }
    }
    return v;
}

struct Tally {
    int n = 0, reach_ok = 0, reach_miss = 0, replay_ok = 0, replay_wrong = 0, claim_kept = 0, claim_broken = 0, claim_other = 0;
    int phantom_ok = 0, phantom_false = 0;
    void Add(const Verdict& v) {
        phantom_ok += v.phantom == "ok";
        phantom_false += v.phantom == "FALSE";
        claim_other += v.claim == "other";
        ++n;
        reach_ok += v.reach == "ok";
        reach_miss += v.reach == "MISS";
        replay_ok += v.replay == "ok";
        replay_wrong += v.replay == "WRONG";
        claim_kept += v.claim == "kept";
        claim_broken += v.claim == "broken";
    }
};

std::string Pct(int part, int whole) {
    if (!whole) return "-";
    char buf[16];
    snprintf(buf, sizeof buf, "%d%%", (part * 100 + whole / 2) / whole);
    return buf;
}

void PrintTally(FILE* out, const char* name, const Tally& t) {
    fprintf(out, "  %-26s %5d  reach ok %4d MISS %3d (%4s)  replay ok %4d WRONG %3d (%4s)  false catches %3d of %4d  chirps kept %3d broken %3d other %3d\n",
            name, t.n, t.reach_ok, t.reach_miss, Pct(t.reach_ok, t.reach_ok + t.reach_miss).c_str(), t.replay_ok, t.replay_wrong,
            Pct(t.replay_ok, t.replay_ok + t.replay_wrong).c_str(), t.phantom_false, t.phantom_ok + t.phantom_false, t.claim_kept,
            t.claim_broken, t.claim_other);
}

// An earlier output's verdicts: key -> "reach replay claim".
std::map<std::string, std::string> LoadBaseline(const char* path) {
    std::map<std::string, std::string> b;
    std::ifstream in(path);
    std::string line;
    while (std::getline(in, line)) {
        if (line.rfind("mv ", 0) != 0) continue;
        std::istringstream s(line);
        std::string tag, key, level, kind, reach, replay, claim, phantom;
        s >> tag >> key >> level >> kind >> reach >> replay >> claim >> phantom;
        b[key] = reach + " " + replay + " " + claim + " " + (phantom == "|" ? std::string("-") : phantom);
    }
    return b;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 4) {
        printf("usage: movement_check <shank_access_geometry.txt> <movements.txt> <out.txt> [--baseline <old out.txt>]\n");
        return 2;
    }
    const char* baseline = nullptr;
    for (int i = 4; i + 1 < argc; ++i) {
        if (std::strcmp(argv[i], "--baseline") == 0) baseline = argv[i + 1];
    }
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_movement_check.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);
    wchar_t wpath[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wpath, MAX_PATH);
    if (level_geometry::Load(wpath) == 0) {
        printf("no levels in %s\n", argv[1]);
        return 1;
    }
    std::vector<Move> moves;
    {
        std::ifstream in(argv[2]);
        if (!in) {
            printf("can't read %s\n", argv[2]);
            return 1;
        }
        std::string line;
        while (std::getline(in, line)) {
            Move m;
            if (ParseMove(line, &m)) moves.push_back(m);
            else if (line.rfind("claim ", 0) == 0 && !moves.empty()) ParseClaim(line, &moves.back());
        }
    }
    FILE* out = nullptr;
    if (fopen_s(&out, argv[3], "w") != 0 || !out) {
        printf("can't write %s\n", argv[3]);
        return 1;
    }
    std::map<std::string, std::string> before;
    if (baseline) before = LoadBaseline(baseline);
    fprintf(out, "# B42-2 movement check (movement_check.exe; derived, never commit)\n");
    fprintf(out, "# mv <session>:<t> <level> <kind> <reach> <replay> <claim> <false catch> | <detail>\n");
    std::map<std::string, Tally> by_kind, by_level;
    Tally all;
    std::vector<std::string> changes;
    std::string current;
    std::vector<Target> swings;
    int skipped = 0;
    for (const Move& m : moves) {
        if (m.flags.find("superspeed") != std::string::npos || m.flags.find("warp") != std::string::npos) {
            ++skipped;
            continue;
        }
        if (m.level != current) {
            current = m.level;
            jump_model::SetInterceptors(nullptr);
            if (!level_geometry::SetLevel(m.level)) {
                jump_model::SetObstacles(nullptr);
                swings.clear();
                continue;
            }
            jump_model::SetObstacles(&level_geometry::Obstacles());
            swings.clear();
            for (const level_geometry::Feature& f : level_geometry::Features()) {
                if (f.type == "swing_point" && !f.points.empty()) swings.push_back(Target{jump_model::kSwing, f.points[0].first, f.points[0].second, 0, 0});
                if (f.type == "slide_pole" && f.points.size() >= 2) {  // (B48d)
                    Target p{jump_model::kPole, f.points[0].first, f.points[0].second, f.points[1].first, f.points[1].second};
                    p.slide = true;
                    swings.push_back(p);
                }
            }
            jump_model::SetInterceptors(&swings);
        }
        if (level_geometry::CurrentLevel() != m.level) {
            ++skipped;
            continue;
        }
        const Verdict v = Check(m);
        fprintf(out, "mv %s %s %s %s %s %s %s | %s\n", m.key.c_str(), m.level.c_str(), m.kind.c_str(), v.reach.c_str(), v.replay.c_str(),
                v.claim.c_str(), v.phantom.c_str(), v.detail.c_str());
        all.Add(v);
        by_kind[m.kind].Add(v);
        by_level[m.level].Add(v);
        if (baseline) {
            const auto it = before.find(m.key);
            const std::string now = v.reach + " " + v.replay + " " + v.claim + " " + v.phantom;
            if (it != before.end() && it->second != now) {
                changes.push_back(m.key + " " + m.level + " " + m.kind + ": " + it->second + " -> " + now);
            }
        }
    }
    jump_model::SetInterceptors(nullptr);
    jump_model::SetObstacles(nullptr);
    FILE* streams[] = {out, stdout};
    for (FILE* s : streams) {
        fprintf(s, "%s%u movements checked (%d skipped: super speed, warps, levels without geometry)\n", s == out ? "# " : "",
                static_cast<unsigned>(all.n), skipped);
        fprintf(s, "%sBy kind:\n", s == out ? "# " : "");
        for (const auto& kv : by_kind) PrintTally(s, kv.first.c_str(), kv.second);
        fprintf(s, "%sBy level:\n", s == out ? "# " : "");
        for (const auto& kv : by_level) PrintTally(s, kv.first.c_str(), kv.second);
        PrintTally(s, "all", all);
        if (baseline) {
            fprintf(s, "%s%u verdicts changed since %s (reach replay claim false-catch: before -> now):\n", s == out ? "# " : "",
                    static_cast<unsigned>(changes.size()), baseline);
            for (const std::string& c : changes) fprintf(s, "%s  %s\n", s == out ? "# " : "", c.c_str());
        }
    }
    fclose(out);
    return 0;
}
