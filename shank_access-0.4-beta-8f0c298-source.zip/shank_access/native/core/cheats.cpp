#include "cheats.h"

#include <windows.h>

#include <atomic>
#include <cctype>

#include "log.h"

namespace cheats {
namespace {

std::atomic<bool> g_master{false};
std::atomic<bool> g_chosen[kCount];
std::atomic<uintptr_t> g_byte[kCount];  // (god mode, super speed: the game's debug bytes)
std::atomic<bool> g_hook{false};
void (*g_on_change)() = nullptr;
const char* const kTags[2] = {"a11y_cheat_health", "a11y_cheat_grenades"};  // (make_windup_patch.py's rules)
const char* const kNames[kCount] = {"Infinite health", "Infinite grenades", "God mode", "Super speed"};
const unsigned kTagHashes[2] = {Hash(kTags[0]), Hash(kTags[1])};
const char* const kSpawnTags[kSpawnCount] = {"a11y_spawn_minigun", "a11y_spawn_flamethrower", "a11y_spawn_health",
                                             "a11y_spawn_grenades"};  // (make_windup_patch.py)
const char* const kSpawnNames[kSpawnCount] = {"minigun", "flamethrower", "health", "grenades"};
const char* const kSpawnLabels[kSpawnCount] = {"Minigun", "Flamethrower", "Health", "Grenades"};
const unsigned kSpawnHashes[kSpawnCount] = {Hash(kSpawnTags[0]), Hash(kSpawnTags[1]), Hash(kSpawnTags[2]), Hash(kSpawnTags[3])};
std::atomic<unsigned> g_spawn_ms[kSpawnCount];  // when asked (0 = not asked)
std::atomic<bool> g_held[kSpawnCount];          // B69: asked while the game wasn't in play

void Changed() {
    Apply();
    if (g_on_change) g_on_change();
}

}  // namespace

unsigned Hash(const char* name) {
    unsigned h = 0;
    for (const char* p = name; *p; ++p) h = h * 0x1003f + static_cast<unsigned char>(std::tolower(static_cast<unsigned char>(*p)));
    return h;
}

void SetMaster(bool on) {
    g_master = on;
    alog::Write("cheats: %s", on ? "on" : "off");
    Changed();
}

bool Master() { return g_master.load(std::memory_order_relaxed); }

void Set(Cheat c, bool chosen) {
    if (c < 0 || c >= kCount) return;
    g_chosen[c] = chosen;
    alog::Write("cheats: %s %s%s", kNames[c], chosen ? "chosen" : "not chosen", Master() ? "" : " (cheats off)");
    Changed();
}

bool Chosen(Cheat c) { return c >= 0 && c < kCount && g_chosen[c].load(std::memory_order_relaxed); }

bool On(Cheat c) { return Master() && Chosen(c); }

const char* Name(Cheat c) { return c >= 0 && c < kCount ? kNames[c] : ""; }

void SetDebugBytes(uintptr_t god_mode, uintptr_t super_speed) {
    g_byte[kGodMode] = god_mode;
    g_byte[kSuperSpeed] = super_speed;
}

void SetHookAvailable(bool installed) { g_hook = installed; }

bool Available(Cheat c) {
    if (c == kHealth || c == kGrenades) return g_hook.load();
    return c >= 0 && c < kCount && g_byte[c].load() != 0;
}

void Apply() {
    static const Cheat kBytes[] = {kGodMode, kSuperSpeed};
    for (Cheat c : kBytes) {
        const uintptr_t addr = g_byte[c].load();
        if (!addr) continue;
        volatile unsigned char* flag = reinterpret_cast<volatile unsigned char*>(addr);
        const unsigned char want = On(c) ? 1 : 0;
        if (*flag != want) {
            *flag = want;
            alog::Write("cheats: %s byte 0x%08x -> %d", kNames[c], static_cast<unsigned>(addr), want);
        }
    }
}

void SetOnChange(void (*fn)()) { g_on_change = fn; }

bool Answers(unsigned tag_hash) { return AnswersAt(tag_hash, GetTickCount()); }

bool AnswersAt(unsigned tag_hash, unsigned now_ms) {
    for (int c = 0; c < 2; ++c) {
        if (tag_hash == kTagHashes[c] && On(static_cast<Cheat>(c))) return true;
    }
    for (int s = 0; s < kSpawnCount; ++s) {
        if (tag_hash != kSpawnHashes[s]) continue;
        unsigned asked = g_spawn_ms[s].load();
        if (!asked) return false;
        const bool fresh = now_ms - asked <= kSpawnWindowMs;
        if (!g_spawn_ms[s].compare_exchange_strong(asked, 0)) return false;  // (another evaluation took it)
        alog::Write(fresh ? "cheats: spawning a %s pickup" : "cheats: the %s spawn lapsed (asked over 2 s ago)", kSpawnNames[s]);
        return fresh;
    }
    return false;
}

void HoldSpawn(Spawn s) {
    if (s < 0 || s >= kSpawnCount) return;
    g_held[s] = true;
    alog::Write("cheats: a %s pickup held until play", kSpawnNames[s]);
}

bool Held(Spawn s) { return s >= 0 && s < kSpawnCount && g_held[s].load(); }

void ReleaseHeld(unsigned now_ms) {
    for (int s = 0; s < kSpawnCount; ++s) {
        if (g_held[s].exchange(false)) AskSpawn(static_cast<Spawn>(s), now_ms);
    }
}

bool CancelHeld(Spawn s) {
    if (s < 0 || s >= kSpawnCount || !g_held[s].exchange(false)) return false;
    alog::Write("cheats: the held %s pickup cancelled", kSpawnNames[s]);
    return true;
}

void DropHeld() {
    for (int s = 0; s < kSpawnCount; ++s) {
        if (g_held[s].exchange(false)) alog::Write("cheats: the held %s pickup dropped (a level load)", kSpawnNames[s]);
    }
}

const char* SpawnName(Spawn s) { return s >= 0 && s < kSpawnCount ? kSpawnLabels[s] : ""; }
const char* SpawnKind(Spawn s) { return s >= 0 && s < kSpawnCount ? kSpawnNames[s] : ""; }

void AskSpawn(Spawn s, unsigned now_ms) {
    if (s < 0 || s >= kSpawnCount) return;
    g_spawn_ms[s] = now_ms ? now_ms : 1;
    alog::Write("cheats: a %s pickup asked for", kSpawnNames[s]);
}

}  // namespace cheats
