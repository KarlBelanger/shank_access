"""Extract accessibility-relevant data from Shank level scripts.

Reads data-pc/levels/<level>/<level>.lua (plain Lua tables written by Klei's
"Shanker" tool) and writes, per level:
  build/levels/<level>.json  - machine-readable (consumed by the mod later)
  build/levels/<level>.txt   - human-readable report, ordered left to right
plus build/levels/index.txt with a one-line summary per level.

Usage (repo root):
  .venv/Scripts/python tools/levels/extract_levels.py [--game-dir DIR] [--out DIR] [--all]
By default only campaign_* levels are processed; --all includes test/coop levels.
"""
import argparse
import glob
import hashlib
import json
import os
import re
import sys

from lupa import LuaRuntime

DEFAULT_GAME_DIR = os.environ.get("SHANK_GAME_DIR", r"C:/Program Files (x86)/Steam/steamapps/common/Shank")
PIXELS_PER_TILE = 64.0  # data/attributes/units.lua

# Prop categories. Keys are prop attribute names (data/attributes/props/<name>.lua).
# Refine as we learn; anything unlisted is reported as "other".
PROP_CATEGORIES = {
    "pickup": [
        "health_pickup", "grenadepickup", "itemmachete", "itemshotgun", "itemsword",
        "itemuzi", "itemminigun", "itemflamethrower", "itemgrenadelauncher",
    ],
    "hazard": [
        "meatgrinder", "meatgrinder_cold", "rockfall", "breaking_ceiling", "propane_tank",
        "explosive_barrel", "barrelflaming", "rocketspawner", "rocket", "guidedmissile",
        "livewire", "livewireground", "fire", "fire_med_cellar1", "fire_med_cellar2",
        "fire_med_cellar3", "fire_small_cellar1", "firetrap", "mine", "dynamite",
        "dynamiterock", "itemsteamventleft", "itemsteamventright", "itemsteamventup",
        "trainhazard", "hazard", "fall_hazard", "trash_compactor", "horizontalwaterjet",
        "oildump", "stompy", "train_meat",
    ],
    "breakable": [
        "crate", "diablo_crate", "diablo_crate2", "barrel", "barrel_break", "itembarrel",
        "vase", "window", "window2", "window3", "window_breaking_church",
        "window_breaking_church_coop2", "window_breaking_villa", "french_door_breaking",
        "doorbreakopen", "statue_break", "statue_gargoyle", "statue_pillar",
        "church_box_breaking", "table_2chairsb", "table_2chairsb_redlight", "table_2chairsf",
        "table_2chairsf_redlight", "table_3chairs", "table_3chairs_redlight", "table_4chairs",
        "table_4chairs_redlight", "rubble", "rubble_breaking", "gimp_cage", "door_bar",
        "barrier", "meatslab",
    ],
    "ambient": [
        "light", "bird", "bat", "bat_flying", "dove", "rat", "candles_church",
        "candles_redlight", "civilian_crowd_fg", "ambient_noise", "proxy", "rope", "death",
        "church_dome", "church_floor", "aaa_fx_test",
    ],
}
CATEGORY_OF = {name: cat for cat, names in PROP_CATEGORIES.items() for name in names}


def vec(t):
    if t is None:
        return None
    return [float(t[1]), float(t[2])]


def region(t):
    if t is None or t["Position"] is None:
        return None
    x, y = vec(t["Position"])
    w, h = vec(t["Size"]) if t["Size"] is not None else (0.0, 0.0)
    return {"x": x, "y": y, "w": w, "h": h}


def prop_tags(game_dir):
    """Tags declared directly in each prop attribute file (best effort, no inheritance)."""
    tags = {}
    for path in glob.glob(os.path.join(game_dir, "data", "attributes", "props", "*.lua")):
        text = open(path, encoding="latin-1").read()
        m = re.search(r"Tags\s*=\s*\{(.*?)\}", text, re.S)
        found = re.findall(r'"([^"]+)"|\[\[([^\]]+)\]\]', m.group(1)) if m else []
        tags[os.path.splitext(os.path.basename(path))[0].lower()] = [a or b for a, b in found]
    return tags


class Walker:
    """Walks nested action tables, recording items with the context they appear in."""

    def __init__(self, lua):
        self.is_table = lambda v: lua.eval("type")(v) == "table"
        self.out = {"props": [], "enemies": [], "pits": [], "damage_zones": [], "wind_zones": [],
                    "triggers": [], "bounds": [], "teleports": [], "tutorials": [], "type_counts": {}}

    def walk(self, t, ctx):
        if not self.is_table(t):
            return
        typ = t["Type"]
        if isinstance(typ, str):
            self.out["type_counts"][typ] = self.out["type_counts"].get(typ, 0) + 1
            self.record(typ, t, ctx)
            if typ in ("spawnregiontrigger", "spawntrigger"):
                name = t["TriggerName"] or t["TriggerText"] or "?"
                ctx = ctx + ["trigger:%s" % name]
            elif typ == "enemygeneratoraction":
                ctx = ctx + ["generator:%s" % (t["params"]["boundstag"] if t["params"] else "?")]
        for k, v in t.items():
            if self.is_table(v):
                self.walk(v, ctx + [str(k)] if k in ("Checkpoints",) else ctx)

    def has_type(self, t, typ):
        if not self.is_table(t):
            return False
        if t["Type"] == typ:
            return True
        return any(self.has_type(v, typ) for _, v in t.items() if self.is_table(v))

    def record(self, typ, t, ctx):
        where = "/".join(c for c in ctx if ":" in c or c.startswith("checkpoint")) or "level start"
        o = self.out
        if typ == "spawnprop":
            name = (t["proptype"] or "").lower()
            o["props"].append({"type": name, "category": CATEGORY_OF.get(name, "other"),
                               "pos": vec(t["offset"]), "context": where})
        elif typ == "spawncharacter":
            o["enemies"].append({"attributes": t["Attributes"], "pos": vec(t["Position"]),
                                 "init_state": t["InitState"], "context": where})
        elif typ == "addareaeffect":
            lo, hi = vec(t["lower"]), vec(t["upper"])
            zone = {"lower": lo, "upper": hi, "context": where,
                    "killevent": t["killevent"] or "", "healthrate": float(t["healthrate"] or 0),
                    "applytoplayer": bool(t["applytoplayer"])}
            if t["fatal"]:
                o["pits"].append(zone)
            elif zone["healthrate"] != 0:
                o["damage_zones"].append(zone)
            elif t["windspeed"]:
                zone.update(windspeed=float(t["windspeed"]), windangle=float(t["windangle"] or 0))
                o["wind_zones"].append(zone)
        elif typ in ("spawnregiontrigger", "spawntrigger"):
            # B29-6: a region that starts a boss fight (PushBossCamera) or a cinematic (a level's end: its cinematic, then
            # setgameover) when entered: a waypoint goal after its checkpoint
            enter = t["EnterActions"] if typ == "spawnregiontrigger" else None
            story = "boss" if self.has_type(enter, "PushBossCamera") else "cinematic" if self.has_type(enter, "playcinematic") else ""
            o["triggers"].append({"name": t["TriggerName"] or "", "text": t["TriggerText"] or "",
                                  "region": region(t["Region"]), "context": where, "story": story})
        elif typ == "setbounds":
            o["bounds"].append({"p1": vec(t["p1"]), "p2": vec(t["p2"]), "context": where})
        elif typ == "teleport":
            o["teleports"].append({k: (vec(v) if self.is_table(v) else v) for k, v in t.items()})
        elif typ == "tutorial":
            o["tutorials"].append({k: v for k, v in t.items() if not self.is_table(v)})


def extract_level(path):
    lua = LuaRuntime(unpack_returned_tuples=True)
    src = open(path, "rb").read()
    lua.execute(src.decode("latin-1"))
    g = lua.globals()
    w = Walker(lua)
    w.walk(g.Actions, [])
    checkpoints = []
    cps = g.Checkpoints
    if cps is not None:
        entries = []
        if cps["Initial"] is not None:
            entries.append(("Initial", cps["Initial"]))
        if cps["Checkpoints"] is not None:
            entries += [(str(k), v) for k, v in sorted(cps["Checkpoints"].items(), key=lambda kv: kv[0])]
        for key, cp in entries:
            checkpoints.append({"key": key, "name": cp["Name"] or key, "next": cp["Next"] or "",
                                "spawn": vec(cp["SpawnLocation0"]), "face_right": bool(cp["FaceRight"]),
                                "region": region(cp["Region"])})
            w.walk(cp["Actions"], ["checkpoint:%s" % (cp["Name"] or key)])
    data = {"level": os.path.splitext(os.path.basename(path))[0],
            "source_sha256": hashlib.sha256(src).hexdigest(),
            "pixels_per_tile": PIXELS_PER_TILE, "checkpoints": checkpoints}
    data.update(w.out)
    return data


def tiles(px):
    return px / PIXELS_PER_TILE


def fmt_pos(p):
    return "(%d, %d)" % (p[0], p[1]) if p else "(?)"


def report(d, tags):
    lines = []
    cats = {}
    for p in d["props"]:
        cats[p["category"]] = cats.get(p["category"], 0) + 1
    lines.append("Level: %s" % d["level"])
    lines.append("Coordinates are in pixels (%d px = 1 tile). x grows to the right. The y axis direction is "
                 "not yet confirmed." % PIXELS_PER_TILE)
    lines.append("Summary: %d checkpoints, %d deadly pits, %d damage zones, %d pickups, %d hazards, "
                 "%d breakables, %d enemy spawns."
                 % (len(d["checkpoints"]), len(d["pits"]), len(d["damage_zones"]), cats.get("pickup", 0),
                    cats.get("hazard", 0), cats.get("breakable", 0), len(d["enemies"])))
    lines.append("")
    lines.append("Checkpoints:")
    for cp in d["checkpoints"]:
        lines.append("  - %s: spawn %s, facing %s. Next: %s"
                     % (cp["name"], fmt_pos(cp["spawn"]), "right" if cp["face_right"] else "left", cp["next"] or "-"))
    lines.append("")
    lines.append("Deadly pits (left to right):")
    for z in sorted(d["pits"], key=lambda z: z["lower"][0]):
        width = z["upper"][0] - z["lower"][0]
        lines.append("  - x %d to %d (%.0f tiles wide), y %d to %d. Kill event: %s. [%s]"
                     % (z["lower"][0], z["upper"][0], tiles(width), z["lower"][1], z["upper"][1],
                        z["killevent"] or "-", z["context"]))
    if not d["pits"]:
        lines.append("  none")
    if d["damage_zones"]:
        lines.append("")
        lines.append("Damage zones:")
        for z in sorted(d["damage_zones"], key=lambda z: z["lower"][0]):
            lines.append("  - x %d to %d, y %d to %d, health rate %g. [%s]"
                         % (z["lower"][0], z["upper"][0], z["lower"][1], z["upper"][1], z["healthrate"], z["context"]))
    for cat in ("pickup", "hazard", "breakable", "other"):
        items = sorted((p for p in d["props"] if p["category"] == cat and p["pos"]), key=lambda p: p["pos"][0])
        if not items:
            continue
        lines.append("")
        lines.append("%s (%d), left to right:" % ({"pickup": "Pickups", "hazard": "Hazards",
                                                   "breakable": "Breakables", "other": "Other props"}[cat], len(items)))
        for p in items:
            extra = " tags=%s" % ",".join(tags.get(p["type"], [])) if tags.get(p["type"]) else ""
            lines.append("  - %s at %s%s [%s]" % (p["type"], fmt_pos(p["pos"]), extra, p["context"]))
    lines.append("")
    lines.append("Enemy spawns: %d. By type:" % len(d["enemies"]))
    by = {}
    for e in d["enemies"]:
        by[e["attributes"]] = by.get(e["attributes"], 0) + 1
    for name, n in sorted(by.items(), key=lambda kv: -kv[1]):
        lines.append("  - %s x%d" % (name, n))
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--game-dir", default=DEFAULT_GAME_DIR)
    ap.add_argument("--out", default=os.path.join("build", "levels"))
    ap.add_argument("--all", action="store_true", help="include non-campaign levels")
    args = ap.parse_args()

    level_root = os.path.join(args.game_dir, "data-pc", "levels")
    paths = sorted(glob.glob(os.path.join(level_root, "*", "*.lua")))
    if not args.all:
        paths = [p for p in paths if os.path.basename(p).startswith("campaign_")]
    if not paths:
        print("No level files found under", level_root, file=sys.stderr)
        return 1
    os.makedirs(args.out, exist_ok=True)
    tags = prop_tags(args.game_dir)
    index = []
    for path in paths:
        d = extract_level(path)
        base = os.path.join(args.out, d["level"])
        with open(base + ".json", "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1)
        with open(base + ".txt", "w", encoding="utf-8") as f:
            f.write(report(d, tags))
        pickups = sum(1 for p in d["props"] if p["category"] == "pickup")
        hazards = sum(1 for p in d["props"] if p["category"] == "hazard")
        index.append("%-34s checkpoints %2d  pits %2d  damage zones %2d  pickups %3d  hazards %3d  enemies %3d"
                     % (d["level"], len(d["checkpoints"]), len(d["pits"]), len(d["damage_zones"]),
                        pickups, hazards, len(d["enemies"])))
    with open(os.path.join(args.out, "index.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(index) + "\n")
    print("\n".join(index))
    print("Wrote %d levels to %s" % (len(paths), args.out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
