#pragma once
// B4 (G4/G6): the level geometry the DLL uses for edge and traversal cues. Loaded from
// bin/shank_access_geometry.txt, generated offline from the game's own collision files by
// tools/levels/geometry.py (never committed). Pixels, y up, 64 px = 1 tile. Shank's position is his
// feet + 32 px: standing on a floor at y 192 he is at y 224 (RE-NOTES "Levels").
#include <string>
#include <utility>
#include <vector>

#include "jump_model.h"

namespace level_geometry {

struct End {
    enum Type { kWall, kStep, kDrop } type = kDrop;
    float value = -1;     // wall/step height, or drop depth (-1 = nothing below)
    bool deadly = false;  // the fall lands in a fatal pit zone, or there's nothing below
    bool climbable = false;  // a wall he can run up (no `noclimb` on its lowest piece; "cwall" in the file)
    bool gap = false;        // B15-6: a drop with a floor close across that running carries him over ("gap" in the file)
};

// A wall as a vertical run (B5): met moving right if facing_left (solid to its right), else moving left.
struct Wall {
    bool faces_left = true;
    float x = 0, y1 = 0, y2 = 0;  // y1 < y2
    bool climbable = false;
};

struct Surface {
    int id = 0;
    std::string tags;  // e.g. "skinny,nosplat" or ""
    End left, right;
    std::vector<std::pair<float, float>> points;  // left to right
};

struct Feature {
    std::string type;  // swing_point, wallrun_zone (min, max corners), pole, slide_pole, shimmy_line
    std::vector<std::pair<float, float>> points;
};

// Loads every level's section (the whole file). Returns the number of levels.
size_t Load(const std::wstring& path);
size_t LoadFromString(const std::string& text);

// Selects the level by the game's name for it ("campaign_1a_wrestlingring", or a path ending in it).
// False if the file has no such level (then the queries find nothing).
bool SetLevel(const std::string& game_name);
std::string CurrentLevel();
// Every level in the loaded file (B6-6 audit).
std::vector<std::string> LevelNames();

constexpr float kFeetOffset = 32.f;   // Shank's y minus the floor's
constexpr float kStandTolerance = 24.f;

// The surface Shank stands on at (x, y), or nullptr (in the air, or no geometry).
const Surface* SurfaceUnder(float x, float y);

struct Ahead {
    bool found = false;
    float distance = 0;  // pixels along x to the end, in the facing direction
    End end;
    float end_x = 0, end_y = 0;
    int surface = -1;
};
Ahead EdgeAhead(float x, float y, bool facing_right);

const std::vector<Feature>& Features();
const std::vector<Surface>& Surfaces();
const std::vector<Wall>& Walls();

// B6-4: what stops a jump in the current level (walls by their solid side, ceilings from `ceil` lines,
// surfaces as floors), for jump_model::SetObstacles.
const std::vector<jump_model::Obstacle>& Obstacles();

// B7b: is the straight line from (x0, y0) to (x1, y1) clear of every wall, ceiling and floor? (A shot's path.)
bool LineClear(float x0, float y0, float x1, float y1);

// B10-1: the level's checkpoints in play order (`checkpoint` lines, from the level data): where he respawns, and the
// trigger rectangle that makes it the current one (corner and size; none for the level's start).
struct Checkpoint {
    int order = 0;
    float spawn_x = 0, spawn_y = 0;
    bool has_region = false;
    float rx = 0, ry = 0, rw = 0, rh = 0;
    std::string name;
};
const std::vector<Checkpoint>& Checkpoints();

// B29-2: the game's chapters (Story Mode sublevels, campaigns.lua): the one starting at checkpoint `checkpoint` (0 = the
// level's start), in play order (`chapter` lines).
struct Chapter {
    int checkpoint = 0;
    std::string name;
};
const std::vector<Chapter>& Chapters();

// B29-6: a region that starts a boss fight (`boss`: its camera) or a cinematic (`cinematic`: a boss intro, the level's
// end) when entered; a waypoint goal after checkpoint `after` (`goal` lines, each checkpoint's nearest first).
struct Goal {
    int after = 0;
    float rx = 0, ry = 0, rw = 0, rh = 0;
    std::string kind;
};
const std::vector<Goal>& Goals();

// B6-2: fatal pit zones (min and max corners; `pit` lines).
struct Pit {
    float x1 = 0, y1 = 0, x2 = 0, y2 = 0;
};
const std::vector<Pit>& Pits();
// Does a fall at x from y_top down to y_bottom pass through a fatal pit zone? (geometry.py's in_pit)
bool PitAcross(float x, float y_top, float y_bottom);
// B6-7: is (x, y) (a floor point) inside a fatal pit zone (or its floor, 32 px below)? Not a place to land.
bool InPit(float x, float y);
// The climbable wall Shank clings to at (x, y), or nullptr: in the air, his centre about his radius from
// the wall (on the open side), within its height.
const Wall* WallBeside(float x, float y);
constexpr float kWallClingPx = 56.f;  // |x - wall| at most this (his radius 32 + slack)

}  // namespace level_geometry
