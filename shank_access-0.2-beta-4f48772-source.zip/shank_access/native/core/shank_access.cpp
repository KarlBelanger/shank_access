// shank_access.dll: the mod's native layer, loaded by the dinput8.dll proxy.
// Opens a11y.log, starts speech (Tolk) and hotkeys, verifies the Shank.exe build, then installs
// the patches and hooks.
#include <windows.h>
#include <objbase.h>

#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <sstream>
#include <string>

#include "announce.h"
#include "audio.h"
#include "config.h"
#include "cues.h"
#include "edge_guard.h"
#include "enemies.h"
#include "pathing.h"
#include "exe_check.h"
#include "mod_state.h"
#include "focus_window.h"
#include "game_pads.h"
#include "hotkeys.h"
#include "input_block.h"
#include "level_geometry.h"
#include "checkpoint_jump.h"
#include "level_hooks.h"
#include "localization.h"
#include "MinHook.h"
#include "log.h"
#include "session_logs.h"
#include "marks.h"
#include "menu_reader.h"
#include "mod_menu.h"
#include "patches.h"
#include "position.h"
#include "sound_hooks.h"
#include "status.h"
#include "speech.h"
#include "test_mode.h"
#include "ui_text.h"
#include "ui_hooks.h"

namespace {

bool g_enabled = false;

// The game closing (any path: Exit Game, Alt+F4, the window closing) ends in ExitProcess. Say
// "Exiting" and mute everything after it, so a late menu announcement isn't the last thing heard.
using ExitProcessFn = void(WINAPI*)(UINT);
ExitProcessFn g_orig_exit_process = nullptr;
std::wstring g_root;            // the game folder (set first in ShankAccess_Init)
volatile LONG g_marked = 0;     // B38-4: an F2 mark this session (a release build saves the logs at exit)

void WINAPI HookExitProcess(UINT code) {
    alog::Write("ExitProcess(%u): the game is closing", code);
#ifdef SHANK_ACCESS_RELEASE
    if (InterlockedCompareExchange(&g_marked, 0, 0)) alog::SaveSession(g_root, true);  // (B38-4: only with a mark; B38-4d: final, the marks flushed)
#endif
    speech::SayFinal("Exiting", 1500);
    audio::StopForExit();  // B20-6: our sound engine stops while its thread still runs
    alog::Write("exit: handing over to the game's ExitProcess");
    g_orig_exit_process(code);
}

bool HookExit() {
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) return false;
    void* target = nullptr;
    st = MH_CreateHookApiEx(L"kernel32", "ExitProcess", reinterpret_cast<void*>(&HookExitProcess),
                            reinterpret_cast<void**>(&g_orig_exit_process), &target);
    if (st == MH_OK) st = MH_EnableHook(target);
    alog::Write("hook ExitProcess: %s", st == MH_OK ? "installed" : MH_StatusToString(st));
    return st == MH_OK;
}

// Phase 4: our cue sounds. XAudio2 is started on this thread (with its own COM apartment, away from
// the game's threads); every 15 ms the cue logic says what to play, from Shank's position (the B4
// tracker: live reads between the Lua pings) and the level geometry. The position tracker's memory
// scans run here too.
// B5-2: the arena/checkpoint bounds in force, for the cues and the P/T summaries.
void SetCueArea() {
    const level_hooks::Bounds b = level_hooks::CurrentBounds();
    cues::Area area;
    area.known = b.known;
    area.min_x = b.min_x;
    area.min_y = b.min_y;
    area.max_x = b.max_x;
    area.max_y = b.max_y;
    area.arena = b.known && !b.is_default;  // B36b-2
    // B28b (mark 3, 2-c: the grenade pickup went silent during a fight, outside the live bounds, which the log didn't
    // show: only the bounds actions are logged): log the live bounds whenever they change.
    static cues::Area last;
    if (area.known != last.known || area.min_x != last.min_x || area.max_x != last.max_x || area.min_y != last.min_y ||
        area.max_y != last.max_y) {
        if (area.known) alog::Write("bounds: live x %.0f..%.0f, y %.0f..%.0f", area.min_x, area.max_x, area.min_y, area.max_y);
        last = area;
    }
    cues::SetArea(area);
}

// B5-3 calibration: while Shank's live height changes (jumps, falls, climbs), log his position at most
// every 30 ms: "traj: <ms> <x> <y>". The arcs give the real gravity and air speeds for the jump model.
// B5b: what the cue player actually played, every 5 s (only if something did): proof for the logs.
void CountPlay(int sound, unsigned now_ms) {
    static int counts[audio::kSoundCount] = {};
    static unsigned since = 0;
    if (sound >= 0 && sound < audio::kSoundCount) ++counts[sound];
    if (!since) since = now_ms;
    if (now_ms - since < 5000) return;
    static const char* const kNames[] = {"drop", "wall", "pickup", "inreach", "deadly", "target", "jumpnow",
                                         "hazardfall", "hazardprojectile", "hazardexplosive",
                                         "enemymedium", "enemylarge", "enemygirl", "enemydog", "enemyboss",
                                         "enemymedium-behind", "enemylarge-behind", "enemygirl-behind", "enemydog-behind",
                                         "enemyboss-behind", "heavyattack", "lockinline", "enemypass", "waypoint", "opening", "locktick", "grabattack",
                                         "hazardfire", "enemyaim", "pickupitem", "gap", "turn", "targetdown", "setup"};
    static_assert(sizeof kNames / sizeof kNames[0] == audio::kSoundCount, "a name for every sound");
    char line[256] = "";
    int len = 0;
    for (int i = 0; i < audio::kSoundCount; ++i) {
        if (counts[i]) len += _snprintf_s(line + len, sizeof line - len, _TRUNCATE, " %s %d", kNames[i], counts[i]);
        counts[i] = 0;
    }
    if (len) alog::Write("cues: played in 5 s:%s", line);
    since = now_ms;
}

void LogQuiet(bool quiet, bool known) {
    static int last = -1;
    const int state = quiet ? 0 : known ? 1 : 2;
    if (state == last) return;
    last = state;
    alog::Write("cues: %s", state == 0 ? "quiet (menu, pause or another window)" : state == 1 ? "active" : "no position");
}

void LogTrajectory(const position::Pos& pos, unsigned now_ms) {
    static float last_y = 0;
    static unsigned last_ms = 0;
    if (!pos.live) return;
    if (std::fabs(pos.y - last_y) >= 1.f && now_ms - last_ms >= 30) {
        alog::Write("traj: %u %.1f %.1f", now_ms, pos.x, pos.y);
        last_ms = now_ms;
    }
    last_y = pos.y;
}

// B29-3 (the user: "Some levels ... load for a second before the cutscene plays, triggering audio cues"; the B27 log: 4-a's
// intro video played 16 s with the cues on): the game's video player (gameMovie*) playing a video = quiet.
volatile LONG g_video_playing = 0;
constexpr DWORD kChapterTutorialMs = 2000;  // B29-2: a tutorial this recent is said again after the chapter

// B29-2: the last automatic message from the menu reader (a tutorial pop-up), so the chapter's name can go first.
SRWLOCK g_recent_auto_lock = SRWLOCK_INIT;
std::string g_recent_auto;
DWORD g_recent_auto_ms = 0;

DWORD WINAPI CueThread(LPVOID volume_percent) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);  // for the thread's life (it runs until the game exits)
    const bool ok = audio::Start();
    audio::SetMasterVolume(static_cast<float>(reinterpret_cast<INT_PTR>(volume_percent)) / 100.f);
    alog::Write("cues: thread started (audio %s)", ok ? "on" : "off");
    for (;;) {
        if (!mod_state::Active()) {  // B38-3 (F11): no cues, scans or pan; the game's camera pan again
            sound_hooks::SetShankCentre(false, 0.f, 0.f);
            Sleep(30);
            continue;
        }
        position::Work(GetTickCount());
        SetCueArea();
        const position::Pos pos = position::Current(GetTickCount());
        LogTrajectory(pos, GetTickCount());
        edge_guard::Update(GetTickCount(), pos);  // B7 safe edges (the hook answers from this)
        enemies::Update(GetTickCount(), pos);     // B8: the enemies from the game's item manager
        sound_hooks::SetShankCentre(pos.known, pos.x, pos.y);  // B8f: the game's sounds pan around him
        // B5b: silent while paused / in a menu or dialog / alt-tabbed (and, via the ping, out of a level).
        const bool quiet = !hotkeys::GameIsForeground() || menu_reader::MenuActive() || mod_menu::IsOpen() ||  // (B13-2: our settings menu too)
                           InterlockedCompareExchange(&g_video_playing, 0, 0) != 0;  // (B29-3: a cutscene video)
        LogQuiet(quiet, pos.known);
        if (quiet) {
            Sleep(15);
            continue;
        }
        const cues::Output out = cues::Tick(GetTickCount(), pos);
        for (const cues::PlayCmd& p : out.plays) {
            audio::Play(p.sound, p.pan, p.semitones, p.volume);
            CountPlay(p.sound, GetTickCount());
        }
        if (!out.chapter.empty()) {  // B29-2: the chapter first; a tutorial said just before it again after it
            speech::Say(out.chapter, true, speech::kAuto);
            AcquireSRWLockShared(&g_recent_auto_lock);
            const std::string recent = GetTickCount() - g_recent_auto_ms <= kChapterTutorialMs ? g_recent_auto : std::string();
            ReleaseSRWLockShared(&g_recent_auto_lock);
            if (!recent.empty()) speech::Say(recent, false, speech::kAuto);
        }
        if (!out.say_now.empty()) speech::Say(out.say_now, true, speech::kAuto);  // B9c: a boss's button prompt, at once
        if (!out.say.empty()) speech::Say(out.say, false, speech::kAuto);
        Sleep(15);
    }
}

void StartCueThread(int volume_percent) {
    HANDLE t = CreateThread(nullptr, 0, CueThread, reinterpret_cast<LPVOID>(static_cast<INT_PTR>(volume_percent)), 0, nullptr);
    if (t) CloseHandle(t);
}

// B16: text from the menu reader: menu reading, or an automatic announcement (tips, tutorials, unlock banners).
void MenuSay(const std::string& text) {
    const bool automatic = menu_reader::TakeAutomatic();
    if (automatic) {  // B29-2
        AcquireSRWLockExclusive(&g_recent_auto_lock);
        g_recent_auto = text;
        g_recent_auto_ms = GetTickCount();
        ReleaseSRWLockExclusive(&g_recent_auto_lock);
    }
    speech::Say(text, true, automatic ? speech::kAuto : speech::kMenu);
}

// B14: the level loaded (for the feedback marks' context).
SRWLOCK g_level_lock = SRWLOCK_INIT;
std::string g_level_name;

// B30-4: a pointOfInterest GUI sound waiting to see whether a tutorial screen comes with it; the grenade tutorial said.
volatile LONG g_poi_ms = 0;
constexpr DWORD kPoiScreenWaitMs = 400;
bool g_grenade_tutorial_said = false;  // (once per level load)

// An automatic message of our own (not from a screen), like a tutorial: the automatic channel, F8 repeats it.
void MenuSayAutomatic(const std::string& text) {
    AcquireSRWLockExclusive(&g_recent_auto_lock);
    g_recent_auto = text;
    g_recent_auto_ms = GetTickCount();
    ReleaseSRWLockExclusive(&g_recent_auto_lock);
    speech::Say(text, true, speech::kAuto);
}
void SetLevelName(const char* name) {
    AcquireSRWLockExclusive(&g_level_lock);
    g_level_name = name ? name : "";
    ReleaseSRWLockExclusive(&g_level_lock);
}

// B14: one line of context for a feedback mark: where Shank is and what the mod was telling him.
std::string MarkContext() {
    AcquireSRWLockShared(&g_level_lock);
    std::string text = "level " + (g_level_name.empty() ? std::string("(none)") : g_level_name);
    ReleaseSRWLockShared(&g_level_lock);
    const position::Pos p = position::Current(GetTickCount());
    char pos[96];
    if (p.known) snprintf(pos, sizeof(pos), "; Shank at (%.0f, %.0f) facing %s", p.x, p.y, p.facing_right ? "right" : "left");
    else snprintf(pos, sizeof(pos), "; Shank's position unknown");
    text += pos;
    text += "; " + status::HealthText();
    text += std::string("; waypoint ") + (cues::WaypointOn() ? "on" : "off") + ", safe edges " + (edge_guard::Enabled() ? "on" : "off");
    if (p.known) text += "; Q: " + cues::NextMove(p);
    text += "; last said: \"" + speech::Last() + "\"";
    return text;
}

// B13-2: the settings as loaded, changed by the settings menu; saved to shank_access_user.ini.
config::Settings g_settings;
std::wstring g_user_ini;

// A key the player can rebind (its saved key, or the default).
void Bind(const char* id, int default_vk, const char* label, void (*action)()) {
    const auto it = g_settings.keys.find(id);
    hotkeys::AddBindable(id, default_vk, it != g_settings.keys.end() ? it->second : default_vk, label, action);
    // B39: its controller binding; B40b (the user: "Bind the back button to mod menu by default"): Back opens the mod menu,
    // the rest none by default.
    const auto pad = g_settings.pads.find(id);
    const unsigned default_pad = std::strcmp(id, "settings") == 0 ? hotkeys::kPadBack : 0u;
    const unsigned use = pad != g_settings.pads.end() ? pad->second : default_pad;
    if (use) hotkeys::SetPad(id, use);
}

// B37-1 (the user, 2026-09-30: "I want to leave the key in, just tie its setting in with C and disable the key with test mode
// off"): with test mode off the enemy cues pan the way C pans the game sounds; in test mode ; keeps its own toggle.
void SyncEnemyPan() {
    if (!test_mode::On()) cues::SetEnemyCameraPan(!sound_hooks::PanAroundShank());
}

void SaveSettings() {
    g_settings.pan_around_shank = sound_hooks::PanAroundShank();
    g_settings.safe_edges = edge_guard::Enabled();
    for (int k = 0; k < announce::kCount; ++k) {
        const auto kind = static_cast<announce::Kind>(k);
        g_settings.announce[announce::IniKey(kind)] = announce::On(kind);
    }
    for (int c = 0; c < speech::kChannelCount; ++c) {  // B16
        g_settings.speech_engine[c] = speech::EngineOf(static_cast<speech::Channel>(c)) == speech::kSapi ? 1 : 0;
    }
    g_settings.sapi_voice = speech::SapiVoice();
    g_settings.sapi_rate = speech::SapiRate();
    g_settings.sapi_volume = speech::SapiVolume();
    g_settings.keys.clear();
    g_settings.pads.clear();
    for (const hotkeys::Binding& b : hotkeys::Bindings()) {
        g_settings.keys[b.id] = b.vk;
        if (b.pad || g_settings.pads.count(b.id) || b.id == "settings") g_settings.pads[b.id] = b.pad;  // B39 (0 = cleared)
        if (b.id == "settings") menu_reader::SetSettingsKeyName(hotkeys::KeyName(b.vk));
    }
    config::Save(g_user_ini, g_settings);
}

// Shank.exe lives in <game>/bin; logs go to <game>, next to the game's own logs.
std::wstring GameRoot(const std::wstring& exe_path) {
    std::wstring dir = exe_path.substr(0, exe_path.find_last_of(L"\\/"));
    return dir.substr(0, dir.find_last_of(L"\\/"));
}

}  // namespace

extern "C" __declspec(dllexport) void __cdecl ShankAccess_Init() {
    static volatile LONG once = 0;
    if (InterlockedExchange(&once, 1)) return;

    wchar_t exe[MAX_PATH];
    if (!GetModuleFileNameW(nullptr, exe, MAX_PATH)) return;
    const std::wstring root = GameRoot(exe);
    g_root = root;
    alog::Open((root + L"\\a11y.log").c_str());
    alog::Write("shank_access %s starting (thread %lu)", SHANK_ACCESS_VERSION, GetCurrentThreadId());

    char exe_utf8[MAX_PATH * 3];
    WideCharToMultiByte(CP_UTF8, 0, exe, -1, exe_utf8, sizeof exe_utf8, nullptr, nullptr);
    alog::Write("exe: %s (module base %p)", exe_utf8, GetModuleHandleW(nullptr));

    // Speech first, so a problem below can be announced, not just logged. Tolk.dll and the screen
    // reader client DLLs sit next to Shank.exe. SHANK_ACCESS_SILENT=1 (host-side tests) skips speech.
    const std::wstring bin_dir = std::wstring(exe).substr(0, std::wstring(exe).find_last_of(L"\\/"));
    wchar_t silent[8] = {};
    const bool speak = GetEnvironmentVariableW(L"SHANK_ACCESS_SILENT", silent, 8) == 0 || silent[0] != L'1';
    if (speak) {
        speech::Start(bin_dir);
        hotkeys::Start();
    } else {
        alog::Write("speech: disabled by SHANK_ACCESS_SILENT");
    }

    const std::string sha = Sha256File(exe);
    if (sha == kExpectedExeSha256) {
        g_enabled = true;
        alog::Write("exe sha256 OK: %s", sha.c_str());
    } else {
        alog::Write("exe sha256 MISMATCH: got '%s', expected '%s'. Mod disabled (addresses would be wrong).",
                   sha.c_str(), kExpectedExeSha256);
        speech::SayWhenGameReady("Shank access is disabled: this version of Shank is not supported.");
        return;
    }
    // B13-2: the deployed defaults, then the player's own choices from the settings menu. (B18: loaded before
    // the movie patches, which only apply in test mode.)
    g_user_ini = bin_dir + L"\\shank_access_user.ini";
    g_settings = config::Load(bin_dir + L"\\shank_access.ini", g_user_ini);
    const config::Settings& settings = g_settings;
#ifdef SHANK_ACCESS_RELEASE
    g_settings.test_mode = false;  // (B37-2: a release build has no test mode; an ini's test_mode is ignored)
#endif
    test_mode::SetOn(settings.test_mode);
    const bool skip_logo = settings.test_mode && patches::SkipLogoMovie();  // testing artifact (see patches.h)
    const bool skip_intro = settings.test_mode && patches::SkipIntroMovie();  // testing artifact
    sound_hooks::StartEarlyVolumeLog();  // B33: the music question: the game's volume settings from launch
    const bool hooks = sound_hooks::Install();
    const bool pan_hook = hooks && sound_hooks::InstallPanHook();  // B8f: game sounds pan around Shank
    sound_hooks::SetFrameCallback(&checkpoint_jump::OnGameFrame);  // B34 (test mode's checkpoint jump)
    if (hooks && sound_hooks::InstallVolumeHook()) {  // B30-3: some game sounds quieter ([sound] quieter=)
        std::vector<std::pair<std::string, float>> quieter;
        const std::string list = g_settings.quieter + ",";
        for (size_t at = 0, comma; (comma = list.find(',', at)) != std::string::npos; at = comma + 1) {
            const std::string item = list.substr(at, comma - at);
            const size_t colon = item.rfind(':');
            if (colon == std::string::npos || colon == 0) continue;
            const int percent = std::atoi(item.c_str() + colon + 1);
            if (percent > 0 && percent < 100) quieter.emplace_back(item.substr(0, colon), percent / 100.f);
        }
        sound_hooks::SetQuieter(quieter);
    }
    // Phase 2 menu reading: IDS_* labels are translated with the game's own English strings.
    const size_t strings = localization::Load(root + L"\\data\\bootstrap\\localization\\localization_en.xml");
    alog::Write("localization: %u strings loaded", static_cast<unsigned>(strings));
    // B13-1: the Credits screen's text, from the game's own credits.xml (read here, never shipped).
    {
        std::ifstream f(root + L"\\data-pc\\credits.xml", std::ios::binary);
        std::stringstream ss;
        if (f) ss << f.rdbuf();
        const std::string credits = menu_reader::CreditsFromXml(ss.str());
        menu_reader::SetCredits(credits);
        alog::Write("credits: %u characters", static_cast<unsigned>(credits.size()));
    }
    // Drawn UI text (How to Play explanations), extracted from the game's files at build time.
    const size_t ui_sections = ui_text::Load(bin_dir + L"\\shank_access_ui_text.txt");
    alog::Write("ui text: %u sections loaded", static_cast<unsigned>(ui_sections));
    // B4: the level geometry (generated from the game's collision files by tools/levels/geometry.py) and
    // the level hook that says which level is loaded.
    const size_t geometry_levels = level_geometry::Load(bin_dir + L"\\shank_access_geometry.txt");
    // B10: the traversal graph for waypoint mode (generated by native/tests/path_graph.cpp).
    const size_t path_levels = pathing::Load(bin_dir + L"\\shank_access_paths.txt");
    // B37-3: the game-derived files are made by shank-access-setup.exe on the player's machine: missing, say so at start.
    const std::wstring game_dir = bin_dir.substr(0, bin_dir.find_last_of(L"\\/"));
    const bool needs_setup = ui_sections == 0 || geometry_levels == 0 || path_levels == 0 ||
                             GetFileAttributesW((game_dir + L"\\data-pc\\stategraphs\\shank\\shank_transitions.lua").c_str()) ==
                                 INVALID_FILE_ATTRIBUTES;
    if (needs_setup) alog::Write("setup: the generated files are missing: run shank-access-setup.exe");
    // B8: the character and prop names (from the game's own attribute file names) for the enemy reader.
    enemies::LoadNames(root + L"\\data\\attributes\\characters");
    enemies::LoadPropNames(root + L"\\data\\attributes\\props");
    alog::Write("geometry: %u levels loaded", static_cast<unsigned>(geometry_levels));
    level_hooks::SetListener([](const char* name) {
        SetLevelName(name);  // B14: for the marks
        level_geometry::SetLevel(name);
        pathing::SetLevel(name);  // B10
        position::OnLevel();
        level_hooks::ForgetBounds();
        cues::Reset();
        checkpoint_jump::OnLevel();  // B34b: forget the simulation found by the scan
        InterlockedExchange(&g_video_playing, 0);  // B29-3 (a new level: its own video starts after the load)
        g_grenade_tutorial_said = false;  // B30-4
        InterlockedExchange(&g_poi_ms, 0);
        edge_guard::Reset();
        status::ForgetBosses();  // B7b
        enemies::OnLevel();      // B8
    });
    const bool level_hook = level_hooks::Install();
    const bool guard_hook = edge_guard::Install();  // B7 safe edges
    if (speak) {
        menu_reader::SetMovieAliveCheck([](void* movie) { return ui_hooks::MovieAlive(movie); });
        ui_hooks::SetEventListener([](const ui_hooks::UiEvent& event) {
            if (!mod_state::Active()) {  // B38-3 (F11 off): only the cutscene state is kept (the cues' quiet rule after it)
                if (event.type == ui_hooks::UiEvent::kInvoke && event.path && event.method && std::strstr(event.path, "gameMovie1")) {
                    if (std::strcmp(event.method, "playVideo") == 0) InterlockedExchange(&g_video_playing, 1);
                    if (std::strcmp(event.method, "stopVideo") == 0) InterlockedExchange(&g_video_playing, 0);
                }
                return;
            }
            static const menu_reader::Reader read = [](void* movie, const std::string& path) {
                return ui_hooks::ReadValue(movie, path.c_str());
            };
            if (event.type == ui_hooks::UiEvent::kValueSet && event.value) {
                // Phase 3: HUD values (health drops, grenade pickups, boss names); queued, not interrupting.
                if (event.path && std::strcmp(event.path, "_level0.HUD.enemyBoss.healthBar.value") == 0 &&
                    event.value->kind == ui_hooks::FlashValue::kNumber) {
                    cues::OnBossHealth(static_cast<float>(event.value->n));  // B29-4: a defeated boss leaves the cues
                }
                const std::string st = status::OnValue(event.path, *event.value, GetTickCount());
                if (!st.empty()) speech::Say(st, false, speech::kAuto);
            }
            if (event.type == ui_hooks::UiEvent::kFrame) {
                const std::string st = status::OnFrame(GetTickCount());  // pickup results (3-2)
                sound_hooks::PollVolumes(menu_reader::MenuActive() ? "menu" : "play");  // B32: the music volume log
                const DWORD poi = static_cast<DWORD>(InterlockedCompareExchange(&g_poi_ms, 0, 0));
                if (poi && GetTickCount() - poi >= kPoiScreenWaitMs) {  // B30-4: no tutorial screen came with it
                    InterlockedExchange(&g_poi_ms, 0);
                    AcquireSRWLockShared(&g_level_lock);
                    const bool first_level = g_level_name.find("campaign_1a_wrestlingring") != std::string::npos;
                    ReleaseSRWLockShared(&g_level_lock);
                    const unsigned shown = menu_reader::LastTutorialScreenMs();
                    if (first_level && !g_grenade_tutorial_said && (!shown || poi - shown > kPoiScreenWaitMs)) {
                        g_grenade_tutorial_said = true;
                        alog::Write("tutorial: the grenade tutorial (no screen of its own)");
                        MenuSayAutomatic("Tutorial: Grenades. Press Grenade to throw one. Enter by default.");
                    }
                }
                if (!st.empty()) speech::Say(st, false, speech::kAuto);
                const std::string said = menu_reader::OnFrame(GetTickCount(), read);
                if (!said.empty()) MenuSay(said);
                return;
            }
            if (event.type == ui_hooks::UiEvent::kScreenTick) {
                static const std::function<std::string(void*)> query = [](void* movie) {
                    return ui_hooks::QueryFocus(movie);
                };
                const std::string said = menu_reader::OnScreenTick(event.movie, GetTickCount(), read, query);
                if (!said.empty()) MenuSay(said);
                return;
            }
            if (event.type == ui_hooks::UiEvent::kScreenShown || event.type == ui_hooks::UiEvent::kScreenHidden) {
                const std::string said = menu_reader::OnScreen(event.type == ui_hooks::UiEvent::kScreenShown,
                                                               event.movie, GetTickCount(), read);
                if (!said.empty()) MenuSay(said);
                return;
            }
            // B29-3: the game's video player starting / stopping a cutscene video (the B28 log: "gameMovie1.playVideo()",
            // then "stopVideo()" when it ends or is skipped)
            // B30-2 (the user: "cues should not stop on any video which doesn't also pause play"): gameMovie1 plays the
            // cutscenes (the game time stops: the B29 log, 3-c's 3c_01); gameMovie0 plays short videos over play (1-a's
            // 1a_03 / 1a_04, 2-a's 2a_02, Toro's intro scene: game time 1.00 s per s, a fight going on): cues stay on.
            if (event.type == ui_hooks::UiEvent::kInvoke && event.path && event.method && std::strstr(event.path, "gameMovie1")) {
                const bool play = std::strcmp(event.method, "playVideo") == 0, stop = std::strcmp(event.method, "stopVideo") == 0;
                if (play || stop) {
                    if (InterlockedExchange(&g_video_playing, play ? 1 : 0) != (play ? 1 : 0)) {
                        alog::Write("cues: %s", play ? "quiet while a video plays" : "the video ended");
                    }
                }
            }
            if (event.type == ui_hooks::UiEvent::kInvoke) {
                void* symbol = event.symbol;
                const menu_reader::Asker ask = [symbol](const std::string& method) {
                    return ui_hooks::InvokeMethod(symbol, method.c_str());
                };
                const std::string said =
                    menu_reader::OnInvoke(event.path, event.method, *event.args, event.result, GetTickCount(), ask, event.movie);
                if (!said.empty()) MenuSay(said);
                return;
            }
            const std::string text =
                menu_reader::OnEvent(event.type, event.movie, event.path, GetTickCount(), read, event.value);
            if (text.empty()) return;
            if (menu_reader::Exiting()) speech::SayFinal(text, 0);  // "Exiting": the last thing heard
            else MenuSay(text);
        });
    }
    if (speak) {
        // Our own Lua messages (B3): "got_<kind>" = a pickup (3-2, speech; queued, not interrupting);
        // everything else (position, drops, walls, pickup beacons) feeds the Phase 4 cues.
        // B8b: the game's own sounds: Shank arming a gun sets the lock-on range.
        sound_hooks::SetSoundListener([](const char* name, float x, float y) {  // (B38-3: not called while off)
            if (position::IsShankOnlySound(name)) position::OnShankSound(x, y, GetTickCount());  // B28: checks the tracker
            cues::OnGameSound(name, x, y, GetTickCount());
            // B30-4 (mark 3, 1-a x ~13000: "point of interest sound with no announcement. Check for missing tutorial"): the
            // level's "Grenade tutorial" trigger plays pointOfInterest and starts a tracked tutorial (tutorialgrenades.gfx)
            // that marks a spot ahead and never opens a screen of its own; 1-a is the only level with one.
            if (name && std::strcmp(name, "Shank/Character/pointOfInterest") == 0 && x == 0.f && y == 0.f) {
                InterlockedExchange(&g_poi_ms, static_cast<LONG>(GetTickCount() | 1));
            }
        });
        sound_hooks::SetCueListener([](const char* cue, float x, float y) {
            if (std::strncmp(cue, "got_", 4) == 0) {
                cues::OnPickedUp(cue + 4, x, y);  // B8d: its beacon stops at once
                const std::string st = status::OnPickup(cue + 4, GetTickCount());
                if (!st.empty()) speech::Say(st, false, speech::kAuto);
            } else if (std::strncmp(cue, "pos_", 4) == 0) {
                position::OnPing(x, y, cue[4] == 'r', GetTickCount());  // B4 G5: the tracker's reference
            } else {
                cues::OnCue(cue, x, y, GetTickCount());
            }
        });
    }
    const bool ui = ui_hooks::Install();  // UI logging (1c) + focus labels (Phase 2)
    alog::Write("init complete: enabled=%d skip_logo=%d skip_intro=%d sound_hooks=%d ui_hooks=%d level_hook=%d",
                g_enabled ? 1 : 0, skip_logo ? 1 : 0, skip_intro ? 1 : 0, hooks ? 1 : 0, ui ? 1 : 0, level_hook ? 1 : 0);
    for (int k = 0; k < announce::kCount; ++k) {
        const auto it = settings.announce.find(announce::IniKey(static_cast<announce::Kind>(k)));
        if (it != settings.announce.end()) announce::Set(static_cast<announce::Kind>(k), it->second);
    }
    // B16: each speech channel's engine and our SAPI voice.
    for (int c = 0; c < speech::kChannelCount; ++c) {
        speech::SetEngine(static_cast<speech::Channel>(c), settings.speech_engine[c] ? speech::kSapi : speech::kScreenReader);
    }
    speech::SetSapiVoice(settings.sapi_voice);
    speech::SetSapiRate(settings.sapi_rate);
    speech::SetSapiVolume(settings.sapi_volume);
    const bool raw_hook = speak && input_block::Install();
    if (speak) test_mode::RegisterHotkeys();  // (B18: the test keys do nothing while test mode is off)
    // Test mode F4 (B3 lag check): our cue audio engine off/on, to see whether it costs frame rate.
    // B8f (the user, 2026-09-26): game sounds pan around Shank by default; C switches to the camera and back.
    sound_hooks::SetPanAroundShank(settings.pan_around_shank);
    SyncEnemyPan();
    if (speak) Bind("pan", 'C', "Sound panning", [] {  // (B38-1: the menu's wording)
        const bool shank = sound_hooks::TogglePanAroundShank();
        SyncEnemyPan();
        speech::Say(shank ? "Sound panning relative to Shank" : "Sound panning relative to camera");
    });
    if (!pan_hook) alog::Write("sound: the pan hook isn't installed; C has no effect");
    // B8e (test mode): ; flips the enemy cues between Shank-relative and the game's camera pan (the user wants
    // to compare them in play).
    cues::SetCameraPan(sound_hooks::CameraPan);
    if (speak) {
        hotkeys::Add(VK_OEM_1, "; (test mode: enemy pan)", [] {
            if (!test_mode::On()) return;
            speech::Say(cues::ToggleEnemyCameraPan() ? "Enemy pan like the game" : "Enemy pan around Shank");
        });
        hotkeys::Add(VK_F4, "F4 (test mode: cue audio)", [] {
            if (!test_mode::On()) return;
            speech::Say(audio::ToggleEnabled() ? "Cue audio on" : "Cue audio off");
        });
        // B18 (the user, 2026-09-27): F3 turns test mode on and off, saved for the next start. Off puts back what
        // the test keys changed; the movie skips follow the saved state at the next start.
#ifndef SHANK_ACCESS_RELEASE  // (B37-2: no F3 in a release build)
        Bind("test_mode", VK_F3, "Test mode", [] {
            const bool on = !test_mode::On();
            test_mode::SetOn(on);
            if (!on) {
                if (!audio::Enabled()) audio::ToggleEnabled();
                SyncEnemyPan();  // (B37-1: back to following C)
            }
            g_settings.test_mode = on;
            SaveSettings();
            speech::Say(on ? "Test mode on" : "Test mode off");
        });
#endif
    }
    if (speak) HookExit();
    // B38-3 (the user: "Add f11 to fully disable the mod ... The only thing the mod should do at this point is listen for
    // f11 and reactivate once it's pressed"): not rebindable, not saved.
    if (speak) hotkeys::Add(VK_F11, "F11 (Shank Access on / off)", [] {
        if (mod_state::Active()) {
            if (mod_menu::IsOpen()) mod_menu::Toggle();  // (closes it: input unblocked, the game's focus back)
            speech::Say("Shank Access off", true, speech::kMenu);
            alog::Write("mod: off (F11)");
            mod_state::SetActive(false);
        } else {
            mod_state::SetActive(true);
            alog::Write("mod: on (F11)");
            speech::Say("Shank Access on", true, speech::kMenu);
        }
    });
    // The user's keys (2026-09-26, B1): F8 repeats the last long message (a dialog, page, tutorial or
    // tip; not menu items or status); H = health; G = grenades. The game binds neither H nor G.
    if (speak) Bind("repeat_long", VK_F8, "Repeat long message", [] {
        const std::string last = menu_reader::LastLongMessage();
        speech::Say(last.empty() ? std::string("Nothing to repeat") : last);
    });
    if (speak) Bind("health", 'H', "Health", [] { speech::Say(status::HealthText()); });
    if (speak) Bind("grenades", 'G', "Grenades", [] { speech::Say(status::GrenadeText()); });
    // Phase 4 (B3): P lists the pickups nearby; the cue thread plays the positioned cue sounds.
    if (speak) Bind("pickups", 'P', "Pickups nearby", [] {
        SetCueArea();
        speech::Say(cues::PickupSummary(GetTickCount(), position::Current(GetTickCount())));
    });
    // B4 G7 (first version): T lists the nearest things to climb, swing on or run along.
    if (speak) Bind("traversal", 'T', "Traversal nearby", [] {
        SetCueArea();
        speech::Say(cues::TraversalSummary(position::Current(GetTickCount())));
    });
    // B10 (Phase 7, the user): W = waypoint mode; Q = the next move on the path.
    if (speak) Bind("waypoint", 'W', "Waypoint mode", [] {
        const position::Pos p = position::Current(GetTickCount());
        speech::Say(cues::ToggleWaypoint(p) ? "Waypoint on. " + cues::NextMove(p) : std::string("Waypoint off"));
    });
    if (speak) Bind("next_move", 'Q', "Next move", [] { speech::Say(cues::NextMove(position::Current(GetTickCount()))); });
    // B8 enemies: N lists the enemies nearby by side; L locks the enemy cue onto the nearest (again: off).
    if (speak) Bind("enemies", 'N', "Enemies nearby", [] { speech::Say(cues::EnemySummary(position::Current(GetTickCount()))); });
    // B8d: L cycles the lock through the enemies in the gun's range (nearest first, then off); K the special ones.
    if (speak) Bind("lock", 'L', "Lock on", [] { speech::Say(cues::LockNext(position::Current(GetTickCount()), false)); });
    if (speak) Bind("lock_special", 'K', "Lock on special enemies", [] { speech::Say(cues::LockNext(position::Current(GetTickCount()), true)); });
    // B7 safe edges (the user, 2026-09-26): E toggles; Shank stops at drops, another tap sends him over.
    if (guard_hook) edge_guard::SetEnabled(settings.safe_edges);
    if (speak && guard_hook) Bind("safe_edges", 'E', "Safe edges", [] {
        speech::Say(edge_guard::Toggle() ? "Safe edges on" : "Safe edges off");
    });
    if (speak && !guard_hook) Bind("safe_edges", 'E', "Safe edges", [] { speech::Say("Safe edges unavailable"); });
    // B13-2: the settings menu (F7; the key the user had before H and G, now free).
    if (speak) {
        mod_menu::Hooks mh;
        mh.get_volume = [] { return g_settings.cue_volume; };
        mh.set_volume = [](int v) {
            g_settings.cue_volume = v;
            audio::SetMasterVolume(v / 100.f);
        };
        mh.get_pan = [] { return sound_hooks::PanAroundShank(); };
        mh.set_pan = [](bool on) {
            sound_hooks::SetPanAroundShank(on);
            SyncEnemyPan();
        };
        if (guard_hook) {
            mh.get_safe_edges = [] { return edge_guard::Enabled(); };
            mh.set_safe_edges = [](bool on) { edge_guard::SetEnabled(on); };
        }
        mh.save = &SaveSettings;
        mh.say = [](const std::string& text) { speech::Say(text, true, speech::kMenu); };  // B17-1: a menu
        mh.block_input = [raw_hook](bool on) {
            if (raw_hook) input_block::SetBlocking(on);
        };
        mh.set_key_handler = [](void (*handler)(int)) { hotkeys::SetMenuHandler(handler); };
        mh.set_pad_handler = [](void (*handler)(unsigned)) { hotkeys::SetPadCaptureHandler(handler); };  // B39
        mh.game_pad_inputs = [] { return game_pads::BoundInputs(); };  // B40-4
        // B15-2 / B17-3: Learn sounds, by category (a group's first sound says the group's name).
        const char* group = "";
        for (const audio::LearnItem& it : audio::LearnOrder()) {
            const bool first = std::strcmp(group, it.group) != 0;
            group = it.group;
            mh.sounds.push_back((first ? std::string(it.group) + ": " : std::string()) + audio::Describe(it.sound));
        }
        mh.play_sound = [](size_t k) {
            const auto& order = audio::LearnOrder();
            if (k < order.size()) audio::Play(order[k].sound, 0.f, 0.f, 1.f);
        };
        // B16 speech settings.
        mh.get_engine = [](int c) { return speech::EngineOf(static_cast<speech::Channel>(c)) == speech::kSapi ? 1 : 0; };
        mh.set_engine = [](int c, int e) { speech::SetEngine(static_cast<speech::Channel>(c), e ? speech::kSapi : speech::kScreenReader); };
        mh.voices = [] { return speech::SapiVoices(); };
        mh.get_voice = [] { return speech::SapiVoice(); };
        mh.set_voice = [](const std::string& v) { speech::SetSapiVoice(v); };
        mh.get_rate = [] { return speech::SapiRate(); };
        mh.set_rate = [](int r) { speech::SetSapiRate(r); };
        mh.get_sapi_volume = [] { return speech::SapiVolume(); };
        mh.set_sapi_volume = [](int v) { speech::SetSapiVolume(v); };
        mh.sample = [](const std::string& text) { speech::SaySapiSample(text); };
        // B34: "Go to checkpoint" (test mode only; in a level): its checkpoints, and a restart at one on the game's thread.
        mh.test_mode = [] { return test_mode::On(); };
        // B34b (the user: "the go to checkpoint menu never appeared in the other side of the tracks chapter"): 1-b pre-train
        // had no bounds action yet, so no simulation; then it's found by its vtables. The list names the chapter a checkpoint
        // starts (the user: "the list showed checkpoints for both bad confession and bombs and bells at the same time").
        static const auto level_names = [] {
            std::vector<std::string> names;
            for (const auto& c : level_geometry::Checkpoints()) names.push_back(c.name);
            return names;
        };
        static const auto sim = [] {
            void* s = level_hooks::Simulation();
            return s ? s : checkpoint_jump::FindSimulation(level_names());
        };
        mh.checkpoints = [] {
            std::vector<std::string> shown;
            const auto names = level_names();
            if (names.empty() || !sim()) return shown;
            const auto& chapters = level_geometry::Chapters();
            for (size_t i = 0; i < names.size(); ++i) {
                std::string label = names[i];
                for (const auto& ch : chapters) {
                    if (ch.checkpoint == static_cast<int>(i)) label += ", the start of " + ch.name;
                }
                shown.push_back(label);
            }
            return shown;
        };
        mh.go_to_checkpoint = [](int i) {
            const auto names = level_names();
            if (i < 0 || i >= static_cast<int>(names.size())) return std::string("Not available");
            return checkpoint_jump::Request(sim(), names[i], names);
        };
        // B38-2: in play (Shank in a level, no game menu or cutscene up), a focused window of ours pauses the game.
        mh.pause_game = [] {
            const bool in_play = position::Current(GetTickCount()).known && !menu_reader::MenuActive() &&
                                 InterlockedCompareExchange(&g_video_playing, 0, 0) == 0 && hotkeys::GameIsForeground();
            return in_play && focus_window::Open(L"Shank Access mod menu", [] {  // B38-2b: drawn, the selection highlighted
                       const mod_menu::View v = mod_menu::CurrentView();
                       focus_window::Content c;
                       c.title = v.title;
                       c.lines = v.items;
                       c.selected = v.selected;
                       return c;
                   });
        };
        mh.resume_game = [] { focus_window::Close(); };
        mh.get_waypoint = [] { return cues::WaypointOn(); };  // B38-1
        mh.set_waypoint = [](bool on) {
            if (on != cues::WaypointOn()) cues::ToggleWaypoint(position::Current(GetTickCount()));
        };
        mod_menu::Init(mh);
        Bind("settings", VK_F7, "Mod menu", [] { mod_menu::Toggle(); });  // (B38-1: "call it the mod menu", the user)
        // B14 (the user, 2026-09-27): F2 marks a moment for feedback, with a comment box.
        marks::Hooks kh;
        kh.context = &MarkContext;
        kh.say = [](const std::string& text) { speech::Say(text); };
        kh.block_input = [raw_hook](bool on) {
            if (raw_hook) input_block::SetBlocking(on);
        };
        marks::Init(root + L"\\a11y_marks.log", kh);
        Bind("mark", VK_F2, "Mark", [] {
            marks::Mark();
            InterlockedExchange(&g_marked, 1);
#ifdef SHANK_ACCESS_RELEASE
            alog::SaveSession(g_root);  // (B38-4: saved now too, so a crash keeps the session; again at exit)
#endif
        });
        for (const hotkeys::Binding& b : hotkeys::Bindings()) {
            if (b.id == "settings") menu_reader::SetSettingsKeyName(hotkeys::KeyName(b.vk));
        }
    }
    if (speak) StartCueThread(settings.cue_volume);
    std::string hello = hooks ? "Shank access loaded." : "Shank access loaded, but its sound hooks failed. Check the log.";
    for (const hotkeys::Binding& b : hotkeys::Bindings()) {  // B13-2: where the settings are
        if (b.id == "settings") hello += " " + hotkeys::KeyName(b.vk) + " for the mod menu.";
    }
    if (settings.test_mode) hello += " Test mode on.";
    if (needs_setup) hello = "Shank Access needs setup. Close the game, run shank-access-setup.exe in the Shank folder, then start the game again.";
    speech::SayWhenGameReady(hello);
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(inst);
    return TRUE;
}
