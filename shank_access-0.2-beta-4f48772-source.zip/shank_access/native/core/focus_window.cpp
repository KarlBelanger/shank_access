#include "focus_window.h"

#include <windows.h>

#include "log.h"

namespace focus_window {
namespace {

SRWLOCK g_lock = SRWLOCK_INIT;
HWND g_hwnd = nullptr;
HANDLE g_ready = nullptr;  // set once the window has the focus (or gave up)
std::function<Content()> g_content;
Content g_shown;           // what the window last drew (window thread only)
HFONT g_font = nullptr, g_title_font = nullptr;
constexpr UINT_PTR kTimer = 1;
constexpr int kWidth = 640, kHeight = 560, kLineH = 30, kMargin = 16;

std::wstring Wide(const std::string& s) {
    if (s.empty()) return std::wstring();
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), nullptr, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), &w[0], n);
    return w;
}

void Paint(HWND hwnd) {
    PAINTSTRUCT ps;
    HDC dc = BeginPaint(hwnd, &ps);
    RECT client;
    GetClientRect(hwnd, &client);
    FillRect(dc, &client, GetSysColorBrush(COLOR_WINDOW));
    SetBkMode(dc, TRANSPARENT);
    HGDIOBJ old = SelectObject(dc, g_title_font);
    SetTextColor(dc, GetSysColor(COLOR_WINDOWTEXT));
    RECT r = {kMargin, kMargin, client.right - kMargin, kMargin + kLineH + 6};
    const std::wstring title = Wide(g_shown.title);
    DrawTextW(dc, title.c_str(), -1, &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);
    SelectObject(dc, g_font);
    const int top = r.bottom + 8;
    const int rows = (client.bottom - top - kMargin) / kLineH;
    const int n = static_cast<int>(g_shown.lines.size());
    int first = 0;  // (a long list scrolls to keep the selected item in view)
    if (rows > 0 && g_shown.selected >= rows) first = g_shown.selected - rows + 1;
    for (int i = first; i < n && i - first < rows; ++i) {
        RECT line = {kMargin, top + (i - first) * kLineH, client.right - kMargin, top + (i - first + 1) * kLineH};
        const bool sel = i == g_shown.selected;
        if (sel) FillRect(dc, &line, GetSysColorBrush(COLOR_HIGHLIGHT));
        SetTextColor(dc, GetSysColor(sel ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT));
        RECT text = line;
        text.left += 8;
        const std::wstring w = Wide(g_shown.lines[i]);
        DrawTextW(dc, w.c_str(), -1, &text, DT_LEFT | DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);
    }
    SelectObject(dc, old);
    EndPaint(hwnd, &ps);
}

void Refresh(HWND hwnd) {
    if (!g_content) return;
    const Content now = g_content();
    if (now == g_shown) return;
    g_shown = now;
    InvalidateRect(hwnd, nullptr, FALSE);
}

LRESULT CALLBACK Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_ACTIVATE:
            if (LOWORD(wp) != WA_INACTIVE && g_ready) SetEvent(g_ready);
            return 0;
        case WM_TIMER:
            if (wp == kTimer) Refresh(hwnd);
            return 0;
        case WM_ERASEBKGND:
            return 1;
        case WM_PAINT:
            Paint(hwnd);
            return 0;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            KillTimer(hwnd, kTimer);
            PostQuitMessage(0);
            return 0;
        default:
            return DefWindowProcW(hwnd, msg, wp, lp);
    }
}

struct Job {
    std::wstring title;
    HWND game;
};

DWORD WINAPI WindowThread(LPVOID p) {
    Job* job = static_cast<Job*>(p);
    static bool registered = false;
    HINSTANCE inst = GetModuleHandleW(nullptr);
    if (!registered) {
        WNDCLASSW wc = {};
        wc.lpfnWndProc = Proc;
        wc.hInstance = inst;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.lpszClassName = kClassName;
        registered = RegisterClassW(&wc) != 0 || GetLastError() == ERROR_CLASS_ALREADY_EXISTS;
    }
    if (!g_font) {
        g_font = CreateFontW(-22, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
        g_title_font = CreateFontW(-26, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    }
    g_shown = Content();
    if (g_content) g_shown = g_content();
    const int cx = GetSystemMetrics(SM_CXSCREEN), cy = GetSystemMetrics(SM_CYSCREEN);
    HWND hwnd = CreateWindowExW(WS_EX_TOPMOST, kClassName, job->title.c_str(), WS_POPUP | WS_CAPTION, (cx - kWidth) / 2,
                                (cy - kHeight) / 2, kWidth, kHeight, nullptr, nullptr, inst, nullptr);
    AcquireSRWLockExclusive(&g_lock);
    g_hwnd = hwnd;
    ReleaseSRWLockExclusive(&g_lock);
    if (!hwnd) {
        alog::Write("mod menu: the focus window couldn't be made (error %lu)", GetLastError());
        SetEvent(g_ready);
        delete job;
        return 0;
    }
    SetTimer(hwnd, kTimer, 100, nullptr);
    ShowWindow(hwnd, SW_SHOW);
    SetForegroundWindow(hwnd);
    SetFocus(hwnd);
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    AcquireSRWLockExclusive(&g_lock);
    g_hwnd = nullptr;
    ReleaseSRWLockExclusive(&g_lock);
    if (job->game) {  // back to the game (as after a mark)
        if (IsIconic(job->game)) ShowWindow(job->game, SW_RESTORE);
        SetForegroundWindow(job->game);
    }
    alog::Write("mod menu: the focus window closed; the game has the focus again");
    delete job;
    return 0;
}

}  // namespace

bool Open(const wchar_t* title, std::function<Content()> content) {
    if (IsOpen()) return true;
    if (!g_ready) g_ready = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    ResetEvent(g_ready);
    g_content = std::move(content);
    Job* job = new Job{title, GetForegroundWindow()};
    HANDLE t = CreateThread(nullptr, 0, WindowThread, job, 0, nullptr);
    if (!t) {
        delete job;
        return false;
    }
    CloseHandle(t);
    const bool active = WaitForSingleObject(g_ready, 1000) == WAIT_OBJECT_0;
    alog::Write("mod menu: the focus window %s (the game pauses)", active ? "has the focus" : "didn't get the focus in time");
    return IsOpen();
}

void Close() {
    AcquireSRWLockShared(&g_lock);
    HWND hwnd = g_hwnd;
    ReleaseSRWLockShared(&g_lock);
    if (hwnd) PostMessageW(hwnd, WM_CLOSE, 0, 0);
}

bool IsOpen() {
    AcquireSRWLockShared(&g_lock);
    const bool open = g_hwnd != nullptr;
    ReleaseSRWLockShared(&g_lock);
    return open;
}

}  // namespace focus_window
