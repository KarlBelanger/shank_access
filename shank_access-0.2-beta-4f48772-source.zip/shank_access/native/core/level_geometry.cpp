#include "level_geometry.h"

#include <windows.h>

#include <cmath>
#include <fstream>
#include <map>
#include <sstream>

#include "log.h"

namespace level_geometry {
namespace {

struct Level {
    std::vector<Surface> surfaces;
    std::vector<Feature> features;
    std::vector<Wall> walls;
    std::vector<jump_model::Obstacle> obstacles;
    std::vector<Pit> pits;
    std::vector<Checkpoint> checkpoints;  // B10-1
    std::vector<Chapter> chapters;        // B29-2
    std::vector<Goal> goals;              // B29-6
};

SRWLOCK g_lock = SRWLOCK_INIT;
std::map<std::string, Level> g_levels;
std::string g_current;
const Level* g_level = nullptr;
const std::vector<Feature> kNoFeatures;
const std::vector<Surface> kNoSurfaces;
const std::vector<Wall> kNoWalls;
const std::vector<jump_model::Obstacle> kNoObstacles;
const std::vector<Pit> kNoPits;
const std::vector<Checkpoint> kNoCheckpoints;
const std::vector<Chapter> kNoChapters;
const std::vector<Goal> kNoGoals;

// Walls, ceilings and floors of a level as jump obstacles.
void BuildObstacles(Level* level, const std::vector<jump_model::Obstacle>& ceilings) {
    level->obstacles = ceilings;
    for (const Wall& w : level->walls) {
        level->obstacles.push_back(jump_model::Obstacle{
            w.faces_left ? jump_model::Obstacle::kWallSolidRight : jump_model::Obstacle::kWallSolidLeft, w.x, w.y1, w.x, w.y2});
    }
    for (const Pit& p : level->pits) {  // B10b: flights into them die
        level->obstacles.push_back(jump_model::Obstacle{jump_model::Obstacle::kPit, p.x1, p.y1, p.x2, p.y2});
    }
    for (const Surface& s : level->surfaces) {
        for (size_t i = 0; i + 1 < s.points.size(); ++i) {
            level->obstacles.push_back(jump_model::Obstacle{jump_model::Obstacle::kFloor, s.points[i].first,
                                                            s.points[i].second, s.points[i + 1].first, s.points[i + 1].second});
        }
    }
}

bool ReadEnd(std::istringstream& in, End* e) {
    std::string type;
    int deadly = 0;
    if (!(in >> type >> e->value >> deadly)) return false;
    e->type = type == "wall" || type == "cwall" ? End::kWall : type == "step" ? End::kStep : End::kDrop;
    e->climbable = type == "cwall";
    e->gap = type == "gap";  // (B15-6: otherwise a drop)
    e->deadly = deadly != 0;
    return true;
}

bool ReadPoints(std::istringstream& in, std::vector<std::pair<float, float>>* pts) {
    int n = 0;
    if (!(in >> n) || n < 1 || n > 10000) return false;
    for (int i = 0; i < n; ++i) {
        float x, y;
        if (!(in >> x >> y)) return false;
        pts->emplace_back(x, y);
    }
    return true;
}

// "levels/campaign_1a_wrestlingring/campaign_1a_wrestlingring.slev" -> "campaign_1a_wrestlingring"
std::string BaseName(const std::string& name) {
    std::string s = name;
    const size_t slash = s.find_last_of("/\\");
    if (slash != std::string::npos) s = s.substr(slash + 1);
    const size_t dot = s.find('.');
    if (dot != std::string::npos) s = s.substr(0, dot);
    return s;
}

}  // namespace

size_t LoadFromString(const std::string& text) {
    std::map<std::string, Level> levels;
    std::map<std::string, std::vector<jump_model::Obstacle>> ceilings;
    Level* cur = nullptr;
    std::vector<jump_model::Obstacle>* cur_ceil = nullptr;
    std::istringstream lines(text);
    std::string line;
    int bad = 0;
    while (std::getline(lines, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        if (line[0] == '[') {
            const std::string name = line.substr(1, line.find(']') - 1);
            cur = &levels[name];
            cur_ceil = &ceilings[name];
            continue;
        }
        if (!cur) continue;
        std::istringstream in(line);
        std::string kind;
        in >> kind;
        if (kind == "surface") {
            Surface s;
            if (in >> s.id >> s.tags && ReadEnd(in, &s.left) && ReadEnd(in, &s.right) && ReadPoints(in, &s.points)) {
                if (s.tags == "-") s.tags.clear();
                cur->surfaces.push_back(std::move(s));
            } else {
                ++bad;
            }
        } else if (kind == "wall") {
            Wall w;
            std::string facing;
            int climb = 0;
            if (in >> facing >> w.x >> w.y1 >> w.y2 >> climb) {
                w.faces_left = facing == "left";
                w.climbable = climb != 0;
                cur->walls.push_back(w);
            } else {
                ++bad;
            }
        } else if (kind == "ceil") {
            float x1, y1, x2, y2;
            if (in >> x1 >> y1 >> x2 >> y2) {
                if (x1 > x2) {
                    std::swap(x1, x2);
                    std::swap(y1, y2);
                }
                cur_ceil->push_back(jump_model::Obstacle{jump_model::Obstacle::kCeiling, x1, y1, x2, y2});
            } else {
                ++bad;
            }
        } else if (kind == "checkpoint") {  // B10-1
            Checkpoint c;
            if (in >> c.order >> c.spawn_x >> c.spawn_y >> c.rx >> c.ry >> c.rw >> c.rh) {
                std::getline(in, c.name);
                const size_t first = c.name.find_first_not_of(' ');
                c.name = first == std::string::npos ? std::string() : c.name.substr(first);
                c.has_region = c.rw > 0 && c.rh > 0;
                cur->checkpoints.push_back(c);
            } else {
                ++bad;
            }
        } else if (kind == "goal") {  // B29-6: a region starting a boss fight or a cinematic, after a checkpoint
            Goal g;
            if (in >> g.after >> g.rx >> g.ry >> g.rw >> g.rh >> g.kind) cur->goals.push_back(g);
            else ++bad;
        } else if (kind == "chapter") {  // B29-2: the chapter starting at a checkpoint (campaigns.lua)
            Chapter c;
            if (in >> c.checkpoint) {
                std::getline(in, c.name);
                const size_t first = c.name.find_first_not_of(' ');
                c.name = first == std::string::npos ? std::string() : c.name.substr(first);
                cur->chapters.push_back(c);
            } else {
                ++bad;
            }
        } else if (kind == "pit") {  // B6-2: fatal pit zones (the level's fatal area effects)
            Pit p;
            if (in >> p.x1 >> p.y1 >> p.x2 >> p.y2) cur->pits.push_back(p);
            else ++bad;
        } else if (kind == "feature") {
            Feature f;
            if (in >> f.type && ReadPoints(in, &f.points)) cur->features.push_back(std::move(f));
            else ++bad;
        }
    }
    for (auto& kv : levels) BuildObstacles(&kv.second, ceilings[kv.first]);
    AcquireSRWLockExclusive(&g_lock);
    g_levels.swap(levels);
    g_level = nullptr;
    auto it = g_levels.find(g_current);
    if (it != g_levels.end()) g_level = &it->second;
    const size_t n = g_levels.size();
    ReleaseSRWLockExclusive(&g_lock);
    if (bad) alog::Write("geometry: %d unreadable lines", bad);
    return n;
}

size_t Load(const std::wstring& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return 0;
    std::stringstream ss;
    ss << f.rdbuf();
    return LoadFromString(ss.str());
}

bool SetLevel(const std::string& game_name) {
    const std::string name = BaseName(game_name);
    AcquireSRWLockExclusive(&g_lock);
    g_current = name;
    auto it = g_levels.find(name);
    g_level = it != g_levels.end() ? &it->second : nullptr;
    const bool ok = g_level != nullptr;
    const size_t surfaces = ok ? g_level->surfaces.size() : 0, features = ok ? g_level->features.size() : 0;
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("geometry: level %s: %s (%u surfaces, %u features)", name.c_str(), ok ? "loaded" : "NO GEOMETRY",
                static_cast<unsigned>(surfaces), static_cast<unsigned>(features));
    return ok;
}

std::string CurrentLevel() {
    AcquireSRWLockShared(&g_lock);
    std::string s = g_current;
    ReleaseSRWLockShared(&g_lock);
    return s;
}

// The level data is only replaced by Load/SetLevel (level loads), never while the game plays, so the
// queries read it without holding the lock for the caller's use of the result.
const Surface* SurfaceUnder(float x, float y) {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    if (!level) return nullptr;
    const float feet = y - kFeetOffset;
    const Surface* best = nullptr;
    float best_d = kStandTolerance;
    for (const Surface& s : level->surfaces) {
        for (size_t i = 0; i + 1 < s.points.size(); ++i) {
            const float x1 = s.points[i].first, y1 = s.points[i].second;
            const float x2 = s.points[i + 1].first, y2 = s.points[i + 1].second;
            if (x < x1 || x > x2 || x2 <= x1) continue;
            const float sy = y1 + (x - x1) / (x2 - x1) * (y2 - y1);
            const float d = std::fabs(feet - sy);
            if (d <= best_d) {
                best_d = d;
                best = &s;
            }
        }
    }
    return best;
}

Ahead EdgeAhead(float x, float y, bool facing_right) {
    Ahead a;
    const Surface* s = SurfaceUnder(x, y);
    if (!s || s->points.empty()) return a;
    a.found = true;
    a.surface = s->id;
    const auto& end = facing_right ? s->points.back() : s->points.front();
    a.end_x = end.first;
    a.end_y = end.second;
    a.distance = facing_right ? end.first - x : x - end.first;
    if (a.distance < 0) a.distance = 0;
    a.end = facing_right ? s->right : s->left;
    return a;
}

const std::vector<Feature>& Features() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->features : kNoFeatures;
}

const std::vector<Wall>& Walls() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->walls : kNoWalls;
}

const Wall* WallBeside(float x, float y) {
    if (SurfaceUnder(x, y)) return nullptr;  // on the ground
    const Wall* best = nullptr;
    float best_d = kWallClingPx;
    for (const Wall& w : Walls()) {
        if (!w.climbable || y < w.y1 - kFeetOffset || y > w.y2 + 2 * kFeetOffset) continue;
        const float d = w.faces_left ? w.x - x : x - w.x;  // he's on the open side
        if (d >= 0 && d <= best_d) {
            best_d = d;
            best = &w;
        }
    }
    return best;
}

const std::vector<jump_model::Obstacle>& Obstacles() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->obstacles : kNoObstacles;
}

std::vector<std::string> LevelNames() {
    std::vector<std::string> names;
    AcquireSRWLockShared(&g_lock);
    for (const auto& kv : g_levels) names.push_back(kv.first);
    ReleaseSRWLockShared(&g_lock);
    return names;
}

const std::vector<Checkpoint>& Checkpoints() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->checkpoints : kNoCheckpoints;
}

const std::vector<Goal>& Goals() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->goals : kNoGoals;
}

const std::vector<Chapter>& Chapters() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->chapters : kNoChapters;
}

const std::vector<Pit>& Pits() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->pits : kNoPits;
}

bool PitAcross(float x, float y_top, float y_bottom) {
    for (const Pit& p : Pits()) {
        if (x >= p.x1 && x <= p.x2 && p.y1 <= y_top && p.y2 >= y_bottom) return true;
    }
    return false;
}

bool LineClear(float x0, float y0, float x1, float y1) {
    const float dx = x1 - x0, dy = y1 - y0;
    for (const jump_model::Obstacle& o : Obstacles()) {
        if (o.kind == jump_model::Obstacle::kPit) continue;  // a zone, not a line
        // Segment intersection: (x0,y0)+t*(dx,dy) meets (o.x1,o.y1)+u*(ex,ey) with t, u in [0, 1].
        const float ex = o.x2 - o.x1, ey = o.y2 - o.y1;
        const float den = dx * ey - dy * ex;
        if (std::fabs(den) < 1e-6f) continue;  // parallel
        const float t = ((o.x1 - x0) * ey - (o.y1 - y0) * ex) / den;
        const float u = ((o.x1 - x0) * dy - (o.y1 - y0) * dx) / den;
        if (t > 0.f && t < 1.f && u >= 0.f && u <= 1.f) return false;
    }
    return true;
}

bool InPit(float x, float y) {
    for (const Pit& p : Pits()) {
        if (x >= p.x1 && x <= p.x2 && y >= p.y1 - kFeetOffset && y <= p.y2) return true;
    }
    return false;
}

const std::vector<Surface>& Surfaces() {
    AcquireSRWLockShared(&g_lock);
    const Level* level = g_level;
    ReleaseSRWLockShared(&g_lock);
    return level ? level->surfaces : kNoSurfaces;
}

}  // namespace level_geometry
