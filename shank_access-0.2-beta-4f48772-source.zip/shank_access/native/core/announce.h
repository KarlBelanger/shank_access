#pragma once
// B13-2: which automatic announcements are spoken (the F7 settings menu, saved in shank_access_user.ini [announce]).
// Query keys (H, G, N, ...) always answer; these only gate what the mod says on its own. Any thread.

namespace announce {

enum Kind {
    kHealth,          // health drops past 75 / 50 / 25 percent (status)
    kPickups,         // "Picked up health, 80 percent", weapons, grenade counts (status)
    kInReach,         // "Health in reach" (cues)
    kCombo,           // "12 hit combo" once a combo ends (status)
    kBoss,            // boss names and boss health steps (status)
    kSpecialEnemies,  // special enemies named as they arrive (cues)
    kPrompts,         // boss openings' button prompts: "Grapple now" (cues)
    kTips,            // loading tips and tutorial hints (menu_reader)
    kMoves,           // B48: waypoint mode on, each next move spoken when the one before is done (cues); off by default
    kCount
};

bool On(Kind k);
void Set(Kind k, bool on);
const char* Label(Kind k);   // spoken in the menu: "Health warnings"
const char* IniKey(Kind k);  // [announce] key: "health"

}  // namespace announce
