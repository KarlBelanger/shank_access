"""Round-trip tests for tools/deploy.py against a fake game folder (never the real install).

Run: .venv/Scripts/python -m unittest discover -s tests -v
"""
import hashlib
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
import deploy  # noqa: E402

os.environ["SHANK_ACCESS_SKIP_PROCESS_CHECK"] = "1"

ORIGINAL_LUA = b"REACTIONS =\r\n{\r\n\tfoo(),\r\n}\r\n"


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)


def read(path):
    with open(path, "rb") as f:
        return f.read()


class DeployTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = self.tmp.name
        self.game = os.path.join(root, "game")
        self.mod = os.path.join(root, "mod")
        self.state = os.path.join(root, "state")
        write(os.path.join(self.game, "bin", "Shank.exe"), b"MZ fake")
        self.target = os.path.join(self.game, "data", "stategraphs", "shank", "shank_transitions.lua")
        # 2026-09-27: patched copies of data/ files go to data-pc/ (new files); the game's own stay vanilla
        self.override = os.path.join(self.game, "data-pc", "stategraphs", "shank", "shank_transitions.lua")
        write(self.target, ORIGINAL_LUA)
        rel = "data/stategraphs/shank/shank_transitions.lua"
        write(os.path.join(self.mod, "pristine.json"),
              json.dumps({rel: hashlib.sha256(ORIGINAL_LUA).hexdigest()}).encode())
        self.patch = os.path.join(self.mod, "patches", *rel.split("/")) + ".patch.json"
        self.set_ops([{"op": "insert_after", "anchor": "\tfoo(),\n", "text": "\ta11y(),\n"}])
        write(os.path.join(self.mod, "files", "bin", "dinput8.dll"), b"proxy")
        self.d = deploy.Deployer(self.game, self.state, mod_dir=self.mod)

    def tearDown(self):
        self.tmp.cleanup()

    def set_ops(self, ops):
        write(self.patch, json.dumps({"ops": ops}).encode())

    def test_round_trip(self):
        self.assertEqual(sorted(self.d.plan()), [("add", "bin/dinput8.dll"),
                                                 ("add", "data-pc/stategraphs/shank/shank_transitions.lua")])
        self.d.deploy()
        self.assertEqual(read(self.override), b"REACTIONS =\r\n{\r\n\tfoo(),\r\n\ta11y(),\r\n}\r\n")  # CRLF kept
        self.assertEqual(read(self.target), ORIGINAL_LUA)  # the game's own file untouched
        self.assertEqual(read(os.path.join(self.game, "bin", "dinput8.dll")), b"proxy")
        self.assertTrue(all(r[3] == "ok" for r in self.d.status()))
        self.assertTrue(all(v == "unchanged" for v, _ in self.d.plan()))
        # redeploy is idempotent: patch is applied to the backed-up pristine, not re-applied on top
        self.d.deploy()
        self.assertEqual(read(self.override).count(b"a11y"), 1)
        self.d.uninstall()
        self.assertEqual(read(self.target), ORIGINAL_LUA)
        self.assertFalse(os.path.exists(self.override))
        self.assertFalse(os.path.exists(os.path.join(self.game, "data-pc", "stategraphs")))  # its folders too
        self.assertFalse(os.path.exists(os.path.join(self.game, "bin", "dinput8.dll")))
        self.assertEqual(self.d.status(), [])

    def test_refuses_modified_original(self):
        write(self.target, ORIGINAL_LUA + b"-- tampered\r\n")
        with self.assertRaises(deploy.DeployError):
            self.d.deploy()
        self.assertFalse(os.path.exists(os.path.join(self.game, "bin", "dinput8.dll")))  # nothing written

    def test_bad_anchor_writes_nothing(self):
        self.set_ops([{"op": "insert_after", "anchor": "missing", "text": "x"}])
        with self.assertRaises(deploy.DeployError):
            self.d.deploy()
        self.assertEqual(read(self.target), ORIGINAL_LUA)
        self.assertFalse(os.path.exists(os.path.join(self.game, "bin", "dinput8.dll")))

    def test_replace_count_enforced(self):
        self.set_ops([{"op": "replace", "find": "\t", "with": "  ", "count": 2}])
        with self.assertRaises(deploy.DeployError):
            self.d.plan()

    def test_steam_verify_has_nothing_to_undo(self):
        self.d.deploy()
        write(self.target, ORIGINAL_LUA)  # Steam "verify integrity" rewrites the game's own files
        self.assertTrue(all(r[3] == "ok" for r in self.d.status()))  # ours are extra files: untouched
        self.assertIn(b"a11y", read(self.override))

    def test_migrates_an_in_place_deploy(self):
        # A deploy from before 2026-09-27 patched data/ in place (backup kept); the next deploy puts the original
        # back and writes the override instead.
        real = deploy.override_path
        deploy.override_path = lambda rel: rel
        try:
            self.d.deploy()
        finally:
            deploy.override_path = real
        self.assertIn(b"a11y", read(self.target))
        self.assertIn(("restore original", "data/stategraphs/shank/shank_transitions.lua"), self.d.plan())
        self.d.deploy()
        self.assertEqual(read(self.target), ORIGINAL_LUA)
        self.assertIn(b"a11y", read(self.override))
        self.assertEqual(sorted(r[0] for r in self.d.status()),
                         ["bin/dinput8.dll", "data-pc/stategraphs/shank/shank_transitions.lua"])

    def test_entry_removed_from_mod_is_restored(self):
        self.d.deploy()
        os.remove(self.patch)
        self.d.deploy()
        self.assertEqual(read(self.target), ORIGINAL_LUA)
        self.assertEqual([r[0] for r in self.d.status()], ["bin/dinput8.dll"])

    def test_record_pristine_refuses_deployed_file(self):
        self.d.deploy()
        with self.assertRaises(deploy.DeployError):
            self.d.record_pristine(["data-pc/stategraphs/shank/shank_transitions.lua"])

    def test_artifact_missing_writes_nothing(self):
        write(os.path.join(self.mod, "artifacts.json"),
              json.dumps({"bin/shank_access.dll": "build/native/Release/shank_access.dll"}).encode())
        with self.assertRaises(deploy.DeployError):
            self.d.deploy()
        self.assertEqual(read(self.target), ORIGINAL_LUA)
        self.assertFalse(os.path.exists(os.path.join(self.game, "bin", "dinput8.dll")))

    def test_artifact_deploys_and_uninstalls(self):
        built = os.path.join(self.tmp.name, "build", "native", "Release", "shank_access.dll")
        write(built, b"MZ built")
        write(os.path.join(self.mod, "artifacts.json"),
              json.dumps({"bin/shank_access.dll": "build/native/Release/shank_access.dll"}).encode())
        self.assertIn(("add", "bin/shank_access.dll"), self.d.plan())
        self.d.deploy()
        self.assertEqual(read(os.path.join(self.game, "bin", "shank_access.dll")), b"MZ built")
        write(built, b"MZ rebuilt")  # a rebuild is picked up by the next deploy
        self.assertIn(("update", "bin/shank_access.dll"), self.d.plan())
        self.d.deploy()
        self.assertEqual(read(os.path.join(self.game, "bin", "shank_access.dll")), b"MZ rebuilt")
        self.d.uninstall()
        self.assertFalse(os.path.exists(os.path.join(self.game, "bin", "shank_access.dll")))

    def test_rejects_non_game_dir(self):
        d = deploy.Deployer(os.path.join(self.tmp.name, "nope"), self.state, mod_dir=self.mod)
        with self.assertRaises(deploy.DeployError):
            d.deploy()


if __name__ == "__main__":
    unittest.main()
