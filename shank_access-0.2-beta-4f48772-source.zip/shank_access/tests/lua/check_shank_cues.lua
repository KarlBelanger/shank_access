-- Run by tools/loadtest50.py after loading Shank's stategraph (Lua 5.0).
-- B4: the only mod transition in Shank's lists is the 4-2 position ping (edges come from the level
-- geometry now). Asserts:
--   A11Y_POS_PING is one NullTransition with pos_r / pos_l that disarms itself (its countdown), last in
--   REACTIONS, AIR_REACTIONS, ON_WALL_REACTIONS, POLEHANG_REACTIONS and SHIMMY_REACTIONS;
--   no other a11y/ sound anywhere in those lists (B3: frequent reports hampered Shank's movement);
--   the game's noFall NullTransition is still there, before the ping.
local function sounds_in(t, found, seen)
  if type(t) ~= "table" or seen[t] then return end
  seen[t] = true
  if t.Type == "playsound" and type(t.sound) == "string" then found[t.sound] = true end
  for _, v in pairs(t) do sounds_in(v, found, seen) end
end

if type(A11Y_POS_PING) ~= "table" or A11Y_POS_PING.type ~= "null" then error("A11Y_POS_PING missing") end
local ping = {}
sounds_in(A11Y_POS_PING, ping, {})
if not (ping["a11y/pos_r"] and ping["a11y/pos_l"]) then error("A11Y_POS_PING lacks pos_r/pos_l") end
local disarms = false
for _, a in ipairs(A11Y_POS_PING.actions or {}) do if a.name == "a11yPos" then disarms = true end end
if not disarms then error("the ping doesn't reset its own countdown") end

-- B19-2: the turn reports, one per direction, each disarmed by its own counter value, just before the ping.
local function sets_counter(tr, value)
  for _, a in ipairs(tr.actions or {}) do
    if a.name == "a11yFacing" and a.value == value then return true end
  end
  return false
end
for label, t in pairs({ R = A11Y_TURN_R, L = A11Y_TURN_L }) do
  if type(t) ~= "table" or t.type ~= "null" then error("A11Y_TURN_" .. label .. " missing") end
  local s = {}
  sounds_in(t, s, {})
  if not s["a11y/turn_" .. string.lower(label)] then error("A11Y_TURN_" .. label .. " doesn't report its turn") end
end
if not sets_counter(A11Y_TURN_R, 1) or not sets_counter(A11Y_TURN_L, 2) then error("a turn report doesn't disarm itself") end

-- B44-1: Up / Down held and let go, each disarmed by its own counter value.
local reports = { [A11Y_POS_PING] = true, [A11Y_TURN_R] = true, [A11Y_TURN_L] = true }
for label, spec in pairs({ UP_ON = { A11Y_UP_ON, "a11yUp", 1, "a11y/up_on" }, UP_OFF = { A11Y_UP_OFF, "a11yUp", 0, "a11y/up_off" },
                            DOWN_ON = { A11Y_DOWN_ON, "a11yDown", 1, "a11y/down_on" },
                            DOWN_OFF = { A11Y_DOWN_OFF, "a11yDown", 0, "a11y/down_off" },
                            FWD_ON = { A11Y_FWD_ON, "a11yFwd", 1, "a11y/fwd_on" }, FWD_OFF = { A11Y_FWD_OFF, "a11yFwd", 0, "a11y/fwd_off" },
                            BACK_ON = { A11Y_BACK_ON, "a11yBack", 1, "a11y/back_on" },
                            BACK_OFF = { A11Y_BACK_OFF, "a11yBack", 0, "a11y/back_off" } }) do
  local t = spec[1]
  if type(t) ~= "table" or t.type ~= "null" then error("A11Y_" .. label .. " missing") end
  local s = {}
  sounds_in(t, s, {})
  if not s[spec[4]] then error("A11Y_" .. label .. " doesn't report " .. spec[4]) end
  local disarm = false
  for _, a in ipairs(t.actions or {}) do if a.name == spec[2] and a.value == spec[3] then disarm = true end end
  if not disarm then error("A11Y_" .. label .. " doesn't disarm itself") end
  reports[t] = true
end

local lists = { REACTIONS = REACTIONS, AIR_REACTIONS = AIR_REACTIONS, ON_WALL_REACTIONS = ON_WALL_REACTIONS,
                POLEHANG_REACTIONS = POLEHANG_REACTIONS, SHIMMY_REACTIONS = SHIMMY_REACTIONS }
for label, list in pairs(lists) do
  local n = table.getn(list)
  if list[n] ~= A11Y_POS_PING then error(label .. ": the position ping is not last") end
  if list[n - 2] ~= A11Y_TURN_R or list[n - 1] ~= A11Y_TURN_L then error(label .. ": the turn reports aren't just before the ping") end
  if list[n - 6] ~= A11Y_UP_ON or list[n - 3] ~= A11Y_DOWN_OFF then error(label .. ": the Up / Down reports aren't before the turns") end
  if list[n - 10] ~= A11Y_FWD_ON or list[n - 7] ~= A11Y_BACK_OFF then error(label .. ": the forward / back reports aren't before Up / Down") end
  for i, tr in ipairs(list) do
    if not reports[tr] then
      local here = {}
      sounds_in(tr, here, {})
      for name in pairs(here) do
        if string.find(name, "^a11y/") then error(label .. " entry " .. i .. " plays " .. name) end
      end
    end
  end
end

local nofall_index, ping_index
for i, tr in ipairs(REACTIONS) do
  if tr.type == "null" and tr.actions and tr.actions[1] and tr.actions[1].name == "noFallDelay" then nofall_index = i end
  if tr == A11Y_POS_PING then ping_index = i end
end
if not nofall_index then error("original noFall NullTransition missing") end
if not (ping_index and ping_index > nofall_index) then error("the ping must come after noFall") end
print("  REACTIONS entries: " .. table.getn(REACTIONS) .. " (noFall at " .. nofall_index .. ", ping at " .. ping_index .. ")")
return true
