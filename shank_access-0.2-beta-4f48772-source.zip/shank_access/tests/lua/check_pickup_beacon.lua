-- Run by tools/loadtest50.py after loading a pickup stategraph (Lua 5.0).
-- Asserts the 4-4 beacon and in-reach NullTransitions are in the shared pickup idle transitions,
-- after the game's own two indicator transitions, named by this pickup's kind, and that the idle
-- state uses that list. The old Uzi_Arm beacon sound must be gone.
if type(A11Y_PICKUP_KIND) ~= "string" then error("A11Y_PICKUP_KIND not set before pickup_common_actions.lua") end
local want = { ["a11y/beacon_" .. A11Y_PICKUP_KIND] = true, ["a11y/inreach_" .. A11Y_PICKUP_KIND] = true }
local found = {}
local function walk(t, i, seen)
  if type(t) ~= "table" or seen[t] then return end
  seen[t] = true
  if t.Type == "playsound" then
    if t.sound == "Sounds/Attacks/Uzi/Uzi_Arm" then error("the old Uzi_Arm beacon is still there") end
    if want[t.sound] then
      if i <= 2 then error(t.sound .. " placed before the game's own transitions") end
      found[t.sound] = true
    end
  end
  for _, v in pairs(t) do walk(v, i, seen) end
end
for i, tr in ipairs(PICKUP_INDICATOR_UPDATE_TRANSITIONS) do
  walk(tr, i, {})
  -- ours are gated: the probes run only when a report is due
  if i > 2 and tr.type == "null" then error("entry " .. i .. " is not gated") end
  -- B3c: every child of our gates resets the countdown itself (a firing makes the game re-check)
  if i > 2 then
    for _, child in ipairs(tr.transitions or {}) do
      local disarms = false
      for _, a in ipairs(child.actions or {}) do if a.name then disarms = true end end
      if not disarms then error("entry " .. i .. ": a child that doesn't reset the countdown") end
    end
  end
end
for name in pairs(want) do
  if not found[name] then error("missing " .. name) end
end
local idle
for _, st in ipairs(PropStates) do if st.name == "idle" then idle = st end end
if not idle or idle.transitions ~= PICKUP_INDICATOR_UPDATE_TRANSITIONS then error("idle state does not use the shared list") end
print("  " .. A11Y_PICKUP_KIND .. ": pickup transitions: " .. table.getn(PICKUP_INDICATOR_UPDATE_TRANSITIONS))
return true
