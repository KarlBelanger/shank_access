#include "exe_check.h"

#include <windows.h>

#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>

// Our own SHA-256 (FIPS 180-4), not bcrypt: 2026-10-18, a start-up deadlock. Our init thread held bcrypt's provider
// lock inside BCryptOpenAlgorithmProvider and waited for the loader lock, while the game's main thread, still loading
// its DLLs, held the loader lock and waited for that bcrypt lock (PLAN In flight). This needs no DLL and no lock.
namespace {

const uint32_t kK[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
    0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
    0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
    0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};

uint32_t Rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

struct Sha256 {
    uint32_t h[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
    unsigned char block[64] = {};
    size_t used = 0;     // bytes in block
    uint64_t total = 0;  // bytes hashed

    void Compress() {
        uint32_t w[64];
        for (int i = 0; i < 16; ++i) {
            w[i] = (uint32_t(block[i * 4]) << 24) | (uint32_t(block[i * 4 + 1]) << 16) | (uint32_t(block[i * 4 + 2]) << 8) |
                   uint32_t(block[i * 4 + 3]);
        }
        for (int i = 16; i < 64; ++i) {
            const uint32_t s0 = Rotr(w[i - 15], 7) ^ Rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
            const uint32_t s1 = Rotr(w[i - 2], 17) ^ Rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] + s0 + w[i - 7] + s1;
        }
        uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
        for (int i = 0; i < 64; ++i) {
            const uint32_t t1 = k + (Rotr(e, 6) ^ Rotr(e, 11) ^ Rotr(e, 25)) + ((e & f) ^ (~e & g)) + kK[i] + w[i];
            const uint32_t t2 = (Rotr(a, 2) ^ Rotr(a, 13) ^ Rotr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
            k = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += k;
    }

    void Update(const unsigned char* p, size_t n) {
        total += n;
        while (n > 0) {
            const size_t take = (64 - used < n) ? 64 - used : n;
            memcpy(block + used, p, take);
            used += take;
            p += take;
            n -= take;
            if (used == 64) { Compress(); used = 0; }
        }
    }

    std::string HexDigest() {
        const uint64_t bits = total * 8;
        const unsigned char pad = 0x80;
        Update(&pad, 1);
        const unsigned char zero = 0;
        while (used != 56) Update(&zero, 1);
        unsigned char len[8];
        for (int i = 0; i < 8; ++i) len[i] = static_cast<unsigned char>(bits >> (56 - 8 * i));
        Update(len, 8);
        static const char hex[] = "0123456789abcdef";
        std::string out;
        for (uint32_t v : h) {
            for (int s = 28; s >= 0; s -= 4) out += hex[(v >> s) & 15];
        }
        return out;
    }
};

}  // namespace

std::string Sha256File(const wchar_t* path) {
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (file == INVALID_HANDLE_VALUE) return {};
    Sha256 sha;
    std::vector<unsigned char> buf(1 << 16);
    DWORD read = 0;
    bool ok = true;
    for (;;) {
        if (!ReadFile(file, buf.data(), static_cast<DWORD>(buf.size()), &read, nullptr)) { ok = false; break; }
        if (read == 0) break;
        sha.Update(buf.data(), read);
    }
    CloseHandle(file);
    return ok ? sha.HexDigest() : std::string();
}

namespace {

std::string FirstLine(const std::wstring& path) {
    std::ifstream f(path, std::ios::binary);
    std::string s;
    if (f) std::getline(f, s);
    while (!s.empty() && (s.back() == '\r' || s.back() == ' ' || s.back() == '\n')) s.pop_back();
    return s;
}

bool IsBuild(const std::string& s) { return s == "steam" || s == "classic"; }

}  // namespace

// B54-7: which game build the installed mod files were made for: "steam", "classic", or "" (can't tell). Setup and
// deploy.py write bin/shank_access_build.txt; without it, the patched scripts tell: only the Steam set patches Shank's
// shank_transitions.lua, only the classic set's stategraphutil.lua has A11Y_ClassicState.
std::string InstalledFilesBuild(const std::wstring& root) {
    const std::string b = FirstLine(root + L"\\bin\\shank_access_build.txt");
    if (IsBuild(b)) return b;
    if (GetFileAttributesW((root + L"\\data-pc\\stategraphs\\shank\\shank_transitions.lua").c_str()) != INVALID_FILE_ATTRIBUTES) {
        return "steam";
    }
    std::ifstream u(root + L"\\data-pc\\stategraphs\\stategraphutil.lua", std::ios::binary);
    if (u) {
        std::stringstream ss;
        ss << u.rdbuf();
        if (ss.str().find("A11Y_ClassicState") != std::string::npos) return "classic";
    }
    return std::string();
}

std::string InstalledModVersion(const std::wstring& root) { return FirstLine(root + L"\\bin\\shank_access_version.txt"); }

// ---- B55-2 / B56-1: one store of the mod's build-specific files per game build ---------------------------------------
namespace {

const wchar_t kStores[] = L"\\shank_access_builds";
const wchar_t kOldAside[] = L"\\shank_access_set_aside";  // (B55-2's single folder)
const char kMarker[] = "shank-access";  // every patch of ours writes this into its file (a comment)
// The build-specific files in bin (the DLLs, settings and UI text are the same for both builds).
const wchar_t* const kBinFiles[] = {L"\\bin\\shank_access_geometry.txt", L"\\bin\\shank_access_paths.txt",
                                    L"\\bin\\shank_access_paths.key", L"\\bin\\shank_access_build.txt"};

bool IsOurs(const std::wstring& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str().find(kMarker) != std::string::npos;
}

bool Exists(const std::wstring& path) { return GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES; }

// Every file under base + rel (rel with backslashes), recursively; lua_only: .lua files only.
void Files(const std::wstring& base, const std::wstring& rel, bool lua_only, std::vector<std::wstring>* out) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((base + rel + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        const std::wstring name = fd.cFileName;
        if (name == L"." || name == L"..") continue;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            Files(base, rel + L"\\" + name, lua_only, out);
        } else if (!lua_only || (name.size() > 4 && _wcsicmp(name.c_str() + name.size() - 4, L".lua") == 0)) {
            out->push_back(rel + L"\\" + name);
        }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

void MakeDirs(const std::wstring& path) {  // every folder of path's parent
    for (size_t i = 3; i < path.size(); ++i) {
        if (path[i] == L'\\') CreateDirectoryW(path.substr(0, i).c_str(), nullptr);
    }
}

// Removes dir's empty folders (deepest first), then dir itself if it's empty.
void RemoveEmptyTree(const std::wstring& dir) {
    std::vector<std::wstring> dirs = {dir};
    for (size_t i = 0; i < dirs.size(); ++i) {
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((dirs[i] + L"\\*").c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) continue;
        do {
            const std::wstring name = fd.cFileName;
            if (name != L"." && name != L".." && (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) dirs.push_back(dirs[i] + L"\\" + name);
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    for (size_t i = dirs.size(); i-- > 0;) RemoveDirectoryW(dirs[i].c_str());
}

void RemoveTree(const std::wstring& dir) {
    std::vector<std::wstring> files;
    Files(dir, L"", false, &files);
    for (const std::wstring& rel : files) DeleteFileW((dir + rel).c_str());
    RemoveEmptyTree(dir);
}

bool Move(const std::wstring& from, const std::wstring& to) {
    MakeDirs(to);
    return MoveFileExW(from.c_str(), to.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_COPY_ALLOWED) != 0;
}

}  // namespace

std::wstring StoreDir(const std::wstring& root, const std::string& build) {
    return root + kStores + L"\\" + std::wstring(build.begin(), build.end());
}

void MigrateOldSetAside(const std::wstring& root) {
    const std::wstring old = root + kOldAside;
    if (!Exists(old)) return;
    const std::string b = FirstLine(old + L"\\build.txt");
    if (IsBuild(b) && !Exists(StoreDir(root, b))) {
        MakeDirs(StoreDir(root, b) + L"\\");
        if (MoveFileExW(old.c_str(), StoreDir(root, b).c_str(), 0)) return;  // (made_by unknown: not used, setup replaces it)
    }
    RemoveTree(old);
}

size_t StashBuildFiles(const std::wstring& root, const std::string& files_for, const std::string& made_by) {
    const std::wstring store = StoreDir(root, files_for);
    RemoveTree(store);  // (an older store of the same build: replaced as a whole)
    size_t moved = 0;
    std::vector<std::wstring> rels;
    Files(root, L"\\data-pc", true, &rels);
    for (const std::wstring& rel : rels) {
        if (!IsOurs(root + rel)) continue;  // (the game's own data-pc scripts stay)
        if (Move(root + rel, store + rel)) ++moved;
    }
    RemoveEmptyTree(root + L"\\data-pc\\stategraphs");  // (only the folders our patches made; the game's own have files)
    for (const wchar_t* rel : kBinFiles) {
        if (Exists(root + rel) && Move(root + rel, store + rel)) ++moved;
    }
    MakeDirs(store + L"\\");
    std::ofstream m(store + L"\\made_by.txt", std::ios::binary | std::ios::trunc);
    m << made_by << "\n";
    std::ofstream b(store + L"\\build.txt", std::ios::binary | std::ios::trunc);
    b << files_for << "\n";
    return moved;
}

bool StoreUsable(const std::wstring& root, const std::string& build, const std::string& made_by) {
    const std::wstring store = StoreDir(root, build);
    return FirstLine(store + L"\\build.txt") == build && Exists(store + L"\\made_by.txt") &&
           FirstLine(store + L"\\made_by.txt") == made_by && Exists(store + L"\\bin\\shank_access_paths.txt");
}

bool SetupRunning(const std::wstring& root) {
    const std::wstring lock = root + L"\\shank_access_setup.lock";
    WIN32_FILE_ATTRIBUTE_DATA a;
    if (!GetFileAttributesExW(lock.c_str(), GetFileExInfoStandard, &a)) return false;
    FILETIME now_ft;
    GetSystemTimeAsFileTime(&now_ft);
    ULARGE_INTEGER now, written;
    now.LowPart = now_ft.dwLowDateTime;
    now.HighPart = now_ft.dwHighDateTime;
    written.LowPart = a.ftLastWriteTime.dwLowDateTime;
    written.HighPart = a.ftLastWriteTime.dwHighDateTime;
    const unsigned long long kMaxAge = 60ull * 60 * 10000000;  // 60 minutes in 100 ns units (an older lock is stale)
    if (now.QuadPart > written.QuadPart && now.QuadPart - written.QuadPart > kMaxAge) return false;
    const unsigned long pid = std::strtoul(FirstLine(lock).c_str(), nullptr, 10);
    if (pid == 0) return false;
    HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!p) return false;  // (setup ended without removing it: stale)
    DWORD code = 0;
    const bool alive = GetExitCodeProcess(p, &code) && code == STILL_ACTIVE;
    CloseHandle(p);
    return alive;
}

size_t UnstashBuildFiles(const std::wstring& root, const std::string& build) {
    const std::wstring store = StoreDir(root, build);
    std::vector<std::wstring> rels;
    Files(store, L"", false, &rels);
    size_t moved = 0;
    for (const std::wstring& rel : rels) {
        if (_wcsicmp(rel.c_str(), L"\\made_by.txt") == 0 || _wcsicmp(rel.c_str(), L"\\build.txt") == 0) continue;
        if (Move(store + rel, root + rel)) ++moved;
    }
    RemoveTree(store);
    RemoveEmptyTree(root + kStores);
    return moved;
}
