// Host-side test of the Phase 3 status logic (never deployed): health drops at 75/50/25, grenade
// pickups only ("3 grenades", not on a level load's reset), boss names, the H/G texts. Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <string>

#include "../core/log.h"
#include "../core/status.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

ui_hooks::FlashValue Num(double n) {
    ui_hooks::FlashValue v;
    v.kind = ui_hooks::FlashValue::kNumber;
    v.n = n;
    return v;
}

ui_hooks::FlashValue Text(const char* s) {
    ui_hooks::FlashValue v;
    v.kind = ui_hooks::FlashValue::kText;
    v.text = s;
    return v;
}

const char kHealth[] = "_level0.HUD.player1.healthBar.value";
const char kGrenades[] = "_level0.HUD.player1.grenadeTxt.text";
const char kBoss[] = "_level0.HUD.enemyBoss.nameTxt.text";

}  // namespace

int main() {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_status_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    unsigned t = 1000;
    auto on = [&](const char* path, const ui_hooks::FlashValue& v) { return status::OnValue(path, v, t += 1000); };
    Check(status::HealthText() == "No health yet" && status::GrenadeText() == "No grenade count yet", "before any value");
    // Health: 100 at level start (not announced), small hits silent, crossings announced once.
    Check(on(kHealth, Num(100)).empty(), "first health value: silent");
    Check(on(kHealth, Num(97.5)).empty(), "small hit: silent");
    Check(on(kHealth, Num(72.5)) == "73 percent health", "drops below 75: announced");
    Check(on(kHealth, Num(70)).empty(), "still below 75: silent");
    Check(on(kHealth, Num(40)) == "40 percent health", "drops below 50: announced");
    Check(on(kHealth, Num(10)) == "10 percent health", "drops below 25: announced");
    Check(on(kHealth, Num(60)).empty(), "healing: silent");
    Check(on(kHealth, Num(45)) == "45 percent health", "below 50 again after healing above it");
    Check(on(kHealth, Num(100)).empty(), "respawn at 100: silent");
    Check(on(kHealth, Num(74)) == "74 percent health", "new life: 75 armed again");
    Check(on(kHealth, Text("x")).empty(), "wrong type: ignored");
    // Grenades: pickups only; number first.
    Check(on(kGrenades, Text("3")).empty(), "first grenade count: silent");
    Check(on(kGrenades, Text("2")).empty(), "thrown: silent");
    Check(on(kGrenades, Text("3")) == "3 grenades", "picked up: announced, number first");
    Check(on(kGrenades, Text("")).empty(), "cleared (level end): silent");
    Check(on(kGrenades, Text("1")).empty(), "first value after clearing: silent");
    Check(on(kGrenades, Text("2")) == "2 grenades", "pickup");
    Check(on(kGrenades, Text("1")).empty(), "thrown");
    // B1c: a level load / respawn resets health to 100 and grenades to 3 in the same ms: silent.
    Check(status::OnValue(kHealth, Num(60), 900000).empty(), "hurt");
    Check(status::OnValue(kHealth, Num(100), 900100).empty(), "reset to full (level load)");
    Check(status::OnValue(kGrenades, Text("3"), 900100).empty(), "grenades restored with the reset: silent");
    Check(status::OnValue(kGrenades, Text("2"), 901000).empty(), "thrown");
    Check(status::OnValue(kGrenades, Text("3"), 902000) == "3 grenades", "a real pickup later: announced");
    Check(status::OnValue(kGrenades, Text("1"), 903000).empty(), "thrown twice");
    Check(status::OnValue(kGrenades, Text("2"), 904000) == "2 grenades", "pickup");
    Check(status::OnValue(kGrenades, Text("1"), 905000).empty(), "thrown");
    // Bosses.
    Check(on(kBoss, Text("The Butcher")) == "Boss: The Butcher", "boss");
    Check(on(kBoss, Text("The Butcher")).empty(), "same boss: once");
    Check(on(kBoss, Text("")).empty(), "boss bar cleared: silent");
    Check(on(kBoss, Text("The Butcher")) == "Boss: The Butcher", "same boss after the bar was cleared (a retry)");
    Check(on("_level0.HUD.enemy0.nameTxt.text", Text("Wallace")).empty(), "regular enemies: silent");
    // The H and G keys.
    Check(status::HealthText() == "100 percent health", "H: health");
    Check(status::GrenadeText() == "1 grenade", "G: singular");
    status::OnValue(kGrenades, Text("2"), 950000);
    Check(status::GrenadeText() == "2 grenades", "G: plural");
    status::Reset();
    Check(status::GrenadeText() == "No grenade count yet", "after reset");
    // 3-2 pickups (our Lua cue "got_<kind>").
    Check(status::OnPickup("minigun", 1000000) == "Picked up minigun", "weapon pickup: minigun");
    Check(status::OnPickup("grenadelauncher", 1000010) == "Picked up grenade launcher", "weapon pickup: grenade launcher");
    Check(status::OnPickup("sword", 1000020) == "Picked up katana", "weapon pickup: the sword is the katana");
    Check(status::OnPickup("uzi", 1000030) == "Picked up Uzi", "weapon pickup: Uzi");
    Check(status::OnPickup("banana", 1000040).empty(), "unknown pickup: silent");
    status::OnValue(kHealth, Num(100), 1001000);
    status::OnValue(kHealth, Num(40), 1002000);
    Check(status::OnPickup("health", 1010000).empty(), "health pickup: nothing at once");
    status::OnValue(kHealth, Num(55), 1010200);
    Check(status::OnFrame(1010300).empty(), "health pickup: still adding");
    status::OnValue(kHealth, Num(70), 1010500);
    Check(status::OnFrame(1010700) == "Picked up health, 70 percent health", "health pickup: the result");
    Check(status::OnFrame(1010800).empty(), "health pickup: once");
    status::OnValue(kGrenades, Text("2"), 1020000);
    Check(status::OnPickup("grenades", 1030000).empty(), "grenade pickup: waits for the count");
    Check(status::OnValue(kGrenades, Text("5"), 1030050) == "5 grenades", "grenade pickup: the count says it");
    Check(status::OnFrame(1030600).empty(), "grenade pickup: not twice");
    Check(status::OnPickup("grenades", 1040000).empty(), "grenade pickup at the maximum");
    Check(status::OnFrame(1040400).empty(), "at the maximum: waiting");
    Check(status::OnFrame(1040500) == "5 grenades", "at the maximum: the count anyway");
    status::OnValue(kGrenades, Text("3"), 1050000);
    Check(status::OnValue(kGrenades, Text("5"), 1060000) == "5 grenades", "count first");
    Check(status::OnPickup("grenades", 1060010).empty(), "then the pickup message: silent");
    Check(status::OnFrame(1060600).empty(), "and nothing later");
    status::Reset();
    // 3-3 boss health (the 1c-3 log: name, then 100 in the same ms; overkill goes negative).
    const char kBossHealth[] = "_level0.HUD.enemyBoss.healthBar.value";
    status::OnValue(kHealth, Num(80), 1100000);
    Check(status::HealthText() == "80 percent health", "H without a boss");
    Check(status::OnValue(kBoss, Text("The Butcher"), 1100100) == "Boss: The Butcher", "boss name");
    Check(status::OnValue(kBossHealth, Num(100), 1100100).empty(), "boss bar full: silent");
    Check(status::OnValue(kBossHealth, Num(80), 1101000).empty(), "boss hit: silent");
    Check(status::OnValue(kBossHealth, Num(72.5), 1102000) == "73 percent boss health", "boss below 75");
    Check(status::HealthText() == "80 percent health, 73 percent boss health", "H: player, then boss");
    Check(status::OnValue(kBossHealth, Num(49), 1103000) == "49 percent boss health", "boss below 50");
    Check(status::OnValue(kBossHealth, Num(30), 1104000).empty(), "boss still above 25");
    Check(status::OnValue(kBossHealth, Num(-750), 1105000) == "0 percent boss health", "overkill: below 25, as 0");
    Check(status::OnValue(kBoss, Text(""), 1106000).empty(), "boss bar cleared");
    Check(status::HealthText() == "80 percent health", "H: the boss is gone");
    Check(status::OnValue(kBoss, Text("The Butcher"), 1107000) == "Boss: The Butcher", "retry");
    Check(status::OnValue(kBossHealth, Num(100), 1107000).empty(), "retry: full, silent");
    Check(status::OnValue(kBossHealth, Num(70), 1108000) == "70 percent boss health", "retry: 75 armed again");
    // B7b: 1-a's fake Butcher: the bar goes to -650, then stays at 0, and its name is never cleared.
    status::OnValue(kBossHealth, Num(-650), 1109000);
    status::OnValue(kBossHealth, Num(0), 1109010);
    Check(status::HealthText() == "80 percent health", "H: a boss at 0 is left out");
    status::OnValue(kBossHealth, Num(100), 1109020);
    Check(status::HealthText() == "80 percent health, 100 percent boss health", "(the bar back up: in again)");
    status::ForgetBosses();
    Check(status::HealthText() == "80 percent health", "a level load forgets the boss");
    // Two bosses (paths assumed from their nameTxt).
    status::OnValue("_level0.HUD.enemyBosses.boss1.nameTxt.text", Text("Angelo"), 1110000);
    status::OnValue("_level0.HUD.enemyBosses.boss1.healthBar.value", Num(100), 1110000);
    Check(status::OnValue("_level0.HUD.enemyBosses.boss1.healthBar.value", Num(60), 1111000) == "60 percent Angelo",
          "two-boss bar: named");
    Check(status::OnValue("_level0.HUD.enemy0.healthBar.value", Num(10), 1112000).empty(), "regular enemies: silent");
    status::Reset();
    // 3-4 combo (the 1c-3 log: "1" … "12", then "1" again right after Shank was hit).
    const char kCombo[] = "_level0.HUD.player1.comboanim.combo.comboNum.text";
    unsigned c = 1200000;
    bool silent = true;
    for (int i = 1; i <= 12; ++i) silent = silent && status::OnValue(kCombo, Text(std::to_string(i).c_str()), c += 100).empty();
    Check(silent, "combo climbing: silent");
    Check(status::OnFrame(c + 1150).empty(), "1.15 s between hits: still going");
    Check(status::OnValue(kCombo, Text("1"), c += 1200) == "12 hit combo", "starts again at 1: the last combo");
    Check(status::OnValue(kCombo, Text("2"), c += 100).empty(), "the new one climbs");
    Check(status::OnFrame(c + 2999).empty(), "idle: not yet");
    Check(status::OnFrame(c + 3000).empty(), "idle: a 2-hit combo stays silent");
    status::OnValue(kCombo, Text("1"), c += 5000);
    status::OnValue(kCombo, Text("2"), c += 100);
    status::OnValue(kCombo, Text("3"), c += 100);
    Check(status::OnFrame(c + 3000) == "3 hit combo", "idle: the combo is over");
    Check(status::OnFrame(c + 4000).empty(), "said once");
    Check(status::OnValue(kCombo, Text("1"), c += 5000).empty(), "after the idle announcement: no repeat");
    status::OnValue(kCombo, Text("5"), c += 100);
    Check(status::OnValue(kCombo, Text("5"), c += 100).empty(), "the same number again: ignored (a rewrite)");
    Check(status::OnValue(kCombo, Text("1"), c += 100) == "5 hit combo", "lower: a new combo");
    Check(status::OnValue(kCombo, Text(""), c += 100).empty(), "cleared: silent");
    Check(status::OnFrame(c + 5000).empty(), "cleared: nothing later");
    status::Reset();
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
