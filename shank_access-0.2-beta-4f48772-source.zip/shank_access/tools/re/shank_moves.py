"""Inventory of Shank's movement launches (B6-1): every stategraph state that calls Jump(), with its tags,
the Jump() calls (angle, speed, when) and the transitions that lead into it (condition text).

Usage: python tools/re/shank_moves.py [--all]   (default: only states with a Jump())
Reads the game's stategraph Lua (read only). Prints a text table for RE-NOTES.
"""
import glob
import os
import re
import sys

SG = r"C:\Program Files (x86)\Steam\steamapps\common\Shank\data\stategraphs\shank"
CONST = {}


def load_constants():
    for f in glob.glob(os.path.join(SG, "*.lua")):
        for m in re.finditer(r"^([A-Z_0-9]+)\s*=\s*([^\n]+)", open(f, encoding="latin-1").read(), re.M):
            CONST.setdefault(m.group(1), m.group(2).split("--")[0].strip())


def states(text):
    """Yield (name, body) for each State{ ... } block (brace matched)."""
    for m in re.finditer(r"State\s*{", text):
        i = m.end()
        depth = 1
        while depth and i < len(text):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
            i += 1
        body = text[m.start():i]
        nm = re.search(r'name\s*=\s*"([^"]+)"', body)
        if nm:
            yield nm.group(1), body


def main(argv):
    load_constants()
    show_all = "--all" in argv
    into = {}
    files = sorted(glob.glob(os.path.join(SG, "*.lua")))
    for f in files:
        for n, l in enumerate(open(f, encoding="latin-1"), 1):
            for m in re.finditer(r'Transition\(\s*"([^"]+)"\s*,?\s*(.*)', l):
                into.setdefault(m.group(1), []).append("%s:%d %s" % (os.path.basename(f), n, m.group(2).strip()[:110]))
            for m in re.finditer(r'GoToState\(\s*"([^"]+)"', l):
                into.setdefault(m.group(1), []).append("%s:%d GoToState" % (os.path.basename(f), n))
    for f in files:
        text = open(f, encoding="latin-1").read()
        for name, body in states(text):
            jumps = re.findall(r"(AtTime\(\s*([^,]+),\s*)?Jump\(([^)]*)\)", body)
            if not jumps and not show_all:
                continue
            tags = re.search(r'tags\s*=\s*"([^"]*)"', body)
            dur = re.search(r"duration\s*=\s*([^,]+)", body)
            print("== %s (%s)  tags: %s  duration: %s" % (name, os.path.basename(f), tags.group(1) if tags else "",
                                                          dur.group(1).strip() if dur else ""))
            for _, when, args in jumps:
                print("   Jump(%s)%s" % (args.strip(), "  at " + when.strip() if when else ""))
            for src in into.get(name, [])[:6]:
                print("   <- " + src)
    for k in ("JUMP_SPEED", "WALL_JUMP_SPEED", "WALL_JUMP_ANGLE", "DOUBLE_JUMP_SPEED"):
        print(k, "=", CONST.get(k))


if __name__ == "__main__":
    main(sys.argv)
