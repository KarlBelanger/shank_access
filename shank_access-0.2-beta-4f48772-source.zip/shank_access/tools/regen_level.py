"""B42-5: rebuild and check one level's routes in one command (instead of every level, ~90 s).

  1. path_graph.exe for that level only (--merge: the other levels' sections of build/levels/shank_access_paths.txt kept);
  2. path_check --all <level>: every checkpoint leg of it has a route;
  3. movement_check over the whole corpus (the jump model against every real flight; with --baseline when
     build/movements/check_base.txt exists: what changed);
  4. risky_moves for that level (build/levels/risky_moves_<level>.txt).

A jump_model change affects every level's routes: rebuild them all before a deploy (path_graph without a level). This is
for working on one level.

Usage: regen_level.py <level, or part of its name>
"""
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable
OUT = os.path.join(ROOT, "build", "native", "out")
GEO = os.path.join(ROOT, "build", "levels", "shank_access_geometry.txt")
PATHS = os.path.join(ROOT, "build", "levels", "shank_access_paths.txt")
MOVES = os.path.join(ROOT, "build", "movements")


def level_named(part):
    levels = [l.strip()[1:-1] for l in open(GEO, encoding="utf-8") if l.startswith("[")]
    hits = [l for l in levels if part in l]
    return hits[0] if len(hits) == 1 else None, levels


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    level, levels = level_named(argv[0])
    if not level:
        print("no single level matches %r (levels: %s)" % (argv[0], ", ".join(levels)))
        return 2
    t0 = time.time()
    r = subprocess.run([os.path.join(OUT, "path_graph.exe"), GEO, PATHS, level, "--merge"], cwd=ROOT)
    if r.returncode:
        return r.returncode
    r = subprocess.run([PY, os.path.join(ROOT, "tools", "levels", "path_check.py"), "--all", level], cwd=ROOT)
    legs_ok = r.returncode == 0
    check = [os.path.join(OUT, "movement_check.exe"), GEO, os.path.join(MOVES, "movements.txt"), os.path.join(MOVES, "check.txt")]
    if os.path.exists(os.path.join(MOVES, "check_base.txt")):
        check += ["--baseline", os.path.join(MOVES, "check_base.txt")]
    if os.path.exists(os.path.join(MOVES, "movements.txt")):
        out = subprocess.run(check, cwd=ROOT, capture_output=True, text=True).stdout
        for line in out.splitlines():
            if line.startswith("  all") or level in line or "verdicts changed" in line:
                print(line)
    else:
        print("(no corpus: run tools/movements.py)")
    subprocess.run([PY, os.path.join(ROOT, "tools", "levels", "risky_moves.py"), level], cwd=ROOT)
    print("%s: done in %.1f s%s" % (level, time.time() - t0, "" if legs_ok else " (LEGS WITHOUT A ROUTE: see above)"))
    return 0 if legs_ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
