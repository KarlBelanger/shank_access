#pragma once
// Translates the game's IDS_* localization keys (some menu labels are keys, e.g. "IDS_CAMPAIGN";
// the game translates them at display time). The strings come from the game's own
// data/bootstrap/localization/localization_en.xml (XLIFF), read at runtime: we ship no Klei text.
#include <cstddef>
#include <string>

namespace localization {

// Parses XLIFF text: every <trans-unit resname="KEY"> ... <source>TEXT</source>. Entities
// (&amp; &quot; &lt; &gt; &apos;) are decoded. Replaces any previous table; returns the count.
size_t LoadFromXliff(const std::string& xml);

// Reads and parses the file. Returns the number of strings (0 if the file can't be read).
size_t Load(const std::wstring& path);

// Returns the translation of `key` if it's a known key, otherwise `key` unchanged.
std::string Translate(const std::string& key);

}  // namespace localization
