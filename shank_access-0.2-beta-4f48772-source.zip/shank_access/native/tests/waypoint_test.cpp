// Host-side test of B10 waypoint mode (never deployed), on the real 1-c data: build/levels/shank_access_geometry.txt
// and build/levels/shank_access_paths.txt. Usage: waypoint_test.exe <geometry.txt> <paths.txt>. Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <cstdlib>
#include <string>

#include "../core/announce.h"
#include "../core/cues.h"
#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"
#include "../core/pathing.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

position::Pos At(float x, float y, bool right, float vx = 0, float vy = 0) {
    position::Pos p;
    p.known = p.live = true;
    p.x = x;
    p.y = y;
    p.facing_right = p.ping_facing_right = right;
    p.vx = vx;
    p.vy = vy;
    return p;
}

struct Heard {
    int chirps = 0, plucks = 0, chimes = 0;
    float chirp_x_sign = 0;  // the last chirp's pan
};

Heard Run(unsigned from, unsigned to, const position::Pos& p) {
    Heard h;
    for (unsigned t = from; t < to; t += 10) {
        for (const cues::PlayCmd& q : cues::Tick(t, p).plays) {
            if (q.sound == audio::kJumpNow) {
                ++h.chirps;
                h.chirp_x_sign = q.pan;
            }
            h.plucks += q.sound == audio::kTarget;
            h.chimes += q.sound == audio::kWaypointChime;
        }
    }
    return h;
}

}  // namespace

int main(int argc, char** argv) {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_waypoint_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);
    if (argc < 3) {
        printf("usage: waypoint_test <geometry.txt> <paths.txt>\n");
        return 2;
    }
    wchar_t w1[MAX_PATH], w2[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, argv[1], -1, w1, MAX_PATH);
    MultiByteToWideChar(CP_ACP, 0, argv[2], -1, w2, MAX_PATH);
    Check(level_geometry::Load(w1) >= 10 && pathing::Load(w2) >= 10, "real geometry and graph loaded");
    level_geometry::SetLevel("campaign_1c_meatpacking");
    pathing::SetLevel("campaign_1c_meatpacking");
    cues::Reset();

    // B47b-3 (B47 session 1 mark 2: "said jump but walk off worked, one to the wall"): a long jump left off s40 at 24008 came
    // down ~8 tiles past the wall at 24000 (the face of the block under that floor) and still "met" it.
    {
        jump_model::SetObstacles(&level_geometry::Obstacles());
        const jump_model::Target w100{jump_model::kWall, 24000.f, 2176.f, 24000.f, 2816.f};
        Check(jump_model::ReachLong(w100, 24008.f, 2912.f, false) == jump_model::kNone,
              "B47b-3: 1-c: no long jump to the wall under the floor he stands on");
    }

    // B48 (the user: "have each move spoken when the previous one was completed. This should not trigger if a number changes
    // or shank turns around, only when waypoint mode is on and the actual interaction being pointed at changes."): 1-c's start.
    {
        cues::Reset();
        announce::Set(announce::kMoves, true);
        cues::ToggleWaypoint(At(768, 288, true));
        std::string said;
        unsigned t = 900000;
        for (; t < 901000; t += 10) said += cues::Tick(t, At(768, 288, true)).say;
        for (float x = 800; x < 3000; x += 20, t += 10) said += cues::Tick(t, At(x, 288, true)).say;  // walking: distances change
        for (int k = 0; k < 50; ++k, t += 10) said += cues::Tick(t, At(3000, 288, k % 20 < 10)).say;    // turning around
        printf("  (B48 walking and turning: \"%s\")\n", said.c_str());
        Check(said.find("wall") == std::string::npos && said.find("swing") == std::string::npos,
              "B48: walking along and turning around say no move (turning waypoint mode on said the first one)");
        said.clear();
        for (int k = 0; k < 150; ++k, t += 10) said += cues::Tick(t, At(4571, 956, false)).say;  // on the first swing point
        printf("  (B48 on swing point 1: \"%s\")\n", said.c_str());
        Check(said.find("jump off the swing point") != std::string::npos, "B48: on the first swing point, its move is said");
        const size_t first = said.find("jump off the swing point");
        Check(said.find("jump off the swing point", first + 1) == std::string::npos, "B48: once");
        said.clear();
        for (int k = 0; k < 100; ++k, t += 10) said += cues::Tick(t, At(4571, 956, k % 30 < 15)).say;
        Check(said.find("jump") == std::string::npos, "B48: turning on the swing point says nothing more");
        announce::Set(announce::kMoves, false);
        cues::ToggleWaypoint(At(4571, 956, false));
        cues::Reset();
    }

    // B43 (the user, waypoint mode off: "climbing the first wall in meat packing plays two jump targets, even though I can
    // only reach the first swing point"): up the street's end wall only swing point 1 chirps, never the street below.
    {
        unsigned t = 500000;
        int low_chirps = 0, swing_heights = 0;
        for (float y = 448; y <= 1536; y += 64) {
            cues::Reset();
            Heard hh = Run(t, t + 600, At(5344, y, false));
            t += 1000;
            const bool swing_ok = jump_model::ReachFromWall(jump_model::Target{jump_model::kSwing, 4725.52f, 1044.6f, 0, 0}, 5344, y, false) !=
                                  jump_model::kNone;
            printf("  (street wall y %.0f: %d chirps, %d plucks, swing point 1 %s)\n", y, hh.chirps, hh.plucks, swing_ok ? "in reach" : "not");
            if (!swing_ok) low_chirps += hh.chirps;
            swing_heights += swing_ok;
        }
        Check(swing_heights > 0, "B43: the wall jump reaches swing point 1 from part of the street wall");
        Check(low_chirps == 0, "B43: elsewhere on the street wall nothing chirps (the street below isn't a jump target)");
        cues::Reset();
    }
    // B44-2 (the user: "a floor reachable from a shimmy line only by holding up should not sound if holding right"): on the
    // street's second swing point facing left, letting go lands on the floor ahead (the route's next move): the chirp; holding
    // Up, the jump up falls back onto the point: the floor plucks instead.
    {
        cues::Reset();
        const position::Pos swing2 = At(4110, 980, false);
        Heard plain = Run(510000, 511500, swing2);
        cues::OnCue("up_on", swing2.x, swing2.y, 511500);
        Heard up = Run(511600, 513100, swing2);
        cues::OnCue("up_off", swing2.x, swing2.y, 513100);
        printf("  (swing point 2 facing left: %d chirps; holding Up: %d chirps, %d plucks)\n", plain.chirps, up.chirps, up.plucks);
        Check(plain.chirps >= 4, "B44-2: swing point 2 facing left: the floor ahead chirps (letting go lands there)");
        Check(up.chirps <= 2 && up.plucks >= 1, "B44-2: ...holding Up: no chirp (the jump up falls back), the floor plucks");
        cues::Reset();
        // The user's example (2026-10-01: "The last shimmy line before entering the plant proper fits this perfectly"): 1-c's
        // bar (1577..2601 at y 4181), its right end: the platform below to the right (2624..3328 at y 3904) only by the jump
        // up (the bar jump right flies over it: B5d's fatal jump, B41-4).
        const position::Pos bar_end = At(2601, 3989, true);
        Heard right = Run(514000, 515500, bar_end);
        cues::OnCue("up_on", bar_end.x, bar_end.y, 515500);
        cues::OnCue("fwd_on", bar_end.x, bar_end.y, 515500);  // (B44e: up and right; Up alone goes straight up)
        Heard held = Run(515600, 517100, bar_end);
        cues::OnCue("up_off", bar_end.x, bar_end.y, 517100);
        cues::OnCue("fwd_off", bar_end.x, bar_end.y, 517100);
        printf("  (the last bar's right end: %d chirps, %d plucks; holding Up: %d chirps)\n", right.chirps, right.plucks, held.chirps);
        Check(right.chirps == 0 && right.plucks >= 1, "B44-2: the last bar's end, holding right: no chirp, the platform plucks");
        Check(held.chirps >= 4, "B44-2: ...holding Up and right: the platform chirps");
        cues::Reset();
        // B44c (the user's live session: "I'm just past the first pole ... a jump target is playing to my right even though
        // I'm facing left"; the log: standing at (2408, 1952) facing left, "jump now reaches Pole at (2930, 1952) (standing
        // jump)"): the standing jump he'd make goes up or left, not back to the pole; facing it, it does reach it.
        Heard away = Run(518000, 519500, At(2408, 1952, false));
        cues::Reset();
        cues::OnCue("fwd_on", 2600, 1952, 519500);
        Heard facing = Run(519500, 521000, At(2600, 1952, true));
        cues::OnCue("fwd_off", 2600, 1952, 521000);
        printf("  (left of the tall pole facing left: %d chirps; facing it: %d)\n", away.chirps, facing.chirps);
        Check(away.chirps == 0, "B44c: standing left of the tall pole facing left: no chirp for the pole behind him");
        Check(facing.chirps >= 4, "B44c: ...facing it, holding toward it: the chirp");
        cues::Reset();
        // B44d (the user, 2-b, hanging from a bar holding Down: "reports valid jump target, but as you can see from my last
        // death it most definitely is not"; the log: at (47390, 3362), the landing at (47552, 3360); he let go and fell to
        // his death at (47454, 2611)).
        level_geometry::SetLevel("campaign_2b_lovehotel");
        pathing::SetLevel("campaign_2b_lovehotel");
        cues::Reset();
        const position::Pos bar2b = At(47390, 3362, true);
        cues::OnCue("down_on", bar2b.x, bar2b.y, 522000);
        Heard down = Run(522000, 523500, bar2b);
        cues::OnCue("down_off", bar2b.x, bar2b.y, 523500);
        printf("  (2-b's bar holding Down: %d chirps)\n", down.chirps);
        Check(down.chirps == 0, "B44d: 2-b's bar, holding Down: letting go reaches nothing (no chirp)");
        level_geometry::SetLevel("campaign_1c_meatpacking");
        pathing::SetLevel("campaign_1c_meatpacking");
        cues::Reset();
    }
    // The level start (the street, x 768): the first move of the climb.
    const position::Pos start = At(768, 288, true);
    Heard h = Run(1000, 1500, start);
    Check(h.chimes == 0, "waypoint off: no chime");
    Check(cues::ToggleWaypoint(start), "W: on");
    h = Run(1500, 3500, start);
    const std::string next = cues::NextMove(start);
    printf("  (Q at the start: %s)\n", next.c_str());
    Check(next.find("walk 72 tiles right, then run up the wall") == 0, "Q at the start: walk to the end wall and run up it (B10b)");
    Check(next.find("Enter Packing Warehouse") != std::string::npos, "...on the way to Enter Packing Warehouse");
    Check(h.chimes >= 1, "the checkpoint chimes");

    // Clinging to the end wall (x 5376) at y 1082, as in the B5 logs: the waypoint is swing point 1 (4726, 1045);
    // swing point 2 (4110, 1158), also within range, is silent.
    const position::Pos cling = At(5344, 1082, false);
    h = Run(4000, 5500, cling);
    printf("  (clinging: %d chirps, %d plucks; Q: %s)\n", h.chirps, h.plucks, cues::NextMove(cling).c_str());
    Check(h.chirps >= 2 && h.chirp_x_sign < 0.f, "clinging to the end wall: the wall jump to swing point 1 chirps (left)");
    Check(cues::NextMove(cling).find("swing point") != std::string::npos, "Q: to the swing point");
    Check(cues::NextMove(cling).find(", then") == std::string::npos, "Q: ...from where he clings (no climbing first)");

    // On the tall pole's right side near its top (3009.9, 3553): the way on is to the left. B10b: jumping left from
    // the right side goes through the pole (the game moves him to the left side first), so that's the move.
    const position::Pos right_side = At(3009.9f, 3553, true);
    h = Run(6000, 8000, right_side);
    printf("  (pole right side: %d chirps; Q: %s)\n", h.chirps, cues::NextMove(right_side).c_str());
    Check(cues::NextMove(right_side).find("jump off the pole to wall run") == 0, "on the pole's right side: Q says jump off the pole (left)");
    Check(h.chirps >= 2 && h.chirp_x_sign < 0.f, "...and the wall run chirps on the left");

    Check(!cues::ToggleWaypoint(start), "W: off");

    // B20-3 (the user: "multiple drop through messages even though checkpoint still far away"): 2-b after Leaving
    // Brothel, on s11 (y 640) with the drop through ~70 tiles right: silent far away, said once near it, and not again
    // when a fight takes him off the floor and back.
    level_geometry::SetLevel("campaign_2b_lovehotel");
    pathing::SetLevel("campaign_2b_lovehotel");
    cues::Reset();
    auto said = [](unsigned from, unsigned to, const position::Pos& p) {
        int n = 0;
        for (unsigned t = from; t < to; t += 10) n += cues::Tick(t, p).say.find("Drop through") != std::string::npos;
        return n;
    };
    const position::Pos far_away = At(23656, 672, true);
    for (const auto& c : level_geometry::Checkpoints()) {  // (a respawn there first, as in the log)
        if (c.name == "Leaving Brothel") said(19000, 19100, At(c.spawn_x, c.spawn_y, true));
    }
    Check(cues::ToggleWaypoint(far_away), "2-b: W on");
    const std::string q = cues::NextMove(far_away);
    printf("  (2-b s11: Q: %s)\n", q.c_str());
    const int far_n = said(20000, 22000, far_away);
    const size_t at = q.find("walk ");
    const float tiles = at == std::string::npos ? 0.f : static_cast<float>(std::atof(q.c_str() + at + 5));
    const position::Pos near_spot = At(23656 + 64.f * (tiles - 2.f), 1120, true);  // (s11 rises to y 1088 there)
    const int near_n = said(22000, 24000, near_spot);
    const position::Pos jumping = At(near_spot.x, 1400, true, 0.f, 600.f);
    said(24000, 24500, jumping);
    const int again = said(24500, 26000, near_spot);
    printf("  (drop-through hint: far %d, near %d at x %.0f, again %d)\n", far_n, near_n, near_spot.x, again);
    // (B48d: dropping through a one-way floor doesn't exist in the game (1-b train mark 7): no such move, no hint)
    Check(q.find("drop through") == std::string::npos && far_n == 0 && near_n == 0 && again == 0,
          "B48d: 2-b: no drop-through move or hint (it isn't in the game)");
    cues::ToggleWaypoint(far_away);

    // B27 (mark 1, 4-a): Shank at (5953, 352) on the floor s1, the health on the one-way platform s3 above: P says the way.
    level_geometry::SetLevel("campaign_4a_winecellar");
    pathing::SetLevel("campaign_4a_winecellar");
    cues::Reset();
    {
        const position::Pos below = At(5953, 352, true);
        for (unsigned t = 50000; t < 51000; t += 10) {
            if (t % 500 == 0) cues::OnCue("beacon_health", 5917, 912, t);
            cues::Tick(t, below);
        }
        const std::string p = cues::PickupSummary(51000, below);
        printf("  (4-a P: %s)\n", p.c_str());
        Check(p.find("To the health: ") != std::string::npos && p.find(" move") != std::string::npos,  // (B41-4: one jump, a ledge grab)
              "4-a: P gives the way to the health on the platform above");
    }

    // B27-4 (mark 4, 4-c): sliding down s18 (45 degrees, ~880 px/s each way) toward swing point f0 (38080, 1216): the
    // slide jump reaches it, so it chirps (it didn't: sliding counted as in the air).
    level_geometry::SetLevel("campaign_4c_thevilla");
    pathing::SetLevel("campaign_4c_thevilla");
    cues::Reset();
    {
        int chirps = 0;
        for (unsigned t = 60000; t < 60600; t += 10) {
            const float x = 37150.f + (t - 60000) * 0.5f;  // down the slope
            const float y = 1792.f - (x - 36800.f) + 32.f;
            for (const cues::PlayCmd& q : cues::Tick(t, At(x, y, true, 880.f, -880.f)).plays) chirps += q.sound == audio::kJumpNow;
        }
        printf("  (4-c slide: %d chirps)\n", chirps);
        Check(chirps >= 2, "4-c: sliding down the slope, the jump to the swing point chirps");
        // B27-6 (mark 5's spot, 4-c): hanging from swing point f7 (49953, 2773): T says so first, not "3 above".
        const position::Pos hang = At(49953, 2773, false);
        for (unsigned t = 61000; t < 61300; t += 10) cues::Tick(t, hang);
        const std::string tt = cues::TraversalSummary(hang);
        printf("  (4-c T on f7: %s)\n", tt.c_str());
        Check(tt.find("Hanging from a swing point.") == 0 && tt.find("here, 3 above") == std::string::npos,
              "4-c: T on a swing point says so first");
    }

    // B28b (mark 1, 2-c): running past "stairstep swing points" (its trigger 208 px wide) with positions only every
    // 0.5 s: one just before it, one just after. The checkpoint still counts.
    level_geometry::SetLevel("campaign_2c_redlight");
    pathing::SetLevel("campaign_2c_redlight");
    cues::Reset();
    {
        const position::Pos before = At(27389, 864, true), after = At(27677, 864, true);
        cues::ToggleWaypoint(before);
        std::string said;
        for (const auto& c : level_geometry::Checkpoints()) {  // placed at the checkpoint before it (as in the log)
            if (c.order == 5) {
                for (unsigned t = 69000; t < 69300; t += 10) cues::Tick(t, At(c.spawn_x, c.spawn_y, true));
            }
        }
        unsigned tw = 69300;  // walking toward it (steps, not a respawn jump)
        for (float x = 22700; x <= 26800; x += 100, tw += 10) cues::Tick(tw, At(x, 864, true));
        for (unsigned t = 70000; t < 70500; t += 10) said += cues::Tick(t, before).say;
        for (unsigned t = 70500; t < 71000; t += 10) said += cues::Tick(t, after).say;
        printf("  (2-c past the checkpoint: \"%s\")\n", said.c_str());
        Check(said.find("Checkpoint. Next: slide pole slide ramp") != std::string::npos,
              "2-c: a checkpoint passed between two positions still counts");
        cues::ToggleWaypoint(after);
    }

    // B28b (mark 6, 2-c): hanging from the shimmy line at (75565, 2830), the jump-now chirp for the floor below sounded
    // while T said "Hanging from a shimmy line. Nothing else nearby." T names that floor now.
    cues::Reset();
    {
        const position::Pos hang = At(75564.8f, 2830.5f, false, -280.f, 110.f);
        int chirps = 0;
        for (unsigned t = 80000; t < 80600; t += 10) {
            for (const cues::PlayCmd& q : cues::Tick(t, hang).plays) chirps += q.sound == audio::kJumpNow;
        }
        const std::string tt = cues::TraversalSummary(hang);
        printf("  (2-c shimmy line: %d chirps; T: %s)\n", chirps, tt.c_str());
        Check(chirps == 0 || tt.find("A floor, ") != std::string::npos || tt.find("A climbable wall, ") != std::string::npos,
              "2-c: when a jump to a floor (or, B47b-2, a wall) chirps, T names it");
    }

    // B29-2: the chapter's name once the level has loaded, by where he starts (4-a: "The Underworld" from its start,
    // "Leap of Faith" from checkpoint 9).
    level_geometry::SetLevel("campaign_4a_winecellar");
    pathing::SetLevel("campaign_4a_winecellar");
    for (int start : {0, 9}) {
        cues::Reset();
        std::string chapter;
        for (const auto& c : level_geometry::Checkpoints()) {
            if (c.order != start) continue;
            for (unsigned t = 90000; t < 90500; t += 10) chapter += cues::Tick(t, At(c.spawn_x, c.spawn_y, true)).chapter;
        }
        printf("  (4-a from checkpoint %d: \"%s\")\n", start, chapter.c_str());
        Check(chapter == (start == 0 ? "The Underworld" : "Leap of Faith"), "4-a: the chapter's name once, by the start checkpoint");
    }

    // B29-6: the Priest's chapter spawns him on a swing point (71417, 11972); the fight starts in the intro's region
    // (70734.., 11860..): that's the next goal, and entering it counts like a checkpoint.
    level_geometry::SetLevel("campaign_3c_church");
    pathing::SetLevel("campaign_3c_church");
    cues::Reset();
    {
        const position::Pos spawn = At(71400, 11952, false);  // (landed: on the sloped floor under the spawn)
        cues::ToggleWaypoint(spawn);
        for (unsigned t = 95000; t < 95500; t += 10) cues::Tick(t, spawn);
        const std::string q = cues::NextMove(spawn);
        printf("  (3-c Priest chapter: Q: %s)\n", q.c_str());
        Check(q.find("Boss fight") != std::string::npos, "3-c: from the Priest chapter's spawn, Q leads to the boss fight");
        std::string said;
        for (unsigned t = 95500; t < 96000; t += 10) said += cues::Tick(t, At(70960, 11892, false)).say;
        printf("  (3-c in the intro's region: \"%s\")\n", said.c_str());
        Check(said.find("Checkpoint.") != std::string::npos, "3-c: the boss fight's trigger counts as a checkpoint");
        cues::ToggleWaypoint(spawn);
    }
    // B41-4 (1-c mark 4, the B40d log): from the shimmy line f19 at x 16014 (hanging, y 2534) he jumped right and caught
    // s29's ledge (16384, 2944): the bar jump reaches it.
    level_geometry::SetLevel("campaign_1c_meatpacking");
    jump_model::SetObstacles(&level_geometry::Obstacles());  // (the cues set them on their next tick; this check runs first)
    {
        jump_model::Target s29{jump_model::kLanding, 16384.f, 2944.f, 16789.3f, 2944.f};
        const jump_model::Jump j = jump_model::ReachFromBar(s29, 16014.f, 2534.f, true);
        printf("  (1-c f19 -> s29 from x 16014: jump %d)\n", static_cast<int>(j));
        Check(j != jump_model::kNone, "B41-4: the bar jump from f19 at x 16014 reaches s29 (a ledge grab)");
    }
    // 4-a's last checkpoint: the level's exit is the goal.
    level_geometry::SetLevel("campaign_4a_winecellar");
    pathing::SetLevel("campaign_4a_winecellar");
    cues::Reset();
    {
        const position::Pos p = At(75000, 10272, true);  // (on the floor to the exit, past the last checkpoint)
        for (unsigned t = 96500; t < 97000; t += 10) cues::Tick(t, At(73665, 9153, true));  // (placed at its spawn first)
        for (unsigned t = 97000; t < 97500; t += 10) cues::Tick(t, p);
        const std::string q = cues::NextMove(p);
        printf("  (4-a last checkpoint: Q: %s)\n", q.c_str());
        Check(q.find("Level exit") != std::string::npos, "4-a: from the last checkpoint, Q leads to the level's exit");
    }
    // B41-5 (1-c marks 2 and 3): onto a slope, Q says so and goes on with the move off it (a turn at once); a chain of
    // slides in one go.
    level_geometry::SetLevel("campaign_1c_meatpacking");
    pathing::SetLevel("campaign_1c_meatpacking");
    cues::Reset();
    {
        const position::Pos on_s43 = At(25000, 3680, true);
        for (unsigned t = 99000; t < 99500; t += 10) cues::Tick(t, At(24300, 3893, true));  // (at Cold Storage 2 first)
        if (!cues::WaypointOn()) cues::ToggleWaypoint(on_s43);
        for (unsigned t = 99500; t < 100000; t += 10) cues::Tick(t, on_s43);
        const std::string q = cues::NextMove(on_s43);
        printf("  (1-c s43: Q: %s)\n", q.c_str());
        Check(q.find("a slope, sliding left") != std::string::npos && q.find("Then turn left at once and long jump") != std::string::npos,
              "B41-5: onto the slope: said, with the turn and the jump off it");
        const position::Pos on_s51 = At(30000, 3040, true);
        for (unsigned t = 100000; t < 100500; t += 10) cues::Tick(t, At(27037, 942, true));  // (Mid Cold Storage first)
        for (unsigned t = 100500; t < 101000; t += 10) cues::Tick(t, on_s51);
        const std::string q2 = cues::NextMove(on_s51);
        printf("  (1-c s51: Q: %s)\n", q2.c_str());
        Check(q2.find(". Then ") != std::string::npos, "B41-5: the slides before the Butcher in one go");
        cues::ToggleWaypoint(on_s51);
    }

    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
