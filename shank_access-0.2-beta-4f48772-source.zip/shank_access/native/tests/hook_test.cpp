// Host-side test of the sound-hook shims (never deployed). Stand-in functions use the same
// unusual convention as Shank's sound functions (name in esi; PlaySoundAt also takes a position
// pointer on the stack, caller cleans). We hook them with the real sound_hooks code and check:
//   - the log line has the right name, position, listener and pan;
//   - the original still runs and sees exactly the caller's esi and position;
//   - callee-saved registers and the stack are unchanged afterwards.
// Exit code 0 = pass.
#include <windows.h>

#include <cstdio>
#include <cstring>
#include <string>

#include "../core/log.h"
#include "../core/sound_hooks.h"
#include "../core/mod_state.h"

namespace {

const char* g_seen_name_at = nullptr;
const float* g_seen_pos = nullptr;
int g_calls_at = 0;
const char* g_seen_name_2d = nullptr;
int g_calls_2d = 0;
float g_listener[4] = {640.f, 360.f, 1000.f, 500.f};  // half-w, half-h, centre x, centre y

// Stand-in for 0x55ab90: starts with the same "sub esp, 10h".
__declspec(naked) void FakePlaySoundAt() {
    __asm {
        sub esp, 0x10
        mov eax, [esp + 0x14]   // pos: the stack argument, now 0x10 deeper
        mov g_seen_pos, eax
        mov g_seen_name_at, esi
        inc g_calls_at
        add esp, 0x10
        ret
    }
}

// Stand-in for 0x55ab10: starts with the same "push ecx".
__declspec(naked) void FakePlaySound() {
    __asm {
        push ecx
        mov g_seen_name_2d, esi
        inc g_calls_2d
        pop ecx
        ret
    }
}

// B8f: stand-in for 0x55b0d0 (starts with the same "push ecx"): dt on the stack, half-size in esi, centre in edi;
// copies them into the listener as the game does.
float g_seen_dt = 0;
const float* g_seen_half = nullptr;
const float* g_seen_centre = nullptr;
__declspec(naked) void FakeSoundUpdate() {
    __asm {
        push ecx
        mov eax, [esp + 8]      // dt (after push ecx)
        mov g_seen_dt, eax
        mov g_seen_half, esi
        mov g_seen_centre, edi
        mov eax, [esi]
        mov dword ptr [g_listener], eax
        mov eax, [esi + 4]
        mov dword ptr [g_listener + 4], eax
        mov eax, [edi]
        mov dword ptr [g_listener + 8], eax
        mov eax, [edi + 4]
        mov dword ptr [g_listener + 12], eax
        pop ecx
        ret
    }
}

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

std::string g_cue;
float g_cue_x = 0, g_cue_y = 0;
int g_cues = 0;

// Calls the (hooked) stand-in PlaySoundAt the way the game does, and records the registers after.
struct After {
    unsigned esi, ebx, edi, esp_before, esp_after;
};
After CallPlaySoundAt(const char* name, float* pos) {
    unsigned r_esi = 0, r_ebx = 0, r_edi = 0, esp_before = 0, esp_after = 0;
    // ebp is left alone: the compiler addresses this function's locals through it.
    __asm {
        push esi
        push ebx
        push edi
        mov esi, name
        mov eax, pos
        mov ebx, 0x12345678
        mov edi, 0x9ABCDEF0
        mov esp_before, esp
        push eax
        call FakePlaySoundAt
        add esp, 4
        mov esp_after, esp
        mov r_esi, esi
        mov r_ebx, ebx
        mov r_edi, edi
        pop edi      // reverse of the pushes above
        pop ebx
        pop esi
    }
    return After{r_esi, r_ebx, r_edi, esp_before, esp_after};
}

// Calls the (hooked) stand-in sound update the way the game does (0x521000-0x52100e).
After CallSoundUpdate(float dt, float* half, float* centre) {
    unsigned r_esi = 0, r_ebx = 0, r_edi = 0, esp_before = 0, esp_after = 0;
    __asm {
        push esi
        push ebx
        push edi
        mov esi, half
        mov edi, centre
        mov ebx, 0x12345678
        mov esp_before, esp
        push dt
        call FakeSoundUpdate
        add esp, 4
        mov esp_after, esp
        mov r_esi, esi
        mov r_ebx, ebx
        mov r_edi, edi
        pop edi
        pop ebx
        pop esi
    }
    return After{r_esi, r_ebx, r_edi, esp_before, esp_after};
}

}  // namespace

int main() {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_hook_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    const bool installed = sound_hooks::InstallAt(reinterpret_cast<unsigned>(&FakePlaySoundAt),
                                                  reinterpret_cast<unsigned>(&FakePlaySound),
                                                  reinterpret_cast<unsigned>(g_listener));
    Check(installed, "hooks installed on stand-ins");

    sound_hooks::SetCueListener([](const char* cue, float x, float y) {
        g_cue = cue;
        g_cue_x = x;
        g_cue_y = y;
        ++g_cues;
    });
    static const char kName[] = "Shank/Character/Sounds/Attacks/Uzi/Uzi_Arm";
    static const char kName2d[] = "Shank/GUI/onfocus";
    float pos[2] = {1320.f, 420.f};
    After a = CallPlaySoundAt(kName, pos);
    Check(g_calls_at == 1, "original PlaySoundAt ran once");
    Check(g_seen_name_at == kName, "original saw the caller's esi (name)");
    Check(g_seen_pos == pos, "original saw the caller's position pointer");
    Check(a.esi == reinterpret_cast<unsigned>(kName), "esi preserved");
    Check(a.ebx == 0x12345678 && a.edi == 0x9ABCDEF0, "ebx/edi preserved");
    Check(a.esp_before == a.esp_after, "stack balanced");
    Check(g_cues == 0, "a game sound is not a cue");

    // Our own a11y/ messages go to the cue listener and never reach the original.
    static const char kCue[] = "Shank/Character/a11y/got_minigun";
    float cue_pos[2] = {-50.f, 2048.f};
    a = CallPlaySoundAt(kCue, cue_pos);
    Check(g_calls_at == 1, "a11y cue: original not called");
    Check(g_cues == 1 && g_cue == "got_minigun" && g_cue_x == -50.f && g_cue_y == 2048.f, "a11y cue: listener got name and position");
    Check(a.esi == reinterpret_cast<unsigned>(kCue), "a11y cue: esi preserved");
    Check(a.ebx == 0x12345678 && a.edi == 0x9ABCDEF0, "a11y cue: ebx/edi preserved");
    Check(a.esp_before == a.esp_after, "a11y cue: stack balanced");
    static const char kPing[] = "Shank/Character/a11y/pos_r";
    CallPlaySoundAt(kPing, cue_pos);
    Check(g_cues == 2 && g_cue == "pos_r" && g_calls_at == 1, "position ping: a cue too");
    static const char kNotCue[] = "Shank/Character/xa11y/nope";
    CallPlaySoundAt(kNotCue, pos);
    Check(g_cues == 2 && g_calls_at == 2, "a11y/ inside another word: a normal sound");
    // B38-3: the mod off (F11): our cues still swallowed but not passed on; game sounds reach the original.
    mod_state::SetActive(false);
    CallPlaySoundAt(kCue, cue_pos);
    Check(g_cues == 2 && g_calls_at == 2, "B38-3 off: an a11y cue is swallowed, the listener not called");
    CallPlaySoundAt(kName, pos);
    Check(g_calls_at == 3 && g_cues == 2, "B38-3 off: a game sound plays as vanilla");
    mod_state::SetActive(true);
    CallPlaySoundAt(kPing, cue_pos);
    Check(g_cues == 3, "B38-3 on again: cues reach the listener");

    const char* name2d_ptr = kName2d;
    __asm {
        push esi
        mov esi, name2d_ptr
        call FakePlaySound
        pop esi
    }
    Check(g_calls_2d == 1 && g_seen_name_2d == kName2d, "original PlaySound ran and saw esi");

    // Read the log back (shared for reading while open).
    char text[4096] = {};
    FILE* f = _fsopen(log_path, "r", _SH_DENYNO);
    if (f) {
        fread(text, 1, sizeof text - 1, f);
        fclose(f);
    }
    Check(strstr(text, "sound at: Shank/Character/Sounds/Attacks/Uzi/Uzi_Arm pos=(1320, 420) listener=(1000, 500) half=(640, 360) pan=0.50") != nullptr,
          "log line: name, position, listener, pan");
    Check(strstr(text, "cue: got_minigun pos=(-50, 2048)") != nullptr, "log line: cue");
    Check(strstr(text, "cue: pos_") == nullptr, "position pings not logged");
    Check(strstr(text, "sound 2d: Shank/GUI/onfocus") != nullptr, "log line: 2d sound");
    if (g_failures) printf("--- log ---\n%s\n", text);
    // B8f: the per-frame sound update (dt on the stack, camera half-size in esi, centre in edi) copies the camera
    // into the listener; the hook then puts Shank's position in the centre's place.
    Check(sound_hooks::InstallPanHookAt(reinterpret_cast<unsigned>(&FakeSoundUpdate)), "pan hook installed on a stand-in");
    float half[2] = {1600.f, 900.f}, centre[2] = {5000.f, 300.f};
    After u = CallSoundUpdate(0.016f, half, centre);
    Check(g_seen_dt == 0.016f && g_seen_half == half && g_seen_centre == centre, "the original saw dt, esi and edi as passed");
    Check(u.ebx == 0x12345678 && u.esi == reinterpret_cast<unsigned>(half) && u.edi == reinterpret_cast<unsigned>(centre),
          "ebx/esi/edi preserved");
    Check(u.esp_before == u.esp_after, "stack balanced");
    Check(g_listener[2] == 5000.f && g_listener[3] == 300.f, "Shank's position not known yet: the camera centre, as the game does");
    sound_hooks::SetShankCentre(true, 4200.f, 224.f);
    CallSoundUpdate(0.016f, half, centre);
    Check(g_listener[0] == 1600.f && g_listener[2] == 4200.f && g_listener[3] == 224.f, "on (the default): the centre is Shank");
    float p = 0;
    Check(sound_hooks::CameraPan(5800.f, &p) && p == 0.5f, "the enemy cues' camera pan still uses the camera's centre");
    Check(!sound_hooks::TogglePanAroundShank(), "C: off");
    CallSoundUpdate(0.016f, half, centre);
    Check(g_listener[2] == 5000.f, "off: the camera centre again");
    sound_hooks::SetPanAroundShank(true);

    // B30-3: the FMOD Event start / volume exports are found in the game's own fmod_event.dll (loaded read-only here).
    Check(!sound_hooks::InstallVolumeHook(), "B30-3: no fmod_event.dll loaded: no volume hook (and no crash)");
    const HMODULE fmod = LoadLibraryExW(L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Shank\\bin\\fmod_event.dll", nullptr,
                                        LOAD_WITH_ALTERED_SEARCH_PATH);
    if (fmod) {
        Check(sound_hooks::InstallVolumeHook(), "B30-3: the game's fmod_event.dll: Event::start hooked, get/setVolume found");
    } else {
        printf("  (the game's fmod_event.dll isn't there: skipped)\n");
    }

    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
