---
name: sync-memory
description: Context-to-memory sync for shank-access. Compare everything important in the current conversation against the project docs (PLAN, TESTING, DESIGN, RE-NOTES, CLAUDE.md), write down whatever is missing, AND close every earlier open item that has since been answered, done, tested or dropped, so nothing is lost or left stale on compaction or a session switch. Use when the user says "sync memory", "save context" or asks for a memory/context comparison or audit; after finishing a task or test session; and on your own whenever the context is getting large (see CLAUDE.md for thresholds).
---

# Sync memory: copy the conversation into durable docs, and close the loops

Goal: after this runs, a brand-new session with **no conversation history** could continue the work exactly, using only the repo docs and the SessionStart briefing, **and nothing in the docs claims to be waiting, untested or open when it isn't.**

Why step 4 exists (2026-09-29): syncs used to only *add* what was missing. When a question was answered or a test happened, the answer went into a new entry, but the old "waiting on the user's choice" / "awaiting user" / "(hypothesis)" stayed where it was. A later session found about 30 stale items, several weeks' worth. Adding the new fact is only half the job. The old marker must be changed too.

## 1. Inventory the conversation
Go through the conversation since the last checkpoint (or since the session started) and list every item of these kinds:

- **Decisions**, and why they were made. That includes choices the user made or approved.
- **The user's statements:** preferences, feedback on cues or UI, goals, constraints, corrections to your assumptions. Quote them closely.
- **Engine facts learned:** addresses, struct offsets, formats, behaviour, including negative results ("X does not work").
- **Test activity:** what was deployed, the instructions given, what the user reported, log findings.
- **Work state:** tasks started but not finished, files changed but not committed, commands still running, branches.
- **Open loops:** questions asked and not yet answered, things promised to the user ("I'll do X next", "remind me…"), hypotheses still being tested.
- **Process or tooling changes:** new scripts, new workflow steps, environment facts (installed tools, paths, versions).
- **Resolutions:** every item above that *settles something from earlier*: an answer to an earlier question, a pick among offered options, "works" / "doesn't work" about an earlier deploy, a hypothesis confirmed or refuted, an offer declined, a feature dropped or declared out of scope. For each one, note **which earlier item it settles** (batch id, question, hypothesis). These drive step 4.

## 2. Compare against the docs
For each item, check whether it's already recorded in the right place. Read the relevant files; don't trust memory.

| Kind | Where it belongs |
|---|---|
| Status, next action, in-flight work, open loops, promises | `docs/PLAN.md`: **Status** and **In flight** |
| Task progress | `docs/PLAN.md` phase checkboxes |
| Decisions and why | `docs/PLAN.md` Decision log |
| One-line history | `docs/PLAN.md` Work log |
| Test session details | `docs/TESTING.md` (entry per session) |
| Cue, hotkey and config details; the user's feedback on how things sound or feel; the user's goals | `docs/DESIGN.md` |
| Engine facts, marked (hypothesis) or (confirmed date, how) | `docs/RE-NOTES.md` |
| Standing rules, the user's working preferences, commands, layout | `CLAUDE.md` |

## 3. Write what's missing
- Add anything missing or stale to the right file. Prefer precise details (exact addresses, file names, the user's wording, thresholds, numbers) over summaries. The details are what compaction loses.
- Make sure **In flight** accurately describes this moment. If nothing is in flight, say so explicitly.
- Update "Last updated" in the Status block.

## 4. Close the loops (mandatory, every run)
Adding the new fact is only half the job. Change the old open marker too.

### 4a. Resolutions from this conversation
For each **resolution** in the inventory:
- Search every doc for the item it settles: grep the batch id (B23, B25b…), key words of the question, the hypothesis text, and the feature name.
- Update **every place** it's mentioned, not just the first one. The same item usually appears in several places:
  - the PLAN In flight record ("waiting on the user's pick");
  - a PLAN phase checkbox (`[ ]` / `[~]`);
  - the PLAN Status block and the "Next:" / "Waiting on the user" / "Kept for later" lines;
  - PLAN section 5, "Open questions / risks";
  - a TESTING entry header;
  - a DESIGN "not yet" / "still to come" line;
  - a RE-NOTES **(hypothesis)**.
- Close it in place with the evidence. Write "answered 2026-09-28: 'Implement all four…' → B23", not just a deleted word. Use `[x]`, or `[-]` with the reason, for checkboxes.

### 4b. Doc-wide sweep
Run `.venv/Scripts/python tools/open_items.py`. It lists every open-looking line: waiting, awaiting, untested, hypothesis, not yet, ask the user, unchecked boxes, and TESTING headers not marked done. It skips the PLAN logs and finished TESTING entries; add `--all` for those.
- Decide each hit:
  - **still open:** leave it;
  - **resolved:** close it with the evidence;
  - **superseded or dropped:** say by what.
- **Never close on a guess.** The evidence must be one of:
  - the conversation;
  - a later doc entry (a later batch, a user quote, a work log line);
  - the collected logs (4c).
- If you can't tell, leave it open. Mention it in the report.
- Many hits are really open (deferred by the user, release items, real hypotheses). That's fine: the point is that each one has been looked at.

### 4c. Test statuses against the logs
For each TESTING entry whose header says "awaiting user" or "partly":
1. List the sessions collected since its deploy (`ls build/logs/`, newest after the deploy date).
2. In each session's `a11y.log`, check two things:
   - which levels were played (`grep -o "campaign_[a-z0-9_]*" | sort -u`);
   - the entry's own **Log markers**, and the user's comments since the deploy.
3. Rewrite the header:
   - `done (evidence)`;
   - `partly tested (what was confirmed); awaiting user: <exactly what's still unplayed>`;
   - `awaiting user (why: e.g. that level not replayed since)`.
4. Keep the words **"awaiting user"** in a header only while something is really still to play. The SessionStart briefing lists tests by exactly that phrase.

### 4d. Status block consistency
- **Current phase:** must name the newest deployed batch.
- **Deployed to the game right now**, **Next action** and **Blocked on:** must match In flight's "Current task".
- **Last updated:** must be today's date.

## 5. Verify
- Run `.venv/Scripts/python tools/session_context.py` and read it as a new session would:
  - Does every line read true right now?
  - Does the "Test sessions awaiting the user" list hold only real outstanding tests?
- Re-run `tools/open_items.py`. Nothing you closed should still show as open.

## 6. Commit
- Run the tests if code changed: `.venv/Scripts/python -m unittest discover -s tests`.
- Commit the docs together with any related code, with a message starting `Sync memory:`.
- Push if a remote is configured.

## 7. Report
Tell the user in 2–6 short sentences:
- what was added or updated, and where;
- **what was closed** (answered, done, tested, dropped), and what is still genuinely open or awaiting a test;
- anything you couldn't resolve that needs their input.

Use player terms, not internal labels (CLAUDE.md). If nothing was missing or stale, say so in one line.
