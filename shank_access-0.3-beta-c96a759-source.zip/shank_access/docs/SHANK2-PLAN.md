# Shank 2 port plan

Written 2026-10-04, when the port was handed to a second developer. It builds on
[SHANK2-ASSESSMENT.md](SHANK2-ASSESSMENT.md): read that first for the engine facts.
The Shank 1 docs (PLAN, RE-NOTES, DESIGN, TESTING) are the record of how the Shank 1 mod was built. Every method
used there (batches, test points, the movement corpus, memory discipline) applies here too.

**Claude: this file is the port's PLAN.** Keep its checkboxes, Status and In flight current. Use the same rules as
docs/PLAN.md (CLAUDE.md "Memory discipline"). Shank 2 engine facts go into RE-NOTES under a "Shank 2" heading.
Shank 2 test sessions go into TESTING.md, titled "Shank 2: ...".

## Status
- **Phase:** not started. Next: S2B0 (onboarding).
- **Developer:** the second developer (who they are, how they test, their preferences: ask at the first session and
  record it in CLAUDE.md "Working with the user", under their own heading).
- **Shank 2 install:** `C:\Program Files (x86)\Steam\steamapps\common\Shank 2` on Karl's machine; confirm the path
  on the new machine. `bin\shank2.exe` SHA-256 must be
  `3cd7aeb0d9f135dc82c4bba491463ecb85fec9aa33b9189ab2cee5160dd045d3` (Steam build, January 2012). Any other hash
  means another build: stop and record it before any address work.
- **Blocked on:** nothing.

## In flight
- Nothing yet. The first session starts S2B0.

## Scope and standing decisions (defaults set 2026-10-04; the new developer may change them, with a Decision log line)
1. **Scope:** the single-player campaign: 8 levels, 107 checkpoints (the table is in the assessment). Survival mode
   (online co-op waves) and co-op are out, as they were for Shank 1.
2. **Repository layout:** one tree, a shared core and a per-game layer. Shank 1 must keep building, and its host
   tests must keep passing, after every Shank 2 change. The game is picked at build time:
   `-DSHANK_GAME=2` into its own build folder `build/native_s2`; Shank 1 stays the default.
   - Per game: `game.h` addresses, `exe_check`'s hash, the hooks and the data tools.
   - Shared: speech, audio, hotkeys, mod_menu, config, marks, session_logs, input_block, focus_window, mod_state,
     pathing, the cue thread's logic.
   - Reason: fixes to the shared parts reach both games, and the Shank 1 beta stays maintainable.
3. **Game-side Lua is Lua 5.1 for Shank 2** (CLAUDE.md's Lua 5.0 rules are Shank 1 only). Shank 2's own
   stategraphs, attributes and behaviour graphs are compiled 5.1 bytecode. Prefer native hooks over Lua. If Lua is
   needed, use our own source file loaded through a source-Lua load point (level scripts, `autoexec.lua`). Never
   ship or commit decompiled Klei code.
4. **Deploying to the Shank 2 folder:** only through tools/deploy.py, extended with a game switch (S2B1), and only
   when the developer is ready to test. Same rules as Shank 1: data-pc overrides, game files stay vanilla, and ask
   before every deploy.
5. **Publishing:** the Shank 1 beta's public repo and forum thread are Karl's. A Shank 2 release, and where it goes,
   is for Karl and the second developer to agree; nothing is published without the developer saying so.

## Batches (test points marked; numbering S2B1, S2B1-1, fix rounds S2B1b)

### S2B0: onboarding (no game changes)
- [ ] Toolchain: VS 2022 Build Tools (C++ x86), CMake, Python 3.14 venv (`py -m venv .venv`,
  `pip install -r requirements.txt`), git. Build `build/native` (Shank 1) and `build/lua50`, and run the unit tests
  and host tests (CLAUDE.md Commands). They must pass before any change.
- [ ] Record the developer in CLAUDE.md: name, screen reader or not, how they want test plans, what they own
  (Shank 1 too?).
- [ ] Check Shank 2's exe hash and install path; set `SHANK_GAME_DIR` / `SHANK_EXE` for the tools if the path
  differs.

### S2B1: bootstrap (test point)
- [ ] S2B1-1: the game switch in native/CMakeLists.txt (`SHANK_GAME`), a Shank 2 `game.h`, and an exe_check with
  shank2.exe's hash. Everything Shank 2 can't use yet is compiled out or inert.
- [ ] S2B1-2: the dinput8 proxy loads shank_access.dll in Shank 2: log to a11y.log, speech says
  "Shank 2 Access loaded".
- [ ] S2B1-3: deploy.py `--game shank2` (own pristine list, own backups folder), plus one harmless data-pc override
  file to confirm that PhysFS searches data-pc first in Shank 2.
- [ ] S2B1-4: F11 mod off / on, F7 settings menu, F2 marks, F8 / F9 repeat working in Shank 2 (shared code; check
  the raw-input hook and the focus-loss pause).
- Test: launch, hear the start-up line, open F7, place an F2 mark, quit. Collect the logs.

### S2B2: test mode for Shank 2 (test point; makes all later testing faster)
- [ ] S2B2-1: F3 test mode (shared) and the startup movie skips for Shank 2's own intro movies (Bink `.bik` in
  data/movies and data-pc/movies; find what plays at start-up and patch it like Shank 1's patches.cpp).
- [ ] S2B2-2: Go to checkpoint (F7, test mode). Shank 2 has `Checkpoint` / `CheckpointTrigger` classes and a debug
  "SWITCH CHECKPOINT" entry in autoexec.lua's debug menu: find the native call behind it.
- [ ] S2B2-3: god mode / super speed if Shank 2 keeps debug flags (autoexec.lua's "SUPER DAMAGE MODE",
  "SUPER SPEED MODE").

### S2B3: menus (Chui) (test point)
- [ ] S2B3-1: find the UI event dispatch (`UIEvent_FocusGained`, `cScreenManager`). Log every focused widget's
  screen, name, type and text while the developer walks the menus.
- [ ] S2B3-2: an offline reader of the 34 `.chui` files (widget names, English text, neighbour links), generated
  into a bin/ text file like ui_text, never committed.
- [ ] S2B3-3: a Chui menu_reader: focus, role, value (spinners, checks, sliders), screen titles, dialogs, level
  select, loadout, death screen, How to Play.

### S2B4: status readouts (test point)
- [ ] Health drops, grenades, boss name and health, combo, pickups, checkpoint reached, death: from the game's
  event classes (`cDamageEvent`, `cHealEvent`, `cComboCountChangedEvent`, `cPickupConsumableEvent`,
  `cCheckPointEvent`, `cDeathEvent`, `BossUI`). H and G keys.

### S2B5: level data (host only)
- [ ] S2B5-1: slev v12: the changed path records and the large tail (hypothesis: the AI navigation graph). Every
  campaign level must parse to the exact end of its file, as Shank 1's did.
- [ ] S2B5-2: extract_levels.py for Shank 2 (`spawngameobject` names, checkpoints and their chain, pits and damage
  zones, chapter names).
- [ ] S2B5-3: geometry.py for Shank 2 (the new tags: climbable, slideable, pushwall, rickety; surface materials),
  deployed as Shank 2's geometry file.

### S2B6: position, level hooks, edge cues (test point)
- [ ] Shank's position natively (player item → physics position), LoadSimData (level name), set-bounds (arena
  bounds), the edge cue, P and T summaries, C (game sounds around Shank).

### S2B7: enemies (test point)
- [ ] The game item list, character names, nearest-enemy tick, pass whooshes, N, L / K lock-on.
- [ ] Attack wind-ups from a native state-change hook against an offline table of wind-up states (the state names
  are readable constants in the bytecode). Shank 2's AI uses behaviour graphs.

### S2B8: pickups, hazards, prompts (test point)
- [ ] Pickup beacons and "in reach", hazards (grenades, molotovs, fire, falling debris, propane), counter / grapple
  prompts, "got" messages, heavy objects. All natively, replacing Shank 1's 29 script patches.

### S2B9: safe edges (test point)
- [ ] The HasTag hook (Shank 2 keeps the HasTag condition) and the guarded drops.

### S2B10 onward: movement model and waypoints (test points level by level)
- [ ] `traj:` logging, then movements.py for Shank 2 logs. Build the corpus from the developer's play: Shank 2's
  movement is in C++, so nothing can be read from scripts.
- [ ] The jump model calibrated per Shank 2 move (jumps, wall runs, swings, shimmies, back roll, wall climb, slides),
  then path_graph, waypoint mode (W) and Q.
- [ ] Level by level, using the Shank 1 user's session rules (CLAUDE.md: group by level, routes need one safe path,
  "no jump" wording).

### S2B-release (when the developers decide)
- [ ] A release build and a Shank 2 setup (tools/setup), readme, publishing: outward-facing, only when they say.

## Decision log
- **2026-10-04** — Port goes ahead with a second developer (Karl: "I found another person who will work on the
  shank 2 port"). Defaults above set by Claude from the assessment's recommendations; the developer may revisit them.

## Work log
- **2026-10-04** — Plan written; handoff zip built (tools/make_handoff.py).
