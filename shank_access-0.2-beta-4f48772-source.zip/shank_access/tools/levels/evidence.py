"""B47-2: the evidence for every move on every checkpoint route, from the old logs against today's model and cue.

For each route move (a jump, fall, drop or catch; on-foot moves are listed apart) it gathers the real flights launched
within 2 tiles of where the move starts (build/movements/movements.json), how they ended (the move's own target, somewhere
else, a death), the model's verdicts on them (build/movements/check.txt: reach, replay, false catch) and today's replayed
jump-now cue (build/movements/replay.txt: kept, false, missing), and gives the move a status:
  proven        real flights made this move (and today's model agrees)
  mixed         some real flights made it, others from the same spot died or missed it
  contradicted  real flights tried it (the same kind of launch, toward its target) and none made it
  model-doubt   real flights made it but the model can't (reach MISS), or the replay found a false / missing chirp there
  untested      no real flight from there
Writes build/levels/evidence.txt (per level, leg, move) and build/levels/evidence.json (for the test plan) and prints a
summary. Run after path_graph, movements.py, movement_check and cue_replay.

Usage: evidence.py [<level>]
"""
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
import path_check  # noqa: E402
import risky_moves as rm  # noqa: E402

MOVES = os.path.join(ROOT, "build", "movements")
LEVELS = os.path.join(ROOT, "build", "levels")
NEAR = 128.0
ON_FOOT = {"climb", "climb_over", "run_up_wall", "climb_up", "climb_down", "slide_down", "switch_sides", "shimmy_along",
           "run_across", "run_off", "drop_through"}
# the corpus's launch kinds for each route move
KINDS = {"long_jump": {"ground", "slide"}, "standing_jump": {"ground"}, "wall_jump": {"cling", "run_up"},
         "run_up_jump": {"run_up", "cling"}, "pole_jump": {"pole"}, "swing_jump": {"swing"}, "bar_jump": {"bar"},
         "jump_up": {"bar", "swing"}, "wall_run_jump": {"wall_run"}, "walk_off": {"walk_off", "fall"},
         "slide_off": {"slide_off", "fall"}, "drop": {"drop", "fall"}, "platform_up": {"ground", "air", "cling"},
         "bounce": {"pole"}}


def end_node(r):
    """The graph node a real flight ended on ('s12', 'f7', 'w53', 'p30' for a pole), or None."""
    on = (r.get("end") or {}).get("on") or {}
    t = on.get("type")
    if t == "landing":
        return "s%d" % on["surface"]
    if t in ("swing", "shimmy", "wallzone"):
        return "f%d" % on["feature"]
    if t == "pole":
        return "p%d" % on["feature"]
    if t == "wall":
        return "w%d" % on["wall"]
    return None


def load_verdicts():
    check, replay = {}, {}
    p = os.path.join(MOVES, "check.txt")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            if line.startswith("mv "):
                f = line.split()
                check[f[1]] = {"reach": f[4], "replay": f[5], "chirp": f[6], "false_catch": f[7] if len(f) > 7 else "-"}
    p = os.path.join(MOVES, "replay.txt")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            if line.startswith("rp "):
                parts = line.rstrip("\n").split(" | ")
                f = parts[0].split()
                replay[f[1]] = (f[6], parts[1] if len(parts) > 2 else "")
    return check, replay


def strong_false(r, chirped):
    """A replayed false chirp whose spot his flight passed within 160 px of (he went for it and missed)."""
    pts = r.get("path") or []
    for cx, cy in re.findall(r"at \((-?\d+), (-?\d+)\)", chirped):
        if any(math.hypot(px - float(cx), py - float(cy)) <= 160 for _, px, py in pts):
            return True
    return False


def move_evidence(level, st, flights, check, replay):
    frm, to, move, x, y, side = st
    base = move.rstrip("!")
    kinds = KINDS.get(base, set())
    want = to if to[0] != "p" else to.rstrip("LR")
    ev = {"tried": 0, "made": 0, "died": 0, "elsewhere": 0, "reach_miss": 0, "false_catch": 0, "chirp_false": 0,
          "chirp_missing": 0, "chirp_kept": 0, "keys": []}
    for r in flights:
        if r["kind"] not in kinds or math.hypot(r["x0"] - x, r["y0"] - y) > NEAR:
            continue
        # launched his way (the move's direction), or nearly straight up
        if r.get("dir") and side and r["dir"] != side and base not in ("jump_up", "drop", "platform_up"):
            continue
        ev["tried"] += 1
        key = "%s:%d" % (r["session"], r["t"])
        ev["keys"].append(key)
        node = end_node(r)
        if node == want:
            ev["made"] += 1
        elif r["end"].get("how") == "death":
            ev["died"] += 1
        else:
            ev["elsewhere"] += 1
        c = check.get(key)
        if c:
            ev["reach_miss"] += c["reach"] == "MISS" and node == want
            ev["false_catch"] += c["false_catch"] == "FALSE"
        rp = replay.get(key)
        if rp:
            if rp[0] == "false" and strong_false(r, rp[1]):
                ev["chirp_false"] += 1
            ev["chirp_missing"] += rp[0] == "missing" and node == want
            ev["chirp_kept"] += rp[0] == "kept" and node == want
    if base in ON_FOOT:
        status = "on foot"
    elif ev["tried"] == 0:
        status = "untested"
    elif ev["made"] == 0:
        status = "contradicted" if ev["died"] or ev["elsewhere"] else "untested"
    elif ev["reach_miss"] or ev["chirp_false"] or ev["chirp_missing"]:
        status = "model-doubt"
    elif ev["died"]:
        status = "mixed"
    else:
        status = "proven"
    return status, ev


def level_evidence(level, all_flights, check, replay):
    surfaces, features, walls, _, _ = path_check.load(level)
    flights = [r for r in all_flights if r.get("level") == level and "x0" in r and r.get("fit") and not r.get("flags")]
    gpath = os.path.join(LEVELS, level + ".geometry.json")
    geo = json.load(open(gpath, encoding="utf-8")) if os.path.exists(gpath) else {"surfaces": []}
    trouble = rm.corpus_trouble(level)
    windows = rm.walk_windows(level)
    chs = rm.chapters(level)
    legs = []
    seen = {}
    for a, b, route in rm.leg_routes(level):
        moves = []
        prev_x = a[1]
        for k, st in enumerate(route):
            key = (st[0], st[1], st[2])
            if key not in seen:
                seen[key] = move_evidence(level, st, flights, check, replay)
            status, ev = seen[key]
            risks = rm.risks(st, surfaces, features, walls, geo, trouble, windows)
            moves.append({"n": k + 1, "of": len(route), "move": st[2].rstrip("!"), "from": st[0], "to": st[1], "x": st[3], "y": st[4],
                          "status": status, "risks": risks, "evidence": {kk: vv for kk, vv in ev.items() if kk != "keys"},
                          "keys": ev["keys"][:6], "text": rm.describe(st, prev_x, surfaces, features, walls)})
            prev_x = rm.target_point(st[1], st[3], st[4], surfaces, features, walls)[0]
        legs.append({"chapter": rm.chapter_of(chs, a[0]), "checkpoint": a[7], "to": b[7], "moves": moves})
    return legs


def main(argv):
    names = [l.strip()[1:-1] for l in open(os.path.join(LEVELS, "shank_access_geometry.txt"), encoding="utf-8") if l.startswith("[")]
    if argv:
        names = [n for n in names if argv[0] in n]
    all_flights = json.load(open(os.path.join(MOVES, "movements.json"), encoding="utf-8"))
    check, replay = load_verdicts()
    out = {}
    lines = ["# B47-2 evidence per route move (tools/levels/evidence.py; derived, never commit)"]
    summary = []
    for level in names:
        legs = level_evidence(level, all_flights, check, replay)
        out[level] = legs
        counts = {}
        done = set()
        lines.append("")
        lines.append("[%s]" % level)
        for leg in legs:
            lines.append("  %s, checkpoint \"%s\" -> \"%s\":" % (leg["chapter"], leg["checkpoint"], leg["to"]))
            for mv in leg["moves"]:
                e = mv["evidence"]
                lines.append("    %2d/%d %-12s %-13s tried %d, made %d, died %d, elsewhere %d%s%s  | %s" % (
                    mv["n"], mv["of"], mv["status"], mv["move"], e["tried"], e["made"], e["died"], e["elsewhere"],
                    "".join([", model can't %d" % e["reach_miss"] if e["reach_miss"] else "",
                             ", false chirp %d" % e["chirp_false"] if e["chirp_false"] else "",
                             ", missing chirp %d" % e["chirp_missing"] if e["chirp_missing"] else ""]),
                    ("  [" + "; ".join(mv["risks"]) + "]") if mv["risks"] else "", mv["text"]))
                k = (mv["from"], mv["to"], mv["move"])
                if k not in done:
                    done.add(k)
                    counts[mv["status"]] = counts.get(mv["status"], 0) + 1
        summary.append("%-28s %s" % (level, ", ".join("%s %d" % kv for kv in sorted(counts.items()))))
    with open(os.path.join(LEVELS, "evidence.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    with open(os.path.join(LEVELS, "evidence.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=0)
    print("\n".join(summary))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
