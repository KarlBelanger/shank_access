#include "test_mode.h"

#include <windows.h>

#include <atomic>
#include <string>

#include "game.h"
#include "hotkeys.h"
#include "log.h"
#include "speech.h"

namespace test_mode {
namespace {

std::atomic<bool> g_on{false};

// Flips a byte flag in the game's debug-settings block and announces the new state.
void Toggle(uintptr_t addr, const char* label) {
    if (!g_on) return;
    volatile unsigned char* flag = reinterpret_cast<volatile unsigned char*>(addr);
    const unsigned char now = *flag ? 0 : 1;
    *flag = now;
    alog::Write("test mode: %s -> %d (byte 0x%08x)", label, now, static_cast<unsigned>(addr));
    speech::Say(std::string(label) + (now ? " on" : " off"));
}

void Clear(uintptr_t addr, const char* label) {
    volatile unsigned char* flag = reinterpret_cast<volatile unsigned char*>(addr);
    if (!*flag) return;
    *flag = 0;
    alog::Write("test mode: %s cleared (byte 0x%08x)", label, static_cast<unsigned>(addr));
}

}  // namespace

void SetOn(bool on) {
    g_on = on;
    if (!on) {
        Clear(game::kDebugGodMode, "God mode");
        Clear(game::kDebugSuperSpeed, "Super speed");
    }
    alog::Write("test mode: %s", on ? "on" : "off");
}

bool On() { return g_on; }

void RegisterHotkeys() {
    hotkeys::Add(VK_F5, "F5 (test mode: god mode)", [] { Toggle(game::kDebugGodMode, "God mode"); });
    hotkeys::Add(VK_F6, "F6 (test mode: super speed)", [] { Toggle(game::kDebugSuperSpeed, "Super speed"); });
    alog::Write("test mode: F5 = god mode, F6 = super speed (while test mode is on)");
}

}  // namespace test_mode
