// Host-side test of B13-2 (never deployed): shank_access_user.ini save/load, the raw-input filter, the settings
// menu (items, changes, key rebinding), announcement toggles. Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <string>
#include <vector>

#include "../core/announce.h"
#include "../core/config.h"
#include "../core/game_pads.h"
#include "../core/hotkeys.h"
#include "../core/input_block.h"
#include "../core/marks.h"
#include "../core/log.h"
#include "../core/session_logs.h"
#include "miniz.h"
#include "../core/mod_menu.h"
#include "../core/speech.h"
#include "../core/status.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

std::vector<std::string> g_said;
int g_volume = 80;
bool g_pan = true, g_edges = false, g_blocked = false;
int g_saves = 0;
void (*g_handler)(int) = nullptr;

}  // namespace

int main() {
    // Config: defaults, then the user file overrides; Save writes what Load reads back.
    wchar_t tmp[MAX_PATH];
    GetTempPathW(MAX_PATH, tmp);
    const std::wstring base = std::wstring(tmp) + L"shank_access_settings_test.ini";
    const std::wstring user = std::wstring(tmp) + L"shank_access_settings_test_user.ini";
    DeleteFileW(base.c_str());
    DeleteFileW(user.c_str());
    WritePrivateProfileStringW(L"cues", L"volume", L"70", base.c_str());
    WritePrivateProfileStringW(L"test", L"test_mode", L"1", base.c_str());
    config::Settings s = config::Load(base, user);
    Check(s.cue_volume == 70 && s.test_mode && s.announce.empty() && s.keys.empty(), "defaults from shank_access.ini");
    s.cue_volume = 40;
    s.pan_around_shank = false;
    s.test_mode = false;  // B18: F3 saves test mode to the user file
    s.announce["combo"] = false;
    s.keys["health"] = 'J';
    s.speech_engine[2] = 1;  // B16
    s.sapi_voice = "DECtalk Paul \xC3\xA9";  // (a non-ASCII name survives)
    s.sapi_rate = -3;
    s.sapi_volume = 70;
    Check(config::Save(user, s), "saved");
    {
        const config::Settings r2 = config::Load(base, user);
        Check(r2.speech_engine[0] == 0 && r2.speech_engine[2] == 1 && r2.sapi_voice == s.sapi_voice && r2.sapi_rate == -3 &&
                  r2.sapi_volume == 70,
              "B16 speech settings saved and read back");
    }
    const config::Settings r = config::Load(base, user);
    Check(r.cue_volume == 40 && !r.pan_around_shank && r.announce.count("combo") && !r.announce.at("combo") &&
              r.keys.count("health") && r.keys.at("health") == 'J' && !r.test_mode,
          "the user file overrides (B18: test mode too)");
    DeleteFileW(base.c_str());
    DeleteFileW(user.c_str());

    // The raw-input filter: a key held when blocking starts gets its release; others become an unused key.
    bool down[256] = {};
    RAWKEYBOARD k = {};
    k.VKey = VK_RIGHT;
    k.Flags = RI_KEY_MAKE;
    k.Message = WM_KEYDOWN;
    input_block::Filter(&k, false, down);
    Check(k.VKey == VK_RIGHT && !(k.Flags & RI_KEY_BREAK) && down[VK_RIGHT], "not blocking: passed on, remembered as down");
    k = RAWKEYBOARD{};
    k.VKey = VK_RIGHT;
    k.Message = WM_KEYDOWN;  // (the auto-repeat of the held key)
    input_block::Filter(&k, true, down);
    Check(k.VKey == VK_RIGHT && (k.Flags & RI_KEY_BREAK) && k.Message == WM_KEYUP && !down[VK_RIGHT],
          "blocking: the held key is released for the game");
    k = RAWKEYBOARD{};
    k.VKey = VK_DOWN;
    k.Message = WM_KEYDOWN;
    input_block::Filter(&k, true, down);
    Check(k.VKey == 0xFF && (k.Flags & RI_KEY_BREAK), "blocking: a new key press never reaches the game");
    k = RAWKEYBOARD{};
    k.VKey = VK_ESCAPE;
    k.Flags = RI_KEY_BREAK;
    k.Message = WM_KEYUP;
    input_block::Filter(&k, false, down);
    Check(k.VKey == 0xFF, "after blocking: the release of a key pressed during it (Escape closing the menu) is hidden too");

    // The menu.
    hotkeys::AddBindable("health", 'H', 'H', "Health", [] {});
    hotkeys::AddBindable("lock", 'L', 'L', "Lock on", [] {});
    hotkeys::AddBindable("settings", VK_F7, VK_F7, "Settings", [] {});
    mod_menu::Hooks h;
    h.get_volume = [] { return g_volume; };
    h.set_volume = [](int v) { g_volume = v; };
    h.get_pan = [] { return g_pan; };
    h.set_pan = [](bool on) { g_pan = on; };
    h.get_safe_edges = [] { return g_edges; };
    h.set_safe_edges = [](bool on) { g_edges = on; };
    h.save = [] { ++g_saves; };
    h.say = [](const std::string& t) { g_said.push_back(t); };
    h.block_input = [](bool on) { g_blocked = on; };
    h.set_key_handler = [](void (*f)(int)) { g_handler = f; };
    h.set_pad_handler = [](void (*f)(unsigned)) { hotkeys::SetPadCaptureHandler(f); };  // B39
    mod_menu::Init(h);
    const size_t n = mod_menu::ItemCount();
    printf("  (%u items; first: %s; last: %s)\n", static_cast<unsigned>(n), mod_menu::ItemText(0).c_str(), mod_menu::ItemText(n - 1).c_str());
    // B17-2: the top level = the categories (no Speech without its hooks), then Close.
    Check(n == 6 && mod_menu::ItemText(0) == "Sounds" && mod_menu::ItemText(4) == "General" && mod_menu::ItemText(5) == "Close",
          "top level: Sounds, Navigation, Enemies, Status and pickups, General, Close");
    mod_menu::Toggle();
    Check(mod_menu::IsOpen() && g_blocked && g_handler && g_said.back().find("Shank Access mod menu") == 0 &&
              g_said.back().find("Sounds, 1 of 6") != std::string::npos,
          "F7 opens: the game's keys blocked, the first category said");
    g_handler(VK_RETURN);
    Check(g_said.back() == "Sounds. Cue volume, 80 percent, 1 of 3. How loud the mod's own sounds are.",
          "Enter: into Sounds, its first setting, then its explainer (B38-1)");
    {
        const mod_menu::View v = mod_menu::CurrentView();
        Check(v.title == "Sounds" && v.items.size() == 3 && v.items[0] == "Cue volume, 80 percent" && v.selected == 0 &&
                  v.items[2] == "Back",
              "B38-2b: the window's view: the category, its items, the first selected");
    }
    g_handler(VK_RIGHT);
    Check(g_volume == 90 && g_said.back() == "Cue volume, 90 percent" && g_saves == 1, "Right: volume up, saved");
    g_handler(VK_RIGHT);
    g_handler(VK_RIGHT);
    Check(g_volume == 100, "volume stops at 100");
    g_handler(VK_DOWN);
    Check(g_said.back() == "Sound panning, relative to Shank, 2 of 3. Where game sounds are placed: around Shank, or around the camera's view.",
          "B38-1: Sound panning, with its explainer");
    g_handler(VK_RETURN);
    Check(!g_pan && g_said.back() == "Sound panning, relative to camera", "Enter toggles the pan (no explainer after a change)");
    g_handler(VK_ESCAPE);
    Check(mod_menu::IsOpen() && g_said.back() == "Sounds, 1 of 6", "Escape: back to the top level, on Sounds");
    g_handler(VK_DOWN);
    g_handler(VK_DOWN);
    g_handler(VK_DOWN);
    g_handler(VK_RETURN);  // Status and pickups
    Check(g_said.back().find("Status and pickups. Health warnings, on, 1 of") == 0 &&
              g_said.back().find(". Speaks when Shank's health drops past 75, 50 and 25 percent.") != std::string::npos,
          "Status and pickups: its announcements first, explained");
    g_handler(VK_SPACE);
    Check(!announce::On(announce::kHealth) && g_said.back() == "Health warnings, off", "Space turns it off");
    // Health warnings off: the status readout stays silent on a drop past 75 percent.
    ui_hooks::FlashValue v;
    v.kind = ui_hooks::FlashValue::kNumber;
    v.n = 100;
    status::OnValue("_level0.HUD.player1.healthBar.value", v, 1000);
    v.n = 70;
    Check(status::OnValue("_level0.HUD.player1.healthBar.value", v, 2000).empty(), "health warning silent when off");
    announce::Set(announce::kHealth, true);
    // Keys: the Health key sits in Status; Lock on in Enemies; rebinding.
    g_handler(VK_END);
    Check(g_said.back().find("Back,") == 0, "End: Back");
    g_handler(VK_UP);
    Check(g_said.back().find("Health controller button, not set") == 0 && g_said.back().find("Speaks Shank's health") != std::string::npos,
          "B39: the controller bindings after the keys, not set, explained");
    g_handler(VK_UP);
    Check(g_said.back().find("Health key, H") == 0 && g_said.back().find("Speaks Shank's health, and a boss's.") != std::string::npos,
          "Status holds the Health key, explained");
    g_handler(VK_ESCAPE);
    g_handler(VK_UP);  // Enemies
    g_handler(VK_RETURN);
    g_handler(VK_END);
    g_handler(VK_UP);
    // B39: Lock on's controller binding: Enter captures (the buttons held together, when let go); a chord; Delete clears.
    Check(g_said.back().find("Lock on controller button, not set") == 0, "Enemies: the Lock on controller binding");
    g_handler(VK_RETURN);
    Check(g_said.back().find("Press the new controller button for Lock on") == 0, "Enter: waiting for controller buttons");
    hotkeys::PadStepForTests(0);  // (B40c: the capture starts with everything up)
    hotkeys::PadStepForTests(hotkeys::kPadBack);
    hotkeys::PadStepForTests(hotkeys::kPadBack | hotkeys::kPadA);
    hotkeys::PadStepForTests(hotkeys::kPadA);
    hotkeys::PadStepForTests(0);
    unsigned lock_pad = 0;
    for (const auto& b : hotkeys::Bindings()) lock_pad = b.id == "lock" ? b.pad : lock_pad;
    Check(lock_pad == (hotkeys::kPadBack | hotkeys::kPadA) && g_said.back() == "Lock on controller button, Back + Button A",
          "B39: Back held with Button A: the chord, saved");
    g_handler(VK_DELETE);
    lock_pad = 1;
    for (const auto& b : hotkeys::Bindings()) lock_pad = b.id == "lock" ? b.pad : lock_pad;
    Check(lock_pad == 0 && g_said.back() == "Lock on controller button, not set", "B39: Delete clears it");
    g_handler(VK_RETURN);
    g_handler(VK_ESCAPE);
    Check(mod_menu::IsOpen() && g_said.back().find("Lock on controller button, not set") == 0, "B39: Escape cancels the capture");
    // B40-4: a binding with an input the game has bound is refused; the right stick (free) is taken.
    {
        mod_menu::Hooks c = h;
        c.game_pad_inputs = [] { return game_pads::DefaultInputs(); };
        mod_menu::Init(c);
        // B40c (the user: "Pressing A on the controller registers two button presses"): the A that starts the capture,
        // still held, isn't captured; the capture starts once everything is up.
        hotkeys::PadStepForTests(hotkeys::kPadA);  // (held from choosing the item)
        g_handler(VK_RETURN);
        hotkeys::PadStepForTests(hotkeys::kPadA);
        Check(g_said.back().find("Press the new controller button for Lock on") == 0, "B40c: A still held: not taken as the binding");
        hotkeys::PadStepForTests(0);
        Check(g_said.back().find("Press the new controller button for Lock on") == 0, "B40c: A let go: still waiting");
        hotkeys::PadStepForTests(hotkeys::kPadBack | hotkeys::kPadA);
        hotkeys::PadStepForTests(0);
        Check(g_said.back() == "Button A is used by the game. Lock on unchanged", "B40-4: Back + Button A refused (A is the game's)");
        g_handler(VK_RETURN);
        hotkeys::PadStepForTests(0);
        hotkeys::PadStepForTests(hotkeys::kPadRStickRight);
        hotkeys::PadStepForTests(0);
        Check(g_said.back() == "Lock on controller button, Right Thumb Right", "B40-1: the right stick pushed right: bound");
        g_handler(VK_DELETE);
        mod_menu::Init(h);
    }
    // B40-3: the pad in the menu: DPad / left stick = arrows, A = Enter, Back = Escape; the menu's own binding = its key.
    {
        using namespace hotkeys;
        const auto keys = [](unsigned pressed, unsigned down, unsigned menu_pad) { return MenuKeysFor(pressed, down, menu_pad, VK_F7); };
        Check(keys(kPadDpadDown, kPadDpadDown, 0) == std::vector<int>{VK_DOWN} && keys(kPadLStickUp, kPadLStickUp, 0) == std::vector<int>{VK_UP} &&
                  keys(kPadA, kPadA, 0) == std::vector<int>{VK_RETURN} && keys(kPadBack, kPadBack, 0) == std::vector<int>{VK_ESCAPE} &&
                  keys(kPadDpadRight, kPadDpadRight, 0) == std::vector<int>{VK_RIGHT},
              "B40-3: DPad / stick = arrows, A = Enter, Back = Escape");
        Check(keys(kPadRightStick, kPadRightStick | kPadBack, kPadBack | kPadRightStick) == std::vector<int>{VK_F7},
              "B40-3: the menu's own chord closes it (not Escape)");
        Check(keys(kPadY, kPadY, 0).empty(), "B40-3: other buttons do nothing in the menu");
        Check(keys(kPadB, kPadB, kPadBack) == std::vector<int>{VK_ESCAPE}, "B40c: B is Escape too");
        Check(keys(kPadBack, kPadBack, kPadBack) == std::vector<int>{VK_ESCAPE}, "B40b: Back as the menu's binding: still Escape inside it");
        // B40-2: the pad hidden from the game while blocking; a button held then stays hidden until let go.
        WORD b = kPadA;
        WORD hidden = input_block::PadFilter(&b, true, false, 0);
        WORD after = kPadA | kPadX;
        hidden = input_block::PadFilter(&after, false, true, hidden);
        WORD released = kPadX;
        const WORD hidden2 = input_block::PadFilter(&released, false, false, hidden);
        WORD again = kPadA;
        input_block::PadFilter(&again, false, false, hidden2);
        Check(after == kPadX && hidden == kPadA && hidden2 == 0 && again == kPadA,
              "B40-2: A held from the menu stays hidden until released, then is the game's again");
        // B40-4: the game's binding values as masks.
        Check(game_pads::BindingToMask(2, 0, false, 0, 0x1000) == kPadA && game_pads::BindingToMask(1, 0, false, 1, 0) == kPadRightTrigger &&
                  game_pads::BindingToMask(0, 0, false, 0, 0) == kPadLStickLeft && game_pads::BindingToMask(0, 3, true, 0, 0) == kPadRStickUp,
              "B40-4: the game's bindings (button, trigger, axis) as masks");
    }
    g_handler(VK_UP);
    Check(g_said.back().find("Lock on key, L") == 0, "Enemies holds the Lock on key");
    g_handler(VK_RETURN);
    Check(g_said.back() == "Press the new key for Lock on. Escape cancels", "Enter: waiting for the new key");
    g_handler('H');
    Check(g_said.back() == "H is already the Health key. Lock on key unchanged", "a key already in use is refused");
    g_handler(VK_RETURN);
    g_handler('J');
    bool lock_j = false;
    for (const auto& b : hotkeys::Bindings()) lock_j |= b.id == "lock" && b.vk == 'J';
    Check(lock_j && g_said.back() == "Lock on key, J", "rebound to J");
    g_handler(VK_RETURN);
    g_handler(VK_SPACE);
    Check(g_said.back() == "Lock on key, Space. The game uses this key too", "a game key is allowed, with a note");
    g_handler(VK_RETURN);
    g_handler(VK_ESCAPE);
    Check(mod_menu::IsOpen() && g_said.back().find("Cancelled") == 0, "Escape while rebinding cancels (the menu stays)");
    g_handler(VK_F7);
    Check(!mod_menu::IsOpen() && !g_blocked && !g_handler && g_said.back() == "Mod menu closed", "F7 closes");
    // B38-1: Waypoint mode on / off in Navigation (after Safe edges).
    {
        static bool wp = false;
        mod_menu::Hooks w = h;
        w.get_waypoint = [] { return wp; };
        w.set_waypoint = [](bool on) { wp = on; };
        mod_menu::Init(w);
        mod_menu::Toggle();
        g_handler(VK_DOWN);
        g_handler(VK_RETURN);  // Navigation
        g_handler(VK_DOWN);
        Check(g_said.back() == "Waypoint mode, off, 2 of 4. Guides you to the next checkpoint, one move at a time.",
              "B38-1: Waypoint mode in Navigation, explained");
        g_handler(VK_RETURN);
        Check(wp && g_said.back() == "Waypoint mode, on", "Enter turns it on");
        // B48: Speak each move, after it (off by default)
        g_handler(VK_DOWN);
        printf("  (%s)\n", g_said.back().c_str());
        Check(g_said.back().find("Speak each move, off, 3 of 4. With waypoint mode on, speaks the next move") == 0,
              "B48: Speak each move in Navigation, off, explained");
        g_handler(VK_RETURN);
        Check(announce::On(announce::kMoves), "B48: Enter turns it on");
        announce::Set(announce::kMoves, false);
        g_handler(VK_ESCAPE);
        g_handler(VK_ESCAPE);
        mod_menu::Init(h);
    }
    // B15-2 Learn sounds: in Sounds (B38-1: first); Enter opens the list; Enter plays; Escape goes back, then out, then closes.
    static int played = -1;
    h.sounds = {"Drop ahead", "Wall ahead"};
    h.play_sound = [](size_t k) { played = static_cast<int>(k); };
    mod_menu::Init(h);
    mod_menu::Toggle();
    g_handler(VK_RETURN);  // Sounds
    Check(g_said.back().find("Sounds. Learn sounds, 1 of 4. Plays each") == 0, "B38-1: Learn sounds is first in Sounds");
    g_handler(VK_RETURN);
    Check(g_said.back().find("Learn sounds. Up and down to choose") == 0 && g_said.back().find("Drop ahead, 1 of 2") != std::string::npos,
          "Enter: the list, its first sound named");
    g_handler(VK_DOWN);
    g_handler(VK_RETURN);
    Check(g_said.back() == "Wall ahead, 2 of 2" && played == 1, "Down, Enter: the second sound named and played");
    g_handler(VK_ESCAPE);
    Check(mod_menu::IsOpen() && g_said.back() == "Learn sounds", "Escape: back to Sounds");
    g_handler(VK_ESCAPE);
    Check(mod_menu::IsOpen() && g_said.back() == "Sounds, 1 of 6", "Escape: out of Sounds");
    g_handler(VK_ESCAPE);
    Check(!mod_menu::IsOpen(), "Escape again: closed");
    // B16 Speech settings: the third item; channels toggle; voice / rate / volume change with a SAPI preview.
    static int engines[3] = {0, 0, 0};
    static std::string voice;
    static int rate = 0, svol = 100, samples = 0;
    h.get_engine = [](int c) { return engines[c]; };
    h.set_engine = [](int c, int e) { engines[c] = e; };
    h.voices = [] { return std::vector<std::string>{"Voice A", "Voice B"}; };
    h.get_voice = [] { return voice; };
    h.set_voice = [](const std::string& v) { voice = v; };
    h.get_rate = [] { return rate; };
    h.set_rate = [](int r) { rate = r < -10 ? -10 : (r > 10 ? 10 : r); };
    h.get_sapi_volume = [] { return svol; };
    h.set_sapi_volume = [](int v) { svol = v < 0 ? 0 : (v > 100 ? 100 : v); };
    h.sample = [](const std::string&) { ++samples; };
    mod_menu::Init(h);
    mod_menu::Toggle();
    Check(g_said.back().find("Speech, 1 of 7") != std::string::npos, "with speech hooks: Speech is the first category");
    g_handler(VK_RETURN);
    Check(g_said.back().find("Speech. Up and down") == 0 &&
              g_said.back().find("Menu reading: screen reader, 1 of 7. Which voice reads menus") != std::string::npos,
          "Enter: the speech list, menu reading first");
    g_handler(VK_DOWN);
    g_handler(VK_DOWN);
    g_handler(VK_RETURN);
    Check(engines[2] == 1 && g_said.back() == "Automatic messages: SAPI", "automatic messages to SAPI");
    g_handler(VK_DOWN);
    g_handler(VK_RIGHT);
    Check(voice == "Voice A" && g_said.back() == "SAPI voice: Voice A, 2 of 3" && samples == 1, "Right: the next voice, with a preview");
    g_handler(VK_LEFT);
    Check(voice.empty() && g_said.back() == "SAPI voice: Windows default, 1 of 3", "Left: back to the Windows default");
    g_handler(VK_DOWN);
    g_handler(VK_RIGHT);
    g_handler(VK_RIGHT);
    Check(rate == 2 && g_said.back() == "SAPI rate: 2", "rate up");
    g_handler(VK_DOWN);
    g_handler(VK_LEFT);
    Check(svol == 90 && g_said.back() == "SAPI volume: 90 percent" && samples == 5, "volume down, previews each time");
    g_handler(VK_ESCAPE);
    Check(mod_menu::IsOpen() && g_said.back() == "Speech, 1 of 7", "Escape: back to the top level, on Speech");
    g_handler(VK_ESCAPE);
    Check(!mod_menu::IsOpen(), "closed");
    // B16: our SAPI voice starts on the speech thread and lists the installed voices (silent: nothing is spoken).
    {
        wchar_t exe[MAX_PATH];
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        std::wstring dir(exe);
        dir = dir.substr(0, dir.find_last_of(L"\\/"));
        speech::Start(dir);
        for (int i = 0; i < 50 && !speech::SapiAvailable(); ++i) Sleep(100);
        const auto voices = speech::SapiVoices();
        printf("  (SAPI: %s, %u voices; first: %s)\n", speech::SapiAvailable() ? "ready" : "unavailable",
               static_cast<unsigned>(voices.size()), voices.empty() ? "-" : voices[0].c_str());
        Check(speech::SapiAvailable() && !voices.empty(), "our SAPI voice started and found the installed voices");
        speech::SetEngine(speech::kAuto, speech::kSapi);
        Check(speech::EngineOf(speech::kAuto) == speech::kSapi && speech::EngineOf(speech::kMenu) == speech::kScreenReader,
              "channels switch independently");
        speech::SetSapiRate(15);
        speech::SetSapiVolume(-5);
        Check(speech::SapiRate() == 10 && speech::SapiVolume() == 0, "rate and volume clamped");
        speech::SetEngine(speech::kAuto, speech::kScreenReader);
    }
    // B14 marks: the lines written to a11y.log and a11y_marks.log.
    Check(marks::MarkLine(3, "21:53:24.628", "level campaign_1c_meatpacking; Shank at (100, 200) facing left") ==
              "MARK 3 at 21:53:24.628: level campaign_1c_meatpacking; Shank at (100, 200) facing left",
          "the mark line");
    Check(marks::CommentLine(3, "the swing point was out of reach") == "MARK 3 comment: the swing point was out of reach" &&
              marks::CommentLine(4, "") == "MARK 4 comment: (none)",
          "the comment line (and a skipped one)");
    // B34: "Go to checkpoint" only with test mode on (and checkpoints known); Enter on one asks for it and closes the menu.
    {
        static bool test_on = false;
        static int asked = -1;
        mod_menu::Hooks c = h;
        c.test_mode = [] { return test_on; };
        c.checkpoints = [] { return std::vector<std::string>{"Start", "Courtyard", "Priest Boss Fight"}; };
        c.go_to_checkpoint = [](int i) {
            asked = i;
            return std::string("Loading Priest Boss Fight");
        };
        mod_menu::Init(c);
        bool listed = false;
        for (size_t i = 0; i < mod_menu::ItemCount(); ++i) listed = listed || mod_menu::ItemText(i) == "Go to checkpoint";
        Check(!listed, "B34: test mode off: no Go to checkpoint");
        test_on = true;
        size_t at = 0;
        for (size_t i = 0; i < mod_menu::ItemCount(); ++i) {
            if (mod_menu::ItemText(i) == "Go to checkpoint") at = i + 1;
        }
        Check(at > 0, "B34: test mode on: Go to checkpoint listed");
        if (mod_menu::IsOpen()) mod_menu::Toggle();
        mod_menu::Toggle();
        for (size_t i = 1; i < at; ++i) g_handler(VK_DOWN);
        g_handler(VK_RETURN);
        Check(g_said.back().find("Go to checkpoint. Start, 1 of 4") == 0, "B34: into it: the level's checkpoints, then Back");
        g_handler(VK_DOWN);
        g_handler(VK_DOWN);
        g_handler(VK_RETURN);
        Check(asked == 2 && !mod_menu::IsOpen() && g_said.back() == "Loading Priest Boss Fight",
              "B34: Enter on one: asked for it, the menu closed, the answer said");
        mod_menu::Init(h);
    }

    // B38-4: a session with a mark is copied to its own folder (here SHANK_ACCESS_LOG_DIR; Documents in play)
    {
        wchar_t tmp[MAX_PATH];
        GetTempPathW(MAX_PATH, tmp);
        const std::wstring game = std::wstring(tmp) + L"sa_b384_game", saved = std::wstring(tmp) + L"sa_b384_saved";
        CreateDirectoryW(game.c_str(), nullptr);
        for (const wchar_t* f : {L"a11y.log", L"a11y_marks.log", L"game.log", L"ai.log"}) {
            FILE* fp = _wfopen((game + L"\\" + f).c_str(), L"wb");
            if (fp) {
                if (std::wstring(f) == L"a11y_marks.log") {
                    fputs("\r\n=== Session 2026-10-01 10:00:00 ===\r\nMARK 1 old\r\n\r\n=== Session 2026-10-03 09:44:18 ===\r\nMARK 1 new\r\n", fp);
                } else if (std::wstring(f) != L"ai.log") {
                    fputs("some log text, some log text, some log text\n", fp);  // (ai.log empty)
                }
                fclose(fp);
            }
        }
        SetEnvironmentVariableW(L"SHANK_ACCESS_LOG_DIR", saved.c_str());
        const std::wstring zip = alog::SaveSession(game);
        const bool named = zip.find(saved + L"\\shank-access-") == 0 && zip.size() > 4 && zip.compare(zip.size() - 4, 4, L".zip") == 0;
        // B38-4c: one zip, shank-access-<timestamp>.zip: our two logs and the game's non-empty ones under game/
        std::string names;
        mz_zip_archive z;
        memset(&z, 0, sizeof z);
        char narrow[MAX_PATH * 3];
        WideCharToMultiByte(CP_UTF8, 0, zip.c_str(), -1, narrow, sizeof narrow, nullptr, nullptr);
        if (named && mz_zip_reader_init_file(&z, narrow, 0)) {
            for (mz_uint i = 0; i < mz_zip_reader_get_num_files(&z); ++i) {
                char n[260];
                mz_zip_reader_get_filename(&z, i, n, sizeof n);
                names += std::string(n) + ";";
            }
            mz_zip_reader_end(&z);
        }
        printf("  (B38-4c zip: %s)\n", names.c_str());
        Check(named && names == "a11y.log;a11y_marks.log;game/game.log;",
              "B38-4c: SaveSession writes shank-access-<timestamp>.zip with a11y.log, a11y_marks.log, game/game.log (not the empty ai.log)");
        // B38-4d: only this session's marks (from the last "=== Session" header)
        std::string marks;
        memset(&z, 0, sizeof z);
        if (named && mz_zip_reader_init_file(&z, narrow, 0)) {
            size_t n = 0;
            void* p = mz_zip_reader_extract_file_to_heap(&z, "a11y_marks.log", &n, 0);
            if (p) {
                marks.assign(static_cast<const char*>(p), n);
                mz_free(p);
            }
            mz_zip_reader_end(&z);
        }
        Check(marks == "=== Session 2026-10-03 09:44:18 ===\r\nMARK 1 new\r\n", "B38-4d: the zip holds only this session's marks");
        const auto there = [](const std::wstring& p) { return GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES; };
        Check(alog::SaveSession(game) == zip && there(game + L"\\a11y_marks.log"), "B38-4c: saved again at a mark: the same zip, the marks kept");
        Check(alog::SaveSession(game, true) == zip && !there(game + L"\\a11y_marks.log"),
              "B38-4d: the final save (exit) rewrites the zip, then flushes the marks file");
        DeleteFileW(zip.c_str());
        SetEnvironmentVariableW(L"SHANK_ACCESS_LOG_DIR", nullptr);
    }

    // B37-2: General lists Test mode (F3) only in a test build
    {
#ifndef SHANK_ACCESS_RELEASE
        hotkeys::AddBindable("test_mode", VK_F3, VK_F3, "Test mode", [] {});  // (as the DLL does; a release DLL doesn't bind F3)
#endif
        mod_menu::Init(h);
        mod_menu::Toggle();
        for (int k = 0; k < 8 && g_said.back().find("General") != 0; ++k) g_handler(VK_DOWN);
        g_handler(VK_RETURN);  // General
        bool listed = false;
        for (size_t i = 0; i < mod_menu::ItemCount(); ++i) {
            listed = listed || mod_menu::ItemText(i).find("Test mode") != std::string::npos;
        }
#ifdef SHANK_ACCESS_RELEASE
        Check(!listed, "B37-2: a release build: no Test mode in General");
#else
        Check(listed, "B37-2: a test build: Test mode in General");
#endif
        mod_menu::Toggle();
        mod_menu::Init(h);
    }

    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
