-- Run by tools/loadtest50.py on the classic branch's install (B50, tools/make_classic_patches.py), after loading Shank's
-- stategraph or a pickup's (Lua 5.0). Asserts:
--   Shank: every state from stategraphs/shank/ (but nis.lua and death.lua) ends its transitions with the reports, the
--   position ping last; no state of those two files has them; none sits inside a CompoundTransition;
--   a pickup: its idle state has the beacon and "in reach" gates (each child resetting its countdown), and its
--   "collected" event plays a11y/got_<kind>.
local function sounds_in(t, found, seen)
  if type(t) ~= "table" or seen[t] then return end
  seen[t] = true
  if t.Type == "playsound" and type(t.sound) == "string" then found[t.sound] = true end
  for _, v in pairs(t) do sounds_in(v, found, seen) end
end

local function src_of(st)
  return string.gsub(string.lower(st.source_file or ""), "\\", "/")
end

if StateGraph and StateGraph.name == "shank" then
  if type(A11Y_SHANK_REPORTS) ~= "table" or table.getn(A11Y_SHANK_REPORTS) ~= 11 then error("the Shank reports weren't built") end
  local with, without = 0, 0
  for _, st in ipairs(ShankStates) do
    local src = src_of(st)
    local skip = string.find(src, "/nis.lua", 1, true) or string.find(src, "/death.lua", 1, true)
    local t = st.transitions or {}
    local n = table.getn(t)
    if skip then
      for i = 1, n do
        if t[i] == A11Y_POS_PING then error("state " .. tostring(st.name) .. " (" .. src .. ") has the ping") end
      end
      without = without + 1
    elseif string.find(src, "stategraphs/shank/", 1, true) then
      if n < 11 or t[n] ~= A11Y_POS_PING then error("state " .. tostring(st.name) .. " (" .. src .. ") lacks the reports") end
      for i = 1, 11 do
        if t[n - 11 + i] ~= A11Y_SHANK_REPORTS[i] then error("state " .. tostring(st.name) .. ": the reports out of order") end
      end
      for i = 1, n - 11 do  -- (B15-4: never inside a compound, whose own actions would run with them)
        if type(t[i]) == "table" and t[i].type == "compound" then
          local s = {}
          sounds_in(t[i], s, {})
          if s["a11y/pos_r"] then error("state " .. tostring(st.name) .. ": the ping inside a compound") end
        end
      end
      with = with + 1
    end
  end
  local ping = {}
  sounds_in(A11Y_POS_PING, ping, {})
  if not (ping["a11y/pos_r"] and ping["a11y/pos_l"]) then error("the ping lacks pos_r / pos_l") end
  print("  Shank: " .. with .. " states report, " .. without .. " (cutscene / death) don't")
  return with > 100
end

-- a pickup
local idle, kind
for _, st in ipairs(PropStates) do
  if st.name == "idle" then idle = st end
  local _, _, k = string.find(src_of(st), "stategraphs/props/([a-z]+)pickup_stategraph%.lua")
  if k then kind = k end
end
if not idle or not kind then error("not a pickup stategraph") end
if kind == "grenade" then kind = "grenades" end
local s = {}
sounds_in(idle.transitions, s, {})
if not s["a11y/beacon_" .. kind] or not s["a11y/inreach_" .. kind] then error(kind .. ": no beacon / in reach in idle") end
for _, tr in ipairs(idle.transitions) do
  if tr.type == "compound" then
    for _, child in ipairs(tr.transitions or {}) do
      local disarms = false
      for _, a in ipairs(child.actions or {}) do if a.name then disarms = true end end
      if not disarms then error(kind .. ": a child that doesn't reset its countdown") end
    end
  end
end
local got = false
for _, st in ipairs(PropStates) do
  for _, e in ipairs(st.events or {}) do
    if e.event == "collected" then
      local g = {}
      sounds_in(e.actions, g, {})
      if g["a11y/got_" .. kind] then got = true end
    end
  end
end
if not got then error(kind .. ": no a11y/got_" .. kind .. " on collected") end
-- B50b: every fx_press_x_start of a pickup's comes right after PlaySound("a11y/prompt_pickup")
for _, st in ipairs(PropStates) do
  for _, list in ipairs({ st.on_enter or {}, st.on_new_enter or {} }) do
    for i, a in ipairs(list) do
      if type(a) == "table" and a.name == "fx_press_x_start" then
        local prev = list[i - 1]
        if not (prev and prev.Type == "playsound" and prev.sound == "a11y/prompt_pickup") then
          error(kind .. ": state " .. tostring(st.name) .. ": the press X indicator isn't tagged")
        end
      end
    end
  end
end
print("  " .. kind .. ": beacon, in reach, got")
return true
