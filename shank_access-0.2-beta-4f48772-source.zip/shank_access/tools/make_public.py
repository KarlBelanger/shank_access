"""B37-5: assemble the public repository's contents (KarlBelanger/shank_access) into build/public/.

  README.md, LICENSE, THIRD_PARTY_NOTICES.md, .github/ (issue forms)  from release/ and the repo root
  licences/                        the third-party licence texts (from third_party/)
  shank-access-setup.exe           build/setup (run tools/setup/build_setup.py --release first)
  shank_access-<version>-source.zip  the full source at HEAD (git archive), without saves/ (the user's own save
                                   files) and with the Steam user id blanked; no game-derived files are in git anyway

Usage (repo root): .venv/Scripts/python tools/make_public.py
"""
import io
import os
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "build", "public")
SCRUB = [(re.compile(rb"<steam-user-id>"), b"<steam-user-id>")]
SKIP = ("saves/",)


def main():
    exe = os.path.join(ROOT, "build", "setup", "shank-access-setup.exe")
    ver_file = os.path.join(ROOT, "build", "setup", "payload", "version.txt")
    if not os.path.exists(exe) or not os.path.exists(ver_file):
        sys.exit("build the setup first: tools/setup/build_setup.py --release")
    version = open(ver_file, encoding="utf-8").read().strip()
    if os.path.isdir(OUT):
        for name in os.listdir(OUT):
            if name == ".git":
                continue
            p = os.path.join(OUT, name)
            shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
    os.makedirs(OUT, exist_ok=True)
    shutil.copy2(os.path.join(ROOT, "release", "README.md"), OUT)
    shutil.copytree(os.path.join(ROOT, "release", ".github"), os.path.join(OUT, ".github"))
    for name in ("LICENSE", "THIRD_PARTY_NOTICES.md"):
        shutil.copy2(os.path.join(ROOT, name), OUT)
    lic = os.path.join(OUT, "licences")
    os.makedirs(lic)
    for src, dst in (("third_party/minhook/LICENSE.txt", "MinHook.txt"), ("third_party/tolk/LICENSE.txt", "Tolk-LGPL-3.0.txt"),
                     ("third_party/tolk/LICENSE-NVDA.txt", "NVDA-Controller-Client-LGPL-2.1.txt"),
                     ("third_party/lua-5.0.3/COPYRIGHT", "Lua-5.0.txt"), ("third_party/miniz/LICENSE", "miniz.txt")):
        shutil.copy2(os.path.join(ROOT, src), os.path.join(lic, dst))
    shutil.copy2(exe, OUT)
    archive = subprocess.run(["git", "archive", "--format=zip", "HEAD"], cwd=ROOT, capture_output=True, check=True).stdout
    src_zip = os.path.join(OUT, "shank_access-%s-source.zip" % version)
    with zipfile.ZipFile(io.BytesIO(archive)) as zin, zipfile.ZipFile(src_zip, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            if item.filename.startswith(SKIP):
                continue
            data = zin.read(item.filename)
            for pat, rep in SCRUB:
                data = pat.sub(rep, data)
            zout.writestr("shank_access/" + item.filename, data)
    print("version %s -> %s" % (version, OUT))
    for name in sorted(os.listdir(OUT)):
        p = os.path.join(OUT, name)
        print("  %-40s %s" % (name, "%d bytes" % os.path.getsize(p) if os.path.isfile(p) else "(folder)"))


if __name__ == "__main__":
    main()
