#pragma once
// B34 (the user: "loading a level at a specific checkpoint through the mod menu ... when testing mode is on"): restart the
// current level at one of its checkpoints, the way the game's own debug code does (RE-NOTES "Checkpoint jump"):
// NextCheckPoint's setter 0x406b80 (the simulation's restart checkpoint: its name at sim+0x38, a position at +0x54),
// then LoadToLastCheckpoint 0x781580 (a load request for this level at that checkpoint, then the loading screen).
// Both run on the game's own thread (the per-frame sound update), never from the menu's thread.
#include <string>
#include <vector>

namespace checkpoint_jump {

// The simulation's current restart checkpoint name ("" if unreadable). Any thread (a read with fault protection).
std::string CurrentName(void* sim);

// Queues a restart at the checkpoint named `name` (a checkpoint of the current level). Returns what to say.
// `valid_names`: the level's checkpoint names; the simulation is trusted only if its current restart name is one of them.
// (Other levels: the game's own level select, then this; the user, 2026-09-30.)
std::string Request(void* sim, const std::string& name, const std::vector<std::string>& valid_names);

// B34b: the simulation when the bounds action hasn't told us yet (1-b pre-train: no arena at its start): a scan for the
// cShankSimulation vtables (0x837d80, then 0x837db0 at +4) whose restart name is one of `valid_names`. Cached per level.
void* FindSimulation(const std::vector<std::string>& valid_names);
void OnLevel();  // a level load: forget the cached one

// The game's thread, once a frame: carries out a queued request.
void OnGameFrame();


}  // namespace checkpoint_jump
