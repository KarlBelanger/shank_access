#include "edge_guard.h"

#include <windows.h>

#include <atomic>
#include <cmath>
#include <cstring>

#include "MinHook.h"
#include "game.h"
#include "level_geometry.h"
#include "log.h"
#include "mod_state.h"

namespace edge_guard {
namespace {

std::atomic<bool> g_enabled{false};
std::atomic<bool> g_active{false};

// The edge being guarded (or let go): the surface and the direction it's in.
struct Edge {
    int surface = -1;
    bool right = true;
    float x = 0;
};
Edge g_edge;
bool g_on_edge = false;      // near a guarded edge this tick
bool g_bounced = false;      // the game hopped him back from it
unsigned g_rest_since = 0;   // at rest near it since (0 = not at rest)
bool g_armed = false;        // stopped, then at rest: the next move toward it lets him go
bool g_let_go = false;       // "another tap": this edge isn't guarded for now
unsigned g_let_go_ms = 0;

bool SameEdge(const Edge& a, int surface, bool right) { return a.surface == surface && a.right == right; }

void Clear() {
    g_on_edge = g_bounced = g_armed = g_let_go = false;
    g_rest_since = 0;
    g_edge = Edge();
    g_active = false;
}

// thiscall(node, ctx) -> 0/1 in eax, ret 4: the same shape as __fastcall(node, edx, ctx).
using EvaluateFn = unsigned(__fastcall*)(void* node, void* edx, void* ctx);
EvaluateFn g_orig = nullptr;

bool AsksGroundNoFall(const void* node) {
    __try {
        const unsigned char* n = static_cast<const unsigned char*>(node);
        return *reinterpret_cast<const unsigned*>(n + kNodeTag) == kHashNoFall &&
               *reinterpret_cast<const unsigned*>(n + kNodeSource) == kHashGround && n[kNodeNott] == 0;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

unsigned __fastcall HookEvaluate(void* node, void* edx, void* ctx) {
    const unsigned r = g_orig(node, edx, ctx);
    if (r || !g_active.load(std::memory_order_relaxed) || !mod_state::Active()) return r;  // (B38-3: off, the game's own answer)
    return AsksGroundNoFall(node) ? 1u : r;
}

// 0x4f92c0: push ecx; mov eax, [esp+8]; push esi; mov esi, ecx
const unsigned char kEvaluatePrologue[] = {0x51, 0x8B, 0x44, 0x24, 0x08, 0x56, 0x8B, 0xF1};

}  // namespace

void SetEnabled(bool on) {
    g_enabled = on;
    if (!on) Clear();
    alog::Write("edge guard: safe edges %s", on ? "on" : "off");
}

bool Enabled() { return g_enabled; }

bool Toggle() {
    SetEnabled(!g_enabled);
    return g_enabled;
}

bool Active() { return g_active; }

void Reset() { Clear(); }

void Update(unsigned now_ms, const position::Pos& s) {
    if (!g_enabled || !s.known) {
        g_active = false;
        return;
    }
    const level_geometry::Surface* under = level_geometry::SurfaceUnder(s.x, s.y);
    const bool grounded = under && std::fabs(s.vy) < 150.f;
    if (!grounded) {  // in the air (a jump, or he went over): nothing to guard
        g_active = false;
        g_on_edge = g_bounced = g_armed = false;
        g_rest_since = 0;
        return;
    }
    // A let-go edge is guarded again once he's away from it, on another surface, or after a while.
    if (g_let_go && (under->id != g_edge.surface || std::fabs(s.x - g_edge.x) > kReleaseAwayPx ||
                     now_ms - g_let_go_ms > kReleaseMs)) {
        g_let_go = false;
        alog::Write("edge guard: edge at x %.0f guarded again", g_edge.x);
    }
    // The edge ahead: a drop deeper than a small step (or deadly / nothing below), close by.
    const level_geometry::Ahead a = level_geometry::EdgeAhead(s.x, s.y, s.facing_right);
    const bool guard_worthy = a.found && a.end.type == level_geometry::End::kDrop && !a.end.gap &&  // (B15-6: running crosses gaps)
                              (a.end.deadly || a.end.value < 0 || a.end.value > kSmallDropPx) &&
                              a.distance <= kGuardRangePx;
    if (guard_worthy && !SameEdge(g_edge, under->id, s.facing_right)) {
        // A new edge: start over (the old one's let-go no longer applies).
        g_edge = Edge{under->id, s.facing_right, a.end_x};
        g_on_edge = g_bounced = g_armed = g_let_go = false;
        g_rest_since = 0;
    }
    // Near the guarded edge (facing either way: the hop back doesn't turn him round, but he may turn).
    const bool close_by = g_edge.surface == under->id && std::fabs(s.x - g_edge.x) <= kGuardRangePx + 64.f;
    if (!close_by) {
        g_active = false;
        g_on_edge = g_bounced = g_armed = false;
        g_rest_since = 0;
        return;
    }
    const float toward = g_edge.right ? s.vx : -s.vx;  // his speed toward the edge
    if (!g_let_go) {
        if (!g_on_edge && guard_worthy) {
            g_on_edge = true;
            alog::Write("edge guard: guarding the %s at x %.0f (depth %.0f), surface %d",
                        a.end.deadly ? "deadly drop" : "drop", a.end_x, a.end.value, under->id);
        }
        if (g_on_edge && toward < -kBounceVx && !g_bounced) {
            g_bounced = true;
            alog::Write("edge guard: stopped at x %.0f", s.x);
        }
        if (g_bounced && std::fabs(s.vx) < kRestVx) {
            if (!g_rest_since) g_rest_since = now_ms;
            if (!g_armed && now_ms - g_rest_since >= kRestMs) g_armed = true;
        } else {
            g_rest_since = 0;
        }
        if (g_armed && toward > kGoVx) {  // "another tap of the direction should send him over"
            g_let_go = true;
            g_let_go_ms = now_ms;
            g_armed = g_bounced = false;
            alog::Write("edge guard: another tap: letting him over the edge at x %.0f", g_edge.x);
        }
    }
    g_active = g_on_edge && !g_let_go;
}

bool InstallAt(unsigned evaluate) {
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) return false;
    void* target = reinterpret_cast<void*>(static_cast<uintptr_t>(evaluate));
    st = MH_CreateHook(target, reinterpret_cast<void*>(&HookEvaluate), reinterpret_cast<void**>(&g_orig));
    if (st == MH_OK) st = MH_EnableHook(target);
    alog::Write("hook HasTag_ParseNode::Evaluate at 0x%08x: %s", evaluate, st == MH_OK ? "installed" : MH_StatusToString(st));
    return st == MH_OK;
}

bool Install() {
    if (std::memcmp(reinterpret_cast<const void*>(game::kHasTagEvaluate), kEvaluatePrologue, sizeof kEvaluatePrologue) != 0) {
        alog::Write("edge guard: HasTag_ParseNode::Evaluate bytes don't match the expected build; not hooking");
        return false;
    }
    return InstallAt(game::kHasTagEvaluate);
}

}  // namespace edge_guard
