// B38-4 / B38-4c: a release build's saved sessions (see session_logs.h).
#include "session_logs.h"

#include <windows.h>
#include <shlobj.h>

#include <algorithm>
#include <cstring>
#include <cwctype>
#include <string>
#include <vector>

#include "log.h"
#include "miniz.h"

#pragma comment(lib, "shell32.lib")  // SHGetKnownFolderPath
#pragma comment(lib, "ole32.lib")    // CoTaskMemFree

namespace alog {
namespace {
SRWLOCK g_save_lock = SRWLOCK_INIT;
std::wstring g_zip_path;  // this session's zip once named

bool MakeDir(const std::wstring& dir) { return CreateDirectoryW(dir.c_str(), nullptr) || GetLastError() == ERROR_ALREADY_EXISTS; }

// A saved session's name: shank-access-yyyy-mm-dd_hh-mm-ss.zip (maybe with _N before .zip).
bool IsSessionZip(const std::wstring& n) {
    const std::wstring pre = L"shank-access-";
    if (n.size() < pre.size() + 19 + 4 || n.compare(0, pre.size(), pre) != 0) return false;
    if (_wcsicmp(n.c_str() + n.size() - 4, L".zip") != 0) return false;
    for (size_t i = 0; i < 19; ++i) {
        const wchar_t c = n[pre.size() + i];
        const bool sep = i == 4 || i == 7 || i == 13 || i == 16;
        if (i == 10 ? c != L'_' : (sep ? c != L'-' : !iswdigit(c))) return false;
    }
    return true;
}

// Keeps the newest `keep` session zips in base (their names sort by time).
void Prune(const std::wstring& base, int keep) {
    std::vector<std::wstring> zips;
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((base + L"\\*.zip").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && IsSessionZip(fd.cFileName)) zips.push_back(fd.cFileName);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    std::sort(zips.begin(), zips.end());
    for (size_t i = 0; i + static_cast<size_t>(keep) < zips.size(); ++i) DeleteFileW((base + L"\\" + zips[i]).c_str());
}

std::wstring NameSessionZip() {
    std::wstring base;
    wchar_t env[MAX_PATH];
    const DWORD n = GetEnvironmentVariableW(L"SHANK_ACCESS_LOG_DIR", env, MAX_PATH);
    if (n > 0 && n < MAX_PATH) {
        base = env;
        if (!MakeDir(base)) return std::wstring();
    } else {
        PWSTR p = nullptr;
        std::wstring docs;
        if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Documents, 0, nullptr, &p)) && p) docs = p;
        CoTaskMemFree(p);
        if (docs.empty()) return std::wstring();
        const std::wstring app = docs + L"\\Shank Access";
        base = app + L"\\logs";
        if (!MakeDir(app) || !MakeDir(base)) return std::wstring();
        Prune(base, kKeepSessions - 1);  // (this session is the last one kept)
    }
    SYSTEMTIME t;
    GetLocalTime(&t);
    wchar_t stamp[64];
    swprintf(stamp, 64, L"%04u-%02u-%02u_%02u-%02u-%02u", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    for (int i = 1; i < 100; ++i) {
        std::wstring path = base + L"\\shank-access-" + stamp + (i > 1 ? L"_" + std::to_wstring(i) : std::wstring()) + L".zip";
        if (GetFileAttributesW(path.c_str()) == INVALID_FILE_ATTRIBUTES) return path;
    }
    return std::wstring();
}

// Reads a whole file, sharing it (a11y.log is open for writing by us; the game's logs by the game).
bool ReadShared(const std::wstring& path, std::string* out) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
                           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    out->clear();
    char buf[65536];
    DWORD got = 0;
    while (ReadFile(h, buf, sizeof buf, &got, nullptr) && got) out->append(buf, got);
    CloseHandle(h);
    return true;
}

struct ZipEntry {
    std::string name;  // inside the zip ("a11y.log", "game/game.log")
    std::string data;
};

// B38-4c: a compressed zip (miniz; the user: "download approved").
std::string BuildZip(const std::vector<ZipEntry>& entries) {
    mz_zip_archive z;
    memset(&z, 0, sizeof z);
    if (!mz_zip_writer_init_heap(&z, 0, 0)) return std::string();
    for (const ZipEntry& e : entries) {
        mz_zip_writer_add_mem(&z, e.name.c_str(), e.data.data(), e.data.size(), static_cast<mz_uint>(MZ_DEFAULT_LEVEL));
    }
    void* buf = nullptr;
    size_t size = 0;
    std::string out;
    if (mz_zip_writer_finalize_heap_archive(&z, &buf, &size) && buf) out.assign(static_cast<const char*>(buf), size);
    mz_zip_writer_end(&z);
    return out;
}
}  // namespace

std::wstring SaveSession(const std::wstring& game_root, bool final) {
    AcquireSRWLockExclusive(&g_save_lock);
    if (g_zip_path.empty()) g_zip_path = NameSessionZip();
    const std::wstring zip = g_zip_path;
    std::vector<ZipEntry> entries;
    bool written = false;
    if (!zip.empty()) {
        std::string data;
        for (const wchar_t* ours : {L"a11y.log", L"a11y_marks.log"}) {
            if (ReadShared(game_root + L"\\" + ours, &data) && !data.empty()) {
                // B38-4d (the user: "only include this session's marks in the zip"): the marks file is appended across
                // sessions; this session's marks start at its last "=== Session" header (written at its first mark)
                if (std::wstring(ours) == L"a11y_marks.log") {
                    const size_t at = data.rfind("=== Session ");
                    if (at != std::string::npos) data = data.substr(at);
                }
                entries.push_back(ZipEntry{ours == std::wstring(L"a11y.log") ? "a11y.log" : "a11y_marks.log", data});
            }
        }
        // The game's own logs (B38-4b: the empty ones, ai / crash / memory in every session so far, are left out)
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((game_root + L"\\*.log").c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) {
            do {
                const std::wstring name = fd.cFileName;
                if ((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || _wcsnicmp(name.c_str(), L"a11y", 4) == 0) continue;
                if (!ReadShared(game_root + L"\\" + name, &data) || data.empty()) continue;
                char narrow[MAX_PATH];
                WideCharToMultiByte(CP_UTF8, 0, name.c_str(), -1, narrow, MAX_PATH, nullptr, nullptr);
                entries.push_back(ZipEntry{std::string("game/") + narrow, data});
            } while (FindNextFileW(h, &fd));
            FindClose(h);
        }
        // Written beside it, then moved over it: a reader never sees half a zip.
        const std::string bytes = BuildZip(entries);
        if (bytes.empty()) entries.clear();
        const std::wstring tmp = zip + L".tmp";
        HANDLE f = CreateFileW(tmp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (f != INVALID_HANDLE_VALUE) {
            DWORD put = 0;
            written = WriteFile(f, bytes.data(), static_cast<DWORD>(bytes.size()), &put, nullptr) && put == bytes.size();
            CloseHandle(f);
            written = written && MoveFileExW(tmp.c_str(), zip.c_str(), MOVEFILE_REPLACE_EXISTING);
            if (!written) DeleteFileW(tmp.c_str());
        }
    }
    // B38-4d (the user: "flush old marks once the zip is finalized on exit"): the marks are in the zip now
    const bool flushed = final && written && DeleteFileW((game_root + L"\\a11y_marks.log").c_str());
    ReleaseSRWLockExclusive(&g_save_lock);
    if (flushed) Write("logs: a11y_marks.log flushed (its marks are in the zip)");
    Write("logs: session %s (%u files) to %ls", written ? "saved" : "NOT saved", static_cast<unsigned>(entries.size()),
          zip.empty() ? L"(nowhere: no Documents folder)" : zip.c_str());
    return written ? zip : std::wstring();
}

}  // namespace alog
