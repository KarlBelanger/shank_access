"""Static analysis helpers for Shank.exe (32-bit, no ASLR).

Usage (from repo root):
  .venv/Scripts/python tools/re/pe.py imports [DLL_SUBSTRING]
  .venv/Scripts/python tools/re/pe.py xref-string "Could not play %s"
  .venv/Scripts/python tools/re/pe.py calls 0x55ab90 [0x55ab10 ...]
  .venv/Scripts/python tools/re/pe.py dis 0x55ab90 0x55ac80
  .venv/Scripts/python tools/re/pe.py str 0x8478f4
  .venv/Scripts/python tools/re/pe.py rtti [SUBSTRING]

The exe path defaults to the Steam install; override with SHANK_EXE.
"""
import os
import re
import struct
import sys

import capstone
import pefile

EXE = os.environ.get("SHANK_EXE", r"C:/Program Files (x86)/Steam/steamapps/common/Shank/bin/Shank.exe")


class Image:
    def __init__(self, path):
        self.pe = pefile.PE(path)
        self.base = self.pe.OPTIONAL_HEADER.ImageBase
        self.img = self.pe.get_memory_mapped_image()
        text = next(s for s in self.pe.sections if s.Name.startswith(b".text"))
        self.tva = text.VirtualAddress
        self.text = self.img[self.tva:self.tva + text.Misc_VirtualSize]
        self.imports = {}
        for entry in self.pe.DIRECTORY_ENTRY_IMPORT:
            for imp in entry.imports:
                name = imp.name.decode() if imp.name else "#%d" % imp.ordinal
                self.imports[imp.address] = "%s!%s" % (entry.dll.decode(), name)
        self.md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)

    def c_string(self, va, maxlen=80):
        off = va - self.base
        if not 0 <= off < len(self.img):
            return None
        s = self.img[off:off + maxlen].split(b"\0")[0]
        if len(s) >= 3 and all(32 <= c < 127 for c in s):
            return s.decode()
        return None

    def find_string(self, s):
        off = self.img.find(s.encode() + b"\0")
        return None if off < 0 else self.base + off

    def refs_to(self, va):
        """Code locations containing the 32-bit immediate `va`."""
        pat = struct.pack("<I", va)
        out, off = [], self.text.find(pat)
        while off != -1:
            out.append(self.base + self.tva + off)
            off = self.text.find(pat, off + 1)
        return out

    def calls_to(self, targets):
        """Direct E8 rel32 call sites to any of `targets`."""
        hits = []
        t = self.text
        for off in range(len(t) - 5):
            if t[off] == 0xE8:
                src = self.base + self.tva + off
                dst = (src + 5 + struct.unpack_from("<i", t, off + 1)[0]) & 0xFFFFFFFF
                if dst in targets:
                    hits.append((dst, src))
        return hits

    def annotate(self, ins):
        for tok in re.findall(r"0x[0-9a-f]+", ins.op_str):
            va = int(tok, 16)
            if va in self.imports:
                return self.imports[va]
            s = self.c_string(va)
            if s and va >= self.base + 0x1000:
                return repr(s)
        return ""

    def disasm(self, lo, hi):
        off = lo - self.base - self.tva
        for ins in self.md.disasm(self.text[off:hi - self.base - self.tva], lo):
            if ins.mnemonic == "int3":
                continue
            yield ins, self.annotate(ins)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1
    im = Image(EXE)
    cmd, args = argv[1], argv[2:]
    if cmd == "imports":
        for addr, name in sorted(im.imports.items(), key=lambda kv: kv[1]):
            if not args or args[0].lower() in name.lower():
                print(hex(addr), name)
    elif cmd == "xref-string":
        va = im.find_string(args[0])
        print("string at", hex(va) if va else None)
        for r in im.refs_to(va) if va else []:
            print("  ref", hex(r))
    elif cmd == "calls":
        targets = {int(a, 16) for a in args}
        for dst, src in im.calls_to(targets):
            print(hex(dst), "<-", hex(src))
    elif cmd == "dis":
        for ins, ann in im.disasm(int(args[0], 16), int(args[1], 16)):
            print("%08x  %-6s %-40s %s" % (ins.address, ins.mnemonic, ins.op_str, ann))
    elif cmd == "str":
        print(im.c_string(int(args[0], 16), 400))
    elif cmd == "rtti":
        for m in sorted(set(re.findall(rb"\.\?A[VU][A-Za-z0-9_@?$]+@@", im.img))):
            s = m.decode()
            if not args or args[0].lower() in s.lower():
                print(s)
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
