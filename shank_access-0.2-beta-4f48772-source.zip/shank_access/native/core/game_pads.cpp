#include "game_pads.h"

#include <windows.h>

#include <vector>

#include "hotkeys.h"
#include "log.h"

namespace game_pads {
namespace {

constexpr unsigned kControllerVtable = 0x843fdc;  // Input::XInputController
constexpr unsigned kMapHead = 0x64;               // its bindings: a std::list's head node (B40d: a list, not a map)
constexpr unsigned kNodeValue = 0x1c;             // a node: +0 next, +4 prev, +8 the action key (0x14 bytes), +0x1c the binding:
                                                  // +0 type, +4 axis, +8 positive, +0xc trigger, +0x10 button
constexpr int kMaxNodes = 64;
// Start pauses; the right stick's left / right roll (B40d, the user: "right stick left and right appear hard bound to
// rolling/dodging"): neither is in the action table.
constexpr unsigned kStartAlways = hotkeys::kPadStart | hotkeys::kPadRStickLeft | hotkeys::kPadRStickRight;

SRWLOCK g_lock = SRWLOCK_INIT;
std::vector<unsigned> g_objects;
bool g_scanned = false;

bool Read(unsigned addr, void* out, size_t n) {
    __try {
        memcpy(out, reinterpret_cast<const void*>(static_cast<uintptr_t>(addr)), n);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

std::vector<unsigned> Scan() {
    std::vector<unsigned> found;
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    const unsigned char* p = static_cast<const unsigned char*>(si.lpMinimumApplicationAddress);
    const unsigned char* end = static_cast<const unsigned char*>(si.lpMaximumApplicationAddress);
    MEMORY_BASIC_INFORMATION mbi;
    while (p < end && VirtualQuery(p, &mbi, sizeof mbi) == sizeof mbi) {
        const unsigned char* next = static_cast<const unsigned char*>(mbi.BaseAddress) + mbi.RegionSize;
        const DWORD prot = mbi.Protect & 0xff;
        if (mbi.State == MEM_COMMIT && (mbi.Type == MEM_PRIVATE || mbi.Type == MEM_IMAGE) &&
            !(mbi.Protect & (PAGE_GUARD | PAGE_NOCACHE)) && (prot == PAGE_READWRITE || prot == PAGE_EXECUTE_READWRITE)) {
            const unsigned* w = static_cast<const unsigned*>(mbi.BaseAddress);
            const size_t n = mbi.RegionSize / 4;
            for (size_t i = 0; i < n && found.size() < 16; ++i) {
                if (w[i] == kControllerVtable) found.push_back(static_cast<unsigned>(reinterpret_cast<uintptr_t>(w + i)));
            }
        }
        if (next <= p) break;
        p = next;
    }
    return found;
}

// Every binding in one controller's list (0x52ec60, its find: from [head] along +0 until back at the head).
bool ReadMap(unsigned object, unsigned* mask) {
    unsigned head = 0;
    if (!Read(object + kMapHead, &head, 4) || !head) return false;
    unsigned node = 0;
    if (!Read(head, &node, 4)) return false;
    int seen = 0;
    while (node && node != head && seen < kMaxNodes) {
        ++seen;
        unsigned value[5];
        unsigned char positive = 0;
        if (!Read(node + kNodeValue, value, sizeof value) || !Read(node + kNodeValue + 8, &positive, 1)) return false;
        if (value[0] > 2) {  // (not a binding: the layout isn't what we think)
            alog::Write("game pads: node %08x type %u: not a binding", node, value[0]);
            return false;
        }
        *mask |= BindingToMask(value[0], value[1], positive != 0, value[3], value[4]);
        if (!Read(node, &node, 4)) return false;
    }
    return seen > 0;
}

}  // namespace

unsigned BindingToMask(unsigned type, unsigned axis, bool positive, unsigned trigger, unsigned button) {
    using namespace hotkeys;
    switch (type) {
        case 0:
            switch (axis) {
                case 0: return positive ? kPadLStickRight : kPadLStickLeft;
                case 1: return positive ? kPadLStickUp : kPadLStickDown;
                case 2: return positive ? kPadRStickRight : kPadRStickLeft;
                case 3: return positive ? kPadRStickUp : kPadRStickDown;
                default: return 0;
            }
        case 1: return trigger == 0 ? kPadLeftTrigger : trigger == 1 ? kPadRightTrigger : 0;
        case 2: return button & 0xf3ff;
        default: return 0;
    }
}

unsigned DefaultInputs() {
    using namespace hotkeys;
    return kPadLStickLeft | kPadLStickRight | kPadLStickUp | kPadLStickDown | kPadX | kPadY | kPadB | kPadA | kPadLeftBumper |
           kPadRightBumper | kPadLeftTrigger | kPadRightTrigger | kPadDpadUp | kPadDpadDown | kPadDpadLeft | kPadDpadRight |
           kPadStart;
}

unsigned BoundInputs() {
    AcquireSRWLockExclusive(&g_lock);
    if (!g_scanned) {
        g_objects = Scan();
        g_scanned = true;
        alog::Write("game pads: %u controller object(s) found", static_cast<unsigned>(g_objects.size()));
    }
    const std::vector<unsigned> objects = g_objects;
    ReleaseSRWLockExclusive(&g_lock);
    unsigned mask = 0;
    bool any = false;
    for (unsigned o : objects) {
        unsigned vt = 0;
        if (!Read(o, &vt, 4) || vt != kControllerVtable) continue;
        unsigned m = 0;
        if (ReadMap(o, &m)) {
            mask |= m;
            any = true;
        }
    }
    if (!any) {
        alog::Write("game pads: the game's bindings couldn't be read; using its defaults");
        return DefaultInputs() | kStartAlways;
    }
    static unsigned logged = 0;  // (the layout is from static RE: the log shows what was read)
    if (mask != logged) {
        alog::Write("game pads: the game's bindings: %s", hotkeys::PadName(mask).c_str());
        logged = mask;
    }
    return mask | kStartAlways;
}

}  // namespace game_pads
