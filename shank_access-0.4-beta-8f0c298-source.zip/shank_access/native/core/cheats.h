#pragma once
#include <cstdint>

// B60 / B66: the cheats (F7 > Cheats; since B66 for every player, not tied to test mode).
// - Infinite health and infinite grenades: our stategraphutil.lua patch gives every one of Shank's states a rule that
//   refills his health (or grenades) while HasTag("a11y_cheat_health") / ("a11y_cheat_grenades") is true. No game object
//   carries those tags; edge_guard's HasTag_ParseNode::Evaluate hook answers yes for an on cheat's tag (Answers).
// - God mode and super speed: the game's own debug bytes (game.h debug_god_mode / debug_super_speed), kept to the cheat's
//   state by Apply.
// B66 (the user, 2026-10-18: "Add a cheats on/off toggle ... This toggle remembers the state of the four other toggles,
// enabling the configuration when on and turning everything off otherwise. This toggle and the state of the other four
// should be remembered across sessions and default to everything off."): each cheat is chosen or not, and the master
// switch turns the chosen ones on together. A cheat is on when the master is on and it's chosen.
namespace cheats {

enum Cheat { kHealth, kGrenades, kGodMode, kSuperSpeed, kCount };

void SetMaster(bool on);
bool Master();
void Set(Cheat c, bool chosen);  // chosen or not (it takes effect while the master is on)
bool Chosen(Cheat c);
bool On(Cheat c);                // the master on and the cheat chosen
const char* Name(Cheat c);       // "Infinite health", "Infinite grenades", "God mode", "Super speed"

// God mode and super speed: the game's debug bytes (0 = not in this build). Apply writes each to its cheat's state when
// it differs (the cue thread calls it often: the game could reset them).
void SetDebugBytes(uintptr_t god_mode, uintptr_t super_speed);
bool Available(Cheat c);  // its byte known (god mode, super speed); health and grenades: SetHookAvailable
void SetHookAvailable(bool installed);
void Apply();

// Called (on the changing thread) after any change of the master or a choice.
void SetOnChange(void (*fn)());

// The game's name hash (0x43d060: sdbm of the lowercased name; RE-NOTES "HasTag_ParseNode").
unsigned Hash(const char* name);

// The HasTag hook's question: is `tag_hash` an on cheat's tag, or a spawn asked for (once)?
bool Answers(unsigned tag_hash);

// B67 / B68 (F7 > Cheats > Spawn items; the user, 2026-10-18: "spawn a minigun or flamethrower next two Shank for him to
// pick up", then health and grenades): the rule in Shank's states for this pickup fires once: the hook answers its tag
// yes one time, within kSpawnWindowMs of the ask (an ask while no state of his runs, e.g. paused, lapses instead of
// spawning much later; 2 s leaves the game time to resume after the menu).
enum Spawn { kSpawnMinigun, kSpawnFlamethrower, kSpawnHealth, kSpawnGrenades, kSpawnCount };
constexpr unsigned kSpawnWindowMs = 2000;
const char* SpawnName(Spawn s);  // "Minigun", "Flamethrower", "Health", "Grenades"
const char* SpawnKind(Spawn s);  // the pickup's kind in the cues: "minigun", "flamethrower", "health", "grenades"
void AskSpawn(Spawn s, unsigned now_ms);
// B69 (the user, 2026-10-19: "spawning an item via the menu does not work. It closes the menu and returns to the pause
// screen ... The mod will need to register the spawn request, then hold it until it detects the game is unpaused and then
// fire the drop."): a spawn is held until the game is in play again (the cue thread's not-quiet tick calls ReleaseHeld,
// which asks for the held ones from then); a level load drops them.
void HoldSpawn(Spawn s);
bool Held(Spawn s);
void ReleaseHeld(unsigned now_ms);
void DropHeld();
bool CancelHeld(Spawn s);  // B69b: the menu's second Enter (false if none was held)
// For tests (the hook asks with GetTickCount()): Answers at a given time.
bool AnswersAt(unsigned tag_hash, unsigned now_ms);

}  // namespace cheats
