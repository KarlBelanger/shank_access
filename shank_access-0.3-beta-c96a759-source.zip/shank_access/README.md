# shank-access (development repository)

A screen reader and audio accessibility mod for **Shank** (Klei Entertainment, 2010), the Steam PC version. It reads the
menus, speaks game events, adds positional sound cues for edges, jumps, pickups, enemies and hazards, and guides the
player from checkpoint to checkpoint with a waypoint mode.

**Status:** public beta 0.2, released 2026-10-03 at https://github.com/KarlBelanger/shank_access (the player's readme
is `release/README.md`; the release is built from this repository). This repository is the private development copy.

**Shank 2:** a port is planned in `docs/SHANK2-PLAN.md` (handed to a second developer on 2026-10-04; their guide is
`handoff/README.md`).

## Where things are

- `CLAUDE.md`: how the project is worked on, the commands, and the layout.
- `docs/PLAN.md`: status, the plan, decisions, the work log and the batch records.
- `docs/RE-NOTES.md`: the reverse-engineering notes (engine facts).
- `docs/DESIGN.md`: cues, keys, settings and the player's feedback.
- `docs/TESTING.md`: one record per test session.
- `native/`: the C++ mod (a `dinput8.dll` proxy and `shank_access.dll`, x86) and its host tests.
- `tools/`: deploying to a game install, log collection and analysis, level extraction, the route graph, the setup
  (`tools/setup/`) and the public release (`tools/make_public.py`).
- `mod/`: what gets deployed: our files and the patches to the game's scripts (never Klei's files).

## How it works

- The mod never ships Klei's files. It consists of our own files plus small patches to the game's scripts, which
  `tools/deploy.py` (development) or the player's setup applies to the installed game, as new files under `data-pc/`.
- A native DLL, loaded through a `dinput8.dll` proxy, plays the cues and talks to the screen reader. It works out most
  cues from the level's collision data (extracted from the player's own install) and Shank's live position; the script
  patches report pickups, hazards and Shank's state.

## Requirements (development)

- Windows 10/11 and Shank on Steam.
- Visual Studio 2022 Build Tools (C++ with the x86 compiler), CMake, Python 3.12+.

```bash
py -m venv .venv
.venv/Scripts/python -m pip install -r requirements.txt
.venv/Scripts/python -m unittest discover -s tests
```

## Licence

MIT (`LICENSE`). Third-party components keep their own licences (`THIRD_PARTY_NOTICES.md`).
