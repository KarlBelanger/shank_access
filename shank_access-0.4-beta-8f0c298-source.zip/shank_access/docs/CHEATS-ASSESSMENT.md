# Cheats and extras: feasibility assessment (2026-10-03)

The user (2026-10-03): "I'm thinking about taking test mode and repurposing it into a cheats and extras menu, with god
mode and super speed, plus the intro movie skips. I'd also add some cheats for players to use. For each of the below,
discuss how feasible it is and how much work would be needed." Discussion only; nothing built, no decision yet.

Effort sizes: **small** = one batch step; **medium** = most of a batch; **large** = several batches.

## Shared foundations
- **The menu (small):** release builds have no F3 or test mode (B37-2). A "Cheats and extras" page in F7 for everyone,
  off by default, holding god mode, super speed, the movie skips and the cheats below. Announce "cheats on" at startup.
- **DLL → Lua switch (small; the mechanism exists):** safe edges (B7) already answer a tag check inside Klei's own Lua
  rule from the DLL (HasTag_ParseNode::Evaluate 0x4f92c0). Cheat rules in Shank's stategraph can ask the same way.
- **Virtual input (medium, once):** the XInputGetState hooks (input_block, B40) can report presses the player didn't
  make (COOP-PLAN's virtual pad). Needed by anything that presses a button for the player.
- **Correction to keep in mind:** the game's debug god mode byte (0xae6539) does **not** stop damage (RE-NOTES; every log
  since B7 shows health dropping to 0 with it on). "God mode" in a public menu should be infinite health below.

## The requested cheats
1. **Infinite health / grenades: easy (small).** A Lua rule in Shank's REACTIONS: while on, HealthDelta back to full
   when below 100%, AddInventory grenades back to 5 (InventoryMax 5). Limits: pits, grinders and other instant kills
   ignore health. True no-damage (or one-hit kills) needs RE of the damage path (cDamageEvent): medium.
2. **Auto parry / grapple: feasible (medium).** Every prompt is already known (fx_press_* events, Cassandra's
   press_lt_slow parry). Best route: patch Shank's grapple transition so "cheat on and prompt active" counts as the
   press; the game's own range check stays. Mash prompts (grabs, the Butcher's choke) via virtual input. Cassandra's
   parry is a timed hold of block during her lunge: the prompt start gives the window.
3. **Auto block: hard and imperfect (medium-large).** We know wind-ups (the State() patch), but not which attacks are
   blockable (guns, grapplers, boss specials, fire, explosions have no wind-up), whether block covers both sides, and
   holding block stops Shank attacking or moving (fights the player's input). Infinite health gives most of the benefit.
4. **Auto jump in waypoint mode: mechanically easy, hard to trust (medium narrow, large done well).** Press jump when the
   jump-now chirp fires for the route's move. Only as good as the jump model; a wrong auto-jump kills. Many moves also
   need a direction, a run-up, or a second input. Slope slides are the model's weakest part (modelled 1248 px/s,
   measured ~780). Suggested narrow start: jump only (the player steers), only on moves evidence.py marks proven.
5. **Auto pick up: easy (small).** Klei's PICKUPS rule is Down + the grapple button (CONTROL_BLOCK, the grapple button despite its name) with the item in its probe; a copy without the
   buttons while on. Health only when hurt, grenades only under 5, weapons optional (auto-swap could replace a minigun
   or katana). Health plays the short health_slam animation.
6. **Auto aim at the locked target: feasible (medium).** Melee: turn to face the target (Lua Toggle("facing") or a
   virtual tap), only when the player isn't steering away. Guns: Shank aims at three angles (straight, up, down via
   Look Up / Crouch; hanging ±45°); pick the nearest and hold it while firing. Check first whether the game already
   auto-aims guns.

## The modes
7. **Boss rush: large (2-3 batches).** Pieces: load a level from our code (not RE'd; B34 chose not to; the level select
   does it, so it's findable), go to the boss checkpoint (have: checkpoint_jump), detect the boss's defeat (have: boss
   health, kill events), carry health and grenades (the cheat switch), skip intros / end cinematics, a summary. Risks:
   bosses are tied to story triggers (cinematics, setgameover at the level end), and finishing a level writes the
   player's save (unlocks): must not disturb it.
8. **Survival: large, most open-ended (3+ batches; after boss rush, it shares level loading).** Level scripts are plain
   Lua patchable in data-pc: take an arena (e.g. World of Warriors'), replace its waves with our own director: wave
   tables by difficulty, pickups via spawnprop, a spoken wave count, a saved best. Spawning: the scripts'
   spawncharacter / enemygeneratoraction, or the native debug SpawnCharacterAtMouse 0x7816c0. Unknowns: whether
   enemies spawned this way behave (bounds, AI), clutter over a long run.

## Other ideas
- **Slow motion (medium; recommended):** the engine already slows time (the Butcher's specials, Cassandra's parry:
  speedSlowDown). If the speed is settable, a 50% / 75% toggle helps tight jumps and slides more reliably than auto jump.
- **Skip this fight (small):** the debug KillAllEnemies 0x7814d0 with the simulation pointer we already find (B34).
  **Skip section:** Go to checkpoint (test mode) offered to players.
- **Fall rescue (medium-large):** instead of dying in a pit, put Shank back on the last safe ground (needs writing his
  position or a restart there).
- **Boss practice:** Go to checkpoint at a boss + infinite health: nearly free once the menu exists.
- **Damage multiplier / one-hit kills:** with the damage-path RE.
- Survival extras: random weapon per wave, a level timer / stats readout.

## Cautions
- Cheats may still record level completions and unlocks in the save (and achievements, if the Steam version has them):
  check before release; perhaps block saving progress while cheats are on.
- Everything off by default; the readme and the startup line say when cheats are on.

## Suggested order
1. The menu + infinite health / grenades + auto pick up + skip fight (one small batch).
2. Virtual input + auto prompts + auto aim.
3. Slow motion RE.
4. Auto jump, narrow.
5. Boss rush, then survival.
