"""B10-2 check: the shortest path in the traversal graph between two spots of a level, as the DLL will find it.

Usage (repo root): .venv/Scripts/python tools/levels/path_check.py <level> <from x> <from y> [<checkpoint name> | --to <node>...]
                   .venv/Scripts/python tools/levels/path_check.py --all [level]   (every checkpoint leg: which have no path)
Reads build/levels/shank_access_geometry.txt and build/levels/shank_access_paths.txt. Without a checkpoint name it
goes to the next checkpoint after the one nearest the start spot.
"""
import heapq
import math
import os
import sys

ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "build", "levels")
MOVE_COST = {m: 0.5 for m in ("climb", "run_up_wall", "climb_over", "slide_down", "climb_down", "switch_sides", "drop_through",
                              "shimmy_along", "run_across", "run_off", "climb_up", "walk_off", "slide_off")}  # moves on foot (as pathing.cpp)
MOVE_COST.update({"walk_off": 0.3, "slide_off": 0.3})  # B20-2: stepping off an edge, no input (as pathing.cpp)


LAST_ROUTE = []  # the last route found: [(from, to, move, x, y, side)]


def section(path, level):
    out, on = [], False
    for line in open(path, encoding="utf-8"):
        line = line.rstrip("\n")
        if line.startswith("["):
            on = line == "[%s]" % level
            continue
        if on and line and not line.startswith("#"):
            out.append(line.split(" "))
    return out


def load(level):
    geo = section(os.path.join(ROOT, "shank_access_geometry.txt"), level)
    surfaces, features, walls, checkpoints, goals = {}, [], [], [], []
    for f in geo:
        if f[0] == "surface":
            n = int(f[9])
            pts = [(float(f[10 + 2 * i]), float(f[11 + 2 * i])) for i in range(n)]
            surfaces["s" + f[1]] = pts
        elif f[0] == "feature":
            n = int(f[2])
            features.append((f[1], [(float(f[3 + 2 * i]), float(f[4 + 2 * i])) for i in range(n)]))
        elif f[0] == "wall":
            walls.append((f[1], float(f[2]), float(f[3]), float(f[4]), f[5] == "1"))
        elif f[0] == "checkpoint":
            checkpoints.append((int(f[1]), float(f[2]), float(f[3]), float(f[4]), float(f[5]), float(f[6]), float(f[7]), " ".join(f[8:])))
        elif f[0] == "goal":  # B29-6: a story region after checkpoint f[1] (as cues.cpp: its middle top as the "spawn")
            rx, ry, rw, rh = map(float, f[2:6])
            goals.append((int(f[1]), rx + rw / 2, ry, rx, ry, rw, rh, "goal %s after %s" % (f[6], f[1])))
    edges = {}
    for f in section(os.path.join(ROOT, "shank_access_paths.txt"), level):
        if f[0] == "edge":
            one_spot = len(f) >= 11 and float(f[8]) - float(f[7]) < 64 and float(f[10]) - float(f[9]) < 64
            # B46 (as pathing.cpp): a walk-off that works at one speed only counts as a one-spot jump
            one_speed = f[3] == "walk_off" and len(f) >= 15 and f[11] == "v" and 0 < int(f[14]) < 5  # (B47c-2)
            fragile = f[3] == "platform_up" and one_spot
            # B41c (as pathing.cpp): a one-spot jump off a wall, wall run, pole, swing point or bar counts 2.5
            hard = not fragile and one_spot and not f[1].startswith("s") and f[3] != "drop" and MOVE_COST.get(f[3], 1.0) == 1.0
            edges.setdefault(f[1], []).append((f[2], "platform_up!" if fragile else (f[3] + "!!" if hard or one_speed else f[3]),
                                               float(f[4]), float(f[5]), f[6]))
    checkpoints += goals  # (after the checkpoints: main finds a goal by its name)
    return surfaces, features, walls, checkpoints, edges


def where(node, surfaces, features, walls):
    if node[0] == "s":
        p = surfaces[node]
        return "floor %s x %.0f..%.0f y %.0f" % (node, p[0][0], p[-1][0], p[0][1])
    if node[0] in "fp":
        i = int(node[1:].rstrip("LR"))
        kind, pts = features[i]
        side = {"L": " (left side)", "R": " (right side)"}.get(node[-1], "")
        return "%s %s at (%.0f, %.0f)%s" % (kind, node, pts[0][0], pts[0][1], side)
    w = walls[int(node[1:])]
    return "climbable wall %s x %.0f y %.0f..%.0f" % (node, w[1], w[2], w[3])


def floor_under(surfaces, x, y):
    best, best_d = None, 1e9
    for sid, pts in surfaces.items():
        for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
            if x1 - 8 <= x <= x2 + 8 and x2 > x1:
                fy = y1 + (x - x1) / (x2 - x1) * (y2 - y1)
                d = abs(y - 32 - fy)
                if d < 48 and d < best_d:
                    best, best_d = sid, d
    if best:
        return best
    # In the air (a spawn point above a floor): the highest floor below.
    for sid, pts in surfaces.items():
        for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
            if x1 - 8 <= x <= x2 + 8 and x2 > x1:
                fy = y1 + (x - x1) / (x2 - x1) * (y2 - y1)
                if fy < y and y - fy < best_d:
                    best, best_d = sid, y - fy
    return best


def main(argv):
    level, fx, fy = argv[1], float(argv[2]), float(argv[3])
    surfaces, features, walls, checkpoints, edges = load(level)
    start = floor_under(surfaces, fx, fy)
    if argv[4:5] == ["--to"]:  # a place in the graph (s12, f7, p20L, w53): directions to an interaction to test
        goals = set(argv[5:])
        print("from", where(start, surfaces, features, walls), "to", ", ".join(where(g, surfaces, features, walls) for g in sorted(goals)))
        return route(start, goals, fx, edges, surfaces, features, walls)
    if argv[4:]:
        goal_cp = next(c for c in checkpoints if c[7] == " ".join(argv[4:]))
    else:
        near = min(checkpoints, key=lambda c: math.hypot(c[1] - fx, c[2] - fy))
        goal_cp = checkpoints[min(near[0] + 1, len(checkpoints) - 1)]
    rx, ry, rw, rh = goal_cp[3:7]
    M = 320  # the trigger rectangle grown by 5 tiles: floors and holds near it count as reaching it
    def crosses(pts):  # a floor piece passing through the (grown) trigger rectangle
        for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
            if x2 < rx - M or x1 > rx + rw + M or x2 <= x1:
                continue
            xa, xb = max(x1, rx - M), min(x2, rx + rw + M)
            for x in (xa, (xa + xb) / 2, xb):
                y = y1 + (x - x1) / (x2 - x1) * (y2 - y1)
                # B27-3 (as cues.cpp GoalsFor): Shank standing there overlaps the rectangle vertically (feet at or under
                # its top, head (160 px) at or over its bottom); 4-a's s33, 205 px above one, had won the route
                if ry - 160 + 32 <= y + 32 <= ry + rh + 32:
                    return True
        return False
    goals = {sid for sid, pts in surfaces.items() if rw > 0 and crosses(pts)}
    for i, (kind, pts) in enumerate(features):  # a hold the trigger is passed from (1-c: a swing point beside it)
        x, y = pts[0]
        if rw > 0 and rx - M <= x <= rx + rw + M and ry - M <= y <= ry + rh + M:
            goals |= {"f%d" % i, "p%dL" % i, "p%dR" % i}
    spawn_floor = floor_under(surfaces, goal_cp[1], goal_cp[2])
    if spawn_floor:
        goals.add(spawn_floor)
    print("from", where(start, surfaces, features, walls), "to", goal_cp[7], "(floors %s)" % sorted(goals))
    return route(start, goals, fx, edges, surfaces, features, walls)


def route(start, goals, fx, edges, surfaces, features, walls):
    dist, prev, heap = {start: 0.0}, {}, [(0.0, start)]
    arrive = {start: fx}  # B27-3 (as pathing.cpp): walking along a floor costs 1 per 40 tiles (the move's start spot)
    while heap:
        d, n = heapq.heappop(heap)
        if n in goals:
            break
        if d > dist.get(n, 1e18):
            continue
        ax = arrive.get(n)
        for to, move, x, y, side in edges.get(n, []):
            walk = abs(x - ax) / (40 * 64) if n.startswith("s") and ax is not None else 0.0
            nd = d + (3.0 if move == "platform_up!" else 2.5 if move.endswith("!!") else MOVE_COST.get(move, 1.0)) + walk  # B15-7 / B41c
            if nd < dist.get(to, 1e18):
                dist[to], prev[to] = nd, (n, move, x, y, side)
                arrive[to] = x
                heapq.heappush(heap, (nd, to))
    else:
        print("no path")
        return 1
    steps, n = [], n
    while n in prev:
        p, move, x, y, side = prev[n]
        steps.append((p, n, move, x, y, side))
        n = p
    LAST_ROUTE[:] = list(reversed(steps))  # (B42-4: for risky_moves.py)
    for p, n, move, x, y, side in reversed(steps):
        print("  %-14s from (%.0f, %.0f) facing %s -> %s" % (move, x, y, "right" if side == "R" else "left", where(n, surfaces, features, walls)))
    return 0


def check_all(only=None):
    """B12: every checkpoint leg of every level (spawn -> next checkpoint): prints the ones without a path. B42-5: only=a
    level (part of its name): that level's legs only."""
    import contextlib, io
    levels = [l.strip()[1:-1] for l in open(os.path.join(ROOT, "shank_access_geometry.txt"), encoding="utf-8") if l.startswith("[")]
    total = bad = 0
    for level in levels:
        if only and only not in level:
            continue
        every = load(level)[3]
        checkpoints = [c for c in every if not c[7].startswith("goal ")]
        legs = list(zip(checkpoints, checkpoints[1:]))
        legs += [(checkpoints[g[0]], g) for g in every if g[7].startswith("goal ")]  # B29-6: checkpoint -> its story goal
        for a, b in legs:
            total += 1
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    r = main(["", level, str(a[1]), str(a[2]), b[7]])
                except Exception:
                    r = 2
            if r:
                bad += 1
                print("no path:", level, a[7], "->", b[7])
    print("%d of %d checkpoint legs (and story goals) have a path" % (total - bad, total))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(check_all(sys.argv[2] if len(sys.argv) > 2 else None) if sys.argv[1:2] == ["--all"] else main(sys.argv))
