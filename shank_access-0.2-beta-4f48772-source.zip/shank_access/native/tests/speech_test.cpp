// Host-side Tolk check (never deployed). Loads Tolk.dll from the given directory (the screen
// reader client DLLs must sit next to this exe, as they do next to Shank.exe), and prints which
// screen reader Tolk detects. Silent unless --speak is given. Exit code 0 = Tolk loaded.
#include <windows.h>

#include <cstdio>
#include <cwchar>
#include <string>

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) {
        fwprintf(stderr, L"usage: speech_test <dir with Tolk.dll> [--speak]\n");
        return 2;
    }
    const bool speak = argc > 2 && wcscmp(argv[2], L"--speak") == 0;
    HMODULE tolk = LoadLibraryW((std::wstring(argv[1]) + L"\\Tolk.dll").c_str());
    if (!tolk) { wprintf(L"FAIL: Tolk.dll not loaded (%lu)\n", GetLastError()); return 1; }
    auto load = reinterpret_cast<void(__cdecl*)()>(GetProcAddress(tolk, "Tolk_Load"));
    auto try_sapi = reinterpret_cast<void(__cdecl*)(bool)>(GetProcAddress(tolk, "Tolk_TrySAPI"));
    auto detect = reinterpret_cast<const wchar_t*(__cdecl*)()>(GetProcAddress(tolk, "Tolk_DetectScreenReader"));
    auto has_speech = reinterpret_cast<bool(__cdecl*)()>(GetProcAddress(tolk, "Tolk_HasSpeech"));
    auto output = reinterpret_cast<bool(__cdecl*)(const wchar_t*, bool)>(GetProcAddress(tolk, "Tolk_Output"));
    if (!load || !try_sapi || !detect || !has_speech || !output) { wprintf(L"FAIL: missing exports\n"); return 1; }
    try_sapi(true);
    load();
    const wchar_t* sr = detect();
    wprintf(L"ok: Tolk loaded; screen reader: %ls; has speech: %d\n", sr ? sr : L"(none)", has_speech() ? 1 : 0);
    if (speak) {
        output(L"Shank access speech test.", true);
        Sleep(3000);  // Tolk output is asynchronous
    }
    return 0;
}
