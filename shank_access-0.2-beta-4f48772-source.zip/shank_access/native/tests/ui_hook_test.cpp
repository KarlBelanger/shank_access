// Host-side test of the UI hooks (never deployed). Stand-ins mimic the game's two functions:
//   FakeCallback     = SwfExternalInterface::Callback: thiscall(this, movie, method, args, argc), ret 0x10
//   FakeSetVariable  = SwfSymbol::SetVariableInternal: esi = symbol, edi = member, [esp+4] = value,
//                      returns al, ret 4 (callee pops)
// We hook them with the real ui_hooks code and check the log lines, the originals' inputs, the
// return value, register preservation, stack balance and change-only logging. Exit 0 = pass.
#include <windows.h>

#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <share.h>

#include "../core/log.h"
#include "../core/ui_hooks.h"

namespace {

void* g_cb_self = nullptr;
const char* g_cb_method = nullptr;
unsigned g_cb_argc = 0;
int g_cb_calls = 0;
const void* g_sv_symbol = nullptr;
const char* g_sv_member = nullptr;
const void* g_sv_value = nullptr;
int g_sv_calls = 0;

__declspec(naked) void FakeCallback() {
    __asm {
        push ebp
        mov ebp, esp
        and esp, 0xfffffff8
        mov g_cb_self, ecx
        mov eax, [ebp + 0x0c]      // method (after this-in-ecx: movie at +8, method at +0xc)
        mov g_cb_method, eax
        mov eax, [ebp + 0x14]      // argc
        mov g_cb_argc, eax
        inc g_cb_calls
        mov esp, ebp
        pop ebp
        ret 0x10
    }
}

__declspec(naked) void FakeSetVariable() {
    __asm {
        push ecx
        mov eax, [esi + 0x2c]      // same first instructions as the game's function
        and al, 0x8f
        mov g_sv_symbol, esi
        mov g_sv_member, edi
        mov eax, [esp + 8]         // the value argument (after push ecx)
        mov g_sv_value, eax
        inc g_sv_calls
        mov eax, 1                 // success in al
        pop ecx
        ret 4
    }
}

// SwfSymbol::InvokeV stand-in: thiscall(ecx = symbol; method, fmt, va_list) -> const char*, ret 0xc.
void* g_inv_self = nullptr;
const char* g_inv_method = nullptr;
const char* g_inv_fmt = nullptr;
va_list g_inv_args = nullptr;
int g_inv_calls = 0;
const char* g_inv_result = "";

__declspec(naked) void FakeInvoke() {
    __asm {
        push ebp
        mov ebp, esp
        mov g_inv_self, ecx
        mov eax, [ebp + 8]
        mov g_inv_method, eax
        mov eax, [ebp + 0x0c]
        mov g_inv_fmt, eax
        mov eax, [ebp + 0x10]
        mov g_inv_args, eax
        inc g_inv_calls
        mov eax, g_inv_result
        pop ebp
        ret 0x0c
    }
}

using InvokeFn = const char*(__fastcall*)(void*, void*, const char*, const char*, va_list);

// SwfScreen::Update stand-in: thiscall(ecx = screen; float dt), ret 4.
void* g_upd_self = nullptr;
int g_upd_calls = 0;
__declspec(naked) void FakeUpdate() {
    __asm {
        push ebp
        mov ebp, esp
        mov g_upd_self, ecx
        inc g_upd_calls
        pop ebp
        ret 4
    }
}
using UpdateFn = void(__fastcall*)(void*, void*, float);

// SwfSymbol::InvokeMethodInternal stand-in: ecx = symbol, edi = method, [esp+4] result,
// [esp+8] args, [esp+0xc] argc; returns al = 1; ret 0xc.
void* g_ii_self = nullptr;
const char* g_ii_method = nullptr;
void* g_ii_args = nullptr;
unsigned g_ii_argc = 0;
int g_ii_calls = 0;
__declspec(naked) void FakeInvokeInternal() {
    __asm {
        mov g_ii_self, ecx
        mov g_ii_method, edi
        mov eax, [esp + 8]
        mov g_ii_args, eax
        mov eax, [esp + 0x0c]
        mov g_ii_argc, eax
        inc g_ii_calls
        mov eax, 1
        ret 0x0c
    }
}

unsigned CallInvokeInternal(void* self, const char* method, void* args, unsigned argc, unsigned* esp_delta,
                            unsigned* edi_out) {
    unsigned result = 0, before = 0, after = 0, r_edi = 0;
    __asm {
        push edi
        mov ecx, self
        mov edi, method
        mov before, esp
        push argc
        push args
        push 0
        call FakeInvokeInternal
        mov after, esp
        movzx eax, al
        mov result, eax
        mov r_edi, edi
        pop edi
    }
    *esp_delta = before - after;
    *edi_out = r_edi;
    return result;
}
const char* CallInvoke(void* self, const char* method, const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    const char* r = reinterpret_cast<InvokeFn>(&FakeInvoke)(self, nullptr, method, fmt, ap);
    va_end(ap);
    return r;
}

// GFxValue stand-in: +0 interface, +4 type, +8 value.
struct Value {
    void* iface;
    unsigned type;
    union {
        double number;
        const char* str;
        const char* const* managed;
    };
};
static_assert(sizeof(Value) == 16, "GFxValue is 16 bytes in GFx 3.x");

// GFxMovie stand-in (1c-3): vtable slot 0x44/4 = GetVariable(out, path), thiscall, ret 8.
//   "_level0.spBtn.label"          -> managed string "Single Player" (must be released)
//   "_level0.plainBtn.label"       -> undefined; "_level0.plainBtn.textField.text" -> plain "Plain"
//   anything else                  -> fails
int g_fake_iface = 0;
const char* g_managed_node = "Single Player";  // a managed string's data points at its char*
int g_getvar_calls = 0;
int g_release_calls = 0;
bool g_release_ok = true;

bool __fastcall FakeGetVariable(void* /*movie*/, void* /*edx*/, Value* out, const char* path) {
    ++g_getvar_calls;
    if (out->type != 0) g_release_ok = false;  // the hook must reset out before the call
    if (strcmp(path, "_level0.spBtn.label") == 0) {
        out->iface = &g_fake_iface;
        out->type = 0x44;
        out->managed = &g_managed_node;
        return true;
    }
    if (strcmp(path, "_level0.plainBtn.label") == 0) {
        out->type = 0;
        return true;
    }
    if (strcmp(path, "_level0.plainBtn.textField.text") == 0) {
        out->type = 4;
        out->str = "Plain";
        return true;
    }
    if (strcmp(path, "_level0.cb.selected") == 0) {  // bool true
        out->type = 2;
        out->number = 0;
        *reinterpret_cast<unsigned char*>(&out->number) = 1;
        return true;
    }
    if (strcmp(path, "_level0.s.value") == 0) {  // number
        out->type = 3;
        out->number = 16.0;
        return true;
    }
    return false;
}

void __fastcall FakeObjectRelease(void* iface, void* /*edx*/, Value* value, void* data) {
    ++g_release_calls;
    if (iface != &g_fake_iface || value->type != 0x44 || data != &g_managed_node) g_release_ok = false;
}

struct FakeMovie {
    void* const* vtable;
};

// Event listener: records "<type>:<path>@<original calls so far>" for each event.
std::string g_events;
void* g_event_movie = nullptr;
std::string g_event_value;
std::string g_event_args;  // kInvoke: "a|b|c=>result"
void* g_event_symbol = nullptr;
void Listener(const ui_hooks::UiEvent& e) {
    if (e.type == ui_hooks::UiEvent::kInvoke) {
        g_event_args.clear();
        for (const std::string& a : *e.args) g_event_args += a + "|";
        g_event_args += std::string("=>") + e.result;
        g_event_symbol = e.symbol;
    }
    char buf[160];
    _snprintf_s(buf, sizeof buf, _TRUNCATE, "%d:%s@%d;", static_cast<int>(e.type), e.path, g_cb_calls);
    g_events += buf;
    g_event_movie = e.movie;
    if (e.value) g_event_value = e.value->text;
}
void* g_movie_vtable[0x60 / 4] = {};

// SwfSymbol stand-in: the widget name std::string starts at +0xc (capacity at +0xc+0x18).
struct Symbol {
    unsigned char bytes[0x40];
};

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

unsigned CallSetVariable(Symbol* sym, const char* member, const Value* value, unsigned* esp_delta, unsigned* esi_out,
                         unsigned* edi_out, unsigned* ebx_out) {
    unsigned result = 0, before = 0, after = 0, r_esi = 0, r_edi = 0, r_ebx = 0;
    __asm {
        push esi
        push edi
        push ebx
        mov esi, sym
        mov edi, member
        mov ebx, 0x5A5A5A5A
        mov before, esp
        push value
        call FakeSetVariable
        mov after, esp             // callee popped its argument
        movzx eax, al
        mov result, eax
        mov r_esi, esi
        mov r_edi, edi
        mov r_ebx, ebx
        pop ebx
        pop edi
        pop esi
    }
    *esp_delta = before - after;
    *esi_out = r_esi;
    *edi_out = r_edi;
    *ebx_out = r_ebx;
    return result;
}

}  // namespace

int main() {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_ui_hook_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    Check(ui_hooks::InstallAt(reinterpret_cast<unsigned>(&FakeCallback), reinterpret_cast<unsigned>(&FakeSetVariable),
                              reinterpret_cast<unsigned>(&FakeObjectRelease), reinterpret_cast<unsigned>(&FakeInvoke),
                              reinterpret_cast<unsigned>(&FakeUpdate), reinterpret_cast<unsigned>(&FakeInvokeInternal)),
          "hooks installed on stand-ins");

    // Hook A: a focus-style call with a string and a number argument.
    static const char kMethod[] = "focusIn";
    Value args[2] = {};
    args[0].type = 4;
    args[0].str = "resumeBtn";
    args[1].type = 3;
    args[1].number = 3.0;
    using Fn = void(__fastcall*)(void*, void*, void*, const char*, const void*, unsigned);
    int self_obj = 0;
    reinterpret_cast<Fn>(&FakeCallback)(&self_obj, nullptr, nullptr, kMethod, args, 2);
    Check(g_cb_calls == 1 && g_cb_self == &self_obj && g_cb_method == kMethod && g_cb_argc == 2,
          "original callback ran with this, method and argc intact");
    Check(g_getvar_calls == 0, "no label read without a movie");

    // 1c-3: focusIn with a movie reads the label through GetVariable.
    ui_hooks::SetEventListener(&Listener);
    g_movie_vtable[0x44 / 4] = reinterpret_cast<void*>(&FakeGetVariable);
    FakeMovie movie = {g_movie_vtable};
    auto focus = [&](const char* path) {
        Value a[2] = {};
        a[0].type = 4;
        a[0].str = path;
        reinterpret_cast<Fn>(&FakeCallback)(&self_obj, nullptr, &movie, kMethod, a, 2);
    };
    focus("_level0.spBtn");     // managed label, released once
    focus("_level0.plainBtn");  // falls back to textField.text
    focus("_level0.nothing");   // neither: (none)
    static const char kNavigate[] = "navigate";
    Value nav[1] = {};
    nav[0].type = 4;
    nav[0].str = "_level0.spBtn";
    reinterpret_cast<Fn>(&FakeCallback)(&self_obj, nullptr, &movie, kNavigate, nav, 1);  // not focusIn: no read
    static const char kChange[] = "change";
    Value chg[1] = {};
    chg[0].type = 4;
    chg[0].str = "_level0.s";
    reinterpret_cast<Fn>(&FakeCallback)(&self_obj, nullptr, &movie, kChange, chg, 1);
    Value undef[1] = {};  // navigate(undefined): no event
    reinterpret_cast<Fn>(&FakeCallback)(&self_obj, nullptr, &movie, kNavigate, undef, 1);
    Check(g_cb_calls == 7, "original callback still ran for every call");
    Check(g_getvar_calls == 5, "GetVariable called: 1 + 2 (fallback) + 2 (both fail), none for navigate/change");
    Check(g_release_calls == 1 && g_release_ok, "managed label released once; out reset before each read");
    Check(g_events == "0:_level0.spBtn@1;0:_level0.plainBtn@2;0:_level0.nothing@3;1:_level0.spBtn@5;3:_level0.s@6;",
          "events: focusIn before the original, navigate/change after it, none for navigate(undefined)");
    Check(g_event_movie == &movie, "events carry the movie");

    // ReadValue: text (managed, released), bool, number, failure.
    const int releases_before = g_release_calls;
    const ui_hooks::FlashValue v_text = ui_hooks::ReadValue(&movie, "_level0.spBtn.label");
    const ui_hooks::FlashValue v_bool = ui_hooks::ReadValue(&movie, "_level0.cb.selected");
    const ui_hooks::FlashValue v_num = ui_hooks::ReadValue(&movie, "_level0.s.value");
    const ui_hooks::FlashValue v_none = ui_hooks::ReadValue(&movie, "_level0.missing");
    Check(v_text.kind == ui_hooks::FlashValue::kText && v_text.text == "Single Player" &&
              g_release_calls == releases_before + 1,
          "ReadValue: managed text read and released");
    Check(v_bool.kind == ui_hooks::FlashValue::kBool && v_bool.b, "ReadValue: bool");
    Check(v_num.kind == ui_hooks::FlashValue::kNumber && v_num.n == 16.0, "ReadValue: number");
    Check(v_none.kind == ui_hooks::FlashValue::kNone, "ReadValue: failure -> kNone");

    // Hook B: set a label on a widget named "resumeBtn" (short name: inline std::string buffer).
    Symbol sym = {};
    const char kWidget[] = "resumeBtn";
    memcpy(sym.bytes + 0xc + 4, kWidget, sizeof kWidget);
    *reinterpret_cast<unsigned*>(sym.bytes + 0xc + 0x18) = 15;
    Value label = {};
    label.type = 4;
    label.str = "Resume Game";
    unsigned delta = 0, r_esi = 0, r_edi = 0, r_ebx = 0;
    const unsigned res = CallSetVariable(&sym, "label", &label, &delta, &r_esi, &r_edi, &r_ebx);
    Check(res == 1, "original SetVariable's return value (al) passed through");
    Check(g_sv_calls == 1 && g_sv_symbol == &sym && g_sv_value == &label && strcmp(g_sv_member, "label") == 0,
          "original SetVariable saw esi, edi and the value");
    Check(delta == 0, "stack balanced (callee popped its argument)");
    Check(r_esi == reinterpret_cast<unsigned>(&sym) && r_ebx == 0x5A5A5A5A, "esi/ebx preserved");

    // Same value again: must not be logged twice. Then a managed string: logged.
    CallSetVariable(&sym, "label", &label, &delta, &r_esi, &r_edi, &r_ebx);
    static const char kNew[] = "Resume";
    static const char* kNewPtr = kNew;
    Value managed = {};
    managed.type = 0x44;
    managed.managed = &kNewPtr;
    CallSetVariable(&sym, "label", &managed, &delta, &r_esi, &r_edi, &r_ebx);
    // A bad string pointer must not crash (SEH): logged as "?".
    Value bad = {};
    bad.type = 4;
    bad.str = reinterpret_cast<const char*>(0x10);
    CallSetVariable(&sym, "text", &bad, &delta, &r_esi, &r_edi, &r_ebx);
    Check(g_sv_calls == 4, "every call still reached the original");

    // Phase 2: <widget>.focused = true is reported with the symbol's movie ([[sym+8]+0x38]) when that
    // movie has the callbacks' vtable; false, or a movie with another vtable, is not reported.
    g_events.clear();
    unsigned char screen[0x40] = {};
    *reinterpret_cast<void**>(screen + 0x38) = &movie;
    Symbol fsym = {};
    const char kSlider[] = "_level0.slider";
    memcpy(fsym.bytes + 0xc + 4, kSlider, sizeof kSlider);
    *reinterpret_cast<unsigned*>(fsym.bytes + 0xc + 0x18) = 15;
    *reinterpret_cast<void**>(fsym.bytes + 8) = screen;
    Value yes = {};
    yes.type = 2;
    *reinterpret_cast<unsigned char*>(&yes.number) = 1;
    Value no = {};
    no.type = 2;
    CallSetVariable(&fsym, "focused", &no, &delta, &r_esi, &r_edi, &r_ebx);
    CallSetVariable(&fsym, "focused", &yes, &delta, &r_esi, &r_edi, &r_ebx);
    void* other_vtable[0x60 / 4] = {};
    FakeMovie other = {other_vtable};
    unsigned char other_screen[0x40] = {};
    *reinterpret_cast<void**>(other_screen + 0x38) = &other;
    *reinterpret_cast<void**>(fsym.bytes + 8) = other_screen;
    CallSetVariable(&fsym, "focused", &no, &delta, &r_esi, &r_edi, &r_ebx);
    CallSetVariable(&fsym, "focused", &yes, &delta, &r_esi, &r_edi, &r_ebx);
    Check(g_events == "2:_level0.slider@7;" && g_event_movie == &movie,
          "focused = true reported once, with the symbol's movie; not for false or a foreign vtable");
    Check(g_sv_calls == 8, "focused sets still reached the original");

    // Phase 2: text/value writes are reported with the value being written (kValueSet, no movie).
    g_events.clear();
    g_event_value.clear();
    CallSetVariable(&fsym, "text", &label, &delta, &r_esi, &r_edi, &r_ebx);
    CallSetVariable(&fsym, "visible", &yes, &delta, &r_esi, &r_edi, &r_ebx);  // other members: no event
    Check(g_events == "4:_level0.slider.text@7;" && g_event_value == "Resume Game" && g_event_movie == &other,
          "text write reported as kValueSet with the new value and the symbol's movie; other members not reported");

    // 2-3: InvokeV (native -> Flash method calls). Arguments are parsed per format specifier, the
    // original sees its inputs and its result is passed back; InvokeMethod calls the original directly.
    g_events.clear();
    Symbol strip = {};
    const char kStrip[] = "_level0.strip";
    memcpy(strip.bytes + 0xc + 4, kStrip, sizeof kStrip);
    *reinterpret_cast<unsigned*>(strip.bytes + 0xc + 0x18) = 15;
    g_inv_result = "ok";
    const char* r = CallInvoke(&strip, "AddCell", "%s, %s, %s, %d, %f", "Chapter One", "levels/one.dds", "campaign_1a",
                               1, 0.5);
    Check(r != nullptr && strcmp(r, "ok") == 0, "InvokeV: the original's result passed back");
    Check(g_inv_calls == 1 && g_inv_self == &strip && strcmp(g_inv_method, "AddCell") == 0 &&
              strcmp(g_inv_fmt, "%s, %s, %s, %d, %f") == 0,
          "InvokeV: the original saw this, method and format");
    Check(g_events == "5:_level0.strip@7;" && g_event_args == "Chapter One|levels/one.dds|campaign_1a|1|0.5|=>ok" &&
              g_event_symbol == &strip,
          "InvokeV: kInvoke event with parsed args, result and the symbol");
    CallInvoke(&strip, "IsSelected", "");
    CallInvoke(&strip, "IsSelected", "");  // same line within 2 s: logged once
    g_inv_result = "3";
    const int events_before = static_cast<int>(g_events.size());
    const std::string asked = ui_hooks::InvokeMethod(&strip, "GetSelectedIndex");
    Check(asked == "3" && strcmp(g_inv_method, "GetSelectedIndex") == 0 && strcmp(g_inv_fmt, "") == 0 &&
              static_cast<int>(g_events.size()) == events_before,
          "InvokeMethod: calls the original with an empty format, no event");

    // 2-5b-3: SwfScreen::Update. The state at +0x3c (1/2 shown, 0/3 hidden) is reported on change,
    // after the original, and only for movies with the callbacks' vtable.
    g_events.clear();
    unsigned char scr[0x40] = {};
    *reinterpret_cast<void**>(scr + 0x38) = &movie;
    *reinterpret_cast<int*>(scr + 0x3c) = 2;
    const auto update = reinterpret_cast<UpdateFn>(&FakeUpdate);
    update(scr, nullptr, 0.016f);
    update(scr, nullptr, 0.016f);  // unchanged: no event
    *reinterpret_cast<int*>(scr + 0x3c) = 3;
    update(scr, nullptr, 0.016f);
    *reinterpret_cast<int*>(scr + 0x3c) = 0;
    update(scr, nullptr, 0.016f);  // still hidden: no event
    unsigned char scr2[0x40] = {};
    *reinterpret_cast<void**>(scr2 + 0x38) = &other;
    *reinterpret_cast<int*>(scr2 + 0x3c) = 1;
    update(scr2, nullptr, 0.016f);  // foreign vtable: logged, not reported
    Check(g_upd_calls == 5 && g_upd_self == scr2, "Update: the original ran every time with the screen");
    // N4: InvokeMethodInternal (register convention): logged, reported as kInvoke with the args,
    // passed through with registers, stack and al intact.
    {
        const std::string events_before = g_events;
        Value items[2] = {};
        items[0].type = 4;
        items[0].str = "Move Left";
        items[1].type = 3;
        items[1].number = 7.0;
        unsigned d = 0, edi_after = 0;
        static const char kAddItem[] = "addItem";
        const unsigned r = CallInvokeInternal(&strip, kAddItem, items, 2, &d, &edi_after);
        Check(r == 1 && d == 0 && edi_after == reinterpret_cast<unsigned>(kAddItem),
              "InvokeMethodInternal: al passed back, stack balanced (callee pops), edi preserved");
        Check(g_ii_calls == 1 && g_ii_self == &strip && g_ii_method == kAddItem && g_ii_args == items && g_ii_argc == 2,
              "InvokeMethodInternal: the original saw ecx, edi, args and argc");
        Check(g_events.size() > events_before.size() && g_event_args == "Move Left|7|=>",
              "InvokeMethodInternal: kInvoke event with decoded args");
        g_events = events_before;
    }
    Check(g_events == "9:frame@7;6:screen@7;9:frame@7;8:screen@7;9:frame@7;7:screen@7;9:frame@7;9:frame@7;",
          "Update: a frame event every call; shown, a tick on the next frame, hidden once each; foreign movie not");

    static char text[65536] = {};
    if (FILE* f = _fsopen(log_path, "r", _SH_DENYNO)) {
        fread(text, 1, sizeof text - 1, f);
        fclose(f);
    }
    auto count = [&](const char* needle) {
        int n = 0;
        for (const char* p = text; (p = strstr(p, needle)) != nullptr; ++p) ++n;
        return n;
    };
    Check(count("ui call: focusIn(\"resumeBtn\", 3)") == 1, "log: callback method and decoded args");
    Check(count("ui set: resumeBtn.label = \"Resume Game\"") == 1, "log: widget.member = value, once (change-only)");
    Check(count("ui set: resumeBtn.label = \"Resume\"") == 1, "log: managed string decoded");
    Check(count("ui set: resumeBtn.text = ?") == 1, "log: bad pointer reported as ? without crashing");
    Check(count("ui label: _level0.spBtn = \"Single Player\"") == 1, "log: managed label read on focusIn");
    Check(count("ui label: _level0.plainBtn = \"Plain\"") == 1, "log: textField.text fallback");
    Check(count("ui label: _level0.nothing = (none)") == 1, "log: no label -> (none)");
    Check(count("ui label: ") == 3, "log: exactly three label lines");
    Check(count("ui invoke: _level0.strip.AddCell(\"Chapter One\", \"levels/one.dds\", \"campaign_1a\", \"1\", \"0.5\") -> \"ok\"") == 1,
          "log: invoke line with args and result");
    Check(count("ui invoke: _level0.strip.IsSelected() -> \"ok\"") == 1, "log: repeated invoke logged once");
    Check(count("ui invoke2: _level0.strip.addItem(\"Move Left\", 7)") == 1, "log: invoke2 line");
    Check(count("ui screen: ") == 3 && count("(movie not verified: not reported)") == 1,
          "log: three screen transitions, the foreign one marked");
    if (g_failures) printf("--- log ---\n%s\n", text);
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
