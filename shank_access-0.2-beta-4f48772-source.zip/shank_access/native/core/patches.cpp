#include "patches.h"

#include <windows.h>

#include <cstring>

#include "log.h"

namespace patches {
namespace {

// Overwrites `size` bytes at `addr` with `replacement`, only if they currently equal `expected`.
bool PatchBytes(const char* label, uintptr_t addr, const unsigned char* expected,
                const unsigned char* replacement, size_t size) {
    void* p = reinterpret_cast<void*>(addr);
    if (std::memcmp(p, expected, size) != 0) {
        alog::Write("patch %s at 0x%08x: original bytes differ; not patched", label, static_cast<unsigned>(addr));
        return false;
    }
    DWORD old = 0;
    if (!VirtualProtect(p, size, PAGE_EXECUTE_READWRITE, &old)) {
        alog::Write("patch %s: VirtualProtect failed (%lu)", label, GetLastError());
        return false;
    }
    std::memcpy(p, replacement, size);
    VirtualProtect(p, size, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, size);
    alog::Write("patch %s at 0x%08x: applied", label, static_cast<unsigned>(addr));
    return true;
}

}  // namespace

bool SkipLogoMovie() {
    // Intro screen activation (0x792c10): unless debug-settings byte +0x70 (a Klei developer skip
    // flag) is set, "mov edx, offset introscee.usm; call 0x54d410" (play video). NOP the call.
    // isPlaying() is then false, so the screen's update goes straight on to its next state.
    constexpr uintptr_t kAddr = 0x792c37;
    const unsigned char expected[] = {0xBA, 0xB8, 0x44, 0x83, 0x00, 0xE8, 0xCF, 0xA7, 0xDB, 0xFF};
    const unsigned char replacement[] = {0xBA, 0xB8, 0x44, 0x83, 0x00, 0x90, 0x90, 0x90, 0x90, 0x90};
    return PatchBytes("SkipLogoMovie", kAddr, expected, replacement, sizeof expected);
}

bool SkipIntroMovie() {
    // Intro screen update (0x792c50), state 0: "mov edx, offset introtomain.usm; call 0x54d410"
    // (play video). NOP the call: the state still advances to 1, isPlaying() then reports false,
    // and the screen moves on once booting has finished. See docs/RE-NOTES.md.
    constexpr uintptr_t kAddr = 0x792ced;
    const unsigned char expected[] = {0xBA, 0xC8, 0x44, 0x83, 0x00, 0xE8, 0x19, 0xA7, 0xDB, 0xFF};
    const unsigned char replacement[] = {0xBA, 0xC8, 0x44, 0x83, 0x00, 0x90, 0x90, 0x90, 0x90, 0x90};
    return PatchBytes("SkipIntroMovie", kAddr, expected, replacement, sizeof expected);
}

}  // namespace patches
