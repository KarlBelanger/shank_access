#pragma once
// B38-4 (the user, 2026-09-30: "The mod should also only save logs to the user's documents folder on exit if it has at
// least one mark."), B38-4c (2026-10-03: "Build the zip, make it save as shank-access-[timestamp].zip in
// shank-access\logs"): a release build (SHANK_ACCESS_RELEASE) saves a session that has an F2 mark as one zip,
// Documents\Shank Access\logs\shank-access-<yyyy-mm-dd_hh-mm-ss>.zip, at each mark (so a crash keeps it) and at exit:
// a11y.log, a11y_marks.log and the game's own non-empty *.log under game/. The newest kKeepSessions zips are kept.
#include <string>

namespace alog {

constexpr int kKeepSessions = 30;

// Writes (or rewrites) this session's zip from game_root's logs; %SHANK_ACCESS_LOG_DIR% instead of the Documents folder
// if set (tests: nothing pruned there). Returns the zip's path, or empty if it couldn't be written. Any thread.
// Only this session's marks go in (from the marks file's last "=== Session" header). final (at exit): once the zip is written,
// the game root's a11y_marks.log is deleted (B38-4d).
std::wstring SaveSession(const std::wstring& game_root, bool final = false);

}  // namespace alog
