-- Run by tools/loadtest50.py after loading any stategraph that loads the patched StateGraphUtil.lua (Lua 5.0), B13-4:
--   .venv/Scripts/python tools/loadtest50.py stategraphs/props/firetrap_stategraph.lua --check tests/lua/check_aim_rules.lua
-- A11Y_IsAiming on the real gunmen's state names and tags (goon medium attacks_gun / attacks_ak47, girl attacks_uzi,
-- large minigun / grenade launcher / shield shotgun, fat biker), and the states that must not count.
local gun = "stategraphs/goon/medium/states/attacks_gun.lua"
local cases = {
  {gun, "gun_idle", "branch aiming", true},
  {gun, "gun_up_idle", "branch aiming up", true},
  {"stategraphs/goon/medium/states/attacks_ak47.lua", "gun_idle_down", "aiming branch", true},
  {"stategraphs/goon/girl/states/attacks_uzi.lua", "shoot_pre", "", true},
  {"stategraphs/goon/large/states/attacks_minigun.lua", "minigun_pre", "attack branch laughing minigunrevup", true},
  {"stategraphs/goon/large/states/attacks_grenadelauncher.lua", "grenadelauncher_shoot_pre", "attack branch", true},
  {"stategraphs/goon/large/states/attacks_shield_shotgun.lua", "open_shoot_pre", "attack", true},
  {"stategraphs/goon/biker_fat/biker_fat_attacks.lua", "shotgun_atk_pre", "attack", true},
  {gun, "gun_attack", "attack shoot", false},             -- the shot itself (its wind-up report ends the aim)
  {"stategraphs/goon/medium/states/attacks_knife.lua", "knife_lungepre", "attack", false},
  {gun, "gun_block_pre", "block", false},
  {"stategraphs/shank/attacks_pistols.lua", "gun_idle", "branch aiming", false},  -- Shank's own
}
local bad = {}
for i = 1, table.getn(cases) do
  local c = cases[i]
  local got = A11Y_IsAiming({name = c[2], tags = c[3]}, c[1])
  if got ~= c[4] then table.insert(bad, c[2] .. " in " .. c[1] .. ": " .. tostring(got)) end
end
-- The shot still reports a wind-up (so the native side ends the aim there).
if A11Y_WindupKind({name = "gun_attack", tags = "attack shoot"}, gun) ~= "shot" then table.insert(bad, "gun_attack wind-up (B26: \"shot\")") end
print("  " .. table.getn(cases) .. " aim cases, " .. table.getn(bad) .. " wrong")
if table.getn(bad) > 0 then error("wrong: " .. table.concat(bad, "; ")) end
return true
