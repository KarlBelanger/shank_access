-- Run by tools/loadtest50.py after loading Toro's or the fake Butcher's stategraph (Lua 5.0), B23-4:
--   .venv/Scripts/python tools/loadtest50.py stategraphs/goon/boss_toro/toro_stategraph.lua --check tests/lua/check_boss_setups.lua
--   .venv/Scripts/python tools/loadtest50.py stategraphs/goon/boss_fakebutcher/fakebutcher_stategraph.lua --check tests/lua/check_boss_setups.lua
-- The charge states (charge_start_pre, charge_pre, charge) start with PlaySound("a11y/en_setup") and end with
-- PlaySound("a11y/en_setup_end"), keeping their own actions after ours; no other state reports either.
local want = { charge_start_pre = true, charge_pre = true, charge = true }
local function first_sound(list)
  if type(list) ~= "table" then return nil end
  local a = list[1]
  if type(a) == "table" and a.Type == "playsound" then return a.sound end
  return nil
end
local function has_sound(list, name)
  if type(list) ~= "table" then return false end
  for i = 1, table.getn(list) do
    local a = list[i]
    if type(a) == "table" and a.Type == "playsound" and a.sound == name then return true end
  end
  return false
end
local found, problems = {}, {}
for _, st in ipairs(StateGraph.States) do
  local s = has_sound(st.on_enter, "a11y/en_setup")
  local e = has_sound(st.on_exit, "a11y/en_setup_end")
  if want[st.name] then
    if first_sound(st.on_enter) ~= "a11y/en_setup" or first_sound(st.on_exit) ~= "a11y/en_setup_end" then
      table.insert(problems, st.name .. " lacks its setup reports")
    end
    if table.getn(st.on_enter) < 2 and st.name == "charge_start_pre" then
      table.insert(problems, "charge_start_pre lost its own on_enter actions")
    end
    table.insert(found, st.name)
  elseif s or e then
    table.insert(problems, st.name .. " reports a setup")
  end
end
print("  setup reports in " .. table.getn(found) .. " states: " .. table.concat(found, ", "))
if table.getn(found) ~= 3 then table.insert(problems, "expected the 3 charge states") end
-- B23-9: Cesar's blocks (his stategraph doesn't load in the harness: a stubbed damage constant at cesar_STATES.lua 908,
-- after the block states), so the rule is checked directly.
local cesar = "@C:/x/data-pc/stategraphs/goon/boss_cesar/cesar_STATES.lua"
for _, n in ipairs({ "block1", "block1_hit", "block2", "block2_hit" }) do
  if not A11Y_IsSetup({ name = n }, cesar) then table.insert(problems, "Cesar's " .. n .. " is not a setup") end
end
for _, n in ipairs({ "block1_pst", "idle", "charge" }) do
  if A11Y_IsSetup({ name = n }, cesar) then table.insert(problems, "Cesar's " .. n .. " is a setup") end
end
if A11Y_IsSetup({ name = "block1" }, "@C:/x/data/stategraphs/goon/medium/med_states.lua") then
  table.insert(problems, "a goon's block1 is a setup")
end
if table.getn(problems) > 0 then error(table.concat(problems, "; ")) end
return true
