// B52b offline tool (host only, not deployed): where along a run a jump reaches a traversal feature, for the Steam and the
// classic build's jumps side by side (jump_model::ClassicScale). For checking a jump-now chirp's window from a log.
//   reach_window.exe <shank_access_geometry.txt> <level> <x_from> <x_to> <y> [R|L]
// Prints, for every feature within 2000 px of the run, the x ranges (8 px steps, feet at y) from which the long jump and
// the standing jump reach it.
#include <windows.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "../core/jump_model.h"
#include "../core/level_geometry.h"
#include "../core/log.h"

namespace {

bool ToTarget(const level_geometry::Feature& f, jump_model::Target* t) {
    const auto& p = f.points;
    if (p.empty()) return false;
    const auto& q = p.size() > 1 ? p[1] : p[0];
    if (f.type == "swing_point") *t = jump_model::Target{jump_model::kSwing, p[0].first, p[0].second, 0, 0};
    else if (f.type == "pole" || f.type == "slide_pole") *t = jump_model::Target{jump_model::kPole, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "shimmy_line") *t = jump_model::Target{jump_model::kShimmy, p[0].first, p[0].second, q.first, q.second};
    else if (f.type == "wallrun_zone") *t = jump_model::Target{jump_model::kWallZone, p[0].first, p[0].second, q.first, q.second};
    else return false;
    if (f.type == "slide_pole") t->slide = true;
    return true;
}

std::string Ranges(const jump_model::Target& t, float x_from, float x_to, float y, bool right, bool long_jump) {
    std::string out;
    float start = 0;
    bool in = false;
    for (float x = x_from; x <= x_to + 0.1f; x += 8.f) {
        const bool ok = (long_jump ? jump_model::ReachLong(t, x, y, right) : jump_model::ReachStanding(t, x, y, right)) !=
                        jump_model::kNone;
        if (ok && !in) start = x;
        if (!ok && in) out += " " + std::to_string(static_cast<int>(start)) + ".." + std::to_string(static_cast<int>(x - 8));
        in = ok;
    }
    if (in) out += " " + std::to_string(static_cast<int>(start)) + ".." + std::to_string(static_cast<int>(x_to));
    return out.empty() ? " none" : out;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 6) {
        printf("usage: reach_window <geometry> <level> <x_from> <x_to> <y> [R|L]\n");
        return 2;
    }
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_reach_window.log");
    wchar_t wlog[MAX_PATH], wpath[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);
    MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wpath, MAX_PATH);
    if (level_geometry::Load(wpath) == 0 || !level_geometry::SetLevel(argv[2])) {
        printf("no level %s in %s\n", argv[2], argv[1]);
        return 1;
    }
    const float x_from = static_cast<float>(atof(argv[3])), x_to = static_cast<float>(atof(argv[4]));
    const float y = static_cast<float>(atof(argv[5]));
    const bool right = argc < 7 || argv[6][0] != 'L';
    jump_model::SetObstacles(&level_geometry::Obstacles());
    std::vector<jump_model::Target> swings;
    for (const auto& f : level_geometry::Features()) {
        jump_model::Target t;
        if (f.type == "swing_point" && ToTarget(f, &t)) swings.push_back(t);
    }
    jump_model::SetInterceptors(&swings);
    for (const auto& f : level_geometry::Features()) {
        jump_model::Target t;
        if (!ToTarget(f, &t)) continue;
        const float fx = (t.x1 + (t.kind == jump_model::kSwing ? t.x1 : t.x2)) / 2;
        if (fx < x_from - 2000 || fx > x_to + 2000) continue;
        printf("%s at (%.0f, %.0f)-(%.0f, %.0f):\n", f.type.c_str(), t.x1, t.y1, t.x2, t.y2);
        for (int b = 0; b < 2; ++b) {
            jump_model::SetBuildScale(b ? jump_model::ClassicScale() : jump_model::BuildScale());
            printf("  %-7s long:%s  standing:%s\n", b ? "classic" : "steam", Ranges(t, x_from, x_to, y, right, true).c_str(),
                   Ranges(t, x_from, x_to, y, right, false).c_str());
        }
    }
    return 0;
}
