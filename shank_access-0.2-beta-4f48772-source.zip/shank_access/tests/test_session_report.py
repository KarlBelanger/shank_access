"""Tests for tools/session_report.py (B42-3) on a synthetic session folder.

Run: .venv/Scripts/python -m unittest discover -s tests -v
"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
import session_report  # noqa: E402

LOG = """[12:00:00.000] shank_access abc starting (thread 1)
[12:00:01.000] level: LoadSimData(1234) -> 1, name campaign_1c_meatpacking
[12:00:05.000] hotkey: Q (Next move)
[12:00:05.000] say (stats): long jump to wall run, 8 tiles right. 2 moves to Enter Packing Warehouse
[12:00:06.000] waypoint: s5 -> f18 (2 moves), next checkpoint Enter Packing Warehouse
[12:00:08.000] cues: jump now reaches Wall run at (3500, 3977) (long jump)
[12:00:08.100] sound at: Shank/Character/jumpFromGround pos=(3050, 3936) listener=(3050, 3936) half=(1600, 900) pan=0.00
[12:00:09.000] cues: too high for Wall run (the jump reached up to y 1746; he's at 1813)
[12:00:09.200] sound at: Shank/Character/Voices/Shank/Shank_Death pos=(3831, 3324) listener=(3831, 3324) half=(1600, 900) pan=0.00
[12:00:09.210] sound at: Shank/Character/Voices/Shank/Shank_Death pos=(3831, 3324) listener=(3831, 3324) half=(1600, 900) pan=0.00
[12:00:20.000] waypoint: s0 -> w10 (11 moves), next checkpoint Enter Packing Warehouse
[12:00:30.000] exit: handing over to the game's ExitProcess
"""
MARKS = """
=== Session 2026-09-30 08:00:00 ===
MARK 1 at 08:00:01.000: an older session
MARK 1 comment: not this one

=== Session 2026-10-01 12:00:03 ===
MARK 1 at 12:00:04.000: level campaign_1c_meatpacking; Shank at (3050, 3936)
MARK 1 comment: this one
"""


class ReportTest(unittest.TestCase):
    def test_report(self):
        with tempfile.TemporaryDirectory() as d:
            folder = os.path.join(d, "20261001-120000-test")
            os.makedirs(folder)
            with open(os.path.join(folder, "a11y.log"), "w", encoding="utf-8") as f:
                f.write(LOG)
            with open(os.path.join(folder, "a11y_marks.log"), "w", encoding="utf-8") as f:
                f.write(MARKS)
            text = session_report.report(folder, check=False)
        self.assertIn("Marks (2):", text)  # this session's mark and its comment, not the older one
        self.assertIn("this one", text)
        self.assertNotIn("an older session", text)
        self.assertIn("Deaths (1):", text)  # the death voice twice: one death
        self.assertIn("campaign_1c_meatpacking at (3831, 3324); last Q: long jump to wall run", text)
        self.assertIn("jump now reaches Wall run at (3500, 3977) (long jump)", text)
        self.assertIn("jumpFromGround pos=(3050, 3936)", text)
        self.assertIn("Too high (1):", text)
        self.assertIn("1 death(s)", text)  # while f18 was the waypoint target


if __name__ == "__main__":
    unittest.main()
