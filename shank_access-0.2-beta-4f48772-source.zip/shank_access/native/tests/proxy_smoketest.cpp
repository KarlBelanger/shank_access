// Host-side smoke test for the dinput8 proxy (never deployed). Loads build/native/out/dinput8.dll,
// creates a real IDirectInput8W through it, and checks that shank_access.dll was loaded and
// wrote its log. Because this test exe is not Shank.exe, the mod must report an exe mismatch
// and stay disabled. Exit code 0 = pass.
#include <windows.h>
#include <unknwn.h>

#include <cstdio>
#include <cstring>
#include <string>

// IID_IDirectInput8W {BF798031-483A-4DA2-AA99-5D64ED369700}
static const GUID kIID_IDirectInput8W = {0xBF798031, 0x483A, 0x4DA2, {0xAA, 0x99, 0x5D, 0x64, 0xED, 0x36, 0x97, 0x00}};

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) {
        fwprintf(stderr, L"usage: proxy_smoketest <dir containing dinput8.dll and shank_access.dll>\n");
        return 2;
    }
    const std::wstring dir = argv[1];
    HMODULE proxy = LoadLibraryW((dir + L"\\dinput8.dll").c_str());
    if (!proxy) { wprintf(L"FAIL: cannot load proxy (%lu)\n", GetLastError()); return 1; }

    using CreateFn = HRESULT(WINAPI*)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
    auto create = reinterpret_cast<CreateFn>(GetProcAddress(proxy, "DirectInput8Create"));
    if (!create) { wprintf(L"FAIL: DirectInput8Create not exported\n"); return 1; }

    IUnknown* di = nullptr;
    HRESULT hr = create(GetModuleHandleW(nullptr), 0x0800, kIID_IDirectInput8W, reinterpret_cast<void**>(&di), nullptr);
    if (FAILED(hr) || !di) { wprintf(L"FAIL: DirectInput8Create hr=0x%08lx\n", static_cast<unsigned long>(hr)); return 1; }
    di->Release();
    wprintf(L"ok: DirectInput8Create forwarded, got IDirectInput8W\n");

    // The mod may be loaded either by the proxy's loader thread or by the call above.
    for (int i = 0; i < 50 && !GetModuleHandleW(L"shank_access.dll"); ++i) Sleep(20);
    if (!GetModuleHandleW(L"shank_access.dll")) { wprintf(L"FAIL: shank_access.dll not loaded\n"); return 1; }
    wprintf(L"ok: shank_access.dll loaded\n");

    // The log must be readable while the mod still has it open (live checks during play).
    // The mod writes it to the parent of the exe's folder: <dir>\..\a11y.log.
    const std::wstring log_path = dir + L"\\..\\a11y.log";
    char text[2048] = {};
    DWORD got = 0;
    for (int i = 0; i < 50 && !strstr(text, "starting"); ++i) {
        HANDLE f = CreateFileW(log_path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                               OPEN_EXISTING, 0, nullptr);
        if (f == INVALID_HANDLE_VALUE) {
            if (GetLastError() == ERROR_SHARING_VIOLATION) { wprintf(L"FAIL: a11y.log is locked while in use\n"); return 1; }
            Sleep(20);
            continue;
        }
        ReadFile(f, text, sizeof text - 1, &got, nullptr);
        text[got] = 0;
        CloseHandle(f);
        if (!strstr(text, "starting")) Sleep(20);
    }
    if (!strstr(text, "starting")) { wprintf(L"FAIL: a11y.log not readable or empty\n"); return 1; }
    wprintf(L"ok: a11y.log readable while open\n");
    return 0;
}
