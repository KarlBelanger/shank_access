// Host-side test of the B8 enemy reader (never deployed): a fake item manager and items laid out as in the
// game (RE-NOTES "Game items and the enemy list"), found by the vtable scan and read each tick; names and
// descriptions. With a path argument it also loads the real character names from the install. Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <vector>

#include "../core/enemies.h"
#include "../core/log.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

// Fake memory: a map of 4-byte words at fake addresses.
std::map<uintptr_t, uint32_t> g_mem;
void Put(uintptr_t a, uint32_t v) { g_mem[a] = v; }
void PutF(uintptr_t a, float f) {
    uint32_t v;
    std::memcpy(&v, &f, 4);
    Put(a, v);
}
bool FakeRead(uintptr_t addr, void* out, size_t n) {
    unsigned char* o = static_cast<unsigned char*>(out);
    for (size_t i = 0; i < n; ++i) {
        const uintptr_t w = (addr + i) & ~uintptr_t(3);
        const auto it = g_mem.find(w);
        if (it == g_mem.end()) {
            if (addr + i < 0x100000) return false;  // unmapped low memory faults
            o[i] = 0;
            continue;
        }
        o[i] = static_cast<unsigned char>(it->second >> (8 * ((addr + i) & 3)));
    }
    return true;
}
std::vector<uintptr_t> FakeScan(uint32_t value) {
    std::vector<uintptr_t> out;
    for (const auto& kv : g_mem) {
        if (kv.second == value) out.push_back(kv.first);
    }
    return out;
}

// An item at `at` with its physics component at at + 0x1000.
void MakeItem(uintptr_t at, uint32_t vt, uint32_t team, const char* name, float x, float y, bool dead = false) {
    Put(at, vt);
    Put(at + enemies::kTeam, team);
    Put(at + enemies::kAttrHash, enemies::Hash(name));
    Put(at + enemies::kPhysics, static_cast<uint32_t>(at + 0x1000));
    PutF(at + 0x1000 + enemies::kPhysicsPos, x);
    PutF(at + 0x1000 + enemies::kPhysicsPos + 4, y);
    if (dead) {
        Put(at + enemies::kLife, static_cast<uint32_t>(at + 0x2000));
        Put(at + 0x2000 + enemies::kLifeFlag, 1);
    } else {
        Put(at + enemies::kLife, 0);
    }
}

position::Pos Shank(float x, float y) {
    position::Pos p;
    p.known = p.live = true;
    p.x = x;
    p.y = y;
    return p;
}

}  // namespace

int main(int argc, char** argv) {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_enemies_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    // Names and kinds.
    Check(enemies::Hash("noFall") == 0xb476217c, "hash = the engine's (sdbm, lowercased)");
    Check(enemies::ClassOf("med_thug_knifepistol") == enemies::kMedium, "medium");
    Check(enemies::ClassOf("large_biker_charger") == enemies::kLarge && enemies::ClassOf("class_lrg_ram") == enemies::kLarge, "large");
    Check(enemies::ClassOf("girl_viper_uzi") == enemies::kGirl && enemies::ClassOf("dog_black_teeth") == enemies::kDog, "girl, dog");
    Check(enemies::IsNonCombatant("boss_mello") && !enemies::IsNonCombatant("boss_gimp"), "B36b-1: Mello (no attack states) is no enemy");
    Check(enemies::ClassOf("boss_butcher") == enemies::kBoss && enemies::ClassOf("helicopter") == enemies::kOther, "boss, other");
    Check(enemies::Describe("med_thug_knifepistol") == "knife and pistol goon", "describe: knife and pistol goon");
    Check(enemies::Describe("large_biker_charger") == "charger big goon", "describe: charger big goon");
    Check(enemies::Describe("large_biker_ram") == "rammer big goon", "describe: rammer");
    Check(enemies::Describe("girl_viper_bo") == "girl with staff", "describe: girl with staff");
    Check(enemies::Describe("girl_viper_uzi") == "girl with uzi", "describe: girl with uzi");
    Check(enemies::Describe("dog_black_teeth") == "dog", "describe: dog");
    Check(enemies::Describe("boss_butcher") == "boss butcher", "describe: boss");
    Check(enemies::Describe("class_lrg_shieldshotgun") == "shield and shotgun big goon", "describe: shield and shotgun");

    // A fake manager with 5 items: Shank, two goons, a dead goon, and a prop-like item of unknown kind.
    for (const char* n : {"shank", "med_thug_knifepistol", "large_biker_charger", "med_biker_pistol"}) enemies::AddName(n);
    enemies::SetMemory(FakeRead, FakeScan);
    const uintptr_t mgr = 0x200000, vec = 0x210000;
    Put(mgr, enemies::kManagerVtable);
    Put(mgr + enemies::kItemsFirst, static_cast<uint32_t>(vec));
    Put(mgr + enemies::kItemsLast, static_cast<uint32_t>(vec + 5 * 4));
    const uintptr_t items[5] = {0x300000, 0x310000, 0x320000, 0x330000, 0x340000};
    for (int i = 0; i < 5; ++i) Put(vec + 4 * i, static_cast<uint32_t>(items[i]));
    MakeItem(items[0], enemies::kShankItemVtable, 0, "shank", 1000, 224);
    MakeItem(items[1], enemies::kShankItemVtable, 1, "med_thug_knifepistol", 1400, 224);
    MakeItem(items[2], enemies::kShankItemVtable, 1, "large_biker_charger", 600, 480);
    MakeItem(items[3], enemies::kShankItemVtable, 1, "med_biker_pistol", 1200, 224, true);
    MakeItem(items[4], enemies::kGameItemVtable, 2, "explosive_barrel", 1100, 224);
    // A decoy "manager" (the vtable value inside some other data) with a nonsense vector.
    Put(0x250000, enemies::kManagerVtable);
    Put(0x250000 + enemies::kItemsFirst, 0x10);
    Put(0x250000 + enemies::kItemsLast, 0x8);

    enemies::Update(1000, position::Pos());
    Check(enemies::Current().empty(), "Shank not tracked yet: no scan, no enemies");
    enemies::Update(1100, Shank(1000, 224));
    std::vector<enemies::Enemy> e = enemies::Current();
    Check(e.size() == 2, "the manager found; two live enemies (not Shank, not the dead one, not the prop)");
    bool knife = false, charger = false;
    for (const auto& en : e) {
        knife = knife || (en.name == "med_thug_knifepistol" && en.x == 1400 && en.cls == enemies::kMedium);
        charger = charger || (en.name == "large_biker_charger" && en.y == 480 && en.cls == enemies::kLarge);
    }
    Check(knife && charger, "names, classes, positions");
    // They move; one dies.
    PutF(items[1] + 0x1000 + enemies::kPhysicsPos, 1300);
    Put(items[2] + enemies::kLife, static_cast<uint32_t>(items[2] + 0x2000));
    Put(items[2] + 0x2000 + enemies::kLifeFlag, 1);
    enemies::Update(1200, Shank(1000, 224));
    e = enemies::Current();
    Check(e.size() == 1 && e[0].x == 1300, "positions follow; the killed one drops out");
    // The manager goes away (level unload): nothing, and a new scan later.
    Put(mgr, 0);
    enemies::Update(1300, Shank(1000, 224));
    Check(enemies::Current().empty(), "the manager's vtable gone: no enemies");
    Put(mgr, enemies::kManagerVtable);
    enemies::Update(2000, Shank(1000, 224));
    Check(enemies::Current().empty(), "no rescan before 3 s");
    enemies::Update(4400, Shank(1000, 224));
    Check(enemies::Current().size() == 1, "rescanned after 3 s: found again");
    enemies::OnLevel();
    Check(enemies::Current().empty(), "a level load forgets them");

    if (argc > 1) {
        wchar_t wdir[MAX_PATH];
        MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wdir, MAX_PATH);
        const size_t n = enemies::LoadNames(std::wstring(wdir) + L"\\data\\attributes\\characters");
        Check(n > 100, "real install: character names loaded");
    }
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
