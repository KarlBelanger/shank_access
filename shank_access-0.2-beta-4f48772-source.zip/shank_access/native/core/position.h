#pragma once
// B4 G5: Shank's position every tick, without Lua firing often in his stategraph (B3: frequent reports
// hampered his movement). The Lua ping (every 0.5 s, exact floats from the sim sound event) is the
// reference. When Shank stands still (two pings at the same spot), the cue thread scans the game's
// writable memory for that (x, y) float pair; later pings keep only the addresses that follow him
// (within kFollowPx) and have moved with him at least once. The survivor is read every tick. Every
// ping re-checks it; a level load or a mismatch forgets it and the scan starts again. B28: every read is also
// checked between pings (where he can be since the last ping, how fast he can move), and an address that fails
// is dropped and never picked again in that level.
#include <cstdint>
#include <functional>
#include <vector>

namespace position {

constexpr float kFollowPx = 64.f;     // a candidate may lag the ping by about a frame of running...
constexpr float kFollowSeconds = 0.08f;  // ...plus this much of his current speed (fast falls)
constexpr float kMovedPx = 96.f;      // "moved with him": his ping moved at least this far since the scan
constexpr int kConfirmMoves = 2;      // pings after movement a candidate must follow to be trusted
constexpr size_t kMaxCandidates = 4096;
constexpr unsigned kPingStaleMs = 5000;  // no ping this long (left the level, a cutscene): position unknown
// B28: checks between pings (the B27play log: an address that held his position only at ping time).
constexpr float kMaxSpeedPxPerS = 5000.f;  // faster than he ever moves (falls ~2300 px/s; B28b: dash attacks, grab snaps)
constexpr float kCheckSlackPx = 96.f;      // a read may be this far from where he could be (lag, rounding)
constexpr size_t kStrikesToDrop = 3;       // implausible reads within kStrikeWindowMs drop the address
constexpr unsigned kBanMs = 15000;         // B28b: a dropped address isn't picked again for this long (B28: the whole level)
constexpr unsigned kStrikeWindowMs = 1000;
constexpr float kSoundCheckPx = 224.f;     // one of his own game sounds this far from the read: a mismatch (good sessions: <= 160)
constexpr size_t kSoundMismatchesToDrop = 2;  // ...this many within kSoundWindowMs drop the address
constexpr unsigned kSoundWindowMs = 3000;

// The Lua ping (game thread): Shank's position and facing.
void OnPing(float x, float y, bool facing_right, unsigned now_ms);

// A level has loaded: the tracked address is gone.
void OnLevel();

// Cue thread, every tick: checks the candidates between pings (B28) and starts a pending scan. B28-3: the real scan
// runs on its own thread (Work returns at once); with SetMemory's test scan it runs inline.
void Work(unsigned now_ms);
bool Scanning();  // a background scan is still running

// B28: a game sound only Shank makes (blocking, skid stop, wall climb, shimmy, ledge climb; the engine plays it at his
// position). Not "step": other characters' steps use the same event (the B27 logs: 106 of 107 steps near a known
// position of his were elsewhere). Checks the tracked address and the candidates against it.
bool IsShankOnlySound(const char* name);
void OnShankSound(float x, float y, unsigned now_ms);

struct Pos {
    bool known = false;   // any position at all (a ping has arrived)
    bool live = false;    // read from the tracked address this call (else: the last ping)
    float x = 0, y = 0;
    bool facing_right = true;       // from his movement when clearly moving, else the ping
    bool ping_facing_right = true;  // the game's own facing (the last ping): while swinging his speed flips
    float vx = 0;         // px/s, smoothed, from live reads
    float vy = 0;         // px/s, smoothed, from live reads
};
Pos Current(unsigned now_ms);

// For tests: replace the memory access. read: copy n bytes at addr (false on a fault). scan: every
// address holding the float pair (x, y) (at most kMaxCandidates).
using ReadFn = std::function<bool(uintptr_t addr, void* out, size_t n)>;
using ScanFn = std::function<std::vector<uintptr_t>(float x, float y)>;
void SetMemory(ReadFn read, ScanFn scan);
void Reset();

// Diagnostics.
size_t CandidateCount();
uintptr_t TrackedAddress();

}  // namespace position
