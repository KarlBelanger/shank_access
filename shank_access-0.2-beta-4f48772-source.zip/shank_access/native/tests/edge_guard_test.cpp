// Host-side test of the B7 safe-edges guard (never deployed): its decisions from the level geometry and
// Shank's movement, and the HasTag_ParseNode::Evaluate hook on a stand-in with the game's convention
// (thiscall(node, ctx) -> 0/1, ret 4). Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <cstring>

#include "../core/edge_guard.h"
#include "../core/level_geometry.h"
#include "../core/log.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

position::Pos At(float x, float y, bool right, float vx, float vy = 0) {
    position::Pos p;
    p.known = p.live = true;
    p.x = x;
    p.y = y;
    p.facing_right = p.ping_facing_right = right;
    p.vx = vx;
    p.vy = vy;
    return p;
}

// Runs the guard for ms milliseconds (15 ms ticks) with Shank at x moving at vx; returns the last answer.
unsigned g_now = 1000;
bool Hold(float x, bool right, float vx, unsigned ms, float y = 224) {
    for (unsigned t = 0; t < ms; t += 15) {
        g_now += 15;
        edge_guard::Update(g_now, At(x, y, right, vx));
    }
    return edge_guard::Active();
}

unsigned g_stand_in_result = 0;
__declspec(noinline) unsigned __fastcall FakeEvaluate(void* node, void*, void* ctx) {
    volatile unsigned r = g_stand_in_result;
    if (node == ctx) r = 7;  // never (keeps the function long enough to hook)
    return r;
}

}  // namespace

int main() {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_edge_guard_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    // A floor 0..1000 at y 192 ending in nothing (deadly); a ledge 2000..3000 whose right end drops 64 px
    // (a step he hops) onto a floor 3000..4000.
    level_geometry::LoadFromString(
        "[g]\n"
        "surface 0 - wall 64 0 drop -1 1 2 0 192 1000 192\n"
        "surface 1 - wall 64 0 drop 64 0 2 2000 192 3000 192\n"
        "surface 2 - step 64 0 wall 64 0 2 3000 128 4000 128\n");
    level_geometry::SetLevel("g");

    Check(!Hold(900, true, 300, 100), "off: never active");
    edge_guard::SetEnabled(true);
    Check(!Hold(500, true, 300, 100), "on, 500 px from the edge: not yet");
    Check(Hold(900, true, 300, 60), "on, 100 px from a deadly edge, running at it: active");
    Check(Hold(960, true, -96, 60), "the game hops him back: still active");
    Check(Hold(950, true, 0, 60), "at rest a moment: still active");
    Check(Hold(950, true, 0, 200), "at rest 200 ms: still active (armed)");
    Check(!Hold(955, true, 200, 30), "another tap toward the edge: let go");
    Check(!Hold(990, true, 200, 60), "still let go while he goes over");
    Check(!Hold(500, false, -300, 60), "walked away (500 px): not active");
    Check(Hold(900, true, 300, 60), "back at the edge: guarded again");
    // Running at the edge without a stop and rest first: no let-go (a held key just bounces).
    Check(Hold(980, true, 250, 200), "held toward the edge without stopping: stays active");
    // Small drop: not guarded.
    edge_guard::Reset();
    Check(!Hold(2900, true, 300, 100), "a 64 px drop (a step): not guarded");
    // In the air: not guarded.
    Check(!Hold(900, true, 300, 100, 600), "in the air: not guarded");
    edge_guard::SetEnabled(false);
    Check(!Hold(900, true, 300, 100), "off again: not active");

    // The hook: answers yes for (ground, nofall) only while active.
    Check(edge_guard::InstallAt(static_cast<unsigned>(reinterpret_cast<uintptr_t>(&FakeEvaluate))), "hook installed");
    unsigned char node[0x30] = {};
    auto set = [&](unsigned tag, unsigned source, unsigned char nott) {
        std::memcpy(node + edge_guard::kNodeTag, &tag, 4);
        std::memcpy(node + edge_guard::kNodeSource, &source, 4);
        node[edge_guard::kNodeNott] = nott;
    };
    unsigned char ctx[8] = {};
    // Call through a pointer, as the game does (a direct call may be optimised past the hooked bytes).
    unsigned(__fastcall* volatile evaluate)(void*, void*, void*) = &FakeEvaluate;
    set(edge_guard::kHashNoFall, edge_guard::kHashGround, 0);
    Check(evaluate(node, nullptr, ctx) == 0, "inactive: the game's answer (no)");
    edge_guard::SetEnabled(true);
    Hold(900, true, 300, 60);
    Check(edge_guard::Active(), "(guard active)");
    Check(evaluate(node, nullptr, ctx) == 1, "active: (ground, nofall) answers yes");
    set(edge_guard::kHashNoFall, edge_guard::kHashGround, 1);
    Check(evaluate(node, nullptr, ctx) == 0, "active, but GroundLacksTag (nott): unchanged");
    set(0x1234, edge_guard::kHashGround, 0);
    Check(evaluate(node, nullptr, ctx) == 0, "active, another tag: unchanged");
    set(edge_guard::kHashNoFall, 0x5678, 0);
    Check(evaluate(node, nullptr, ctx) == 0, "active, another source: unchanged");
    g_stand_in_result = 1;
    set(0x1234, edge_guard::kHashGround, 0);
    Check(evaluate(node, nullptr, ctx) == 1, "the game's own yes is kept");
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
