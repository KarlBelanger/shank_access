#include "patches.h"

#include <windows.h>

#include <cstring>

#include "game.h"
#include "log.h"

namespace patches {
namespace {

// Overwrites `size` bytes at `addr` with `replacement`, only if they currently equal `expected`.
bool PatchBytes(const char* label, uintptr_t addr, const unsigned char* expected,
                const unsigned char* replacement, size_t size) {
    void* p = reinterpret_cast<void*>(addr);
    if (std::memcmp(p, expected, size) != 0) {
        alog::Write("patch %s at 0x%08x: original bytes differ; not patched", label, static_cast<unsigned>(addr));
        return false;
    }
    DWORD old = 0;
    if (!VirtualProtect(p, size, PAGE_EXECUTE_READWRITE, &old)) {
        alog::Write("patch %s: VirtualProtect failed (%lu)", label, GetLastError());
        return false;
    }
    std::memcpy(p, replacement, size);
    VirtualProtect(p, size, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, size);
    alog::Write("patch %s at 0x%08x: applied", label, static_cast<unsigned>(addr));
    return true;
}

}  // namespace

bool SkipLogoMovie() {
    // Intro screen activation (0x792c10; classic 0x790010): unless a debug-settings byte (a Klei developer skip flag) is
    // set, "mov edx, offset introscee.usm; call <play video>". NOP the call. isPlaying() is then false, so the screen's
    // update goes straight on to its next state.
    const game::Addresses& a = game::A();
    unsigned char replacement[10];
    std::memcpy(replacement, a.logo_movie_bytes, 5);
    std::memset(replacement + 5, 0x90, 5);
    return PatchBytes("SkipLogoMovie", a.logo_movie_at, a.logo_movie_bytes, replacement, sizeof replacement);
}

bool SkipIntroMovie() {
    // Intro screen update (0x792c50; classic 0x790050), state 0: "mov edx, offset introtomain.usm; call <play video>".
    // NOP the call: the state still advances to 1, isPlaying() then reports false, and the screen moves on once booting
    // has finished. See docs/RE-NOTES.md.
    const game::Addresses& a = game::A();
    unsigned char replacement[10];
    std::memcpy(replacement, a.intro_movie_bytes, 5);
    std::memset(replacement + 5, 0x90, 5);
    return PatchBytes("SkipIntroMovie", a.intro_movie_at, a.intro_movie_bytes, replacement, sizeof replacement);
}

}  // namespace patches
