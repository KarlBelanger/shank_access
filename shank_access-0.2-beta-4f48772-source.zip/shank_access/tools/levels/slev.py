"""Decoder for Shank's level collision files (`data-pc/levels/<name>/<name>.slev`, "LVEL" version 7).

Format (from LevelData::LoadSimData 0x495e40 and the readers it calls; docs/RE-NOTES.md "Level collision"):
  header      "LVEL", u32 version (<= 7), u32 A (level+0x6c), u32 B (level+0x70)
  segments    u32 n; each: f32 x1, y1, x2, y2; u8 flag; u32 ntags; u32 tags[ntags]   (0x563f10, added to the
              collision world by 0x503e70; linked afterwards by 0x503fb0)
  movie       string (length-prefixed), f32 x4                                          (0x496290)
  points      u32 n; each f32 x, y                                                      (0x4963f0 -> 0x5058d0)
  boxes       u32 n; each f32 x1, y1, x2, y2 (two corners; min/max taken)              (0x4963f0)
  paths       u32 n; each: u32 count; (count - 1) x (f32 x, y; u32 ntags; u32 tags[]); f32 end x, y
                                                                                        (0x503a90 -> 0x51ab80)
  regions x2  PropertyRegion containers (0x5669b0): u32 version 1, then batches [u32 count; count x region] until
              a count of 0. region (0x566410 peeks the type): u32 type (0 LerpRegion, 1 ConstantRegion,
              2 LerpGroupRegion), i32 x1, y1, x2, y2; then type 0: 4 property sets, 1: 1 property set,
              2: u32 n + n regions. Property set: u32 n; n x (u32 key hash, u32 value type: 1 u8 bool,
              2 f32, 3 u32, 4 string). (Camera/lighting-style settings by area; not traversal.)
  moving      u32 count of moving platforms (0x497240; animation, "Bar" / "One Way", "Ping-Pong"/"Once"/"Loop").
              0 in every level file (2026-09-26), so their record layout isn't decoded.
  The file ends there (every level checked).

Tags are sdbm hashes of lowercase names (RE-NOTES). Coordinates are pixels, y up, 64 px = 1 tile. A segment's
solid side is on the right of its direction (floors run left to right, ceilings right to left, a wall going up
faces left, going down faces right).
"""
import struct
import sys

TAG_NAMES = ["noclimb", "skinny", "nosplat", "throwfg", "throwbg", "slipperyright", "slipperyleft", "bg", "mg",
             "nofall", "slide"]


def sdbm(text):
    h = 0
    for c in text.lower().encode():
        h = (c + (h << 6) + (h << 16) - h) & 0xFFFFFFFF
    return h


TAGS = {sdbm(n): n for n in TAG_NAMES}


def tag_name(h):
    return TAGS.get(h, "0x%08x" % h)


class Reader:
    def __init__(self, data):
        self.d = data
        self.o = 0

    def u8(self):
        v = self.d[self.o]
        self.o += 1
        return v

    def u32(self):
        v = struct.unpack_from("<I", self.d, self.o)[0]
        self.o += 4
        return v

    def f32(self, n=1):
        v = struct.unpack_from("<%df" % n, self.d, self.o)
        self.o += 4 * n
        return v if n > 1 else v[0]

    def tags(self):
        n = self.u32()
        if n > 64:
            raise ValueError("implausible tag count %d at 0x%x" % (n, self.o - 4))
        return [tag_name(self.u32()) for _ in range(n)]

    def string(self):
        n = self.u8()  # one byte in every file seen (the reader is 0x43dc30)
        s = self.d[self.o:self.o + n].decode("latin-1")
        self.o += n
        return s


def kind(x1, y1, x2, y2):
    if y1 == y2:
        return "floor" if x2 > x1 else "ceiling"
    if x1 == x2:
        return "wall_facing_left" if y2 > y1 else "wall_facing_right"
    # Slopes: the outward normal is on the left of the direction; up-facing = walkable.
    nx, ny = -(y2 - y1), (x2 - x1)
    return "slope" if ny > 0 else "overhang"


def decode(data):
    r = Reader(data)
    magic = r.d[:4]
    r.o = 4
    if magic != b"LVEL":
        raise ValueError("not an LVEL file")
    out = {"version": r.u32(), "a": r.u32(), "b": r.u32()}
    segs = []
    for _ in range(r.u32()):
        x1, y1, x2, y2 = r.f32(4)
        flag = r.u8()
        segs.append({"p1": [x1, y1], "p2": [x2, y2], "flag": flag, "tags": r.tags(), "kind": kind(x1, y1, x2, y2)})
    out["segments"] = segs
    out["movie"] = {"name": r.string(), "params": list(r.f32(4))}
    out["points"] = [list(r.f32(2)) for _ in range(r.u32())]
    boxes = []
    for _ in range(r.u32()):
        x1, y1, x2, y2 = r.f32(4)
        boxes.append({"min": [min(x1, x2), min(y1, y2)], "max": [max(x1, x2), max(y1, y2)]})
    out["boxes"] = boxes
    paths = []
    for _ in range(r.u32()):
        nodes = []
        for _ in range(r.u32() - 1):  # the count includes the end point (0x51ae50 sizes the list to count - 1)
            x, y = r.f32(2)
            nodes.append({"p": [x, y], "tags": r.tags()})
        end = list(r.f32(2))
        paths.append({"nodes": nodes, "end": end})
    out["paths"] = paths
    out["regions"] = [region for _ in range(2) for region in _container(r)]
    out["moving_platforms"] = r.u32()
    if out["moving_platforms"]:
        raise NotImplementedError("moving platforms present: their layout isn't decoded (0x497240)")
    if r.o != len(r.d):
        raise ValueError("%d bytes left after the moving platforms" % (len(r.d) - r.o))
    return out


def _propset(r):
    props = {}
    n = r.u32()
    if n > 500:
        raise ValueError("implausible property count %d at 0x%x" % (n, r.o - 4))
    for _ in range(n):
        key, kind_ = r.u32(), r.u32()
        if kind_ == 1:
            value = bool(r.u8())
        elif kind_ == 2:
            value = r.f32()
        elif kind_ == 3:
            value = r.u32()
        elif kind_ == 4:
            value = r.string()
        else:
            raise ValueError("property value type %d at 0x%x" % (kind_, r.o - 4))
        props["0x%08x" % key] = value
    return props


def _region(r):
    kind_ = r.u32()
    rect = list(struct.unpack_from("<4i", r.d, r.o))
    r.o += 16
    out = {"type": ["lerp", "constant", "group"][kind_] if kind_ < 3 else kind_, "rect": rect}
    if kind_ == 0:
        out["properties"] = [_propset(r) for _ in range(4)]
    elif kind_ == 1:
        out["properties"] = [_propset(r)]
    elif kind_ == 2:
        out["children"] = [_region(r) for _ in range(r.u32())]
    else:
        raise ValueError("region type %d at 0x%x" % (kind_, r.o - 20))
    return out


def _container(r):
    version = r.u32()
    if version != 1:
        raise ValueError("region container version %d at 0x%x" % (version, r.o - 4))
    regions = []
    while True:
        n = r.u32()
        if n == 0:
            return regions
        regions.extend(_region(r) for _ in range(n))


def main(argv):
    import json
    d = decode(open(argv[1], "rb").read())
    if len(argv) > 2 and argv[2] == "--json":
        print(json.dumps(d, indent=1))
        return
    print("version", d["version"], "a", d["a"], "b", d["b"], "segments", len(d["segments"]), "movie", d["movie"])
    print("points", d["points"])
    print("boxes", d["boxes"])
    print("paths", len(d["paths"]))
    for p in d["paths"]:
        print("  ", [(n["p"], n["tags"]) for n in p["nodes"]], "end", p["end"])
    print("regions", len(d["regions"]), "moving platforms", d["moving_platforms"])


if __name__ == "__main__":
    main(sys.argv)
