-- Load-test harness for game scripts under the real Lua 5.0 interpreter (lua50.exe).
-- Emulates the engine's LoadFile() over the game's data roots, with an overlay of patched
-- files, so a patched stategraph can be executed exactly as the game would load it.
--
-- Usage: lua50 loadtest.lua <overlay_map_file> <entry> [<root> ...]
--   overlay_map_file: lines "lowercase/game/relative/path.lua<TAB>C:/abs/patched/file.lua"
--   entry:            game-relative path under data/ (e.g. stategraphs/shank/shank_stategraph.lua)
--   roots:            directories searched in order (e.g. <game>/data <game>/data-pc)
-- Unknown globals that get *called* are stubbed and reported (engine functions, or typos).

local overlay_file = arg[1]
local entry = arg[2]
local roots = {}
for i = 3, table.getn(arg) do table.insert(roots, arg[i]) end

local overlay = {}
local f = io.open(overlay_file, "r")
if f then
  for line in f:lines() do
    local _, _, key, path = string.find(line, "^([^\t]+)\t(.+)$")
    if key then overlay[key] = path end
  end
  f:close()
end

local loaded_count = 0
local function resolve(p)
  local key = string.lower(string.gsub(p, "\\", "/"))
  if overlay[key] then return overlay[key], true end
  for _, root in ipairs(roots) do
    local path = root .. "/" .. p
    local h = io.open(path, "r")
    if h then h:close() return path, false end
  end
  return nil
end

function LoadFile(p)
  local path, patched = resolve(p)
  if not path then error("LoadFile: not found: " .. tostring(p), 2) end
  local chunk, err = loadfile(path)
  if not chunk then error("LoadFile: " .. err, 2) end
  loaded_count = loaded_count + 1
  if patched then print("  [patched] " .. p) end
  chunk()
end

function Print(s) end

-- Report calls to undefined globals instead of dying, so engine-provided functions don't stop the test.
local stubbed = {}
setmetatable(getfenv(0), { __index = function(t, k)
  if type(k) == "string" and string.find(k, "^[A-Z]") and not stubbed[k] then
    stubbed[k] = true
  end
  if stubbed[k] then return function() return {} end end
  return nil
end })

local ok, err = pcall(LoadFile, entry)
print("files loaded: " .. loaded_count)
local names = {}
for k in pairs(stubbed) do table.insert(names, k) end
table.sort(names)
print("stubbed globals: " .. (table.getn(names) > 0 and table.concat(names, ", ") or "none"))
if not ok then
  print("LOAD FAILED: " .. tostring(err))
  os.exit(1)
end

-- Optional check script: CHECK global set via an extra file named by env LOADTEST_CHECK.
local check = os.getenv("LOADTEST_CHECK")
if check and check ~= "" then
  local chunk, cerr = loadfile(check)
  if not chunk then print("CHECK LOAD FAILED: " .. cerr) os.exit(1) end
  local cok, cres = pcall(chunk)
  if not cok or cres == false then print("CHECK FAILED: " .. tostring(cres)) os.exit(1) end
  print("check passed")
end
print("LOAD OK")
