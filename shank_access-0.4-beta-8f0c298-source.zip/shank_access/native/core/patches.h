#pragma once
// Small in-memory code patches to Shank.exe (never on disk). Each one checks the exact original
// bytes first and does nothing if they differ.
namespace patches {

// First testing artifacts (user instruction, 2026-09-24); B18 tied them to test mode; since B70 (the user, 2026-10-19) the
// player's own setting, F7 > Cheats > Skip startup movies ([startup] skip_movies), applied at the game's start.

// Skips the FIRST startup movie (introscee.usm): the unskippable logo sequence with its own music.
bool SkipLogoMovie();

// Skips the SECOND startup movie (introtomain.usm), which is skippable anyway.
bool SkipIntroMovie();

}  // namespace patches
