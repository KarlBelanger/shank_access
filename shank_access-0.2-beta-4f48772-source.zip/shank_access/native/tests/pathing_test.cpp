// Host-side test of the B10 path finder (never deployed): a small graph, and with a path argument the real
// build/levels/shank_access_paths.txt (1-c's opening climb, as tools/levels/path_check.py finds it). Exit 0 = pass.
#include <windows.h>

#include <cstdio>
#include <string>

#include "../core/log.h"
#include "../core/pathing.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

}  // namespace

int main(int argc, char** argv) {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_pathing_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    pathing::LoadFromString(
        "[t]\n"
        "edge s0 w1 run_up_wall 100 32 R\n"
        "edge w1 f2 run_up_jump 90 300 L\n"
        "edge f2 s3 swing_jump 50 400 L\n"
        "edge s0 s3 long_jump 10 32 L\n"   // a direct jump: one move instead of three
        "edge s3 s4 climb 0 500 L\n"
        "edge s0 p5R long_jump 200 32 R\n"
        "edge p5R p5L bounce 280 600 R\n");
    Check(pathing::SetLevel("levels/t/t.slev"), "level chosen by the game's path");
    auto p = pathing::Path("s0", {"s4"});
    Check(p.size() == 2 && p[0].move == "long_jump" && p[1].move == "climb", "fewest jumps (on foot counts half)");
    p = pathing::Path("s0", {"f2"});
    Check(p.size() == 2 && p[0].to == "w1" && p[1].to == "f2", "through the wall to the swing point");
    p = pathing::Path("s0", {"p5L"});
    Check(p.size() == 2 && p[1].move == "bounce", "a pole's other side via the bounce");
    Check(pathing::Path("s3", {"s0"}).empty(), "no way back: empty");
    Check(pathing::Path("s0", {"s0"}).empty(), "already there: empty");
    Check(pathing::MoveName("run_up_wall") == "run up the wall", "move names");
    // B46: a walk-off that works at one speed only (its v window) costs as a one-spot jump: two plain jumps win over it.
    pathing::LoadFromString(
        "[u]\n"
        "edge s0 s9 walk_off 100 32 R 100 100 32 32 v 704 768 3\n"
        "edge s0 s1 long_jump 100 32 R 100 300 32 32\n"
        "edge s1 s9 long_jump 400 32 R 400 600 32 32\n"
        "edge s0 s8 walk_off 100 32 R 100 100 32 32 v 96 768 22\n");
    Check(pathing::SetLevel("u"), "B46 level");
    p = pathing::Path("s0", {"s9"});
    Check(p.size() == 2 && p[0].move == "long_jump", "B46: a one-speed walk-off (a full sprint only) loses to two jumps");
    p = pathing::Path("s0", {"s8"});
    Check(p.size() == 1 && p[0].v_n == 22 && !pathing::OneSpeedWalkOff(p[0]), "B46: a walk-off at any speed: one cheap move");
    pathing::LoadFromString("[u]\nedge s0 s9 walk_off 100 32 R 100 100 32 32 v 704 768 3\n");
    pathing::SetLevel("u");
    p = pathing::Path("s0", {"s9"});
    Check(p.size() == 1 && pathing::OneSpeedWalkOff(p[0]) && p[0].v_lo == 704.f, "B46: the window parsed");

    if (argc > 1) {
        wchar_t wpath[MAX_PATH];
        MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wpath, MAX_PATH);
        Check(pathing::Load(wpath) >= 10, "real file: every level");
        Check(pathing::SetLevel("campaign_1c_meatpacking"), "real file: 1-c");
        p = pathing::Path("s0", {"f10", "p10L", "p10R", "s9"});
        for (const auto& s : p) printf("  %s -> %s (%s)\n", s.from.c_str(), s.to.c_str(), s.move.c_str());
        // (since B27: the long jump from s4 reaches the pole's right side; the pole jump left goes through the pole
        // from either side, B10b)
        // (B44g: 12 steps since the stricter wall-run and pole catches: the floor above s4 first)
        bool pole_early = false;
        for (size_t k = 3; k < p.size() && k < 6; ++k) pole_early = pole_early || p[k].to == "p30L" || p[k].to == "p30R";
        Check(p.size() >= 11 && p.size() <= 12 && p[0].move == "run_up_wall" && p[1].to == "f11" && p[2].to == "f12" && pole_early,
              "1-c: the opening climb (the end wall, swing 1, swing 2, ..., the pole's left side, ...)");
        // B41-1 (mark 5): walking off s43 lands on the slope s59 (not 38 tiles down on s45, through it).
        p = pathing::Path("s43", {"s45"});
        Check(p.empty() || p[0].to != "s45", "B41-1: no fall from s43 through the slope to s45");
        p = pathing::Path("s43", {"s59"});
        Check(p.size() == 1 && p[0].move == "walk_off", "B41-1: walking off s43 lands on the slope");
        // B41-3 (mark 3): from the shimmy line f29 down to s15 is a drop, not a jump.
        p = pathing::Path("f29", {"s15"});
        Check(p.size() == 1 && p[0].move == "drop", "B41-3: shimmy line f29 to the floor below: drop");
        // B41-6 (mark 1): from s42 (Cold Storage 2) the way on starts right (walking off left lands in the meat grinder).
        p = pathing::Path("s42", {"s45", "s46", "s47"});
        Check(!p.empty() && p[0].to == "s43" && p[0].right, "B41-6: from Cold Storage 2 the route starts right, not into the grinder");
        // B41c: the first slope before the Butcher needs the jump; the second slides off onto the third (the user).
        p = pathing::Path("s51", {"s61"});
        Check(p.size() == 2 && p[0].move == "long_jump" && p[1].move == "slide_off", "B41c: s51 long jump, s60 slide off");
        // B41c: off the wall run f16 to the shimmy line f21 by the wall w108 (not the one-spot long jump from its end).
        p = pathing::Path("f16", {"f21"});
        // (B42b: the run-up jump launches as the wall jump, so the graph may name it either)
        Check(p.size() == 2 && p[0].to == "w108" && (p[1].move == "run_up_jump" || p[1].move == "wall_jump"),
              "B41c: wall run, wall w108, then the shimmy line");
        // B47c-1 (sessions 1-2: "walked into swing point without jumping"): off s39's end onto the swing point: run off.
        p = pathing::Path("s39", {"f7"});
        Check(p.size() == 1 && p[0].move == "run_off", "B47c-1: 1-c s39 -> swing point f7: run off the edge, no jump");
        Check(pathing::SetLevel("campaign_4a_winecellar"), "real file: 4-a");
        p = pathing::Path("s30", {"f7"});
        Check(p.size() == 1 && p[0].move == "run_off", "B47c-1: 4-a s30 -> swing point f7: run off the edge");
        // B47c-6 (mark 6): off s58's end into the climbable wall w67 2 tiles across: on foot.
        p = pathing::Path("s58", {"w67"});
        Check(p.size() == 1 && p[0].move == "run_across", "B47c-6: 4-a s58 -> wall w67: run across the gap");
        // B47c-2 (mark 3): s47 -> the pole p24L works at 672..768 only: one speed now (4 samples)
        p = pathing::Path("s47", {"p24L"});
        Check(!p.empty() && (p[0].move != "walk_off" || pathing::OneSpeedWalkOff(p[0])), "B47c-2: 4-a s47 -> p24L: not a plain walk-off");
    }
    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
