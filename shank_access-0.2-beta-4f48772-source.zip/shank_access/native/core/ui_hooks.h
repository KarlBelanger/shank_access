#pragma once
// Scaleform UI hooks (docs/RE-NOTES.md "UI (Scaleform GFx 3.x, CLIK)").
//   - SwfExternalInterface::Callback (0x5534d0): every Flash -> game call (focus, clicks, ...).
//     Logged as  ui call: <method>(<args>)
//   - SwfSymbol::SetVariableInternal (0x559a50): every game -> Flash member set (text, labels,
//     HUD values). Logged as  ui set: <widget>.<member> = <value>  (only when the value changes).
//   - 1c-3: on focusIn("<path>"), reads <path>.label (or <path>.textField.text) through the movie's
//     GetVariable (vtable +0x44) and logs  ui label: <path> = <value>
//   - SwfSymbol::InvokeV (0x559b50): every game -> Flash method call (2-3: the level select film
//     strip). Logged as  ui invoke: <widget>.<method>(<args>) -> "<result>"
//   - Phase 2: UI events (focus, navigate, value changes, invokes) go to an event listener (menu_reader),
//     which can read Flash values with ReadValue().
// The game behaves exactly as before: the hooks only read.
#include <string>
#include <vector>

namespace ui_hooks {

// Hooks the game's functions after checking their first bytes. Returns false (and logs why) on failure.
bool Install();

// Hooks the given addresses without the byte check (used by native/tests/ui_hook_test.cpp).
// object_release = ObjectInterface::ObjectRelease (thiscall(iface; GFxValue*, data), ret 8).
// invoke = SwfSymbol::InvokeV (thiscall(symbol; method, fmt, va_list) -> const char*, ret 0xc).
// update = SwfScreen::Update (thiscall(screen; float dt), ret 4; state at +0x3c, movie at +0x38).
// invoke_internal = SwfSymbol::InvokeMethodInternal (ecx = symbol, edi = method; result, args, argc
// on the stack; ret 0xc). Its calls are reported as kInvoke too (result "", before the call).
bool InstallAt(unsigned callback, unsigned set_variable, unsigned object_release, unsigned invoke, unsigned update,
               unsigned invoke_internal);

// A Flash value read by path.
struct FlashValue {
    enum Kind { kNone, kBool, kNumber, kText, kOther } kind = kNone;  // kNone: failed/undefined/null
    bool b = false;
    double n = 0;
    std::string text;  // UTF-8
};

// Reads a Flash variable by full path ("_level0.musicSlider.value") with the movie's GetVariable.
// Game UI thread only (call it from the event listener). Never throws; faults give kNone.
FlashValue ReadValue(void* movie, const char* path);

struct UiEvent {
    enum Type {
        kFocusIn,     // focusIn("<path>"), before the game handles it
        kNavigate,    // navigate("<path>"), after the game handles it (path = the newly focused widget)
        kFocusedSet,  // the game set <path>.focused = true (how the Settings dialog sets its first focus)
        kChange,      // change / stepperChange / click / select("<path>"), after the game handles it;
                      // value = the second argument if there is one (a list's new row index)
        kValueSet,    // the game is writing <widget>.text or <widget>.value: path = "<widget>.<member>",
                      // value = the new value (the write hasn't landed yet); movie = the widget's
                      // movie for comparison only (may be nullptr; don't read through it)
        kInvoke,      // the game called a Flash method on a widget (SwfSymbol::InvokeV), after it
                      // returned: path = the widget, method, args, result; symbol = the widget;
                      // movie = the widget's movie, for comparison only (don't read through it)
        kScreenShown,   // a screen started opening / is open (SwfScreen state 1 or 2); movie = its movie
        kScreenHidden,  // a screen started closing / closed (state 3 or 0); movie = its movie
                        // (both from SwfScreen::Update, only for movies with the callbacks' vtable;
                        // path = "screen")
        kScreenTick,    // each of the next frames (up to kScreenTickFrames) after kScreenShown, while
                        // the screen stays shown: a chance to ask it for its focus (QueryFocus)
        kFrame,         // every SwfScreen::Update call (several per frame): a clock for delayed
                        // announcements; movie may be nullptr
    };
    Type type;
    void* movie;
    const char* path;
    const char* method;               // the Flash method name; "focused" / the member for sets
    const FlashValue* value = nullptr;  // kValueSet only
    void* symbol = nullptr;                              // kInvoke only
    const std::vector<std::string>* args = nullptr;      // kInvoke only: the formatted arguments
    const char* result = nullptr;                        // kInvoke only: the method's result text
};

// True if a screen's Update ran with this movie within `within_ms`. Movies can be destroyed (the
// main menu's when a level loads) without ever reporting "hidden"; never read through a stored
// movie pointer unless it is alive (2-5b-3 crash).
bool MovieAlive(void* movie, unsigned within_ms = 250);

constexpr int kScreenTickFrames = 20;

// Asks a movie which widget has the focus: Invoke "Selection.getFocus" (movie vtable +0x5c), else
// GetVariable "_global.gfx.managers.FocusHandler._instance.currentFocus._target" ("/a/b" is turned
// into "_level0.a.b"). "" if neither answers. Game UI thread only; the movie must be alive.
std::string QueryFocus(void* movie);

// Calls a no-argument Flash method on a widget (as the game does, e.g. "GetSelectedIndex") and
// returns its result text. Game UI thread only; "" if the hook isn't installed or it faults.
std::string InvokeMethod(void* symbol, const char* method);

// Called on the game's UI thread. Must be quick: the game waits for it. Set before Install().
using EventListener = void (*)(const UiEvent& event);
void SetEventListener(EventListener listener);

}  // namespace ui_hooks
