"""B50: writes mod/patches-classic/ (the Steam classic branch's script patches; run from the repo root after any change to
a shared Steam patch or to tools/make_windup_patch.py).

The classic build's scripts differ (docs/CLASSIC-ASSESSMENT.md): 16 of the Steam patches apply unchanged and are copied
(SHARED); the rest can't apply, because classic Shank has no REACTIONS lists and its pickups no
pickup_common_actions.lua. Their reports are added instead from State() in stategraphutil.lua, which every stategraph
calls for each of its states:
  - every state of Shank's (stategraphs/shank/, but not nis.lua or death.lua) gets the Steam build's reports at the end
    of its transitions: the position ping, the turn reports and the Up / Down / forward / back reports. They are
    never inside a CompoundTransition, so the carried weapons' drop wrappers can't run with them (the Steam build's
    B15-4 problem; classic needs no carryweapon patches);
  - every pickup (stategraphs/props/<kind>pickup_stategraph.lua) gets the beacon and "in reach" reports in its idle
    state and "a11y/got_<kind>" in its "collected" event.
The helpers are built on first use inside State() (when the game's condition and action helpers are loaded), not
when stategraphutil.lua itself loads. Lua 5.0. Lua text with a backslash is built with chr(92) (CLAUDE.md).
"""
import json
import os
import shutil

STEAM = os.path.join("mod", "patches", "data")
CLASSIC = os.path.join("mod", "patches-classic", "data")
NL, TAB, BS = chr(10), chr(9), chr(92)

# Steam patches whose anchors are the same in the classic scripts (checked 2026-10-07 by applying them).
SHARED = [
    "commonpresentation.lua",
    "stategraphs/props/barrel_stategraph.lua",
    "stategraphs/props/breaking_ceiling_stategraph.lua",
    "stategraphs/props/doorbreakopen_stategraph.lua",
    "stategraphs/props/explosive_barrel_stategraph.lua",
    "stategraphs/props/firetrap_stategraph.lua",
    "stategraphs/props/flashbang_stategraph.lua",
    "stategraphs/props/grenade_jeep_stategraph.lua",
    "stategraphs/props/grenade_projectile_stategraph.lua",
    "stategraphs/props/grenade_timed_stategraph.lua",
    "stategraphs/props/guidedmissile_stategraph.lua",
    "stategraphs/props/meatslab_stategraph.lua",
    "stategraphs/props/propane_tank_stategraph.lua",
    "stategraphs/props/rocket_stategraph.lua",
    "stategraphs/props/rockfall_stategraph.lua",
]


def report(name, cond, counter, value, sound):
    return (TAB + "A11Y_" + name + " = NullTransition(" + cond + "," + NL + TAB + TAB + "{ SetCounter(\"" + counter + "\", " +
            str(value) + "), PlaySound(\"a11y/" + sound + "\") })")


FUNC = NL.join([
    "-- shank-access B50 (the classic build): the reports the Steam build's patches put in Shank's REACTIONS lists and in",
    "-- pickup_common_actions.lua, added to each state here instead (tools/make_classic_patches.py). Sound names are",
    "-- messages: a11y/ sounds never reach FMOD. Each report fires rarely and disarms itself in its own actions (B3c: a",
    "-- firing transition makes the game re-check the list).",
    "function A11Y_MakeShankReports()",
    TAB + "-- the position and facing twice a second (4-2)",
    TAB + "A11Y_POS_PING = NullTransition(CountdownExpired(\"a11yPos\"),",
    TAB + TAB + "{ SetCountdown(\"a11yPos\", 0.5), IfAction(CheckBool(\"facing\"), { PlaySound(\"a11y/pos_r\") }, { PlaySound(\"a11y/pos_l\") }) })",
    TAB + "-- a turn (B19-2): 1 = right, 2 = left, 0 = not reported yet (ValCmp has no \"ne\")",
    report("TURN_R", "And(CheckBool(\"facing\"), Or(ValCmp(\"CNT:a11yFacing\", \"lt\", 1), ValCmp(\"CNT:a11yFacing\", \"gt\", 1)))",
           "a11yFacing", 1, "turn_r"),
    report("TURN_L", "And(CheckBool(\"facing\", false), ValCmp(\"CNT:a11yFacing\", \"lt\", 2))", "a11yFacing", 2, "turn_l"),
    TAB + "-- Up / Down (B44-1) and forward / back (B44e) held or let go",
    report("UP_ON", "And(ControlIsDown(CONTROL_UP), ValCmp(\"CNT:a11yUp\", \"lt\", 1))", "a11yUp", 1, "up_on"),
    report("UP_OFF", "And(ControlIsUp(CONTROL_UP), ValCmp(\"CNT:a11yUp\", \"gt\", 0))", "a11yUp", 0, "up_off"),
    report("DOWN_ON", "And(ControlIsDown(CONTROL_DOWN), ValCmp(\"CNT:a11yDown\", \"lt\", 1))", "a11yDown", 1, "down_on"),
    report("DOWN_OFF", "And(ControlIsUp(CONTROL_DOWN), ValCmp(\"CNT:a11yDown\", \"gt\", 0))", "a11yDown", 0, "down_off"),
    report("FWD_ON", "And(ControlIsDown(CONTROL_FORWARD), ValCmp(\"CNT:a11yFwd\", \"lt\", 1))", "a11yFwd", 1, "fwd_on"),
    report("FWD_OFF", "And(ControlIsUp(CONTROL_FORWARD), ValCmp(\"CNT:a11yFwd\", \"gt\", 0))", "a11yFwd", 0, "fwd_off"),
    report("BACK_ON", "And(ControlIsDown(CONTROL_BACK), ValCmp(\"CNT:a11yBack\", \"lt\", 1))", "a11yBack", 1, "back_on"),
    report("BACK_OFF", "And(ControlIsUp(CONTROL_BACK), ValCmp(\"CNT:a11yBack\", \"gt\", 0))", "a11yBack", 0, "back_off"),
    TAB + "A11Y_SHANK_REPORTS = { A11Y_FWD_ON, A11Y_FWD_OFF, A11Y_BACK_ON, A11Y_BACK_OFF, A11Y_UP_ON, A11Y_UP_OFF, A11Y_DOWN_ON,",
    TAB + TAB + "A11Y_DOWN_OFF, A11Y_TURN_R, A11Y_TURN_L, A11Y_POS_PING }",
    "end",
    "",
    "-- the pickup beacon (every 0.5 s while the player is within about a screen, once it has landed: B13-5) and \"in reach\"",
    "-- (the game's own prompt range, every 0.25 s) (4-4). The probes only run when a report is due; every child resets its",
    "-- countdown in its own actions.",
    "-- B55-6 (the user: \"The catana pickup never sounded in the underworld\"): only health and grenades wait to land (an",
    "-- enemy's drop falls: B13-5); a weapon is placed by the level, and 4-a's katana (PlaceOnGround = false) never \"lands\".",
    "function A11Y_Landed(kind, cond)",
    TAB + "if kind == \"health\" or kind == \"grenades\" then return And(CheckBool(\"onground\"), cond) end",
    TAB + "return cond",
    "end",
    "",
    "function A11Y_PickupReports(kind)",
    TAB + "return {",
    TAB + TAB + "CompoundTransition(CountdownExpired(\"a11yPickupBeacon\"), nil,",
    TAB + TAB + "{",
    TAB + TAB + TAB + "NullTransition(A11Y_Landed(kind, Probe{offset={0,0}, size={3200, 1800}, characters=true, ownteam=true, otherteam=true, condition=HasAttributeTag(\"player\")}),",
    TAB + TAB + TAB + TAB + "{ SetCountdown(\"a11yPickupBeacon\", 0.5), PlaySound(\"a11y/beacon_\" .. kind) }),",
    TAB + TAB + TAB + "NullTransition(CountdownExpired(\"a11yPickupBeacon\"), { SetCountdown(\"a11yPickupBeacon\", 0.1) }),",
    TAB + TAB + "}),",
    TAB + TAB + "CompoundTransition(CountdownExpired(\"a11yPickupInReach\"), nil,",
    TAB + TAB + "{",
    TAB + TAB + TAB + "-- B55-5: classic Shank collects with Probe{offset={100,0}, size={300,64}} from himself (shank_transitions'",
    TAB + TAB + TAB + "-- PICKUPS): up to 250 px ahead of him, 50 behind. From the pickup: he faces it within 250, or is within 50.",
    TAB + TAB + TAB + "NullTransition(A11Y_Landed(kind, Or(",
    TAB + TAB + TAB + TAB + "Probe{offset={0,0}, size={500, 64}, characters=true, ownteam=true, otherteam=true, facingme=true, condition=HasAttributeTag(\"player\")},",
    TAB + TAB + TAB + TAB + "Probe{offset={0,0}, size={100, 64}, characters=true, ownteam=true, otherteam=true, condition=HasAttributeTag(\"player\")})),",
    TAB + TAB + TAB + TAB + "{ SetCountdown(\"a11yPickupInReach\", 0.25), PlaySound(\"a11y/inreach_\" .. kind) }),",
    TAB + TAB + TAB + "NullTransition(CountdownExpired(\"a11yPickupInReach\"), { SetCountdown(\"a11yPickupInReach\", 0.25) }),",
    TAB + TAB + "}),",
    TAB + "}",
    "end",
    "",
    "-- a copy of list (or an empty table) with extra's items after it",
    "function A11Y_Joined(list, extra)",
    TAB + "local out = {}",
    TAB + "if type(list) == \"table\" then",
    TAB + TAB + "for i = 1, table.getn(list) do table.insert(out, list[i]) end",
    TAB + "end",
    TAB + "for i = 1, table.getn(extra) do table.insert(out, extra[i]) end",
    TAB + "return out",
    "end",
    "",
    "-- a copy of an action list with PlaySound(\"a11y/prompt_pickup\") before its fx_press_x_start (unchanged if none)",
    "function A11Y_TagPickupPrompt(list)",
    TAB + "if type(list) ~= \"table\" then return list end",
    TAB + "local out, tagged = {}, false",
    TAB + "for i = 1, table.getn(list) do",
    TAB + TAB + "local a = list[i]",
    TAB + TAB + "if type(a) == \"table\" and a.name == \"fx_press_x_start\" then",
    TAB + TAB + TAB + "table.insert(out, PlaySound(\"a11y/prompt_pickup\"))",
    TAB + TAB + TAB + "tagged = true",
    TAB + TAB + "end",
    TAB + TAB + "table.insert(out, a)",
    TAB + "end",
    TAB + "if tagged then return out end",
    TAB + "return list",
    "end",
    "",
    "function A11Y_ClassicState(args, src)",
    TAB + "if type(src) ~= \"string\" or string.len(src) > 260 then return end  -- a file name, not source text",
    TAB + "src = string.gsub(string.lower(src), \"" + BS + BS + "\", \"/\")  -- the engine's chunk names may use backslashes",
    TAB + "if string.find(src, \"stategraphs/shank/\", 1, true) then",
    TAB + TAB + "if string.find(src, \"/nis.lua\", 1, true) or string.find(src, \"/death.lua\", 1, true) then return end",
    TAB + TAB + "if type(A11Y_SHANK_REPORTS) ~= \"table\" then A11Y_MakeShankReports() end",
    TAB + TAB + "args.transitions = A11Y_Joined(args.transitions, A11Y_SHANK_REPORTS)",
    TAB + TAB + "return",
    TAB + "end",
    TAB + "local _, _, kind = string.find(src, \"stategraphs/props/([a-z]+)pickup_stategraph%.lua\")",
    TAB + "if not kind then return end",
    TAB + "if kind == \"grenade\" then kind = \"grenades\" end  -- (the Steam build's name for it)",
    TAB + "if args.name == \"idle\" then args.transitions = A11Y_Joined(args.transitions, A11Y_PickupReports(kind)) end",
    TAB + "-- B50b: classic pickups show the game's \"press X\" indicator (fx_press_x_start) when they appear, which the mod",
    TAB + "-- would read as a grapple's mash prompt: a11y/prompt_pickup just before it tells the mod to skip that one",
    TAB + "args.on_enter = A11Y_TagPickupPrompt(args.on_enter)",
    TAB + "args.on_new_enter = A11Y_TagPickupPrompt(args.on_new_enter)",
    TAB + "if type(args.events) == \"table\" then",
    TAB + TAB + "for i = 1, table.getn(args.events) do",
    TAB + TAB + TAB + "local e = args.events[i]",
    TAB + TAB + TAB + "if type(e) == \"table\" and e.event == \"collected\" then",
    TAB + TAB + TAB + TAB + "-- 3-2: what was picked up (from the pickup's position)",
    TAB + TAB + TAB + TAB + "e.actions = A11Y_Joined(e.actions, { PlaySound(\"a11y/got_\" .. kind) })",
    TAB + TAB + TAB + "end",
    TAB + TAB + "end",
    TAB + "end",
    "end",
    "",
    "",
])

CALL = NL.join([
    "",
    TAB + "-- shank-access B50 (classic): Shank's reports and the pickups' (tools/make_classic_patches.py)",
    TAB + "A11Y_ClassicState(args, info.source)",
])


def main():
    if os.path.isdir(os.path.join("mod", "patches-classic", "data")):
        shutil.rmtree(os.path.join("mod", "patches-classic", "data"))
    for rel in SHARED:
        dst = os.path.join(CLASSIC, *rel.split("/")) + ".patch.json"
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(os.path.join(STEAM, *rel.split("/")) + ".patch.json", dst)
    util = json.load(open(os.path.join(STEAM, "stategraphs", "stategraphutil.lua.patch.json"), encoding="utf-8"))
    util["ops"].append({"op": "insert_before", "anchor": "function State( args )", "text": FUNC})
    util["ops"].append({"op": "insert_after", "anchor": "args.source_file_line = info.currentline", "text": CALL})
    dst = os.path.join(CLASSIC, "stategraphs", "stategraphutil.lua.patch.json")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, "w", encoding="utf-8", newline=NL) as f:
        json.dump(util, f, indent=1)
        f.write(NL)
    print("wrote %d shared patches and the classic stategraphutil.lua patch to mod/patches-classic" % len(SHARED))


if __name__ == "__main__":
    main()
