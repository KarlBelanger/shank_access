#include "ui_hooks.h"

#include <windows.h>

#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>

#include "MinHook.h"
#include "log.h"
#include "mod_state.h"

namespace ui_hooks {
namespace {

// ---- Reading game data safely -------------------------------------------------------------
// These run on game threads with pointers we don't own, so every read is SEH-guarded: a bad
// pointer produces "?" in the log instead of crashing the game. No C++ objects in these
// functions (required for __try).

// GFx 3.x GFxValue (16 bytes): +0 interface, +4 type (bit 0x40 = managed), +8 value.
constexpr unsigned kGFxValueSize = 16;

void FormatValue(const unsigned char* v, char* buf, size_t n) {
    __try {
        const unsigned type = *reinterpret_cast<const unsigned*>(v + 4);
        const bool managed = (type & 0x40) != 0;
        switch (type & 0x0f) {
        case 0: _snprintf_s(buf, n, _TRUNCATE, "undefined"); break;
        case 1: _snprintf_s(buf, n, _TRUNCATE, "null"); break;
        case 2: _snprintf_s(buf, n, _TRUNCATE, "%s", v[8] ? "true" : "false"); break;
        case 3: _snprintf_s(buf, n, _TRUNCATE, "%g", *reinterpret_cast<const double*>(v + 8)); break;
        case 4: {
            const char* s = managed ? **reinterpret_cast<const char* const* const*>(v + 8)
                                    : *reinterpret_cast<const char* const*>(v + 8);
            _snprintf_s(buf, n, _TRUNCATE, "\"%s\"", s ? s : "");
            break;
        }
        case 5: {
            const wchar_t* s = managed ? **reinterpret_cast<const wchar_t* const* const*>(v + 8)
                                       : *reinterpret_cast<const wchar_t* const*>(v + 8);
            _snprintf_s(buf, n, _TRUNCATE, "L\"%ls\"", s ? s : L"");
            break;
        }
        case 6: _snprintf_s(buf, n, _TRUNCATE, "[object]"); break;
        case 7: _snprintf_s(buf, n, _TRUNCATE, "[array]"); break;
        case 8: _snprintf_s(buf, n, _TRUNCATE, "[displayobject]"); break;
        default: _snprintf_s(buf, n, _TRUNCATE, "[type 0x%x]", type); break;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        _snprintf_s(buf, n, _TRUNCATE, "?");
    }
}

void CopyCString(const char* s, char* buf, size_t n) {
    __try {
        _snprintf_s(buf, n, _TRUNCATE, "%s", s ? s : "(null)");
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        _snprintf_s(buf, n, _TRUNCATE, "?");
    }
}

// MSVC std::string as used by the game: capacity at +0x18; >= 16 means heap pointer at +4,
// otherwise the characters are inline at +4 (see 0x402d50).
void ReadStdString(const unsigned char* str, char* buf, size_t n) {
    __try {
        const unsigned cap = *reinterpret_cast<const unsigned*>(str + 0x18);
        const char* p = cap >= 16 ? *reinterpret_cast<const char* const*>(str + 4)
                                  : reinterpret_cast<const char*>(str + 4);
        _snprintf_s(buf, n, _TRUNCATE, "%s", p);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        _snprintf_s(buf, n, _TRUNCATE, "?");
    }
}

// ---- Logging budget and change detection ---------------------------------------------------
constexpr int kMaxPerSecond = 60;
SRWLOCK g_lock = SRWLOCK_INIT;
DWORD g_window_start = 0;
int g_in_window = 0;
int g_dropped = 0;
std::map<std::string, std::string> g_last_values;  // "widget.member" -> last logged value

bool Budget() {  // call with g_lock held
    if (!mod_state::Active()) return false;  // B38-3: nothing logged while the mod is off
    const DWORD now = GetTickCount();
    if (now - g_window_start >= 1000) {
        if (g_dropped) alog::Write("ui: (%d lines dropped by the rate limit)", g_dropped);
        g_window_start = now;
        g_in_window = 0;
        g_dropped = 0;
    }
    if (g_in_window >= kMaxPerSecond) {
        ++g_dropped;
        return false;
    }
    ++g_in_window;
    return true;
}

// ---- Reading Flash values by path (1c-3) ----------------------------------------------------
// GFxMovie vtable +0x44 = GetVariable(GFxValue* out, const char* path), thiscall, returns al.
// ObjectInterface::ObjectRelease(GFxValue*, void* data) at 0x5c7620 (thiscall, ret 8) releases a
// managed value (type bit 0x40). See docs/RE-NOTES.md "1c-3 static notes".
constexpr unsigned kGetVariableSlot = 0x44 / 4;
using GetVariableFn = bool(__fastcall*)(void* movie, void* edx, unsigned char* out, const char* path);
using ObjectReleaseFn = void(__fastcall*)(void* iface, void* edx, unsigned char* value, void* data);
ObjectReleaseFn g_object_release = nullptr;

// Returns false if GetVariable failed or faulted. out must be 16 bytes; it's reset to undefined first
// (GetVariable assigns into it, which would release a stale managed value).
bool SafeGetVariable(void* movie, const char* path, unsigned char* out) {
    std::memset(out, 0, kGFxValueSize);
    __try {
        const auto fn = reinterpret_cast<GetVariableFn>((*reinterpret_cast<void** const*>(movie))[kGetVariableSlot]);
        return fn(movie, nullptr, out, path);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        std::memset(out, 0, kGFxValueSize);
        return false;
    }
}

void SafeRelease(unsigned char* value) {
    __try {
        if ((*reinterpret_cast<unsigned*>(value + 4) & 0x40) && g_object_release) {
            g_object_release(*reinterpret_cast<void**>(value), nullptr, value,
                             *reinterpret_cast<void**>(value + 8));
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
    std::memset(value, 0, kGFxValueSize);
}

// Copies a string GFxValue's characters as UTF-8 (no quotes); wide strings are converted.
// False if it isn't a non-empty string or a read faults.
bool ReadTextValue(const unsigned char* v, char* buf, size_t n) {
    __try {
        const unsigned type = *reinterpret_cast<const unsigned*>(v + 4);
        const bool managed = (type & 0x40) != 0;
        if ((type & 0x0f) == 4) {
            const char* s = managed ? **reinterpret_cast<const char* const* const*>(v + 8)
                                    : *reinterpret_cast<const char* const*>(v + 8);
            if (!s || !*s) return false;
            _snprintf_s(buf, n, _TRUNCATE, "%s", s);
            return true;
        }
        if ((type & 0x0f) == 5) {
            const wchar_t* s = managed ? **reinterpret_cast<const wchar_t* const* const*>(v + 8)
                                       : *reinterpret_cast<const wchar_t* const*>(v + 8);
            if (!s || !*s) return false;
            const int len = WideCharToMultiByte(CP_UTF8, 0, s, -1, buf, static_cast<int>(n), nullptr, nullptr);
            if (len <= 0) buf[0] = '\0';
            return len > 1;
        }
        return false;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Reads a GFxValue's type, and its bool (as 0/1) or number. False if the read faults.
bool ReadTypeAndNumber(const unsigned char* v, unsigned* type, double* number) {
    __try {
        *type = *reinterpret_cast<const unsigned*>(v + 4);
        if ((*type & 0x0f) == 2) *number = v[8] ? 1.0 : 0.0;
        else if ((*type & 0x0f) == 3) *number = *reinterpret_cast<const double*>(v + 8);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

FlashValue DecodeValue(const unsigned char* value) {
    FlashValue out;
    char buf[512] = {};
    unsigned type = 0;
    double number = 0;
    if (!ReadTypeAndNumber(value, &type, &number)) return out;
    switch (type & 0x0f) {
    case 2: out.kind = FlashValue::kBool; out.b = number != 0; break;
    case 3: out.kind = FlashValue::kNumber; out.n = number; break;
    case 4:
    case 5:
        out.kind = FlashValue::kText;  // empty if unreadable
        if (ReadTextValue(value, buf, sizeof buf)) out.text = buf;
        break;
    case 0:
    case 1: break;
    default: out.kind = FlashValue::kOther; break;
    }
    return out;
}

// Reads <path>.label, falling back to <path>.textField.text. Returns the raw text ("" if neither
// is a non-empty string).
std::string ReadLabel(void* movie, const char* path) {
    static const char* const kMembers[] = {".label", ".textField.text"};
    for (const char* member : kMembers) {
        const std::string full = std::string(path) + member;
        alignas(8) unsigned char value[kGFxValueSize];
        char buf[256] = {};
        const bool ok = SafeGetVariable(movie, full.c_str(), value) && ReadTextValue(value, buf, sizeof buf);
        SafeRelease(value);
        if (ok) return buf;
    }
    return std::string();
}

// ---- Hook A: SwfExternalInterface::Callback (thiscall, ret 0x10) --------------------------
using CallbackFn = void(__fastcall*)(void* self, void* edx, void* movie, const char* method,
                                     const unsigned char* args, unsigned argc);
CallbackFn g_orig_callback = nullptr;

EventListener g_listener = nullptr;
void* volatile g_movie_vtable = nullptr;  // the vtable of the movies seen in callbacks

void* VtableOf(void* object) {
    __try {
        return object ? *reinterpret_cast<void**>(object) : nullptr;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

void Dispatch(UiEvent::Type type, void* movie, const char* path, const char* method,
              const FlashValue* value = nullptr) {
    if (!g_listener || (!movie && type != UiEvent::kValueSet && type != UiEvent::kFrame) || !path[0]) return;
    const UiEvent event = {type, movie, path, method, value};
    g_listener(event);
}

// focusIn("<path>", ...): log the focused widget's label (1c-3).
void LogFocusLabel(void* movie, const char* path) {
    const std::string label = ReadLabel(movie, path);
    AcquireSRWLockExclusive(&g_lock);
    const bool ok = Budget();
    ReleaseSRWLockExclusive(&g_lock);
    if (!ok) return;
    if (label.empty()) alog::Write("ui label: %s = (none)", path);
    else alog::Write("ui label: %s = \"%s\"", path, label.c_str());
}

void LogCall(const char* method, const unsigned char* args, unsigned argc) {
    char name[128];
    CopyCString(method, name, sizeof name);
    std::string line = std::string("ui call: ") + name + "(";
    for (unsigned i = 0; i < argc && i < 8; ++i) {
        char value[256];
        FormatValue(args + i * kGFxValueSize, value, sizeof value);
        if (i) line += ", ";
        line += value;
    }
    if (argc > 8) line += ", ...";
    line += ")";
    AcquireSRWLockExclusive(&g_lock);
    const bool ok = Budget();
    ReleaseSRWLockExclusive(&g_lock);
    if (ok) alog::Write("%s", line.c_str());
}

void __fastcall HookCallback(void* self, void* edx, void* movie, const char* method, const unsigned char* args,
                             unsigned argc) {
    LogCall(method, args, argc);
    if (!g_movie_vtable && movie) g_movie_vtable = VtableOf(movie);
    char name[32], path[256] = {};
    CopyCString(method, name, sizeof name);
    const bool has_path = argc >= 1 && movie && ReadTextValue(args, path, sizeof path);
    if (has_path && std::strcmp(name, "focusIn") == 0) {
        LogFocusLabel(movie, path);
        Dispatch(UiEvent::kFocusIn, movie, path, name);
    }
    g_orig_callback(self, edx, movie, method, args, argc);
    if (!has_path) return;
    if (std::strcmp(name, "navigate") == 0) {
        Dispatch(UiEvent::kNavigate, movie, path, name);
    } else if (std::strcmp(name, "change") == 0 || std::strcmp(name, "stepperChange") == 0 ||
               std::strcmp(name, "click") == 0 || std::strcmp(name, "select") == 0) {
        // The second argument, if any, rides along as the event value: a list box sends its new
        // row index as change("<path>", <index>) (the Controls bindings list, B1f).
        FlashValue second;
        if (argc >= 2) second = DecodeValue(args + kGFxValueSize);
        Dispatch(UiEvent::kChange, movie, path, name, argc >= 2 ? &second : nullptr);
    }
}

// ---- Hook B: SwfSymbol::SetVariableInternal (esi = symbol, edi = member, [esp+4] = value) ---
void* g_orig_set_variable = nullptr;

// The symbol's movie: SwfSymbol +8 = its SwfScreen, SwfScreen +0x38 = the GFx movie (see
// SwfSymbol::InvokeMethodInternal 0x559920). nullptr if unreadable.
void* SymbolMovie(const unsigned char* symbol) {
    __try {
        const unsigned char* screen = *reinterpret_cast<const unsigned char* const*>(symbol + 8);
        return *reinterpret_cast<void* const*>(screen + 0x38);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

bool IsTrue(const unsigned char* value) {
    __try {
        return (*reinterpret_cast<const unsigned*>(value + 4) & 0x0f) == 2 && value[8] != 0;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

void __cdecl OnSetVariable(const unsigned char* symbol, const char* member, const unsigned char* value) {
    char widget[256], name[128], text[256];
    ReadStdString(symbol + 0xc, widget, sizeof widget);
    CopyCString(member, name, sizeof name);
    FormatValue(value, text, sizeof text);
    const std::string key = std::string(widget) + "." + name;
    AcquireSRWLockExclusive(&g_lock);
    auto it = g_last_values.find(key);
    const bool changed = it == g_last_values.end() || it->second != text;
    if (changed) g_last_values[key] = text;
    const bool ok = changed && Budget();
    ReleaseSRWLockExclusive(&g_lock);
    if (ok) alog::Write("ui set: %s = %s", key.c_str(), text);
    // Phase 2: the value being written (this runs before the game's write lands), for text and values
    // that the menu reader may be waiting for (a slider's number when the Settings dialog opens).
    if (g_listener && (std::strcmp(name, "text") == 0 || std::strcmp(name, "value") == 0)) {
        const FlashValue v = DecodeValue(value);
        // The symbol's movie, for comparison only (not vtable-checked, so never read through).
        Dispatch(UiEvent::kValueSet, SymbolMovie(symbol), key.c_str(), name, &v);
    }
    if (std::strcmp(name, "focused") == 0 && IsTrue(value) && widget[0] != '?') {
        // Only read through the symbol's movie if it is the same kind of object as the callbacks' movies.
        void* movie = SymbolMovie(symbol);
        void* vtable = VtableOf(movie);
        if (vtable && vtable == g_movie_vtable) {
            Dispatch(UiEvent::kFocusedSet, movie, widget, "focused");
        } else {
            alog::Write("ui: %s.focused = true not reported: movie %p vtable %p, expected %p", widget, movie, vtable,
                        g_movie_vtable);
        }
    }
}

// After pushad (32 bytes) and pushfd (4 bytes): return address at [esp+36], the value pointer at
// [esp+40]. All registers and flags are restored before jumping to the original, which then pops
// its own argument (ret 4) and returns its result in al as usual.
__declspec(naked) void HookSetVariable() {
    __asm {
        pushad
        pushfd
        push dword ptr [esp + 40]   // value
        push edi                    // member name
        push esi                    // symbol
        call OnSetVariable
        add esp, 12
        popfd
        popad
        jmp dword ptr [g_orig_set_variable]
    }
}

// ---- Hook C: SwfSymbol::InvokeV (thiscall(symbol; method, fmt, va_list) -> const char*, ret 0xc)
// Native -> Flash method calls, e.g. the level select's AddCell / SelectNext (2-3).
using InvokeFn = const char*(__fastcall*)(void* self, void* edx, const char* method, const char* fmt, va_list args);
InvokeFn g_orig_invoke = nullptr;

constexpr int kMaxArgs = 8;
constexpr size_t kArgLen = 200;
struct ParsedArgs {
    int n;
    char text[kMaxArgs][kArgLen];
};

// Formats each printf-style argument separately (%s, %d/%i/%c, %u/%x, %f/%g/%e). Stops at anything
// else or on a fault. No C++ objects here (SEH).
void ParseArgs(const char* fmt, va_list ap, ParsedArgs* out) {
    out->n = 0;
    __try {
        const char* p = fmt;
        const char* cur = reinterpret_cast<const char*>(ap);
        while (p && *p && out->n < kMaxArgs) {
            if (*p++ != '%') continue;
            if (*p == '%') {
                ++p;
                continue;
            }
            while (*p && std::strchr("-+ #0123456789.lhI", *p)) ++p;
            const char conv = *p;
            if (!conv) break;
            ++p;
            char* dst = out->text[out->n];
            switch (conv) {
            case 's': {
                const char* s = *reinterpret_cast<const char* const*>(cur);
                cur += 4;
                _snprintf_s(dst, kArgLen, _TRUNCATE, "%s", s ? s : "");
                break;
            }
            case 'd':
            case 'i':
            case 'c':
                _snprintf_s(dst, kArgLen, _TRUNCATE, "%d", *reinterpret_cast<const int*>(cur));
                cur += 4;
                break;
            case 'u':
            case 'x':
                _snprintf_s(dst, kArgLen, _TRUNCATE, "%u", *reinterpret_cast<const unsigned*>(cur));
                cur += 4;
                break;
            case 'f':
            case 'g':
            case 'e':
                _snprintf_s(dst, kArgLen, _TRUNCATE, "%g", *reinterpret_cast<const double*>(cur));
                cur += 8;
                break;
            default:
                return;
            }
            ++out->n;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
}

bool SafeInvoke(void* symbol, const char* method, char* buf, size_t n) {
    buf[0] = '\0';
    if (!g_orig_invoke || !symbol) return false;
    int dummy[4] = {};
    __try {
        const char* r = g_orig_invoke(symbol, nullptr, method, "", reinterpret_cast<va_list>(dummy));
        _snprintf_s(buf, n, _TRUNCATE, "%s", r ? r : "");
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        buf[0] = '\0';
        return false;
    }
}

std::map<std::string, DWORD> g_invoke_logged;  // log line -> when it was last written

const char* __fastcall HookInvoke(void* self, void* edx, const char* method, const char* fmt, va_list args) {
    ParsedArgs parsed;
    ParseArgs(fmt, args, &parsed);  // before the call: the arguments are ours to read now
    const char* result = g_orig_invoke(self, edx, method, fmt, args);
    char widget[256], name[64], res[256];
    ReadStdString(static_cast<const unsigned char*>(self) + 0xc, widget, sizeof widget);
    CopyCString(method, name, sizeof name);
    CopyCString(result, res, sizeof res);
    std::vector<std::string> list;
    std::string line = std::string("ui invoke: ") + widget + "." + name + "(";
    for (int i = 0; i < parsed.n; ++i) {
        list.emplace_back(parsed.text[i]);
        line += (i ? ", \"" : "\"") + list.back() + "\"";
    }
    line += std::string(") -> \"") + res + "\"";
    // Some methods are polled every frame (IsLoadingImage, IsSelected): log a repeated line at most
    // every 2 s.
    const DWORD now = GetTickCount();
    AcquireSRWLockExclusive(&g_lock);
    if (g_invoke_logged.size() > 2000) g_invoke_logged.clear();
    auto it = g_invoke_logged.find(line);
    const bool fresh = it == g_invoke_logged.end() || now - it->second >= 2000;
    if (fresh) g_invoke_logged[line] = now;
    const bool ok = fresh && Budget();
    ReleaseSRWLockExclusive(&g_lock);
    if (ok) alog::Write("%s", line.c_str());
    if (g_listener && widget[0] != '?') {
        // The widget's movie, for comparison only (not vtable-checked, so never read through).
        UiEvent event = {UiEvent::kInvoke, SymbolMovie(static_cast<const unsigned char*>(self)), widget, name};
        event.symbol = self;
        event.args = &list;
        event.result = res;
        g_listener(event);
    }
    return result;
}

// ---- Hook E: SwfSymbol::InvokeMethodInternal (ecx = symbol, edi = method, [esp+4] = result
// GFxValue*, [esp+8] = args GFxValue*, [esp+0xc] = argc; ret 0xc) ------------------------------
// Native -> Flash method calls with GFxValue arguments: the list boxes' clearItems / addItem /
// setSelectedIndex / getItem (the Controls screen's binding list, N4), and video calls.
void* g_orig_invoke_internal = nullptr;

void __cdecl OnInvokeInternal(const unsigned char* symbol, const char* method, const unsigned char* args,
                              unsigned argc) {
    char widget[256], name[64];
    ReadStdString(symbol + 0xc, widget, sizeof widget);
    CopyCString(method, name, sizeof name);
    std::vector<std::string> list;
    std::string line = std::string("ui invoke2: ") + widget + "." + name + "(";
    for (unsigned i = 0; i < argc && i < 8 && args; ++i) {
        char shown[256];
        FormatValue(args + i * kGFxValueSize, shown, sizeof shown);
        line += (i ? ", " : "") + std::string(shown);
        const FlashValue v = DecodeValue(args + i * kGFxValueSize);
        if (v.kind == FlashValue::kText) list.push_back(v.text);
        else if (v.kind == FlashValue::kNumber) {
            char num[32];
            _snprintf_s(num, sizeof num, _TRUNCATE, "%g", v.n);
            list.emplace_back(num);
        } else if (v.kind == FlashValue::kBool) list.emplace_back(v.b ? "true" : "false");
        else list.emplace_back(shown);
    }
    line += ")";
    const DWORD now = GetTickCount();
    AcquireSRWLockExclusive(&g_lock);
    if (g_invoke_logged.size() > 2000) g_invoke_logged.clear();
    auto it = g_invoke_logged.find(line);
    const bool fresh = it == g_invoke_logged.end() || now - it->second >= 2000;
    if (fresh) g_invoke_logged[line] = now;
    const bool ok = fresh && Budget();
    ReleaseSRWLockExclusive(&g_lock);
    if (ok) alog::Write("%s", line.c_str());
    if (g_listener && widget[0] != '?') {
        UiEvent event = {UiEvent::kInvoke, SymbolMovie(symbol), widget, name};
        event.symbol = const_cast<unsigned char*>(symbol);
        event.args = &list;
        event.result = "";
        g_listener(event);
    }
}

// Before the original runs (its arguments are ours to read now). After pushad (32) and pushfd (4):
// return address [esp+36], result [esp+40], args [esp+44], argc [esp+48].
__declspec(naked) void HookInvokeInternal() {
    __asm {
        pushad
        pushfd
        push dword ptr [esp + 48]   // argc
        push dword ptr [esp + 48]   // args (shifted by the push above)
        push edi                    // method name
        push ecx                    // symbol
        call OnInvokeInternal
        add esp, 16
        popfd
        popad
        jmp dword ptr [g_orig_invoke_internal]
    }
}

// ---- Hook D: SwfScreen::Update (thiscall(screen; float dt), ret 4) -------------------------
// Every frame for every screen. We watch its state (+0x3c: 0 closed, 1 opening, 2 open,
// 3 closing) to learn when a screen appears or goes away: CLIK restores a screen's focus without
// telling the game (2-5b-2 test), so this is how the menu reader knows a screen came back.
using UpdateFn = void(__fastcall*)(void* screen, void* edx, float dt);
UpdateFn g_orig_update = nullptr;
SRWLOCK g_screen_lock = SRWLOCK_INIT;
std::map<void*, bool> g_screen_shown;  // screen -> last seen shown state
std::map<void*, DWORD> g_movie_seen;    // movie -> when a screen's Update last ran with it (liveness)
std::map<void*, int> g_screen_ticks;    // screen -> kScreenTick frames still to send after "shown"

bool ReadScreen(const unsigned char* screen, void** movie, int* state, int* visible) {
    __try {
        *movie = *reinterpret_cast<void* const*>(screen + 0x38);
        *state = *reinterpret_cast<const int*>(screen + 0x3c);
        *visible = screen[0xc];
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Frame-rate monitor (B3 lag report, 2026-09-26): each screen's Update runs once per frame, so the
// busiest screen's call count is the frame rate, and its dt sum is the game time that passed. Logged
// every 5 s as  perf: <fps> fps, game time <x> s per s, longest frame <ms> ms.
struct PerfCount {
    int calls = 0;
    double dt = 0;
    DWORD last = 0, max_gap = 0;
};
std::map<void*, PerfCount> g_perf;
DWORD g_perf_start = 0;

void CountFrame(void* screen, float dt) {
    const DWORD now = GetTickCount();
    PerfCount& p = g_perf[screen];
    if (p.last && now - p.last > p.max_gap) p.max_gap = now - p.last;
    p.last = now;
    ++p.calls;
    p.dt += dt;
    if (!g_perf_start) g_perf_start = now;
    const DWORD span = now - g_perf_start;
    if (span < 5000) return;
    const PerfCount* best = nullptr;
    for (const auto& kv : g_perf) {
        if (!best || kv.second.calls > best->calls) best = &kv.second;
    }
    if (best) {
        alog::Write("perf: %.1f fps, game time %.2f s per s, longest frame %lu ms (%u screens updating)",
                    best->calls * 1000.0 / span, best->dt * 1000.0 / span, best->max_gap, static_cast<unsigned>(g_perf.size()));
    }
    g_perf.clear();
    g_perf_start = now;
}

void __fastcall HookUpdate(void* screen, void* edx, float dt) {
    g_orig_update(screen, edx, dt);
    CountFrame(screen, dt);  // game thread only
    Dispatch(UiEvent::kFrame, nullptr, "frame", "frame");
    void* movie = nullptr;
    int state = 0, visible = 0;
    if (!ReadScreen(static_cast<const unsigned char*>(screen), &movie, &state, &visible)) return;
    const bool shown = state == 1 || state == 2;
    AcquireSRWLockExclusive(&g_screen_lock);
    if (movie) g_movie_seen[movie] = GetTickCount();
    auto it = g_screen_shown.find(screen);
    const bool changed = it == g_screen_shown.end() || it->second != shown;
    if (changed) g_screen_shown[screen] = shown;
    bool tick = false;
    if (changed) {
        if (shown) g_screen_ticks[screen] = kScreenTickFrames;
        else g_screen_ticks.erase(screen);
    } else if (shown) {
        auto t = g_screen_ticks.find(screen);
        if (t != g_screen_ticks.end()) {
            tick = true;
            if (--t->second <= 0) g_screen_ticks.erase(t);
        }
    }
    ReleaseSRWLockExclusive(&g_screen_lock);
    const bool readable = movie && g_movie_vtable && VtableOf(movie) == g_movie_vtable;
    if (!changed) {
        if (tick && readable) Dispatch(UiEvent::kScreenTick, movie, "screen", "tick");
        return;
    }
    alog::Write("ui screen: %p movie %p %s (state %d, visible byte %d)%s", screen, movie, shown ? "shown" : "hidden",
                state, visible, readable ? "" : " (movie not verified: not reported)");
    if (readable) Dispatch(shown ? UiEvent::kScreenShown : UiEvent::kScreenHidden, movie, "screen", "screen");
}

// ---- Installation -------------------------------------------------------------------------
const unsigned char kCallbackPrologue[] = {0x55, 0x8B, 0xEC, 0x83, 0xE4, 0xF8, 0x6A, 0xFF, 0x68, 0xD8, 0x04, 0x7C, 0x00};
const unsigned char kSetVariablePrologue[] = {0x51, 0x8B, 0x46, 0x2C, 0x24, 0x8F, 0x3C, 0x08};
const unsigned char kObjectReleasePrologue[] = {0x8B, 0x44, 0x24, 0x04, 0x8B, 0x40, 0x04, 0x25, 0x8F, 0x00, 0x00, 0x00};
const unsigned char kInvokePrologue[] = {0x81, 0xEC, 0x04, 0x01, 0x00, 0x00, 0xA1, 0x70, 0x46, 0x88, 0x00};
const unsigned char kUpdatePrologue[] = {0xD9, 0x44, 0x24, 0x04, 0x56, 0x8B, 0xF1, 0x8B, 0x4E, 0x38};
const unsigned char kInvokeInternalPrologue[] = {0x81, 0xEC, 0x0C, 0x01, 0x00, 0x00, 0xA1, 0x70, 0x46, 0x88, 0x00};

bool HookOne(const char* label, unsigned target, void* detour, void** orig) {
    void* t = reinterpret_cast<void*>(static_cast<uintptr_t>(target));
    MH_STATUS st = MH_CreateHook(t, detour, orig);
    if (st == MH_OK) st = MH_EnableHook(t);
    alog::Write("hook %s at 0x%08x: %s", label, target, st == MH_OK ? "installed" : MH_StatusToString(st));
    return st == MH_OK;
}

}  // namespace

bool Install() {
    if (std::memcmp(reinterpret_cast<const void*>(0x5534d0), kCallbackPrologue, sizeof kCallbackPrologue) != 0 ||
        std::memcmp(reinterpret_cast<const void*>(0x559a50), kSetVariablePrologue, sizeof kSetVariablePrologue) != 0 ||
        std::memcmp(reinterpret_cast<const void*>(0x5c7620), kObjectReleasePrologue, sizeof kObjectReleasePrologue) != 0) {
        alog::Write("ui hooks: function bytes don't match the expected build; not hooking");
        return false;
    }
    if (std::memcmp(reinterpret_cast<const void*>(0x559b50), kInvokePrologue, sizeof kInvokePrologue) != 0 ||
        std::memcmp(reinterpret_cast<const void*>(0x553d50), kUpdatePrologue, sizeof kUpdatePrologue) != 0 ||
        std::memcmp(reinterpret_cast<const void*>(0x559920), kInvokeInternalPrologue,
                    sizeof kInvokeInternalPrologue) != 0) {
        alog::Write("ui hooks: InvokeV / SwfScreen::Update / InvokeMethodInternal bytes don't match; not hooking");
        return false;
    }
    return InstallAt(0x5534d0, 0x559a50, 0x5c7620, 0x559b50, 0x553d50, 0x559920);
}

namespace {

// GFxMovie vtable +0x5c = Invoke(const char* method, GFxValue* result, const GFxValue* args,
// UInt argc), thiscall, returns al (as SwfSymbol::InvokeMethodInternal 0x559920 uses it).
using MovieInvokeFn = bool(__fastcall*)(void* movie, void* edx, const char* method, unsigned char* result,
                                        const unsigned char* args, unsigned argc);

bool SafeMovieInvoke(void* movie, const char* method, unsigned char* result) {
    std::memset(result, 0, kGFxValueSize);
    __try {
        const auto fn = reinterpret_cast<MovieInvokeFn>((*reinterpret_cast<void** const*>(movie))[0x5c / 4]);
        return fn(movie, nullptr, method, result, nullptr, 0);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        std::memset(result, 0, kGFxValueSize);
        return false;
    }
}

}  // namespace

std::string QueryFocus(void* movie) {
    if (!movie) return std::string();
    alignas(8) unsigned char value[kGFxValueSize];
    char buf[256] = {};
    std::string path;
    if (SafeMovieInvoke(movie, "Selection.getFocus", value) && ReadTextValue(value, buf, sizeof buf)) path = buf;
    SafeRelease(value);
    if (!path.empty()) return path;
    // CLIK's own record of the focus: a display object; its _target is "/controls/howToPlayBtn".
    const FlashValue target = ReadValue(movie, "_global.gfx.managers.FocusHandler._instance.currentFocus._target");
    if (target.kind == FlashValue::kText && target.text.size() > 1 && target.text[0] == '/') {
        path = "_level0" + target.text;
        for (char& c : path) {
            if (c == '/') c = '.';
        }
    }
    return path;
}

bool MovieAlive(void* movie, unsigned within_ms) {
    AcquireSRWLockShared(&g_screen_lock);
    auto it = g_movie_seen.find(movie);
    const bool alive = it != g_movie_seen.end() && GetTickCount() - it->second <= within_ms;
    ReleaseSRWLockShared(&g_screen_lock);
    return alive;
}

std::string InvokeMethod(void* symbol, const char* method) {
    char buf[256] = {};
    if (!SafeInvoke(symbol, method, buf, sizeof buf)) return std::string();
    return buf;
}

void SetEventListener(EventListener listener) { g_listener = listener; }

FlashValue ReadValue(void* movie, const char* path) {
    FlashValue out;
    if (!movie || !path) return out;
    alignas(8) unsigned char value[kGFxValueSize];
    if (SafeGetVariable(movie, path, value)) out = DecodeValue(value);
    SafeRelease(value);
    return out;
}

bool InstallAt(unsigned callback, unsigned set_variable, unsigned object_release, unsigned invoke, unsigned update,
               unsigned invoke_internal) {
    g_object_release = reinterpret_cast<ObjectReleaseFn>(static_cast<uintptr_t>(object_release));
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        alog::Write("ui hooks: MH_Initialize failed: %s", MH_StatusToString(st));
        return false;
    }
    g_window_start = GetTickCount();
    const bool a = HookOne("UiCallback", callback, reinterpret_cast<void*>(&HookCallback),
                           reinterpret_cast<void**>(&g_orig_callback));
    const bool b = HookOne("SetVariableInternal", set_variable, reinterpret_cast<void*>(&HookSetVariable),
                           &g_orig_set_variable);
    const bool c = HookOne("InvokeV", invoke, reinterpret_cast<void*>(&HookInvoke),
                           reinterpret_cast<void**>(&g_orig_invoke));
    const bool d = HookOne("SwfScreen::Update", update, reinterpret_cast<void*>(&HookUpdate),
                           reinterpret_cast<void**>(&g_orig_update));
    const bool e = HookOne("InvokeMethodInternal", invoke_internal, reinterpret_cast<void*>(&HookInvokeInternal),
                           &g_orig_invoke_internal);
    return a && b && c && d && e;
}

}  // namespace ui_hooks
