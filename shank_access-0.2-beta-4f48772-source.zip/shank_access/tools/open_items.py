"""List every open-looking marker in the project docs, for /sync-memory's loop-closing sweep.

Each hit is something that says "not finished" (waiting, awaiting, untested, hypothesis, an unchecked box, ...).
The sweep checks each one against the conversation, later doc entries and the collected logs, and either closes
it (with the evidence) or leaves it because it really is still open.

Usage: .venv/Scripts/python tools/open_items.py [--all]
  default: skips the PLAN work log and decision log (history; old "pending" lines there are fine).
  --all:   includes them.
Standard library only.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = ["docs/PLAN.md", "docs/TESTING.md", "docs/DESIGN.md", "docs/RE-NOTES.md", "CLAUDE.md"]

# Words and phrases that mark something as not finished.
PATTERNS = [
    r"\bwaiting\b", r"\bawaiting\b", r"\bin progress\b", r"\bnot yet\b", r"\bpending\b", r"\buntested\b",
    r"\bstill open\b", r"\bstill to come\b", r"\bto be (?:decided|confirmed|checked)\b", r"\bhypothesis\b",
    r"\bask the user\b", r"\basked the user\b", r"\bopen question", r"\(open\b", r"\bopen:", r"\bfollow-up\b",
    r"\bthe user is testing\b", r"\bthe user tests next\b", r"\bTODO\b", r"\bTBD\b",
    r"\bunconfirmed\b", r"\bneeds an in-game test\b", r"\bwill (?:show|confirm|tell)\b",
]
OPEN_RE = re.compile("|".join(PATTERNS), re.I)
BOX_RE = re.compile(r"^\s*- \[[ ~]\]")          # an unchecked or in-progress checkbox
HEADER_RE = re.compile(r"^## \d{4}-\d{2}-\d{2} ")  # a TESTING entry header
# Lines that describe the conventions themselves, not an open item.
IGNORE_RE = re.compile(r"Legend: `\[ \]`|Label anything unconfirmed as|status: awaiting user \| done|"
                       r"<status: awaiting user", re.I)


def history_ranges(lines):
    """Line index ranges of PLAN's work log and decision log (history)."""
    ranges, start = [], None
    for i, line in enumerate(lines):
        if line.startswith("## "):
            if start is not None:
                ranges.append((start, i))
                start = None
            if re.search(r"work log|decision log", line, re.I):
                start = i
    if start is not None:
        ranges.append((start, len(lines)))
    return ranges


def main():
    sys.stdout.reconfigure(encoding="utf-8")  # the docs use arrows etc.; the Windows console code page can't
    include_history = "--all" in sys.argv
    total = 0
    for rel in DOCS:
        path = os.path.join(ROOT, rel)
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            lines = f.read().splitlines()
        skip = [] if include_history or not rel.endswith("PLAN.md") else history_ranges(lines)
        hits = []
        closed_entry = False  # TESTING: inside an entry whose header says done / abandoned (history)
        for i, line in enumerate(lines):
            if rel.endswith("TESTING.md") and line.startswith("## "):
                closed_entry = bool(re.search(r"— (?:done|abandoned|crashed)\b", line, re.I)) and not re.search(
                    r"awaiting user", line, re.I)
            elif closed_entry and not include_history:
                continue
            if any(a <= i < b for a, b in skip) or IGNORE_RE.search(line):
                continue
            kind = None
            if rel.endswith("TESTING.md") and HEADER_RE.match(line):
                if re.search(r"awaiting user|partly|in part|deployed\s*$", line, re.I):
                    kind = "test"
            elif BOX_RE.match(line):
                kind = "box"
            else:
                m = OPEN_RE.search(line)
                if m:
                    kind = m.group(0).lower()
            if kind:
                snippet = line.strip()
                if len(snippet) > 180:
                    at = OPEN_RE.search(snippet)
                    lo = max(0, (at.start() if at else 0) - 80)
                    snippet = ("..." if lo else "") + snippet[lo:lo + 180] + "..."
                hits.append(f"  {rel}:{i + 1} [{kind}] {snippet}")
        if hits:
            print(f"{rel}: {len(hits)} open-looking line(s)")
            print("\n".join(hits))
            total += len(hits)
    print(f"total: {total}")


if __name__ == "__main__":
    main()
