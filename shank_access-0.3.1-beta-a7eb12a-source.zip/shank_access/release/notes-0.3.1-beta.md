Shank Access 0.3.1 beta fixes two problems that stopped setup from installing the mod on some computers. Nothing
else changes from 0.3 beta.

## Installing or updating

Download **shank-access-setup.exe** below and run it. Your settings are kept. The first update works out the routes
between checkpoints again, so it takes about two minutes.

## Fixes

- On Windows in a language other than English, setup could stop with "Setup failed: 'NoneType' object has no
  attribute 'lower'". Setup checks whether Shank is running, and it couldn't read Windows' answer in some languages.
  It now reads it in any language.
- If your Windows user name has letters from another alphabet, such as Russian or Japanese, setup could stop with
  "Working out the routes failed". Setup now works with any letters in your user name and in the Shank folder's path.

Version 0.3.1-beta-REV. The source zip below has the full source for this version.
