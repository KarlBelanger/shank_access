#include "marks.h"

#include <windows.h>

#include <cstdio>

#include "log.h"

namespace marks {
namespace {

constexpr int kEditId = 100;

SRWLOCK g_lock = SRWLOCK_INIT;
std::wstring g_path;
Hooks g_hooks;
int g_count = 0;           // marks this session
bool g_open = false;       // a comment window is up
bool g_session_written = false;

std::string Utf8(const std::wstring& w) {
    if (w.empty()) return std::string();
    const int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()), nullptr, 0, nullptr, nullptr);
    std::string out(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()), &out[0], n, nullptr, nullptr);
    return out;
}

std::string Now(bool with_date) {
    SYSTEMTIME t;
    GetLocalTime(&t);
    char buf[64];
    if (with_date) {
        snprintf(buf, sizeof(buf), "%04u-%02u-%02u %02u:%02u:%02u", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    } else {
        snprintf(buf, sizeof(buf), "%02u:%02u:%02u.%03u", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    }
    return buf;
}

// Appends lines to a11y_marks.log (UTF-8), with a session header before the first mark of a session.
void Append(const std::string& line) {
    AcquireSRWLockExclusive(&g_lock);
    const std::wstring path = g_path;
    std::string text;
    if (!g_session_written) {
        text = "\r\n=== Session " + Now(true) + " ===\r\n";
        g_session_written = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
    text += line + "\r\n";
    HANDLE f = CreateFileW(path.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) {
        alog::Write("marks: can't write a11y_marks.log (error %lu)", GetLastError());
        return;
    }
    DWORD written = 0;
    WriteFile(f, text.data(), static_cast<DWORD>(text.size()), &written, nullptr);
    CloseHandle(f);
}

struct Window {
    int n;
    HWND edit = nullptr;
    bool saved = false;
    bool done = false;
    std::wstring text;
};

LRESULT CALLBACK Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    Window* w = reinterpret_cast<Window*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    switch (msg) {
        case WM_CREATE:
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(reinterpret_cast<CREATESTRUCTW*>(lp)->lpCreateParams));
            return 0;
        case DM_GETDEFID:  // Enter in the edit box = Save (IsDialogMessage asks)
            return MAKELONG(IDOK, DC_HASDEFID);
        case WM_COMMAND:
            if (w && (LOWORD(wp) == IDOK || LOWORD(wp) == IDCANCEL)) {
                w->saved = LOWORD(wp) == IDOK;
                if (w->saved) {
                    const int len = GetWindowTextLengthW(w->edit);
                    std::wstring t(len, L'\0');
                    if (len) GetWindowTextW(w->edit, &t[0], len + 1);
                    w->text = t;
                }
                w->done = true;
                return 0;
            }
            break;
        case WM_CLOSE:
            if (w) w->done = true;
            return 0;
        case WM_ACTIVATE:
            if (LOWORD(wp) != WA_INACTIVE && w && w->edit) SetFocus(w->edit);
            return 0;
        default:
            break;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

// Runs the comment window for mark n on this thread; returns whether it was saved, and the comment.
bool AskComment(int n, HWND game, std::string* comment) {
    static bool registered = false;
    HINSTANCE inst = GetModuleHandleW(nullptr);
    if (!registered) {
        WNDCLASSW wc = {};
        wc.lpfnWndProc = Proc;
        wc.hInstance = inst;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_BTNFACE + 1);
        wc.lpszClassName = L"ShankAccessMark";
        registered = RegisterClassW(&wc) != 0 || GetLastError() == ERROR_CLASS_ALREADY_EXISTS;
    }
    Window w;
    w.n = n;
    const std::wstring title = L"Shank access: mark " + std::to_wstring(n);
    const int cx = GetSystemMetrics(SM_CXSCREEN), cy = GetSystemMetrics(SM_CYSCREEN);
    HWND hwnd = CreateWindowExW(WS_EX_TOPMOST | WS_EX_DLGMODALFRAME, L"ShankAccessMark", title.c_str(),
                                WS_POPUP | WS_CAPTION | WS_SYSMENU, cx / 2 - 260, cy / 2 - 70, 520, 140, nullptr, nullptr, inst, &w);
    if (!hwnd) return false;
    HFONT font = static_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
    // The label comes right before the edit box, so the screen reader names the box with it.
    const std::wstring label = L"Comment for mark " + std::to_wstring(n) + L" (Enter saves, Escape skips):";
    HWND lab = CreateWindowExW(0, L"STATIC", label.c_str(), WS_CHILD | WS_VISIBLE, 12, 10, 490, 20, hwnd, nullptr, inst, nullptr);
    w.edit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL, 12, 34, 490, 24, hwnd,
                             reinterpret_cast<HMENU>(static_cast<INT_PTR>(kEditId)), inst, nullptr);
    HWND ok = CreateWindowExW(0, L"BUTTON", L"Save", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON, 322, 68, 85, 26, hwnd,
                              reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDOK)), inst, nullptr);
    HWND cancel = CreateWindowExW(0, L"BUTTON", L"Skip", WS_CHILD | WS_VISIBLE | WS_TABSTOP, 417, 68, 85, 26, hwnd,
                                  reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDCANCEL)), inst, nullptr);
    for (HWND c : {lab, w.edit, ok, cancel}) SendMessageW(c, WM_SETFONT, reinterpret_cast<WPARAM>(font), TRUE);
    ShowWindow(hwnd, SW_SHOW);
    SetForegroundWindow(hwnd);
    SetFocus(w.edit);
    MSG msg;
    while (!w.done && GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (!IsDialogMessageW(hwnd, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    DestroyWindow(hwnd);
    if (game) {  // back to the game (it paused when it lost the focus)
        if (IsIconic(game)) ShowWindow(game, SW_RESTORE);
        SetForegroundWindow(game);
    }
    if (w.saved) *comment = Utf8(w.text);
    return w.saved;
}

struct Job {
    int n;
    HWND game;
};

DWORD WINAPI CommentThread(LPVOID p) {
    Job* job = static_cast<Job*>(p);
    std::string comment;
    if (g_hooks.block_input) g_hooks.block_input(true);
    const bool saved = AskComment(job->n, job->game, &comment);
    if (g_hooks.block_input) g_hooks.block_input(false);
    const std::string line = CommentLine(job->n, saved ? comment : std::string());
    alog::Write("%s", line.c_str());
    Append(line);
    if (g_hooks.say) g_hooks.say("Mark " + std::to_string(job->n) + (saved && !comment.empty() ? " saved" : ", no comment"));
    AcquireSRWLockExclusive(&g_lock);
    g_open = false;
    ReleaseSRWLockExclusive(&g_lock);
    delete job;
    return 0;
}

}  // namespace

std::string MarkLine(int n, const std::string& time, const std::string& context) {
    return "MARK " + std::to_string(n) + " at " + time + ": " + context;
}

std::string CommentLine(int n, const std::string& comment) {
    return "MARK " + std::to_string(n) + " comment: " + (comment.empty() ? std::string("(none)") : comment);
}

void Init(const std::wstring& marks_path, const Hooks& hooks) {
    AcquireSRWLockExclusive(&g_lock);
    g_path = marks_path;
    g_hooks = hooks;
    ReleaseSRWLockExclusive(&g_lock);
}

void Mark() {
    AcquireSRWLockExclusive(&g_lock);
    if (g_open) {
        ReleaseSRWLockExclusive(&g_lock);
        return;
    }
    g_open = true;
    const int n = ++g_count;
    ReleaseSRWLockExclusive(&g_lock);
    const std::string line = MarkLine(n, Now(false), g_hooks.context ? g_hooks.context() : std::string());
    alog::Write("%s", line.c_str());  // written before the window opens: the mark is kept whatever happens next
    Append(line);
    Job* job = new Job{n, GetForegroundWindow()};
    if (HANDLE t = CreateThread(nullptr, 0, CommentThread, job, 0, nullptr)) {
        CloseHandle(t);
    } else {
        delete job;
        AcquireSRWLockExclusive(&g_lock);
        g_open = false;
        ReleaseSRWLockExclusive(&g_lock);
        if (g_hooks.say) g_hooks.say("Mark " + std::to_string(n));
    }
}

}  // namespace marks
