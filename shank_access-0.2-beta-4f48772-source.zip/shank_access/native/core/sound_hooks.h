#pragma once
#include <string>
#include <utility>
#include <vector>

// Phase 1b-2: hooks on the game's two sound functions, logging every call to a11y.log with the
// event name, world position and the pan listener. The game still plays every one of its own
// sounds exactly as before; only our own "a11y/" messages are taken out (see SetCueListener).
namespace sound_hooks {

// Installs both hooks. Returns false (and logs why) if MinHook fails or the function bytes
// don't match the expected build.
bool Install();

// Hooks the given addresses without the build/prologue check. Used by Install() with the game's
// addresses, and by native/tests/hook_test.cpp with stand-in functions of the same convention.
// `listener` = address of the 4 listener floats (half-width, half-height, centre x, centre y).
bool InstallAt(unsigned play_at, unsigned play, unsigned listener);

// Our own messages from Lua (B3, 2026-09-26): a patched stategraph's PlaySound("a11y/<cue>") arrives
// here as "<cue>" with the emitter's world position (pixels; Shank's own for his probes, the
// pickup's for pickups). These never reach FMOD. Called on the game's thread; must be quick.
using CueListener = void (*)(const char* cue, float x, float y);
void SetCueListener(CueListener listener);

// B8b: the game's own positioned sounds (not ours), e.g. Shank arming a gun. Game thread; must be quick.
using SoundListener = void (*)(const char* name, float x, float y);
void SetSoundListener(SoundListener listener);

// B8e: the camera's pan for a sound at x: (x - camera centre x) / camera half-width, as the game computes it
// (with B8f on, the camera centre saved before it's replaced by Shank's). False if the listener isn't known yet.
bool CameraPan(float x, float* pan);

// B8f: every game sound pans around Shank (the user, 2026-09-26). The engine copies the camera centre and half-size
// into four sound globals once a frame (0x55b0d0, the only writer; RE-NOTES "Every engine pan reads the same four
// globals"); right after it, the centre is replaced by Shank's position, so his own sounds are centred and
// everything else pans around him. Off, or while his position isn't known: the camera, as the game does.
bool InstallPanHook();                  // byte-checked
// B30-3: game sounds whose name contains a key play at that volume factor (FMOD Event::start hooked in fmod_event.dll).
bool InstallVolumeHook();
// B32: logs the game's volume settings and FMOD's applied category volumes when they change (game UI thread; every 0.5 s).
void PollVolumes(const char* what);
// B34: called on the game's thread after each per-frame sound update (while a level runs).
void SetFrameCallback(void (*callback)());
// B33: the game's volume settings every 100 ms for the first 15 s after launch (our thread; no FMOD calls).
void StartEarlyVolumeLog();
void SetQuieter(const std::vector<std::pair<std::string, float>>& list);
bool InstallPanHookAt(unsigned update);  // tests: a stand-in with the same convention (dt on the stack, esi/edi)
void SetShankCentre(bool known, float x, float y);  // the cue thread, every tick
void SetPanAroundShank(bool on);
bool PanAroundShank();
bool TogglePanAroundShank();  // returns the new state

}  // namespace sound_hooks
