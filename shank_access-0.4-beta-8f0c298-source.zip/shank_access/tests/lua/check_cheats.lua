-- Run by tools/loadtest50.py after loading Shank's stategraph (Lua 5.0; both builds: the rule is in the shared
-- stategraphutil.lua patch, tools/make_windup_patch.py). B60, test mode's cheats. Asserts:
--   A11Y_CHEATS is two NullTransitions: HasTag("a11y_cheat_health") with health above 0 and below full -> HealthDelta
--   to full (as a percent); HasTag("a11y_cheat_grenades") with fewer than 5 grenades and outside an attack
--   state -> one more grenade (AddInventory, the pickups' action; B60b);
--   every state from stategraphs/shank/ (but nis.lua and death.lua) starts its transitions with them, in that order;
--   no state of those two files has them, and no other stategraph's state does.
local function src_of(st)
  return string.gsub(string.lower(st.source_file or ""), "\\", "/")
end

local function has_tag(cond, tag)
  if type(cond) ~= "table" then return false end
  if cond.type == "hastag" and cond.tag == tag and not cond.nott then return true end
  for _, c in ipairs(cond.children or {}) do
    if has_tag(c, tag) then return true end
  end
  return false
end

if type(A11Y_CHEATS) ~= "table" or table.getn(A11Y_CHEATS) ~= 6 then error("the cheats weren't built") end
-- B67: test mode's spawns: each gated only by its own tag, one SpawnGameObject of the game's own weapon pickup, thrown
-- up in front of him as the game drops a carried one
for i, spec in ipairs({ { "a11y_spawn_minigun", "props/itemminigun" }, { "a11y_spawn_flamethrower", "props/itemflamethrower" },
                        { "a11y_spawn_health", "props/health_pickup" }, { "a11y_spawn_grenades", "props/grenadepickup" } }) do  -- (B68)
  local t = A11Y_CHEATS[2 + i]
  local s = t.actions and t.actions[1]
  if not (t.condition and t.condition.type == "hastag" and t.condition.tag == spec[1] and not t.condition.nott) then
    error(spec[1] .. ": not gated by its tag alone")
  end
  if not (s and s.Type == "SpawnGameObject" and s.name == spec[2] and s.state == "idle" and table.getn(t.actions) == 1) then
    error(spec[1] .. ": doesn't spawn " .. spec[2])
  end
end
local health, grenades = A11Y_CHEATS[1], A11Y_CHEATS[2]
for _, t in ipairs(A11Y_CHEATS) do
  if t.type ~= "null" then error("a cheat rule isn't a NullTransition") end
end
if not has_tag(health.condition, "a11y_cheat_health") then error("infinite health isn't gated by its tag") end
if not has_tag(grenades.condition, "a11y_cheat_grenades") then error("infinite grenades isn't gated by its tag") end
local a = health.actions and health.actions[1]
if not (a and a.Type == "healthdelta" and a.aspercent and a.amount == 1) then error("infinite health doesn't refill to full") end
a = grenades.actions and grenades.actions[1]
if not (a and a.Type == "CounterAction" and a.name == "grenades" and a.inventory and a.action == "add" and a.value == 1) then
  error("infinite grenades doesn't add a grenade")
end
local function lacks_attack(cond)
  if type(cond) ~= "table" then return false end
  if cond.type == "hastag" and cond.tag == "attack" and cond.nott then return true end
  for _, c in ipairs(cond.children or {}) do
    if lacks_attack(c) then return true end
  end
  return false
end
if not lacks_attack(grenades.condition) then error("infinite grenades can refill during a throw") end

local with, without = 0, 0
for _, st in ipairs(ShankStates) do
  local src = src_of(st)
  local t = st.transitions or {}
  local skip = string.find(src, "/nis.lua", 1, true) or string.find(src, "/death.lua", 1, true)
  local shanks = string.find(src, "stategraphs/shank/", 1, true) or string.find(src, "stategraphs_shank_", 1, true)  -- (patched files' harness names)
  if skip or not shanks then
    for i = 1, table.getn(t) do
      if t[i] == health or t[i] == grenades then error("state " .. tostring(st.name) .. " (" .. src .. ") has the cheats") end
    end
    without = without + 1
  else
    if t[1] ~= health or t[2] ~= grenades then error("state " .. tostring(st.name) .. " (" .. src .. ") doesn't start with the cheats") end
    with = with + 1
  end
end
if with < 500 then error("only " .. with .. " of Shank's states have the cheats") end
-- B67d: the carry reports, right after the cheats, in every state from carryweapon_<weapon>.lua and in no other
if type(A11Y_CARRY) ~= "table" then error("the carry reports weren't built") end
local carrying = { minigun = 0, flamethrower = 0 }
for _, st in ipairs(ShankStates) do
  local src = src_of(st)
  local t = st.transitions or {}
  for weapon, rule in pairs(A11Y_CARRY) do
    local from = string.find(src, "carryweapon_" .. weapon .. ".lua", 1, true) ~= nil
    local has = false
    for i = 1, table.getn(t) do has = has or t[i] == rule end
    if from and t[7] ~= rule then error("state " .. tostring(st.name) .. " (" .. src .. ") lacks the " .. weapon .. " carry report") end
    if has and not from then error("state " .. tostring(st.name) .. " (" .. src .. ") has the " .. weapon .. " carry report") end
    if from then carrying[weapon] = carrying[weapon] + 1 end
  end
end
if carrying.minigun < 10 or carrying.flamethrower < 10 then error("too few carry states") end
print("carry reports: " .. carrying.minigun .. " minigun states, " .. carrying.flamethrower .. " flamethrower states")
print("cheats: " .. with .. " of Shank's states start with them, " .. without .. " (nis / death) don't")
