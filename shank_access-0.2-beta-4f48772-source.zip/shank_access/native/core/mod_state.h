#pragma once
// B38-3 (the user, 2026-09-30: "Add f11 to fully disable the mod. The mod should announce "Shank Access off" and disable
// everything so the game acts like the mod isn't installed. The only thing the mod should do at this point is listen for
// f11 and reactivate once it's pressed."): whether the mod is on. Off, every hook passes straight through (our own a11y/
// Lua messages are still swallowed: the patched scripts can't be unloaded), nothing is spoken, played or logged, and only
// F11 is listened for. Not saved: every start is on.
#include <atomic>

namespace mod_state {

inline std::atomic<bool>& Flag() {
    static std::atomic<bool> on{true};
    return on;
}
inline bool Active() { return Flag().load(std::memory_order_relaxed); }
inline void SetActive(bool on) { Flag().store(on, std::memory_order_relaxed); }

}  // namespace mod_state
