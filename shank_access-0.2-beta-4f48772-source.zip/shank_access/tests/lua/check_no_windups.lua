-- Run by tools/loadtest50.py after loading a non-goon stategraph (Shank's), B8-4: the patched State() must
-- not add wind-up reports outside stategraphs/goon/.
local function walk(t, seen)
  if type(t) ~= "table" or seen[t] then return 0 end
  seen[t] = true
  local n = 0
  if t.Type == "playsound" and type(t.sound) == "string" and string.find(t.sound, "a11y/en_windup", 1, true) == 1 then n = 1 end
  for _, v in pairs(t) do n = n + walk(v, seen) end
  return n
end
local n = walk(StateGraph, {})
if n > 0 then error(n .. " wind-up reports in a non-goon stategraph") end
print("  no wind-up reports (ok)")
return true
