"""B54-2: the setup's staged install (tools/setup/shank_access_setup.py sync): only files whose content differs are
written, the old install's files the new one doesn't have are removed, the player's settings stay.

Run: .venv/Scripts/python -m unittest discover -s tests -v
"""
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools", "setup"))
import shank_access_setup as setup  # noqa: E402


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)


class SyncTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.stage = os.path.join(self.tmp.name, "stage")
        self.target = os.path.join(self.tmp.name, "game")

    def tearDown(self):
        self.tmp.cleanup()

    def test_switch_changes_only_what_differs(self):
        # the old install (the other build): a DLL, its own patch, a patch both builds have (different content)
        old = {"bin/shank_access.dll": b"dll", "data-pc/stategraphs/shank/shank_transitions.lua": b"steam only",
               "data-pc/stategraphs/stategraphutil.lua": b"steam util", "bin/shank_access_build.txt": b"steam"}
        for rel, data in old.items():
            write(os.path.join(self.target, rel), data)
        write(os.path.join(self.target, setup.USER_INI), b"[keys]")
        new = {"bin/shank_access.dll": b"dll", "data-pc/stategraphs/stategraphutil.lua": b"classic util",
               "bin/shank_access_build.txt": b"classic"}
        for rel, data in new.items():
            write(os.path.join(self.stage, rel), data)
        dll = os.path.join(self.target, "bin", "shank_access.dll")
        before = os.stat(dll).st_mtime_ns
        written, kept, removed = setup.sync(self.stage, self.target, list(new), list(old))
        self.assertEqual((written, kept, removed), (2, 1, 1))
        self.assertEqual(os.stat(dll).st_mtime_ns, before)  # the same DLL: not rewritten
        self.assertEqual(open(os.path.join(self.target, "data-pc", "stategraphs", "stategraphutil.lua"), "rb").read(),
                         b"classic util")
        self.assertFalse(os.path.exists(os.path.join(self.target, "data-pc", "stategraphs", "shank")))  # file and folder gone
        self.assertTrue(os.path.exists(os.path.join(self.target, setup.USER_INI)))  # the player's settings stay

    def test_both_directions(self):
        # B54-7 (the user: "the mod installer can go in both directions, normal > classic > normal"): each switch leaves
        # exactly the other build's set, whichever way it goes.
        sets = {
            "steam": {"bin/shank_access.dll": b"dll", "bin/shank_access_build.txt": b"steam",
                      "data-pc/stategraphs/shank/shank_transitions.lua": b"steam transitions",
                      "data-pc/stategraphs/stategraphutil.lua": b"steam util", "bin/shank_access_paths.txt": b"steam paths"},
            "classic": {"bin/shank_access.dll": b"dll", "bin/shank_access_build.txt": b"classic",
                        "data-pc/stategraphs/stategraphutil.lua": b"classic util", "bin/shank_access_paths.txt": b"classic paths"},
        }
        installed = []
        for build in ("steam", "classic", "steam", "classic"):
            stage = os.path.join(self.tmp.name, "stage_" + build + str(len(installed)))
            for rel, data in sets[build].items():
                write(os.path.join(stage, rel), data)
            setup.sync(stage, self.target, list(sets[build]), installed)
            installed = list(sets[build])
            have = {}
            for dirpath, _, names in os.walk(self.target):
                for n in names:
                    p = os.path.join(dirpath, n)
                    have[os.path.relpath(p, self.target).replace(os.sep, "/")] = open(p, "rb").read()
            self.assertEqual(have, sets[build], "after switching to " + build)
            self.assertEqual(setup.installed_build(self.target) if os.path.exists(
                os.path.join(self.target, setup.VERSION_FILE)) else build, build)

    def test_patch_set_per_build(self):
        # each build gets its own patch set and vanilla hashes (apply_patches)
        data = os.path.join(self.tmp.name, "data")
        game = os.path.join(self.tmp.name, "game_src")
        write(os.path.join(game, "data", "a.lua"), b"-- a\n")
        write(os.path.join(game, "data", "b.lua"), b"-- b\n")
        write(os.path.join(data, "mod", "pristine.json"), b"{}")
        write(os.path.join(data, "mod", "pristine-classic.json"), b"{}")
        op = b'{"ops": [{"op": "append", "text": "-- ours\\n"}]}'
        write(os.path.join(data, "mod", "patches", "data", "a.lua.patch.json"), op)
        write(os.path.join(data, "mod", "patches-classic", "data", "b.lua.patch.json"), op)
        real = setup.DATA
        setup.DATA = data
        try:
            for build, want in (("steam", "data-pc/a.lua"), ("classic", "data-pc/b.lua")):
                written = []
                setup.apply_patches(game, os.path.join(self.tmp.name, "out_" + build), written, lambda m: None, build)
                self.assertEqual(written, [want])
        finally:
            setup.DATA = real

    def test_keep_as_store_and_routes_cache(self):
        # B56-2: a switch keeps the old build's scripts and bin files as its store (with who made it)
        rels = ["bin/shank_access.dll", "bin/shank_access_paths.txt", setup.PATHS_KEY, "bin/shank_access_build.txt",
                "data-pc/stategraphs/stategraphutil.lua"]
        for rel in rels:
            write(os.path.join(self.target, rel), rel.encode())
        self.assertEqual(setup.keep_as_store(self.target, "classic", "0.3-beta-x", rels), 4)  # (not the DLL)
        store = setup.store_dir(self.target, "classic")
        self.assertFalse(os.path.exists(os.path.join(store, "bin", "shank_access.dll")))
        self.assertEqual(open(os.path.join(store, "made_by.txt")).read().strip(), "0.3-beta-x")
        self.assertEqual(open(os.path.join(store, "build.txt")).read().strip(), "classic")
        # B56-3: the routes are reused when the key matches (active or in this build's store), else not
        write(os.path.join(self.target, setup.PATHS_KEY), b"k1\n")
        write(os.path.join(self.target, "bin", "shank_access_paths.txt"), b"active routes")
        self.assertEqual(setup.cached_paths(self.target, "steam", "k1"), b"active routes")
        write(os.path.join(store, setup.PATHS_KEY), b"k2\n")
        write(os.path.join(store, "bin", "shank_access_paths.txt"), b"classic routes")
        self.assertEqual(setup.cached_paths(self.target, "classic", "k2"), b"classic routes")
        self.assertIsNone(setup.cached_paths(self.target, "classic", "k3"))
        # the key changes with the geometry and the build
        self.assertNotEqual(setup.paths_key(b"geo a", "steam"), setup.paths_key(b"geo b", "steam"))
        self.assertNotEqual(setup.paths_key(b"geo a", "steam"), setup.paths_key(b"geo a", "classic"))

    def test_setup_lock(self):
        # B57-1: the lock holds setup's own process id while it works and goes when it ends (even on an error)
        os.makedirs(self.target)
        lock = os.path.join(self.target, setup.LOCK)
        with setup.SetupLock(self.target):
            self.assertEqual(open(lock).read().strip(), str(os.getpid()))
        self.assertFalse(os.path.exists(lock))
        with self.assertRaises(RuntimeError):
            with setup.SetupLock(self.target):
                raise RuntimeError()
        self.assertFalse(os.path.exists(lock))
        # another live setup's lock: refused (and left in place); a dead process's lock: taken over
        write(lock, ("%d\n" % os.getppid()).encode())
        with self.assertRaises(setup.SetupError):
            with setup.SetupLock(self.target):
                pass
        self.assertTrue(os.path.exists(lock))
        write(lock, b"4294967293\n")
        with setup.SetupLock(self.target):
            pass
        self.assertFalse(os.path.exists(lock))

    def test_install_into_a_new_folder(self):
        # (found by the 0.3-beta release check: the lock was written before anything made a new --target folder)
        real = setup.check_game, setup._install
        setup.check_game = lambda game: "steam"
        setup._install = lambda game, target, *a: os.path.exists(os.path.join(target, setup.LOCK))
        try:
            self.assertTrue(setup.install("game", os.path.join(self.tmp.name, "new", "folder")))
        finally:
            setup.check_game, setup._install = real

    def test_wait_for_game(self):
        real = setup.game_running
        state = {"running": True, "asked": 0}

        def ask():
            state["asked"] += 1
            state["running"] = False  # (the player closed the game, then chose Retry)
            return True
        setup.game_running = lambda: state["running"]
        try:
            setup.wait_for_game("g", "g", ask)
            self.assertEqual(state["asked"], 1)
            state["running"] = True
            with self.assertRaises(setup.SetupError):
                setup.wait_for_game("g", "g", lambda: False)  # Cancel
            with self.assertRaises(setup.SetupError):
                setup.wait_for_game("g", "g")  # (the command line: no window to ask)
            setup.wait_for_game("other", "g")  # (a test target, not the game folder: no wait)
        finally:
            setup.game_running = real

    def test_commit_file_in_use(self):
        # B57-1: a file that can't be replaced (here read-only; in play, the loaded DLL): a clear message, no temp files left
        dll = os.path.join(self.target, "bin", "shank_access.dll")
        write(dll, b"old dll")
        os.chmod(dll, 0o444)
        write(os.path.join(self.stage, "bin", "shank_access.dll"), b"new dll")
        try:
            with self.assertRaises(setup.SetupError) as e:
                setup.commit(self.stage, self.target, ["bin/shank_access.dll"], "steam", "v1", "steam")
            self.assertIn("in use", str(e.exception))
            self.assertIn("shank_access.dll", str(e.exception))
            self.assertEqual(os.listdir(os.path.join(self.target, "bin")), ["shank_access.dll"])
        finally:
            os.chmod(dll, 0o666)

    def test_commit_keeps_the_mods_own_store(self):
        # B57-1: the game was started during a switch's staging and the mod moved the old (classic) set to its store
        # itself: the commit keeps that store instead of replacing it with an empty one
        store = setup.store_dir(self.target, "classic")
        write(os.path.join(store, "bin", "shank_access_paths.txt"), b"classic routes")
        write(os.path.join(store, "made_by.txt"), b"v1\n")
        write(os.path.join(store, "build.txt"), b"classic\n")
        write(os.path.join(self.target, setup.LIST), b"bin/shank_access_paths.txt\nbin/shank_access_build.txt\n")
        write(os.path.join(self.stage, "bin", "shank_access_paths.txt"), b"steam routes")
        write(os.path.join(self.stage, "bin", "shank_access_build.txt"), b"steam")
        setup.commit(self.stage, self.target, ["bin/shank_access_paths.txt", "bin/shank_access_build.txt"], "steam", "v1",
                     "classic")
        self.assertEqual(open(os.path.join(store, "bin", "shank_access_paths.txt"), "rb").read(), b"classic routes")
        self.assertEqual(open(os.path.join(self.target, "bin", "shank_access_paths.txt"), "rb").read(), b"steam routes")

    def test_sources_and_remade_store(self):
        # B58: the kept copy of a build's sources (laid out like the game folder) and a remade set becoming its store
        game = os.path.join(self.tmp.name, "game_src")
        write(os.path.join(game, "data", "campaigns.lua"), b"campaigns")
        write(os.path.join(game, "data", "attributes", "props", "barrel.lua"), b"barrel")
        write(os.path.join(game, "data-pc", "levels", "campaign_1a", "campaign_1a.lua"), b"level")
        write(os.path.join(game, "data-pc", "levels", "campaign_1a", "campaign_1a.slev"), b"slev")
        write(os.path.join(game, "data-pc", "levels", "campaign_1a", "campaign_1a.zip"), b"art")  # (not read: not kept)
        write(os.path.join(game, "data-pc", "levels", "menu", "menu.lua"), b"menu")  # (not a campaign level)
        self.assertFalse(setup.has_sources(self.target, "classic"))
        setup.save_sources(game, self.target, "classic")
        self.assertTrue(setup.has_sources(self.target, "classic"))
        self.assertFalse(setup.has_sources(self.target, "steam"))
        kept = setup.sources_dir(self.target, "classic")
        self.assertTrue(os.path.isfile(os.path.join(kept, "data-pc", "levels", "campaign_1a", "campaign_1a.slev")))
        self.assertTrue(os.path.isfile(os.path.join(kept, "data", "attributes", "props", "barrel.lua")))
        self.assertFalse(os.path.exists(os.path.join(kept, "data-pc", "levels", "campaign_1a", "campaign_1a.zip")))
        self.assertFalse(os.path.exists(os.path.join(kept, "data-pc", "levels", "menu")))
        # the remade set replaces the old store whole (an old file the new set doesn't have goes)
        write(os.path.join(setup.store_dir(self.target, "classic"), "data-pc", "old.lua"), b"old")
        rels = ["bin/shank_access_paths.txt", "data-pc/stategraphs/stategraphutil.lua", "bin/shank_access.dll"]
        for rel in rels:
            write(os.path.join(self.stage, rel), rel.encode())
        setup.put_store(self.stage, self.target, "classic", "v2", rels)
        store = setup.store_dir(self.target, "classic")
        self.assertEqual(setup.store_made_by(self.target, "classic"), "v2")
        self.assertTrue(os.path.isfile(os.path.join(store, "bin", "shank_access_paths.txt")))
        self.assertFalse(os.path.exists(os.path.join(store, "bin", "shank_access.dll")))  # (shared files aren't stored)
        self.assertFalse(os.path.exists(os.path.join(store, "data-pc", "old.lua")))
        self.assertIsNone(setup.store_made_by(self.target, "steam"))

    def test_installed_build_with_files_stored(self):
        write(os.path.join(self.target, setup.VERSION_FILE), b"0.3-beta-x")
        os.makedirs(os.path.join(self.target, setup.STORES, "classic"))
        self.assertIsNone(setup.installed_build(self.target))  # (the mod moved its files away: a switch to offer)

    def test_installed_build(self):
        self.assertIsNone(setup.installed_build(self.target))
        write(os.path.join(self.target, setup.VERSION_FILE), b"0.2-beta-x")
        self.assertEqual(setup.installed_build(self.target), "steam")  # (installs before B54 were all for Steam)
        write(os.path.join(self.target, setup.BUILD_FILE), b"classic")
        self.assertEqual(setup.installed_build(self.target), "classic")


if __name__ == "__main__":
    unittest.main()
