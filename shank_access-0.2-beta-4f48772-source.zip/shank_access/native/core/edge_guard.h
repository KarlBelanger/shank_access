#pragma once
// B7-2 safe edges (the user, 2026-09-26: stop Shank "at all but very small drops, but another tap of the
// direction should send him over... This is a safety system, not an invisible wall"). Toggled with E.
//
// How: Klei's own anti-fall rule (the last entry of Shank's REACTIONS) stops him at an edge when the ground
// has the `noFall` tag (the game hops him back: `backtoledge`). We hook HasTag_ParseNode::Evaluate
// (0x4f92c0) and answer "yes" for (ground, nofall) while the guard is active; the rule does the rest.
// The guard is decided on the cue thread from the level geometry and his tracked position.
#include "position.h"

namespace edge_guard {

constexpr float kSmallDropPx = 80.f;     // drops this deep or less (the steps he hops, 1 tile) don't stop him
constexpr float kGuardRangePx = 160.f;   // the guard is on within this of the edge (the game's facingedge: ~1.5 tiles)
constexpr float kBounceVx = 30.f;        // moving away from the edge at least this fast (px/s) = the game hopped him back
constexpr float kRestVx = 40.f;          // at rest: slower than this
constexpr unsigned kRestMs = 150;        // ...for this long after a stop arms "another tap"
constexpr float kGoVx = 60.f;            // then moving toward the edge at least this fast = let him go
constexpr float kReleaseAwayPx = 3 * 64.f;  // a let-go edge is guarded again once he's this far from it...
constexpr unsigned kReleaseMs = 5000;       // ...or after this long, or on another surface

void SetEnabled(bool on);
bool Enabled();
bool Toggle();  // returns the new state

// Each cue tick (any thread but the game's): works out whether the guard is on.
void Update(unsigned now_ms, const position::Pos& s);
bool Active();  // what the hook answers for (ground, nofall)
void Reset();   // a level load

// Checks the function's first bytes, then hooks it. False (logged) if anything doesn't match.
bool Install();
// For native/tests: hooks a stand-in of the same convention, no byte check.
bool InstallAt(unsigned evaluate);

// The hashes the hook looks for (sdbm of the lowercased name, 0x43d060).
constexpr unsigned kHashNoFall = 0xb476217c;
constexpr unsigned kHashGround = 0x919d2307;
// HasTag_ParseNode fields (RE-NOTES "Tag conditions and the anti-fall rule").
constexpr unsigned kNodeTag = 0x20, kNodeNott = 0x24, kNodeSource = 0x28;

}  // namespace edge_guard
