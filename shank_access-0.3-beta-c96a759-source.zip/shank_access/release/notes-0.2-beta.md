The first public beta of Shank Access, a screen reader and audio accessibility mod for the Steam version of Shank.

## Installing

Download **shank-access-setup.exe** below and run it. Setup finds Shank in your Steam libraries (or lets you choose the
folder), then installs the mod in about two minutes. Run it again later to update, reinstall or uninstall. The README
on the repository's main page covers the keys, the sounds, waypoint mode, controller support and how to report a
problem.

## In this beta

- Menus, dialogs and tutorials read aloud through your screen reader or a SAPI voice.
- Positional sounds for ledges, walls, jump targets, pickups, enemies, enemy attacks and hazards, with a Learn sounds
  list in the mod menu.
- Waypoint mode, which guides you from checkpoint to checkpoint one move at a time.
- Health, grenade, pickup, enemy and boss readouts, and lock-on for enemy sounds.
- A mod menu for speech, sounds, announcements and keys, with controller bindings.
- Feedback marks (F2). A session with a mark saves its logs as one zip file in Documents\Shank Access\logs, ready to
  attach to an issue.

Single player only. Every single-player level has been played through with the mod, but expect rough spots, and
please report them.

Version 0.2-beta-4f48772. The source zip below has the full source for this version.
