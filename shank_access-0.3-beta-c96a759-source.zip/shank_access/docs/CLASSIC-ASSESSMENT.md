# The Steam "classic" branch: what supporting it would take (assessment, 2026-10-07)

The user switched Steam to the **classic** beta branch (it restores older content that was cut) and asked what it would
take to make the mod work on it, noting that it is said to be the same build as the non-Steam release. Static analysis
only; nothing built. Scratch scripts were not kept (they used deploy.apply_ops, geometry.analyse and pefile).

## The classic exe
- `bin/Shank.exe` 4,935,680 bytes, SHA-256 `e75f922996b3a7828b3a62cf9ce7e17eab5d83138b219aa5cc676c3c5d52fc3c`.
- Linked 2014-03-18 (the current Steam exe: 2012-09-20). PDB path `c:\klei\archive\ShankPC_original\Shank\obj\Win32\Production\Shank\Shank.pdb`:
  a 2014 rebuild of the **original** PC source tree from Klei's archive.
- Same image base 0x400000, DllCharacteristics 0x8000 (no ASLR): addresses are still fixed per exe.
- Sections shifted: `.data` at 0x47f000 (was 0x484000). Same imports, including `steam_api.dll` and `DINPUT8.dll` (our
  proxy still loads: the mod started and disabled itself on the hash check, a11y.log 2026-10-07 05:05).
- Still **Lua 5.0**.
- The same code, recompiled: the hooked functions are there with the same prologues and calling conventions,
  a little lower. Found so far:
  - HasTag_ParseNode::Evaluate 0x4f8c50 (was 0x4f92c0)
  - the per-frame sound update 0x559540 (was 0x55b0d0)
  - SwfScreen::Update 0x5521e0 (was 0x553d50)
  - PlaySound 0x558f80 (was 0x55ab10; esi = name, same body); the FMOD EventSystem* global 0xadad20 (was 0xadfdf0)
  - the intro movie calls: introscee.usm referenced at 0x790038, introtomain.usm at 0x7900ee (were 0x792c37 / 0x792ced)
  - RTTI is present for every class we use (cShankSimulation, cGameItemManager, cShankGameItem,
    Input::XInputController, HasTag_ParseNode, cSetBoundsAction, SwfScreen, SwfSymbol, SwfExternalInterface).
  - The rest have short prologues that match many places; they need the usual string / RTTI / call-graph work.
- We have **no copy of the current Steam exe** (Steam replaced it). Not needed for this work: every address was found
  the first time without one, and RE-NOTES records how.

## The classic data
Compared against mod/pristine.json (our hashes of the current Steam files):
- **Scripts changed:** 59 goon stategraph files, 47 of Shank's, 24 prop stategraphs, character and prop attributes,
  gameconstants, conditionutil, commonpresentation. `stategraphs/props/pickup_common_actions.lua` does not exist.
- **Shank moves slower:** constants.lua has JUMP_SPEED 11.5 MPS (was 12.5), WALL_JUMP_SPEED 12.5 (was 13.5); run speeds
  unchanged. The jump model, the path graph and every route are calibrated for the current build.
- **No anti-fall rule:** classic shank_transitions.lua has no `noFall` / `GroundHasTag` / `REACTIONS` table (a different,
  older layout). Safe edges (E) answers that rule's question, so it would do nothing. The exe still knows
  `facingedge`, so we could add the rule ourselves in our patch (hypothesis).
- **Our 29 script patches:** 16 apply as they are (commonpresentation, stategraphutil (wind-ups), most hazards and
  projectiles); 13 fail: the 9 pickup patches (they anchor on pickup_common_actions), pickup_common_actions itself,
  shank_transitions (Shank's cues and the position ping) and the two carried-weapon patches.
- **Levels:** the level scripts have small changes (1-b pretrain one pickup fewer and one enemy more, Venom of the
  Vipers 3 more enemies, the villa one fewer; the PAX demo and test levels gone). Collision: 1-a, 2-a and 2-c
  identical; 1-b train and 4-a lost a few surfaces; several others differ in details. The generated geometry and
  path files must be built per branch.
- UI: gamescreen.gfx and introscreen.gfx changed, aboutdialog.gfx is gone. Menu reading needs a check in play.
- Other files the classic branch adds or restores (textures, animations, fx, movies) are not used by the mod.

## Right now
The deployed mod's patched scripts in data-pc/ (built from the current Steam scripts) still **override the classic
scripts** although the DLL disabled itself: an old Shank stategraph, commonpresentation and pickups mixed into the
classic game. Until the mod supports classic, uninstall it (`tools/deploy.py uninstall`) before playing the classic
branch, or switch Steam back.

## What it would take (one mod for both builds)
1. **Addresses per build.** game.h's constants and the scattered literals (about 35 addresses, plus the vtables in
   enemies, game_pads and checkpoint_jump) become a table chosen by the exe hash at startup; the hash check accepts
   both builds. Better still: find each function by a byte signature at startup, so a third build of the same code
   can work without new tables. Struct offsets (simulation bounds +0xb0, restart name +0x38, item layout) need
   checking. Medium; mostly static work, the same as the original reverse engineering but quicker.
2. **A second patch set.** deploy.py and the setup pick the patch set by the exe hash. Rebase the 13 failing patches
   onto the classic scripts (pickups without the common file: each pickup gets its own beacon and pickup report;
   Shank's transitions in the older layout; carried weapons). Regenerate the wind-up rules and run every loadtest
   check against the classic files. Medium.
3. **Safe edges:** **unsupported on classic (decided 2026-10-07).** Classic has no anti-fall rule, no step-back state and no onfall handler, so the mod would have to build the stop itself (about a batch plus tuning, low-to-medium confidence).
4. **Levels:** geometry, paths and UI text built from the classic install, deployed by the setup for that build.
   Scripted; small.
5. **Movement:** the jump model takes its speeds per build; the slower jumps change which jumps reach. Regenerate the
   path graph, check every checkpoint leg, and recalibrate from classic play logs (the movement corpus is all current
   build). **The largest part,** and it needs play testing across the campaign (the level-by-level sessions the user
   described).
6. **Testing:** the menus, the HUD readouts (health, grenades, bosses) and the cues in play, then the routes
   level by level.

## The non-Steam release
Not confirmed to be this exe. This classic exe imports steam_api.dll, so a DRM-free build cannot be byte-identical
and will have another hash. It is probably the same source, so step 1's signature search would very likely
find the same functions there too; the data would need the same comparison. Need a copy of that exe (or its hash) to
confirm.
