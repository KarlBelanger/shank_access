#include "menu_reader.h"

#include <windows.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iterator>
#include <map>

#include "announce.h"
#include "localization.h"
#include "ui_text.h"
#include "log.h"

namespace menu_reader {
namespace {

using ui_hooks::FlashValue;
using ui_hooks::UiEvent;

enum class Role { kButton, kSlider, kSpinner, kCheckbox };

// Our own names for widgets that have no label (Settings dialog, 2-2). value_text: a sibling text
// field that shows the value the way the screen does (the slider's own .value is one step off).
struct Known {
    const char* leaf;
    const char* name;
    const char* value_text;
};
const Known kKnown[] = {
    {"musicSlider", "Music volume", "musicVolumeTxt"},
    {"soundSlider", "Sound volume", "soundVolumeTxt"},
    {"modeSpinner", "Resolution", nullptr},
    {"ratioSpinner", "Aspect ratio", nullptr},
    {"adapterSpinner", "Display adapter", nullptr},
    {"rumbleSpinner", "Rumble", nullptr},
    {"cbBloom", "Bloom", nullptr},
    {"cbBlur", "Blur", nullptr},
    {"cbDisplacements", "Displacement effects", nullptr},
    {"cbFullscreen", "Fullscreen", nullptr},
    {"listBox", "Key bindings list", nullptr},  // the Controls screen (controllerconfig.gfx; B1f)
    // Weapons screen (weaponunlocksdialog.gfx, icon buttons; N1). Names as the game's own titles show
    // them where seen in logs (Chainsaw, Chain Fists, Pistols, Uzi); the rest are our guesses and are
    // replaced by the game's title once the user picks that weapon (see LearnedName).
    {"sawBtn", "Chainsaw", nullptr},
    {"chainsBtn", "Chain Fists", nullptr},
    {"macheteBtn", "Machete", nullptr},
    {"swordBtn", "Katana", nullptr},
    {"gunsBtn", "Pistols", nullptr},
    {"uziBtn", "Uzi", nullptr},
    {"shotgunBtn", "Shotgun", nullptr},
    // Unlocks screen = outfits (unlocksdialog.gfx "SELECT AN OUTFIT"; unlockBtn<index> follows the
    // OUTFITS index order in data/unlocks.lua). Our own names.
    {"unlockBtn0", "Shank outfit", nullptr},
    {"unlockBtn1", "Wildman outfit", nullptr},
    {"unlockBtn2", "Spartan outfit", nullptr},
    {"unlockBtn3", "Kung Fu outfit", nullptr},
    {"unlockBtn4", "Horror outfit", nullptr},
    {"unlockBtn5", "Disco outfit", nullptr},
    {"unlockBtn6", "Red ninja outfit", nullptr},
    {"unlockBtn7", "White ninja outfit", nullptr},
    {"unlockBtn8", "Droid outfit", nullptr},
    {"unlockBtn9", "Teddy bear outfit", nullptr},
    {"unlockBtn10", "DeathSpank outfit", nullptr},
};

// Weapons screen buttons and the title field that shows the equipped weapon of their kind.
struct WeaponSlot {
    const char* leaf;
    const char* title_field;  // sibling text field: the equipped weapon's name
};
const WeaponSlot kWeaponSlots[] = {
    {"sawBtn", "meleeTitleTxt"},   {"chainsBtn", "meleeTitleTxt"}, {"macheteBtn", "meleeTitleTxt"},
    {"swordBtn", "meleeTitleTxt"}, {"gunsBtn", "gunTitleTxt"},     {"uziBtn", "gunTitleTxt"},
    {"shotgunBtn", "gunTitleTxt"},
};

const WeaponSlot* FindWeaponSlot(const std::string& leaf) {
    for (const WeaponSlot& w : kWeaponSlots) {
        if (leaf == w.leaf) return &w;
    }
    return nullptr;
}

// Names learned at runtime: when choosing a widget makes the game write a title (the Weapons screen
// writes "Uzi" into gunTitleTxt when the Uzi is picked), that title becomes the widget's name.
SRWLOCK g_learned_lock = SRWLOCK_INIT;
std::map<std::string, std::string> g_learned;  // widget path -> the game's name for it

std::string LearnedName(const std::string& path) {
    AcquireSRWLockShared(&g_learned_lock);
    auto it = g_learned.find(path);
    std::string out = it != g_learned.end() ? it->second : std::string();
    ReleaseSRWLockShared(&g_learned_lock);
    return out;
}

const Known* FindKnown(const std::string& leaf) {
    for (const Known& k : kKnown) {
        if (leaf == k.leaf) return &k;
    }
    return nullptr;
}

bool EndsWith(const std::string& s, const char* suffix) {
    const size_t n = std::char_traits<char>::length(suffix);
    return s.size() > n && s.compare(s.size() - n, n, suffix) == 0;
}

bool StartsWithWord(const std::string& s, const char* prefix) {  // "cbBloom": prefix then uppercase
    const size_t n = std::char_traits<char>::length(prefix);
    return s.size() > n && s.compare(0, n, prefix) == 0 && std::isupper(static_cast<unsigned char>(s[n]));
}

std::string Leaf(const std::string& path) {
    const size_t dot = path.find_last_of('.');
    return dot == std::string::npos ? path : path.substr(dot + 1);
}

std::string Parent(const std::string& path) {
    const size_t dot = path.find_last_of('.');
    return dot == std::string::npos ? std::string() : path.substr(0, dot);
}

Role RoleOf(const std::string& leaf) {
    if (EndsWith(leaf, "Slider")) return Role::kSlider;
    if (EndsWith(leaf, "Spinner")) return Role::kSpinner;
    if (StartsWithWord(leaf, "cb")) return Role::kCheckbox;
    return Role::kButton;
}

const char* RoleWord(Role role) {
    switch (role) {
    case Role::kSlider: return "slider";
    case Role::kSpinner: return "selector";
    case Role::kCheckbox: return "checkbox";
    default: return "";
    }
}

// "sawBtn" -> "Saw", "listBox" -> "List box", "cbFullscreen" -> "Fullscreen".
std::string Prettify(std::string leaf) {
    for (const char* prefix : {"cb", "btn"}) {
        if (StartsWithWord(leaf, prefix)) leaf = leaf.substr(std::char_traits<char>::length(prefix));
    }
    for (const char* suffix : {"Button", "Btn", "Spinner", "Slider"}) {
        if (EndsWith(leaf, suffix)) {
            leaf = leaf.substr(0, leaf.size() - std::char_traits<char>::length(suffix));
            break;
        }
    }
    std::string out;
    for (size_t i = 0; i < leaf.size(); ++i) {
        const unsigned char c = static_cast<unsigned char>(leaf[i]);
        if (i > 0 && std::isupper(c)) {
            out += ' ';
            out += static_cast<char>(std::tolower(c));
        } else {
            out += static_cast<char>(c);
        }
    }
    if (!out.empty()) out[0] = static_cast<char>(std::toupper(static_cast<unsigned char>(out[0])));
    return out;
}

const char* KindName(FlashValue::Kind kind) {
    switch (kind) {
    case FlashValue::kBool: return "bool";
    case FlashValue::kNumber: return "number";
    case FlashValue::kText: return "text";
    case FlashValue::kOther: return "object";
    default: return "nothing";
    }
}

std::string ReadText(const Reader& read, void* movie, const std::string& path) {
    const FlashValue v = read(movie, path);
    if (v.kind == FlashValue::kText) return v.text;
    if (v.kind == FlashValue::kNumber) {
        char buf[32];
        _snprintf_s(buf, sizeof buf, _TRUNCATE, "%g", v.n);
        return buf;
    }
    return std::string();
}

std::string Name(const Reader& read, void* movie, const std::string& path, Role role, const Known* known) {
    std::string label = ReadText(read, movie, path + ".label");
    if (label.empty() && role == Role::kButton) label = ReadText(read, movie, path + ".textField.text");
    if (!label.empty()) return localization::Translate(label);
    const std::string learned = LearnedName(path);
    if (!learned.empty()) return learned;
    if (known) return known->name;
    return Prettify(Leaf(path));
}

// CLIK keeps a widget's disabled state in _disabled; a path lookup may not run the `disabled`
// getter (as with `selected`, 2-2b). True if either reads as true.
bool IsDisabled(const Reader& read, void* movie, const std::string& path) {
    for (const char* member : {".disabled", "._disabled"}) {
        const FlashValue v = read(movie, path + member);
        if (v.kind == FlashValue::kBool) return v.b;
    }
    return false;
}

// The value as shown, plus where it came from (for the log).
std::string Value(const Reader& read, void* movie, const std::string& path, Role role, const Known* known,
                  std::string* source) {
    switch (role) {
    case Role::kSlider: {
        if (known && known->value_text) {
            const std::string p = Parent(path);
            *source = (p.empty() ? std::string() : p + ".") + known->value_text + ".text";
            const std::string t = ReadText(read, movie, *source);
            if (!t.empty()) return t;
        }
        *source = path + ".value";
        const FlashValue v = read(movie, *source);
        if (v.kind != FlashValue::kNumber) return std::string();
        char buf[32];
        _snprintf_s(buf, sizeof buf, _TRUNCATE, "%.0f", std::floor(v.n + 0.5));
        return buf;
    }
    case Role::kSpinner:
        for (const char* member : {".textField.text", ".selectedItem", ".selectedItem.label"}) {
            *source = path + member;
            const std::string t = ReadText(read, movie, *source);
            if (!t.empty()) return localization::Translate(t);
        }
        *source = "(none)";
        return std::string();
    case Role::kCheckbox: {
        // CLIK keeps the state in _selected; a path lookup may not run the `selected` getter
        // (2-2 test: `.selected` gave nothing).
        std::string tried;
        for (const char* member : {".selected", "._selected"}) {
            const FlashValue v = read(movie, path + member);
            if (v.kind == FlashValue::kBool) {
                *source = tried + path + member;
                return v.b ? "checked" : "not checked";
            }
            tried += std::string(member) + " gave " + KindName(v.kind) + "; ";
        }
        *source = tried;
        return std::string();
    }
    default:
        return std::string();
    }
}

std::string Join(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (b.empty()) return a;
    return a + ", " + b;
}

// Where a slider's shown value is written: its text field ("<parent>.musicVolumeTxt.text") or its
// own ".value". Empty for other roles.
std::string ValueSource(const std::string& path, Role role, const Known* known) {
    if (role != Role::kSlider) return std::string();
    if (known && known->value_text) {
        const std::string p = Parent(path);
        return (p.empty() ? std::string() : p + ".") + known->value_text + ".text";
    }
    return path + ".value";
}

std::string ValueText(const FlashValue& v) {
    if (v.kind == FlashValue::kText) return v.text;
    if (v.kind == FlashValue::kNumber) {
        char buf[32];
        _snprintf_s(buf, sizeof buf, _TRUNCATE, "%.0f", std::floor(v.n + 0.5));
        return buf;
    }
    return std::string();
}

SRWLOCK g_lock = SRWLOCK_INIT;
std::string g_path;
void* g_movie = nullptr;
unsigned g_ms = 0;
bool g_have = false;
std::string g_focus_value;   // the value spoken with the current focus
std::string g_focus_prefix;  // the screen title / dialog text spoken before it (kept for a late re-announce)
std::string g_change_path, g_change_value;  // the last value change spoken
unsigned g_change_ms = 0;
// 2-5a: the dialog text the game just wrote (headerTxt / bodyTxt), waiting for the dialog's first
// focus. An empty write clears it (the busy "Please wait" dialog is written and cleared at once).
std::string g_dialog_header, g_dialog_body, g_dialog_parent;
void* g_dialog_movie = nullptr;
unsigned g_dialog_ms = 0;

// 2-5b: screen titles (our own names), found from the widget the game focuses when a screen opens.
// Widgets shared by several screens (backBtn, quitBtn, dialog buttons) are deliberately absent.
struct ScreenWidgets {
    const char* title;
    const char* prefix;              // common path prefix
    const char* const* leaves;       // widget names after the prefix; nullptr = any name starting with prefix
};
const char* const kMainMenu[] = {"spBtn", "mpBtn", "achievementsBtn", "leaderboardsBtn", "helpBtn", "quitBtn", nullptr};
const char* const kHelp[] = {"howToPlayBtn", "controlsBtn", "settingsBtn", "creditsBtn", "eraseSaveDataBtn",
                             "conceptArtBtn", nullptr};
const char* const kDifficulty[] = {"normalBtn", "hardBtn", nullptr};
const char* const kSettings[] = {"musicSlider", "soundSlider", "rumbleSpinner", "modeSpinner", "ratioSpinner",
                                 "adapterSpinner", "cbBloom", "cbBlur", "cbDisplacements", "cbFullscreen",
                                 "applyBtn", "closeBtn", "resetBtn", "defaultsBtn", nullptr};
const char* const kPause[] = {"resumeBtn", "lastCheckpointBtn", "unlocksBtn", "weaponsBtn", "helpOptionsBtn", nullptr};
const char* const kWeapons[] = {"sawBtn", "gunsBtn", "macheteBtn", "swordBtn", "uziBtn", "shotgunBtn", "chainsBtn",
                                nullptr};
const char* const kControls[] = {"listBox", "btnPrevious", "btnNext", "btnReset", "btnSave", "btnLoad", nullptr};
const char* const kHowToPlay[] = {"nextBtn", "prevBtn", nullptr};
const char* const kLobby[] = {"player0.readyBtn", "player1.readyBtn", nullptr};
// B13-1 (widget names from conceptartscreen.gfx / aboutdialog.gfx; About Us shares the Help & Options buttons
// except forumsBtn, so only that one names it).
const char* const kConceptArt[] = {"imageSpinner", "nextBtn", "prevBtn", nullptr};
const char* const kAbout[] = {"forumsBtn", nullptr};
const ScreenWidgets kScreens[] = {
    {"Main menu", "_level0.controls.", kMainMenu},
    {"Help and options", "_level0.controls.", kHelp},
    {"Choose difficulty", "_level0.controls.", kDifficulty},
    {"Settings", "_level0.", kSettings},
    {"Pause menu", "_level0.", kPause},
    {"Weapons", "_level0.", kWeapons},
    {"Controls", "_level0.", kControls},
    {"How to play", "_level0.", kHowToPlay},
    {"Multiplayer lobby", "_level0.", kLobby},
    {"Unlocks", "_level0.unlockBtn", nullptr},
    {"Concept art", "_level0.controls.", kConceptArt},
    {"About us", "_level0.controls.", kAbout},
};

std::string g_last_title;  // the last screen title spoken
// 2-5b-3: per movie, the widget last focused there (CLIK restores it silently); the movies in the
// order they last had the focus (most recent last); the movies whose screen is shown.
std::map<void*, std::string> g_last_path_in;
std::vector<void*> g_focus_history;
std::map<void*, bool> g_screen_shown_movie;
std::function<bool(void*)> g_alive;  // liveness of stored movie pointers (see SetMovieAliveCheck)
std::map<void*, unsigned> g_probe;   // movie -> when it was shown without focus (OnScreenTick asks)
std::map<void*, std::vector<std::string>> g_paths_in;  // movie -> every path that had the focus there
struct PendingRestore {
    bool active = false;
    void* movie = nullptr;
    std::string path;
    unsigned due = 0;
};
PendingRestore g_pending;  // 2-5b-7: a delayed "back on this screen" announcement
struct PendingPage {
    bool active = false;
    void* movie = nullptr;
    std::string parent;
    unsigned due = 0;
};
PendingPage g_page;  // N3: How to Play Next/Prev: read the page's name once the new frame shows
std::map<void*, std::string> g_page_text;  // movie -> the page text last spoken
volatile LONG g_read_screen = 0;           // N3: the read-screen key was pressed (any thread)
bool g_exiting = false;    // the Quit button was pressed: say nothing more
std::string g_last_long;   // B1e: the last long message (dialog/page/tutorial/tip/description) for F8
std::string g_focus_text;  // the text spoken with the current focus (a list row / "equipped" follow-up)
struct PendingRefresh {
    bool active = false;
    std::string widget;
    unsigned due = 0;
};
PendingRefresh g_refresh;  // B1f: a list rebuilt under the focus (a rebind): re-read the selected row
// N1: description text the game writes (…TitleTxt / …BodyTxt, e.g. the Weapons screen's
// meleeTitleTxt / meleeBodyTxt), spoken when it arrives with a click (choosing a weapon).
struct DescWrite {
    std::string value;
    void* movie = nullptr;
    unsigned ms = 0;
};
std::map<std::string, DescWrite> g_desc;  // "<parent>.<prefix>TitleTxt.text" etc. -> latest write

// N2: text the game writes during play that is spoken when it appears. Field suffix -> what to say
// before it. The same text on the same field is repeated only after kAnnouncedRepeatMs without
// writes (a field rewritten every frame is spoken once).
struct Announced {
    const char* suffix;
    const char* prefix;
};
const Announced kAnnounced[] = {
    {"_level0.hintText.text", "Loading. Tip: "},                // the loading screen's tip
    {"_level0.tutorial.help.helpText.text", "Tutorial: "},     // tutorial hints during play
    {"unlockTxt.text", ""},                                    // "You unlocked a new weapon!"
    {"resultsTxt.text", ""},                                   // B13-1: the end credits' results (play time)
};
struct AnnouncedState {
    std::string value;
    unsigned last_write = 0;
};
std::map<std::string, AnnouncedState> g_announced;  // path -> last value and write time

const Announced* FindAnnounced(const std::string& path) {
    for (const Announced& a : kAnnounced) {
        const std::string suffix = a.suffix;
        if (path == suffix || EndsWith(path, ("." + suffix).c_str())) return &a;
    }
    return nullptr;
}

bool IsDescText(const std::string& path) {
    return EndsWith(path, "TitleTxt.text") || EndsWith(path, "BodyTxt.text");
}

bool Seen(void* movie, const std::string& path) {  // call with g_lock held
    auto it = g_paths_in.find(movie);
    return it != g_paths_in.end() && std::find(it->second.begin(), it->second.end(), path) != it->second.end();
}

bool Alive(void* movie) { return !g_alive || g_alive(movie); }

// Text fields read (under the focused widget's parent) when a screen is entered and by the
// read-screen key. From a scan of data*/ui/*.gfx: dialog text (headerTxt, bodyTxt), unlock pop-ups
// (unlockTxt, costumeName, costumeChangeText), How to Play pages (nameTxt = the move's name),
// Credits (titleTxt, resultsTxt).
const char* const kScreenTextFields[] = {"headerTxt", "bodyTxt",  "unlockTxt",  "costumeName",
                                         "costumeChangeText", "nameTxt", "titleTxt", "resultsTxt"};

// N3: pause-menu statistics (pausedialog.gfx; its labels are static text, so these are our words).
struct StatField {
    const char* field;
    const char* label;
};
const StatField kPauseStats[] = {
    {"longestCombo", "Longest combo"},      {"totalEnemyKills", "Total enemy kills"},
    {"totalCreatureKills", "Total creature kills"}, {"shankKills", "Shank kills"},
    {"grenadeKills", "Grenade kills"},
};

// "Erase Save Data" -> "Erase Save Data." (text that already ends a sentence is kept as is).
// Line breaks become spaces and surrounding whitespace is trimmed first: the quit dialog's SWF text
// ends with a line break, which made "exit the game?." (2-5b test: NVDA read an extra period).
std::string Sentence(std::string s) {
    for (char& c : s) {
        if (c == '\r' || c == '\n' || c == '\t') c = ' ';
    }
    const size_t first = s.find_first_not_of(' ');
    if (first == std::string::npos) return std::string();
    s = s.substr(first, s.find_last_not_of(' ') - first + 1);
    const char last = s.back();
    return (last == '.' || last == '?' || last == '!' || last == ':') ? s : s + ".";
}

bool IsDialogText(const std::string& path, bool* header) {
    *header = EndsWith(path, ".headerTxt.text");
    return *header || EndsWith(path, ".bodyTxt.text");
}

const char* TypeName(UiEvent::Type type) {
    switch (type) {
    case UiEvent::kFocusIn: return "focusIn";
    case UiEvent::kNavigate: return "navigate";
    case UiEvent::kFocusedSet: return "focused=true";
    default: return "change";
    }
}

// ---- Cell lists (2-3 level select) ----
struct CellList {
    std::vector<std::vector<std::string>> cells;
    int selected = -1;  // the last spoken index
    unsigned last_poll_ms = 0;
    bool polled = false;
    std::string last_answer;  // GetSelectedIndex's last answer (logged when it changes)
    bool pollable = false;     // cells from the level select's AddCell (GetSelectedIndex exists there)
    std::string spoken;        // B1f: the row text last spoken (a rebuild re-announces the row if it changed)
    void* movie = nullptr;     // the widget's movie (identity only), for the read-screen key
};
std::map<std::string, CellList> g_cells;  // widget path -> its cells (guarded by g_lock)

bool LooksReadable(const std::string& s) {
    if (s.empty()) return false;
    if (s.find_first_of("/\\") != std::string::npos) return false;
    const size_t dot = s.find_last_of('.');
    if (dot != std::string::npos && s.size() - dot <= 5 && s.find(' ') == std::string::npos) return false;  // file
    if (s.find(' ') != std::string::npos) return true;
    for (unsigned char c : s) {
        if (std::isupper(c)) return true;  // "Chapter", or an IDS_* key (translated by the caller)
    }
    return false;  // all lower case without spaces: an identifier such as campaign_1a_wrestlingring
}

// A list item's text: its readable strings, the first as the name ("Move Left: A"); numbers and
// paths are left out.
std::string ItemText(const std::vector<std::string>& args) {
    // The Controls list's rows are (icon, action, key); keys can be digits ("1") that the readable
    // test would drop (B1 log: "Previous Gun, 13 of 16" without its key).
    if (args.size() == 3 && LooksReadable(args[1]) && !args[2].empty() && !LooksReadable(args[0])) {
        return args[1] + ": " + args[2];
    }
    std::string out;
    bool first = true;
    for (const std::string& a : args) {
        if (!LooksReadable(a)) continue;
        out = out.empty() ? a : out + (first ? ": " : ", ") + a;
        if (!out.empty() && out != a) first = false;
    }
    return out;
}

bool ParseIndex(const std::string& s, int* out) {
    if (s.empty()) return false;
    char* end = nullptr;
    const long v = std::strtol(s.c_str(), &end, 10);
    if (end == s.c_str() || *end != '\0') return false;
    *out = static_cast<int>(v);
    return true;
}

// "4 minutes 46 seconds" (whole seconds; hours when needed).
std::string SpokenDuration(double seconds) {
    long total = static_cast<long>(std::floor(seconds + 0.5));
    const long h = total / 3600, m = (total / 60) % 60, s = total % 60;
    std::string out;
    auto part = [&out](long n, const char* one, const char* many) {
        char buf[32];
        _snprintf_s(buf, sizeof buf, _TRUNCATE, "%ld %s", n, n == 1 ? one : many);
        out = out.empty() ? std::string(buf) : out + " " + buf;
    };
    if (h) part(h, "hour", "hours");
    if (m) part(m, "minute", "minutes");
    if (s || out.empty()) part(s, "second", "seconds");
    return out;
}

// Speaks cell `index` of `widget` (and remembers it as selected) unless it is already the spoken one
// (always for SelectCell: the screen was just (re)built).
std::string SpeakCell(const std::string& widget, const std::string& method, int index, const std::string& how,
                      bool select_cell, void* movie, unsigned now_ms) {
    AcquireSRWLockExclusive(&g_lock);
    std::vector<std::string> cell;
    bool same = false;
    int count = 0;
    auto jt = g_cells.find(widget);
    if (jt != g_cells.end() && index < static_cast<int>(jt->second.cells.size())) {
        count = static_cast<int>(jt->second.cells.size());
        cell = jt->second.cells[index];
        same = !select_cell && jt->second.selected == index;
        jt->second.selected = index;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (same) {
        alog::Write("menu: %s.%s -> still cell %d (%s), silent", widget.c_str(), method.c_str(), index, how.c_str());
        return std::string();
    }
    if (movie) {  // the focus is now on this screen (see OnInvoke in menu_reader.h)
        AcquireSRWLockExclusive(&g_lock);
        g_have = true;
        g_movie = movie;
        g_path = widget;
        g_ms = now_ms;
        ReleaseSRWLockExclusive(&g_lock);
    }
    std::string text = Join(CellName(cell), CellDetails(cell));
    char pos[32];
    _snprintf_s(pos, sizeof pos, _TRUNCATE, "%d of %d", index + 1, count);
    text = Join(text, pos);
    if (select_cell && widget == "_level0.FilmStrip.LevelSelector") {  // the level select screen opened (2-5b)
        AcquireSRWLockExclusive(&g_lock);
        g_last_title = "Level select";
        ReleaseSRWLockExclusive(&g_lock);
        text = "Level select. " + text;
    }
    std::string all;
    for (const std::string& a : cell) all += (all.empty() ? "" : " | ") + a;
    alog::Write("menu: %s.%s -> cell %d via %s [%s] -> say \"%s\"", widget.c_str(), method.c_str(), index, how.c_str(),
                all.c_str(), text.c_str());
    return text;
}

// B1e: remember a long message for F8 (dialog/page/tutorial/tip/description text).
void SetLong(const std::string& text) {
    if (text.empty()) return;
    AcquireSRWLockExclusive(&g_lock);
    g_last_long = text;
    ReleaseSRWLockExclusive(&g_lock);
}

// B1f: a list box row ("Jump: Space, 8 of 16"). If the list itself was focused moments ago, the
// focus text comes first in the same utterance ("Controls. Key bindings list, Move Left: Left, 1 of
// 16"); otherwise the row alone. Silent when the same row with the same text was already spoken.
std::string ListRow(const std::string& widget, int index, unsigned now_ms, bool force) {
    AcquireSRWLockExclusive(&g_lock);
    auto it = g_cells.find(widget);
    if (it == g_cells.end() || index < 0 || index >= static_cast<int>(it->second.cells.size())) {
        ReleaseSRWLockExclusive(&g_lock);
        return std::string();
    }
    CellList& list = it->second;
    const std::string row = ItemText(list.cells[index]);
    const bool same = !force && list.selected == index && list.spoken == row;
    list.selected = index;
    list.spoken = row;
    const int count = static_cast<int>(list.cells.size());
    const bool with_focus = g_have && g_path == widget && now_ms - g_ms < kSameFocusWithinMs;
    const std::string focus_text = g_focus_text;
    ReleaseSRWLockExclusive(&g_lock);
    if (same || row.empty()) return std::string();
    char pos[32];
    _snprintf_s(pos, sizeof pos, _TRUNCATE, "%d of %d", index + 1, count);
    std::string text = row + ", " + pos;
    if (with_focus && !focus_text.empty()) text = focus_text + ", " + text;
    alog::Write("menu: %s row %d -> say \"%s\"", widget.c_str(), index, text.c_str());
    return text;
}

// A text field's text as a sentence. A page title (nameTxt, e.g. "Combos") also brings the page's
// drawn text, which only the extracted ui_text data has (How to Play explanations).
std::string FieldText(const Reader& read, void* movie, const std::string& prefix, const char* field) {
    const std::string raw = ReadText(read, movie, prefix + field + ".text");
    std::string out = Sentence(raw);
    if (!out.empty() && std::string(field) == "nameTxt") {
        const std::string page = ui_text::PageText(raw);
        if (!page.empty()) out += " " + page;
    }
    return out;
}

// A widget as spoken when focused: "<name>, <role>, <value>[, unavailable][, equipped]".
std::string Describe(const Reader& read, void* movie, const std::string& path, std::string* value_out,
                     std::string* source) {
    const std::string leaf = Leaf(path);
    const Known* known = FindKnown(leaf);
    const Role role = RoleOf(leaf);
    std::string text = Join(Name(read, movie, path, role, known), RoleWord(role));
    const std::string value = Value(read, movie, path, role, known, source);
    if (value_out) *value_out = value;
    text = Join(text, value);
    if (IsDisabled(read, movie, path)) text = Join(text, "unavailable");
    // Weapons screen: the weapon shown in its kind's title field is the equipped one.
    if (const WeaponSlot* slot = FindWeaponSlot(leaf)) {
        const std::string parent = Parent(path);
        const std::string equipped =
            ReadText(read, movie, (parent.empty() ? std::string() : parent + ".") + slot->title_field + ".text");
        if (!equipped.empty() && Sentence(equipped) == Sentence(Name(read, movie, path, role, known))) {
            text = Join(text, "equipped");
        }
    }
    return text;
}

}  // namespace

std::string ScreenTitle(const std::string& path) {
    for (const ScreenWidgets& s : kScreens) {
        const std::string prefix = s.prefix;
        if (path.compare(0, prefix.size(), prefix) != 0) continue;
        if (!s.leaves) return path.size() > prefix.size() ? s.title : std::string();
        const std::string rest = path.substr(prefix.size());
        for (const char* const* leaf = s.leaves; *leaf; ++leaf) {
            if (rest == *leaf) return s.title;
        }
    }
    return std::string();
}

std::string CellName(const std::vector<std::string>& args) {
    for (const std::string& a : args) {
        if (LooksReadable(a)) return localization::Translate(a);
    }
    return args.empty() ? std::string() : Prettify(args[0]);
}

std::string CellDetails(const std::vector<std::string>& args) {
    // Level select AddCell: (name, small image, large image, flag, time). The time is the best
    // completion time in seconds (the game divides milliseconds by 1000), or -1 without one
    // (0x7929bd; 2-3c).
    if (args.size() < 5) return std::string();
    // args[3] is 1 for a locked chapter (fresh-save test: 1 from the first unreached chapter on).
    if (args[3] == "1") return "locked";
    char* end = nullptr;
    const double t = std::strtod(args[4].c_str(), &end);
    if (end == args[4].c_str() || *end != '\0') return std::string();
    if (t < 0) return "no completion time";
    return "completion time " + SpokenDuration(t);
}

std::string OnInvoke(const std::string& widget, const std::string& method, const std::vector<std::string>& args,
                     const std::string& result, unsigned now_ms, const Asker& ask, void* movie) {
    // Level select's film strip (InvokeV: Clear / AddCell / SelectCell) and CLIK list boxes
    // (InvokeMethodInternal: clearItems / addItem / setSelectedIndex; N4, e.g. the Controls list).
    if (method == "Clear" || method == "clearItems") {
        AcquireSRWLockExclusive(&g_lock);
        auto old = g_cells.find(widget);
        const int keep_selected = old != g_cells.end() ? old->second.selected : -1;
        const std::string keep_spoken = old != g_cells.end() ? old->second.spoken : std::string();
        g_cells.erase(widget);
        if (method == "clearItems" && keep_selected >= 0) {  // a list box keeps its row across a rebuild
            g_cells[widget].selected = keep_selected;
            g_cells[widget].spoken = keep_spoken;
        }
        if (method == "clearItems" && g_have && g_path == widget) {  // rebuilt under the focus (a rebind)
            g_refresh.active = true;
            g_refresh.widget = widget;
            g_refresh.due = now_ms + kListRefreshMs;
        }
        ReleaseSRWLockExclusive(&g_lock);
        return std::string();
    }
    if (method == "AddCell" || method == "addItem") {
        AcquireSRWLockExclusive(&g_lock);
        CellList& list = g_cells[widget];
        list.cells.push_back(args);
        list.pollable = method == "AddCell";
        list.movie = movie;
        ReleaseSRWLockExclusive(&g_lock);
        return std::string();
    }
    if (method == "setSelectedIndex") {  // the game moved a list's selection: speak it if it changed
        int index = -1;
        AcquireSRWLockShared(&g_lock);
        auto it = g_cells.find(widget);
        const bool known = it != g_cells.end() && !args.empty() && ParseIndex(args[0], &index) && index >= 0 &&
                           index < static_cast<int>(it->second.cells.size());
        ReleaseSRWLockShared(&g_lock);
        if (!known) return std::string();
        return ListRow(widget, index, now_ms, false);
    }
    const bool select_cell = method == "SelectCell";
    const int step = method == "SelectNext" ? 1 : method == "SelectPrev" ? -1 : 0;
    // Any other call on a widget with cells is a chance to poll: keyboard scrolling moves the level
    // select's film strip inside Flash without any call to the game (2-3 test), but the game polls
    // IsSelected / IsLoadingImage on it every frame.
    const bool poll = !select_cell && step == 0 && method != "GetSelectedIndex";
    (void)result;

    AcquireSRWLockExclusive(&g_lock);
    auto it = g_cells.find(widget);
    const bool known = it != g_cells.end() && !it->second.cells.empty() && (it->second.pollable || !poll);
    const int count = known ? static_cast<int>(it->second.cells.size()) : 0;
    const int previous = known ? it->second.selected : -1;
    bool poll_now = false;
    if (known && poll && (!it->second.polled || now_ms - it->second.last_poll_ms >= kPollEveryMs)) {
        it->second.polled = true;
        it->second.last_poll_ms = now_ms;
        poll_now = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (!known) return std::string();
    if (poll) {
        if (!poll_now || !ask) return std::string();
        const std::string answer = ask("GetSelectedIndex");
        AcquireSRWLockExclusive(&g_lock);
        auto kt = g_cells.find(widget);
        const bool changed_answer = kt != g_cells.end() && kt->second.last_answer != answer;
        if (changed_answer) kt->second.last_answer = answer;
        ReleaseSRWLockExclusive(&g_lock);
        if (changed_answer) {
            alog::Write("menu: %s.GetSelectedIndex -> \"%s\" (polled on %s)", widget.c_str(), answer.c_str(),
                        method.c_str());
        }
        int asked = -1;
        if (!ParseIndex(answer, &asked) || asked < 0 || asked >= count || asked == previous) return std::string();
        return SpeakCell(widget, method, asked, "poll", false, movie, now_ms);
    }

    // Where the selection is now: SelectCell's own index, else ask the widget, else track it.
    int index = -1;
    std::string how;
    if (select_cell && !args.empty() && ParseIndex(args[0], &index)) {
        how = "SelectCell argument";
    } else {
        int asked = -1;
        const std::string answer = ask ? ask("GetSelectedIndex") : std::string();
        const int tracked = previous < 0 ? 0 : (std::max)(0, (std::min)(count - 1, previous + step));
        if (ParseIndex(answer, &asked) && asked >= 0 && asked < count && asked != previous) {
            index = asked;
            how = "GetSelectedIndex \"" + answer + "\"";
        } else {
            index = tracked;
            how = "tracked (GetSelectedIndex \"" + answer + "\")";
        }
    }
    if (index < 0 || index >= count) {
        alog::Write("menu: %s.%s -> index %d out of range (%d cells), silent", widget.c_str(), method.c_str(), index,
                    count);
        return std::string();
    }

    return SpeakCell(widget, method, index, how, select_cell, movie, now_ms);
}

std::string OnScreenTick(void* movie, unsigned now_ms, const Reader& read,
                         const std::function<std::string(void*)>& query) {
    AcquireSRWLockExclusive(&g_lock);
    auto it = g_probe.find(movie);
    bool ask = false;
    if (it != g_probe.end()) {
        if ((g_have && g_movie == movie) || now_ms - it->second > kFocusProbeMs) g_probe.erase(it);  // done / too late
        else ask = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (!ask || !query) return std::string();
    const std::string path = query(movie);
    if (path.empty()) return std::string();
    AcquireSRWLockExclusive(&g_lock);
    g_probe.erase(movie);
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("menu: asked movie %p for its focus -> %s", movie, path.c_str());
    return OnEvent(UiEvent::kFocusedSet, movie, path, now_ms, read);
}

bool MenuActive() {
    AcquireSRWLockExclusive(&g_lock);
    bool active = false;
    if (g_have) {
        auto sh = g_screen_shown_movie.find(g_movie);
        active = sh != g_screen_shown_movie.end() && sh->second && Alive(g_movie);
    }
    ReleaseSRWLockExclusive(&g_lock);
    return active;
}

void SetMovieAliveCheck(std::function<bool(void*)> alive) {
    AcquireSRWLockExclusive(&g_lock);
    g_alive = std::move(alive);
    ReleaseSRWLockExclusive(&g_lock);
}

// B15-3: the game's tutorial pop-ups (the level's "tutorial" actions show these SWFs; the game pauses a moment and
// plays pointOfInterest). Their text is drawn, with the key shown as an icon, so these are our own words, naming
// the action and its default keyboard key. tutorialhint.gfx writes its text to helpText (spoken as "Tutorial: ...").
struct Tutorial {
    const char* file;
    const char* say;
};
const Tutorial kTutorials[] = {
    {"tutorialmovement.gfx", "Tutorial: Movement. Use the arrow keys to move Shank."},
    {"tutorialbasicattacks.gfx", "Tutorial: Basic combat. Quick attack, heavy attack and gun attack: Left Control, Left Shift and Left Alt by default."},
    {"tutorialblock.gfx", "Tutorial: Hold Block to guard. Caps Lock by default."},
    {"tutorialgrapplestart.gfx", "Tutorial: Grappling. Press Grapple to grab an enemy. Right Control by default."},
    {"tutorialgrapplefinish.gfx", "Tutorial: While grappling, press an attack for a grapple attack."},
    {"tutorialpouncestart.gfx", "Tutorial: Pounce. Press Pounce to pounce on an enemy. Right Shift by default."},
    {"tutorialgrenades.gfx", "Tutorial: Grenades. Press Grenade to throw one. Enter by default."},
    {"tutorialclimb.gfx", "Tutorial: Wall climb. Hold up or toward the wall to climb it."},
    {"tutorialwallrun.gfx", "Tutorial: Wall run. Jump and hold forward to run along the wall."},
    {"tutorialchangecontrols.gfx", "Tutorial: You can change the controls in Help and Options."},
    {"tutorialgimp.gfx", "Hint: keep the slave between you and Denny."},
    // B15-1b: the cutscene skip prompt (Escape during a cutscene; its drawn text: "Space to Skip", "ESC to Pause").
    // (Recognised by its file: B15-1's class vtable was the wrapper's, not the screen's: every screen has 0x845088.)
    {"skipcinematic.gfx", "Space to skip, Escape to pause."},
};
constexpr unsigned kCreditsClickMs = 3000;
unsigned g_credits_click_ms = 0;  // B29-5: the Credits button pressed (its own reading)
void* g_end_credits_movie = nullptr;  // B29-5: the credits screen opened on its own (after Cesar), while it's up
std::string g_credits;  // B13-1 (the credits text; set by SetCredits)
volatile LONG g_auto_said = 0;  // B16: the last text returned was an automatic announcement (TakeAutomatic)
std::string g_popups;          // B15-1b: the pop-ups' texts said together (several can open in the same frame)
unsigned g_popups_ms = 0;
unsigned g_tutorial_screen_ms = 0;  // B30-4: the last tutorial screen shown
constexpr unsigned kPopupsTogetherMs = 300;

// The SWF a movie was loaded from ("tutorialwallrun.gfx"), from its _url; "" if unreadable.
std::string MovieFile(const Reader& read, void* movie) {
    const FlashValue v = read(movie, "_level0._url");
    if (v.kind != FlashValue::kText || v.text.empty()) return std::string();
    std::string f = v.text;
    const size_t slash = f.find_last_of("/\\");
    if (slash != std::string::npos) f = f.substr(slash + 1);
    for (char& c : f) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return f;
}

std::string TutorialText(const std::string& file) {
    for (const Tutorial& t : kTutorials) {
        if (file == t.file) return t.say;
    }
    return std::string();
}

std::string OnScreen(bool shown, void* movie, unsigned now_ms, const Reader& read) {
    if (!shown) {
        AcquireSRWLockExclusive(&g_lock);
        if (movie == g_end_credits_movie) g_end_credits_movie = nullptr;
        ReleaseSRWLockExclusive(&g_lock);
    }
    if (shown && read) {  // B15-3: a tutorial pop-up says what it teaches
        const std::string file = MovieFile(read, movie);
        alog::Write("menu: screen shown (movie %p) is %s", movie, file.empty() ? "(no _url)" : file.c_str());
        // B29-5 (the user, the credits after Cesar: "Pressing arrows during this part starts to say the word credits then
        // focuses on the back button ... just read out the credits file as in the option off the regular menu"): the
        // credits screen opening on its own (not from the Credits button) reads the credits (F8 repeats them).
        if (file == "creditsscreen.gfx") {
            AcquireSRWLockExclusive(&g_lock);
            const bool own = !g_credits_click_ms || now_ms - g_credits_click_ms > kCreditsClickMs;
            const std::string credits = own && !g_credits.empty() ? "Credits. " + g_credits : std::string();
            if (!credits.empty()) {
                g_last_long = credits;
                g_end_credits_movie = movie;
                g_screen_shown_movie[movie] = true;
            }
            ReleaseSRWLockExclusive(&g_lock);
            if (!credits.empty()) {
                alog::Write("menu: the end credits -> the credits (%u characters)", static_cast<unsigned>(credits.size()));
                return credits;
            }
        }
        const std::string tut = TutorialText(file);
        if (!tut.empty()) {
            AcquireSRWLockExclusive(&g_lock);
            // (1-a opens two tutorials in the same ms: the second announcement would cut the first off)
            g_popups = g_popups_ms && now_ms - g_popups_ms <= kPopupsTogetherMs ? g_popups + " " + tut : tut;
            g_popups_ms = now_ms ? now_ms : 1;
            g_tutorial_screen_ms = g_popups_ms;  // (B30-4)
            const std::string said = g_popups;
            g_last_long = said;  // (F8 repeats it)
            ReleaseSRWLockExclusive(&g_lock);
            if (file != "skipcinematic.gfx") InterlockedExchange(&g_auto_said, 1);  // B16: tutorials come on their own
            return said;
        }
    }
    AcquireSRWLockExclusive(&g_lock);
    g_screen_shown_movie[movie] = shown;
    if (!shown) {
        g_probe.erase(movie);
        // Leaving the pause menu (Resume, Escape, or Escape from its Help & Options): say so; it also
        // cuts off any announcement still being spoken (the user: "Just use the word resumed").
        auto lp = g_last_path_in.find(movie);
        if (lp != g_last_path_in.end() && ScreenTitle(lp->second) == "Pause menu") {
            g_pending.active = false;
            g_have = false;
            g_last_title.clear();
            ReleaseSRWLockExclusive(&g_lock);
            alog::Write("menu: the pause menu closed (movie %p) -> say \"Resumed\"", movie);
            return "Resumed";
        }
    }
    void* target = nullptr;
    if (shown) {
        // Not when the game has just reported a focus in another screen: that screen is the real
        // one (the pause menu opens with a hidden Help screen that reports a stray focus).
        const bool just_focused_elsewhere = g_have && g_movie != movie && now_ms - g_ms < kScreenRestoreQuietMs;
        if (!(g_have && g_movie == movie) && !just_focused_elsewhere) target = movie;
    } else if (g_have && g_movie == movie) {
        for (auto it = g_focus_history.rbegin(); it != g_focus_history.rend(); ++it) {
            auto sh = g_screen_shown_movie.find(*it);
            if (*it != movie && sh != g_screen_shown_movie.end() && sh->second && Alive(*it)) {
                target = *it;
                break;
            }
        }
    }
    std::string path;
    if (target) {
        auto lp = g_last_path_in.find(target);
        if (lp != g_last_path_in.end()) path = lp->second;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (!target) return std::string();
    if (path.empty()) {
        alog::Write("menu: screen %s (movie %p): no earlier focus there; asking it for its focus on the next frames",
                    shown ? "shown" : "hidden", movie);
        if (shown) {
            AcquireSRWLockExclusive(&g_lock);
            g_probe[target] = now_ms;
            ReleaseSRWLockExclusive(&g_lock);
        }
        return std::string();
    }
    if (!shown) {  // back on an earlier screen: wait, it may close too (see kRestoreDelayMs)
        AcquireSRWLockExclusive(&g_lock);
        g_pending.active = true;
        g_pending.movie = target;
        g_pending.path = path;
        g_pending.due = now_ms + kRestoreDelayMs;
        ReleaseSRWLockExclusive(&g_lock);
        alog::Write("menu: screen hidden (movie %p) -> back in movie %p at %s; announcing in %u ms unless it closes",
                    movie, target, path.c_str(), kRestoreDelayMs);
        return std::string();
    }
    alog::Write("menu: screen shown (movie %p) -> focus restored at %s", movie, path.c_str());
    return OnEvent(UiEvent::kFocusedSet, target, path, now_ms, read);
}

void RequestReadScreen() { InterlockedExchange(&g_read_screen, 1); }


bool TakeAutomatic() { return InterlockedExchange(&g_auto_said, 0) != 0; }
std::string g_settings_key;        // B13-2: the settings key's name ("F7")
bool g_settings_hint_said = false;

void SetSettingsKeyName(const std::string& name) {
    AcquireSRWLockExclusive(&g_lock);
    g_settings_key = name;
    ReleaseSRWLockExclusive(&g_lock);
}

std::string Trim(const std::string& t) {
    const size_t a = t.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return std::string();
    return t.substr(a, t.find_last_not_of(" \t\r\n") - a + 1);
}

std::string CreditsFromXml(const std::string& xml) {
    // Rows: <header1>..</header1>, <header2>..</header2>, <name title="..">..</name>, <space/>.
    auto unescape = [](std::string t) {
        const std::pair<const char*, const char*> kEnt[] = {{"&amp;", "&"}, {"&lt;", "<"}, {"&gt;", ">"}, {"&quot;", "\""}, {"&apos;", "'"}};
        for (const auto& e : kEnt) {
            for (size_t at = t.find(e.first); at != std::string::npos; at = t.find(e.first, at + 1)) t.replace(at, std::strlen(e.first), e.second);
        }
        return Trim(t);
    };
    std::string out, heading;
    bool names_since = false;
    size_t pos = 0;
    while ((pos = xml.find('<', pos)) != std::string::npos) {
        const size_t close = xml.find('>', pos);
        if (close == std::string::npos) break;
        const std::string tag = xml.substr(pos + 1, close - pos - 1);
        const std::string name = tag.substr(0, tag.find_first_of(" /"));
        if (name != "header1" && name != "header2" && name != "name") {
            pos = close + 1;
            continue;
        }
        const size_t end = xml.find("</" + name + ">", close);
        if (end == std::string::npos) break;
        const std::string text = unescape(xml.substr(close + 1, end - close - 1));
        pos = end;
        if (text.empty()) continue;
        if (name == "name") {
            std::string title;
            const size_t t = tag.find("title=\"");
            if (t != std::string::npos) title = unescape(tag.substr(t + 7, tag.find('"', t + 7) - t - 7));
            out += names_since ? "; " : (heading.empty() ? "" : ": ");
            out += title.empty() ? text : text + ", " + title;
            names_since = true;
        } else {
            if (!out.empty()) out += ". ";
            out += text;
            heading = text;
            names_since = false;
        }
    }
    if (!out.empty()) out += ".";
    return out;
}

void SetCredits(const std::string& text) {
    AcquireSRWLockExclusive(&g_lock);
    g_credits = text;
    ReleaseSRWLockExclusive(&g_lock);
}

unsigned LastTutorialScreenMs() {
    AcquireSRWLockShared(&g_lock);
    const unsigned ms = g_tutorial_screen_ms;
    ReleaseSRWLockShared(&g_lock);
    return ms;
}

std::string LastLongMessage() {
    AcquireSRWLockShared(&g_lock);
    const std::string out = g_last_long;
    ReleaseSRWLockShared(&g_lock);
    return out;
}

// N3: everything readable on the focused screen, for the read-screen key.
std::string ReadScreen(const Reader& read) {
    AcquireSRWLockShared(&g_lock);
    const bool have = g_have;
    void* movie = g_movie;
    const std::string path = g_path;
    std::string cell_text;  // level select: the selected chapter
    auto c = g_cells.find(path);
    if (c != g_cells.end() && c->second.selected >= 0 &&
        c->second.selected < static_cast<int>(c->second.cells.size())) {
        const auto& cell = c->second.cells[c->second.selected];
        char pos[32];
        _snprintf_s(pos, sizeof pos, _TRUNCATE, "%d of %d", c->second.selected + 1,
                    static_cast<int>(c->second.cells.size()));
        cell_text = Join(Join(CellName(cell), CellDetails(cell)), pos);
    }
    std::vector<std::string> desc_paths;
    for (const auto& kv : g_desc) {
        if (kv.second.movie == movie) desc_paths.push_back(kv.first);
    }
    std::string lists;  // N4: list boxes on this screen (e.g. the Controls bindings)
    for (const auto& kv : g_cells) {
        if (kv.second.movie != movie || kv.second.pollable || kv.second.cells.empty()) continue;
        std::string items;
        for (const auto& cell : kv.second.cells) {
            const std::string t = ItemText(cell);
            if (!t.empty()) items = items.empty() ? t : items + "; " + t;
        }
        lists = lists.empty() ? "List: " + items : lists + ". List: " + items;
    }
    ReleaseSRWLockShared(&g_lock);
    if (!have || !movie || !Alive(movie)) return "Nothing to read here";
    if (!cell_text.empty()) return "Level select. " + cell_text;

    std::string out;
    const std::string title = ScreenTitle(path);
    if (!title.empty()) out = Sentence(title);
    const std::string parent = Parent(path);
    const std::string prefix = parent.empty() ? std::string() : parent + ".";
    auto add = [&out](const std::string& t) {
        const std::string sent = Sentence(t);
        if (!sent.empty()) out = out.empty() ? sent : out + " " + sent;
    };
    for (const char* field : kScreenTextFields) add(FieldText(read, movie, prefix, field));
    for (const std::string& p : desc_paths) add(ReadText(read, movie, p));
    if (title == "Pause menu") {
        for (const StatField& st : kPauseStats) {
            const std::string v = ReadText(read, movie, std::string("_level0.Stats.") + st.field + ".text");
            if (!v.empty()) add(std::string(st.label) + " " + v);
        }
        for (int i = 0; i < 9; ++i) {
            char name_path[64], kills_path[64];
            _snprintf_s(name_path, sizeof name_path, _TRUNCATE, "_level0.Stats.weaponName%d.text", i);
            _snprintf_s(kills_path, sizeof kills_path, _TRUNCATE, "_level0.Stats.weaponKills%d.text", i);
            const std::string name = ReadText(read, movie, name_path);
            const std::string kills = ReadText(read, movie, kills_path);
            if (name.find_first_not_of(" ") != std::string::npos && name.find_first_not_of(" ") != name.find("Kills"))
                add(name + " " + kills);
        }
    }
    add(lists);
    std::string source;
    add("Focus: " + Describe(read, movie, path, nullptr, &source));
    return out;
}

std::string OnFrame(unsigned now_ms, const Reader& read) {
    if (InterlockedExchange(&g_read_screen, 0)) {
        const std::string text = ReadScreen(read);
        alog::Write("menu: read screen -> say \"%s\"", text.c_str());
        return text;
    }
    AcquireSRWLockExclusive(&g_lock);
    if (g_refresh.active && static_cast<int>(now_ms - g_refresh.due) >= 0) {
        // B1f: the focused list was rebuilt (a rebind): speak its selected row if the text changed.
        const std::string widget = g_refresh.widget;
        g_refresh.active = false;
        auto it = g_cells.find(widget);
        const int index = it != g_cells.end() ? it->second.selected : -1;
        const bool focused = g_have && g_path == widget;
        ReleaseSRWLockExclusive(&g_lock);
        if (!focused || index < 0) return std::string();
        return ListRow(widget, index, now_ms, false);
    }
    if (g_page.active && static_cast<int>(now_ms - g_page.due) >= 0) {
        const PendingPage page = g_page;
        g_page.active = false;
        ReleaseSRWLockExclusive(&g_lock);
        AcquireSRWLockShared(&g_lock);
        const bool still_here = g_have && g_movie == page.movie;  // the page turn may have opened another screen
        ReleaseSRWLockShared(&g_lock);
        if (!still_here || !Alive(page.movie)) return std::string();
        const std::string prefix = page.parent.empty() ? std::string() : page.parent + ".";
        std::string text;
        for (const char* field : {"nameTxt", "titleTxt"}) {
            const std::string t = FieldText(read, page.movie, prefix, field);
            if (!t.empty()) text = text.empty() ? t : text + " " + t;
        }
        AcquireSRWLockExclusive(&g_lock);
        const bool changed = !text.empty() && g_page_text[page.movie] != text;
        if (changed) g_page_text[page.movie] = text;
        ReleaseSRWLockExclusive(&g_lock);
        if (!changed) return std::string();
        alog::Write("menu: page turned (movie %p) -> say \"%s\"", page.movie, text.c_str());
        SetLong(text);
        return text;
    }
    ReleaseSRWLockExclusive(&g_lock);
    AcquireSRWLockExclusive(&g_lock);
    if (!g_pending.active || g_exiting || static_cast<int>(now_ms - g_pending.due) < 0) {
        ReleaseSRWLockExclusive(&g_lock);
        return std::string();
    }
    PendingRestore p = g_pending;
    g_pending.active = false;
    auto sh = g_screen_shown_movie.find(p.movie);
    const bool still_shown = sh != g_screen_shown_movie.end() && sh->second && Alive(p.movie);
    ReleaseSRWLockExclusive(&g_lock);
    if (!still_shown) {
        alog::Write("menu: delayed announcement for movie %p dropped (the screen closed)", p.movie);
        return std::string();
    }
    return OnEvent(UiEvent::kFocusedSet, p.movie, p.path, now_ms, read);
}

bool Exiting() {
    AcquireSRWLockShared(&g_lock);
    const bool e = g_exiting;
    ReleaseSRWLockShared(&g_lock);
    return e;
}

void Reset() {
    AcquireSRWLockExclusive(&g_lock);
    g_last_path_in.clear();
    g_focus_history.clear();
    g_screen_shown_movie.clear();
    g_probe.clear();
    g_paths_in.clear();
    g_pending = PendingRestore();
    g_exiting = false;
    g_desc.clear();
    g_announced.clear();
    g_page = PendingPage();
    g_last_long.clear();
    g_focus_text.clear();
    g_refresh = PendingRefresh();
    g_page_text.clear();
    InterlockedExchange(&g_read_screen, 0);
    AcquireSRWLockExclusive(&g_learned_lock);
    g_learned.clear();
    ReleaseSRWLockExclusive(&g_learned_lock);
    g_path.clear();
    g_movie = nullptr;
    g_ms = 0;
    g_have = false;
    g_focus_value.clear();
    g_change_path.clear();
    g_change_value.clear();
    g_change_ms = 0;
    g_cells.clear();
    g_dialog_header.clear();
    g_dialog_body.clear();
    g_dialog_parent.clear();
    g_dialog_movie = nullptr;
    g_dialog_ms = 0;
    g_last_title.clear();
    g_focus_prefix.clear();
    ReleaseSRWLockExclusive(&g_lock);
}

std::string OnEvent(UiEvent::Type type, void* movie, const std::string& path, unsigned now_ms, const Reader& read,
                    const FlashValue* new_value) {
    // B29-5: on the end credits, the scrolling movie isn't a control ("Credits movie"), and the game's own focus moves
    // (Back shown again) would cut the credits off; the player's own arrows still move to Back.
    if (Leaf(path) == "creditsMovie") return std::string();
    if (type == UiEvent::kFocusedSet) {
        AcquireSRWLockShared(&g_lock);
        const bool end_credits = movie && movie == g_end_credits_movie;
        ReleaseSRWLockShared(&g_lock);
        if (end_credits) return std::string();
    }
    if (type == UiEvent::kValueSet) {
        if (const Announced* a = FindAnnounced(path)) {
            const std::string value = new_value ? ValueText(*new_value) : std::string();
            AcquireSRWLockExclusive(&g_lock);
            AnnouncedState& st = g_announced[path];
            const bool repeat = value == st.value && now_ms - st.last_write < kAnnouncedRepeatMs;
            st.value = value;
            st.last_write = now_ms;
            ReleaseSRWLockExclusive(&g_lock);
            if (value.empty() || repeat) return std::string();
            // B13-2: loading tips and tutorial hints can be turned off (unlock banners stay)
            if (a->prefix[0] && !announce::On(announce::kTips)) return std::string();
            const std::string said = std::string(a->prefix) + Sentence(value);
            alog::Write("menu: %s written -> say \"%s\"", path.c_str(), said.c_str());
            SetLong(said);
            InterlockedExchange(&g_auto_said, 1);  // B16: spoken on its own (tips, tutorial hints, unlock banners)
            return said;
        }
    }
    if (type == UiEvent::kValueSet && IsDescText(path)) {
        AcquireSRWLockExclusive(&g_lock);
        DescWrite& w = g_desc[path];
        w.value = new_value ? ValueText(*new_value) : std::string();
        w.movie = movie;
        w.ms = now_ms;
        // B1b: the Weapons screen writes its titles just after setting the focus, so "equipped" can't
        // be known at focus time. If this is the focused weapon's title field and names that weapon,
        // re-announce the focus with "equipped".
        std::string follow;
        const WeaponSlot* slot = g_have ? FindWeaponSlot(Leaf(g_path)) : nullptr;
        if (slot && movie == g_movie && now_ms - g_ms < kLateValueWithinMs &&
            path == (Parent(g_path).empty() ? std::string() : Parent(g_path) + ".") + slot->title_field + ".text" &&
            g_focus_text.find("equipped") == std::string::npos) {
            const std::string leaf = Leaf(g_path);
            const std::string learned = LearnedName(g_path);
            const Known* known = FindKnown(leaf);
            const std::string name = !learned.empty() ? learned : known ? known->name : std::string();
            if (!name.empty() && Sentence(name) == Sentence(w.value)) {
                g_focus_text = Join(g_focus_text, "equipped");
                follow = g_focus_text;
            }
        }
        ReleaseSRWLockExclusive(&g_lock);
        if (!follow.empty()) alog::Write("menu: the focused weapon is equipped -> say \"%s\"", follow.c_str());
        return follow;
    }
    bool is_header = false;
    if (type == UiEvent::kValueSet && IsDialogText(path, &is_header)) {
        const std::string value = new_value ? ValueText(*new_value) : std::string();
        AcquireSRWLockExclusive(&g_lock);
        (is_header ? g_dialog_header : g_dialog_body) = value;
        if (!value.empty()) {
            g_dialog_ms = now_ms;
            g_dialog_movie = movie;
            g_dialog_parent = Parent(Parent(path));  // "_level0.headerTxt.text" -> "_level0"
        }
        ReleaseSRWLockExclusive(&g_lock);
        return std::string();
    }
    if (type == UiEvent::kValueSet) {
        // Called for every text/value write (HUD included), so bail out cheaply first.
        AcquireSRWLockShared(&g_lock);
        const bool recent = g_have && now_ms - g_ms < kLateValueWithinMs;
        const std::string focus_path = recent ? g_path : std::string();
        void* focus_movie = g_movie;
        const std::string focus_value = g_focus_value;
        const std::string focus_prefix = g_focus_prefix;
        ReleaseSRWLockShared(&g_lock);
        if (!recent || !new_value || !Alive(focus_movie)) return std::string();
        const std::string leaf = Leaf(focus_path);
        const Known* known = FindKnown(leaf);
        const Role role = RoleOf(leaf);
        if (path != ValueSource(focus_path, role, known)) return std::string();
        const std::string value = ValueText(*new_value);
        if (value.empty() || value == focus_value) return std::string();
        AcquireSRWLockExclusive(&g_lock);
        if (g_path == focus_path) g_focus_value = value;
        ReleaseSRWLockExclusive(&g_lock);
        std::string text = Join(Join(Name(read, focus_movie, focus_path, role, known), RoleWord(role)), value);
        if (IsDisabled(read, focus_movie, focus_path)) text = Join(text, "unavailable");
        if (!focus_prefix.empty()) text = focus_prefix + " " + text;  // this replaces the first announcement
        alog::Write("menu: late value %s = \"%s\" for the focused %s -> say \"%s\"", path.c_str(), value.c_str(),
                    focus_path.c_str(), text.c_str());
        return text;
    }

    const std::string leaf = Leaf(path);
    const Known* known = FindKnown(leaf);
    const Role role = RoleOf(leaf);

    if (type == UiEvent::kChange && new_value && new_value->kind == FlashValue::kNumber) {
        // B1f: a list box's row changed: change("<list>", <index>).
        AcquireSRWLockShared(&g_lock);
        auto lc = g_cells.find(path);
        const bool is_list = lc != g_cells.end() && !lc->second.pollable;
        ReleaseSRWLockShared(&g_lock);
        if (is_list) return ListRow(path, static_cast<int>(new_value->n), now_ms, false);
    }
    if (type == UiEvent::kChange) {
        AcquireSRWLockExclusive(&g_lock);
        const bool quit = path == "_level0.quitBtn" && Seen(movie, "_level0.cancelBtn") && !g_exiting;
        if (quit) {
            g_exiting = true;
            g_pending.active = false;
        }
        const bool focused = g_have && path == g_path;
        ReleaseSRWLockExclusive(&g_lock);
        if (quit) {
            alog::Write("menu: Quit pressed in the Exit Game dialog (movie %p) -> \"Exiting\"", movie);
            return "Exiting";
        }
        // How to Play: Next/Prev turn the page; its name (nameTxt) changes on the next frame.
        const std::string click_leaf = Leaf(path);
        // B13-1: Credits: the scrolling movie's text, from the game's credits.xml (F8 repeats it).
        if (click_leaf == "creditsBtn") {
            AcquireSRWLockExclusive(&g_lock);
            g_credits_click_ms = now_ms ? now_ms : 1;  // (B29-5: its screen then isn't the end credits)
            const std::string credits = g_credits.empty() ? std::string() : "Credits. " + g_credits;
            if (!credits.empty()) g_last_long = credits;
            ReleaseSRWLockExclusive(&g_lock);
            if (!credits.empty()) {
                alog::Write("menu: Credits opened -> the credits (%u characters)", static_cast<unsigned>(credits.size()));
                return credits;
            }
        }
        if (click_leaf == "nextBtn" || click_leaf == "prevBtn") {
            AcquireSRWLockExclusive(&g_lock);
            g_page.active = true;
            g_page.movie = movie;
            g_page.parent = Parent(path);
            g_page.due = now_ms + kPageReadDelayMs;
            ReleaseSRWLockExclusive(&g_lock);
        }
        // Choosing something made the game write a description beside it (same movie, same parent,
        // during this click): "Uzi. <description>". The title also becomes the widget's name.
        {
            std::map<std::string, std::string> titles, bodies;  // prefix path -> text
            AcquireSRWLockShared(&g_lock);
            for (const auto& kv : g_desc) {
                if (kv.second.movie != movie || now_ms - kv.second.ms > kDescWithClickMs || kv.second.value.empty()) continue;
                const std::string field = Parent(kv.first);  // "_level0.gunTitleTxt"
                if (Parent(field) != Parent(path)) continue;
                const bool title = EndsWith(kv.first, "TitleTxt.text");
                const std::string prefix = field.substr(0, field.size() - (title ? 8 : 7));  // strip TitleTxt/BodyTxt
                (title ? titles : bodies)[prefix] = kv.second.value;
            }
            ReleaseSRWLockShared(&g_lock);
            // B1b: choosing a weapon rewrites both slots (melee and gun); only the clicked weapon's
            // own slot is spoken.
            if (const WeaponSlot* slot = FindWeaponSlot(click_leaf)) {
                const std::string own = (Parent(path).empty() ? std::string() : Parent(path) + ".") +
                                        std::string(slot->title_field).substr(0, std::strlen(slot->title_field) - 8);
                for (auto t = titles.begin(); t != titles.end();) t = t->first == own ? std::next(t) : titles.erase(t);
            }
            std::string said;
            for (const auto& t : titles) {
                const std::string one = Sentence(t.second);
                said = said.empty() ? one : said + " " + one;
                auto b = bodies.find(t.first);
                if (b != bodies.end()) said = said + " " + Sentence(b->second);
            }
            if (!said.empty()) {
                if (titles.size() == 1) {
                    AcquireSRWLockExclusive(&g_learned_lock);
                    g_learned[path] = titles.begin()->second;
                    ReleaseSRWLockExclusive(&g_learned_lock);
                }
                alog::Write("menu: %s chosen -> description \"%s\"", path.c_str(), said.c_str());
                SetLong(said);
                return said;
            }
        }
        if (!focused || role == Role::kButton) return std::string();
        std::string source;
        const std::string value = Value(read, movie, path, role, known, &source);
        AcquireSRWLockExclusive(&g_lock);
        const bool repeat = path == g_change_path && value == g_change_value && now_ms - g_change_ms < kSameValueWithinMs;
        if (!repeat) {
            g_change_path = path;
            g_change_value = value;
            g_change_ms = now_ms;
        }
        ReleaseSRWLockExclusive(&g_lock);
        if (repeat) return std::string();
        alog::Write("menu: change %s (from %s) -> say \"%s\"", path.c_str(), source.c_str(), value.c_str());
        return value;
    }

    // A focus event.
    AcquireSRWLockExclusive(&g_lock);
    const unsigned since = now_ms - g_ms;
    const bool same_path = g_have && path == g_path;
    const char* skip = nullptr;
    if (type == UiEvent::kNavigate && same_path) {
        // A key press that didn't move the focus (the end of a list, a single-button dialog): the
        // game still plays its move click, so say where the focus is again (the user, 2026-09-25).
        // Only a navigate in the same instant as the spoken focus is the same move reported twice.
        if (since < kRepeatNavigateAfterMs) skip = "same move reported twice";
    } else if (same_path && since < kSameFocusWithinMs) {
        skip = "same focus reported again";
    } else if (g_have && movie != g_movie && since < kIgnoreOtherMovieWithinMs) {
        skip = "another screen's focus right after this one";
    }
    const void* prev_movie = g_movie;
    if (!skip) {
        g_have = true;
        g_path = path;
        g_movie = movie;
        g_ms = now_ms;
        g_last_path_in[movie] = path;
        if (!Seen(movie, path)) g_paths_in[movie].push_back(path);
        g_pending.active = false;  // the user (or the game) moved on
        g_focus_history.erase(std::remove(g_focus_history.begin(), g_focus_history.end(), movie),
                              g_focus_history.end());
        g_focus_history.push_back(movie);
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (skip) {
        alog::Write("menu: ignored %s %s (movie %p): %s, %u ms after the previous focus (movie %p)", TypeName(type),
                    path.c_str(), movie, skip, since, prev_movie);
        return std::string();
    }

    std::string source, value;
    std::string text = Describe(read, movie, path, &value, &source);
    AcquireSRWLockExclusive(&g_lock);
    if (g_path == path) g_focus_value = value;
    ReleaseSRWLockExclusive(&g_lock);

    // 2-5a: a dialog just opened (its text was written moments ago, in this movie, beside this
    // button): say its title and message first, once.
    std::string dialog;
    AcquireSRWLockExclusive(&g_lock);
    if ((!g_dialog_header.empty() || !g_dialog_body.empty()) && now_ms - g_dialog_ms < kDialogTextWithinMs &&
        movie == g_dialog_movie && Parent(path) == g_dialog_parent) {
        dialog = Sentence(g_dialog_header);
        const std::string body = Sentence(g_dialog_body);
        dialog = dialog.empty() ? body : (body.empty() ? dialog : dialog + " " + body);
        g_dialog_header.clear();
        g_dialog_body.clear();
    }
    ReleaseSRWLockExclusive(&g_lock);
    // Some dialogs keep their text in the SWF and the game never writes it (the main menu's Exit
    // Game prompt, quitdialog.gfx: bodyTxt "Are you sure you want to exit the game?"). On the first
    // focus in a new movie, read the text fields beside the button. Only dialog SWFs have them
    // (modaldialog, quitdialog, newconceptartdialog, busydialog).
    if (dialog.empty() && movie != prev_movie) {
        const std::string parent = Parent(path);
        const std::string prefix = parent.empty() ? std::string() : parent + ".";
        // Dialog SWFs only (scan of data*/ui/*.gfx): modal/quit/concept-art dialogs use headerTxt and
        // bodyTxt; the unlock pop-ups use unlockTxt ("You unlocked a new weapon!"), costumeName and
        // costumeChangeText (N2).
        for (const char* field : kScreenTextFields) {
            const std::string t = FieldText(read, movie, prefix, field);
            if (!t.empty()) dialog = dialog.empty() ? t : dialog + " " + t;
        }
        if (!dialog.empty()) alog::Write("menu: dialog text read from the text fields under %s", parent.c_str());
    }
    std::string prefix = dialog;

    // 2-5b: the screen's title when the focus enters another screen movie (opening a menu, backing
    // out, or returning from a dialog; backing out arrives as a navigate), or when the game itself
    // sets the focus after a pause (reopening the pause menu, same movie). Arrow presses within a
    // screen never get it (the difficulty screen sends focusIn before navigate on every press).
    {
        const std::string title = ScreenTitle(path);
        AcquireSRWLockExclusive(&g_lock);
        const bool due = !title.empty() && (movie != prev_movie ||
                                            (type == UiEvent::kFocusedSet && since >= kTitleAgainAfterMs));
        if (due) g_last_title = title;
        // B13-2: the first time Help & Options opens, where the mod's own settings are.
        std::string hint;
        if (due && title == "Help and options" && !g_settings_hint_said && !g_settings_key.empty()) {
            g_settings_hint_said = true;
            hint = " Shank Access mod menu: " + g_settings_key + ".";
        }
        ReleaseSRWLockExclusive(&g_lock);
        if (due) prefix = (prefix.empty() ? Sentence(title) : Sentence(title) + " " + prefix) + hint;
        else if (title.empty() && movie != prev_movie && dialog.empty()) {
            alog::Write("menu: no screen title known for %s (first focus in movie %p)", path.c_str(), movie);
        }
    }

    if (!prefix.empty()) text = prefix + " " + text;
    AcquireSRWLockExclusive(&g_lock);
    if (g_path == path) {
        g_focus_prefix = prefix;
        g_focus_text = text;
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (!dialog.empty()) SetLong(text);  // dialog / page / pop-up text: worth repeating with F8
    alog::Write("menu: %s %s (movie %p)%s%s -> say \"%s\"", TypeName(type), path.c_str(), movie,
                source.empty() ? "" : " value from ", source.c_str(), text.c_str());
    return text;
}

}  // namespace menu_reader
