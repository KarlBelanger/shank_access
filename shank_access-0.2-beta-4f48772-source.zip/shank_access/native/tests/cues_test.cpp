// Host-side test of the Phase 4 cue logic (never deployed): the edge cue v2 from level geometry and
// Shank's position, pickup beacons relative to Shank, in-reach, the pickup summary; plus the synthesized
// samples. Silent unless run with --play (plays each sound) or --start (XAudio2 starts, nothing played).
// Exit 0 = pass.
#include <windows.h>
#include <objbase.h>

#include <cmath>
#include <cstdio>
#include <cstring>
#include <initializer_list>
#include <string>

#include "../core/audio.h"
#include "../core/cues.h"
#include "../core/enemies.h"
#include "../core/level_geometry.h"
#include "../core/log.h"

namespace {

int g_failures = 0;
void Check(bool ok, const char* what) {
    printf("%s: %s\n", ok ? "ok" : "FAIL", what);
    if (!ok) ++g_failures;
}

position::Pos At(float x, float y, bool right = true, float vx = 0) {
    position::Pos p;
    p.known = true;
    p.live = true;
    p.x = x;
    p.y = y;
    p.facing_right = right;
    p.vx = vx;
    return p;
}

struct Counts {
    int plays[audio::kSoundCount] = {};
    cues::PlayCmd last[audio::kSoundCount] = {};
    std::string said;
};

// Every 10 ms over [from, to): Shank moves at vx px/s from x0 (y fixed); pickup reports come as given.
struct Report {
    const char* name;
    float x, y;
    unsigned every_ms;
};
Counts Run(unsigned from, unsigned to, float x0, float y, bool right, float vx, std::initializer_list<Report> reports = {}) {
    Counts c;
    for (unsigned t = from; t < to; t += 10) {
        for (const Report& r : reports) {
            if ((t - from) % r.every_ms == 0) cues::OnCue(r.name, r.x, r.y, t);
        }
        const float x = x0 + vx * (t - from) / 1000.f;
        const cues::Output out = cues::Tick(t, At(x, y, right, vx));
        for (const cues::PlayCmd& p : out.plays) {
            ++c.plays[p.sound];
            c.last[p.sound] = p;
        }
        c.said += out.say;
    }
    return c;
}

}  // namespace

int main(int argc, char** argv) {
    char log_path[MAX_PATH];
    GetTempPathA(MAX_PATH, log_path);
    strcat_s(log_path, "shank_access_cues_test.log");
    wchar_t wlog[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, log_path, -1, wlog, MAX_PATH);
    alog::Open(wlog);

    // Samples: every sound exists, is short, doesn't clip and starts without a click.
    for (int s = 0; s < audio::kSoundCount; ++s) {
        unsigned n = 0;
        const float* data = audio::Samples(static_cast<audio::Sound>(s), &n);
        float peak = 0.f;
        for (unsigned i = 0; i < n; ++i) peak = std::fmax(peak, std::fabs(data[i]));
        char what[64];
        sprintf_s(what, "sound %d: %u samples, peak %.2f, soft start", s, n, peak);
        Check(n > 1000 && n < audio::kSampleRate / 2 && peak > 0.1f && peak <= 1.f && std::fabs(data[0]) < 0.01f, what);
        sprintf_s(what, "sound %d: described for Learn sounds (B15-2)", s);
        Check(audio::Describe(static_cast<audio::Sound>(s))[0] != 0, what);
    }

    {  // B17-3: Learn sounds lists every sound exactly once, grouped (a group's sounds together)
        std::vector<int> seen(audio::kSoundCount, 0);
        std::vector<std::string> groups;
        for (const audio::LearnItem& it : audio::LearnOrder()) {
            if (it.sound >= 0 && it.sound < audio::kSoundCount) ++seen[it.sound];
            if (groups.empty() || groups.back() != it.group) groups.push_back(it.group);
        }
        bool once = true;
        for (int s = 0; s < audio::kSoundCount; ++s) {
            // B23-1: the four other "behind" sounds are the goon's entry (the same muffling)
            const bool folded = s == audio::kEnemyLargeBehind || s == audio::kEnemyGirlBehind || s == audio::kEnemyDogBehind ||
                                s == audio::kEnemyBossBehind;
            once = once && seen[s] == (folded ? 0 : 1);
        }
        Check(once, "Learn sounds: every sound once (the behind sounds as one)");
        bool together = true;
        for (size_t i = 0; i < groups.size(); ++i) {
            for (size_t j = i + 1; j < groups.size(); ++j) together = together && groups[i] != groups[j];
        }
        Check(together && groups.size() == 6, "Learn sounds: 6 groups, each in one run");
    }

    // A test level: floor x 0..2000 at y 192 ending in a safe 2-tile drop on the right, a 10-tile wall on
    // the left; a second floor 2200..3000 ending in a deadly drop; a third ending in a 1-tile step.
    level_geometry::LoadFromString(
        "[t]\n"
        "surface 0 - wall 640 0 drop 128 0 2 0 192 2000 192\n"
        "surface 1 - drop 128 0 drop -1 1 2 2200 192 3000 192\n"
        "surface 2 - drop -1 1 step 64 0 2 4000 192 4500 192\n");
    level_geometry::SetLevel("t");
    const float y = 224;  // standing: feet + 32

    Check(cues::EdgeCloseness(768, 0) == 1.f && cues::EdgeCloseness(0, 0) == 0.f, "closeness by distance");
    Check(std::fabs(cues::EdgeCloseness(700, 770) - 700.f / (770.f * 1.6f)) < 0.01f, "running: the range grows (1.6 s ahead)");
    Check(cues::EdgeCloseness(1200, 770) < 1.f && cues::EdgeCloseness(1200, 0) > 1.f, "running: 1200 px is in range, standing it isn't");

    Check(Run(0, 500, 500, y, true, 0).plays[audio::kDrop] == 0, "1500 px from the drop: silent");
    Counts c = Run(1000, 3000, 1300, y, true, 0);  // standing 700 px from the drop
    Check(c.plays[audio::kDrop] >= 3 && c.plays[audio::kDrop] <= 5, "standing 700 px away: a slow pulse (about every 0.5 s)");
    Check(c.last[audio::kDrop].pan > 0.4f, "to the facing side");
    c = Run(3000, 3500, 1950, y, true, 0);  // standing at the edge
    Check(c.plays[audio::kDrop] >= 4, "standing at the edge: fast pulses (by distance; the user, B4)");
    cues::Reset();
    c = Run(4000, 5500, 800, y, true, 800);  // running at it from 1200 px: reaches it in 1.5 s
    Check(c.plays[audio::kDrop] >= 6, "running at the drop from 19 tiles: 6 accelerating pulses in 1.5 s");
    Check(c.plays[audio::kDeadly] == 0 && c.plays[audio::kWall] == 0, "a safe drop: only the drop sound");
    // Facing left: the wall 10 tiles high at x 0.
    c = Run(5000, 6000, 300, y, false, 0);
    Check(c.plays[audio::kWall] >= 1 && c.last[audio::kWall].pan < -0.4f, "facing left: the wall, to the left");
    Check(Run(6000, 7000, 20, y, false, 0).plays[audio::kWall] == 0, "against the wall: silent");
    // Deadly drop on surface 1.
    c = Run(7000, 8000, 2700, y, true, 300);
    Check(c.plays[audio::kDeadly] >= 3 && c.plays[audio::kDrop] == 0, "a deadly drop: the deadly sound");
    // A 1-tile step: silent (he hops it).
    c = Run(8000, 9000, 4300, y, true, 300);
    Check(c.plays[audio::kDrop] + c.plays[audio::kWall] + c.plays[audio::kDeadly] == 0, "a step: silent");
    Check(Run(9100, 9600, 1500, y + 200, true, 0).plays[audio::kDrop] == 0, "in the air: silent");
    // B15-6: a narrow gap (deadly below, a floor close across): its own sound, not the deadly buzz.
    level_geometry::LoadFromString("[g]\nsurface 0 - wall 640 0 gap -1 1 2 0 192 2000 192\nsurface 1 - gap -1 1 drop -1 1 2 2192 192 4000 192\n");
    level_geometry::SetLevel("g");
    c = Run(9600, 10600, 1700, y, true, 300);
    Check(c.plays[audio::kGap] >= 3 && c.plays[audio::kDeadly] == 0, "a narrow gap ahead: the gap sound");
    level_geometry::LoadFromString(
        "[t]\n"
        "surface 0 - wall 640 0 drop 128 0 2 0 192 2000 192\n"
        "surface 1 - drop 128 0 drop -1 1 2 2200 192 3000 192\n"
        "surface 2 - drop -1 1 step 64 0 2 4000 192 4500 192\n");
    level_geometry::SetLevel("t");
    // B5-4 jump targets. A floor 0..1000 ending deadly; the far side 1300..2000 at the same height; a swing
    // point at (1150, 640). Long jump: up to 545 px across at the same height; the grab spot is 128 ahead, 192 up.
    level_geometry::LoadFromString(
        "[j]\n"
        "surface 0 - wall 640 0 drop -1 1 2 0 192 1000 192\n"
        "surface 1 - drop -1 1 wall 640 0 2 1300 192 2000 192\n"
        "feature swing_point 1 1150 640\n");
    level_geometry::SetLevel("j");
    cues::Reset();
    c = Run(30000, 31000, 400, y, true, 0);
    Check(c.plays[audio::kTarget] == 0 && c.plays[audio::kJumpNow] == 0, "the swing point 12+ tiles away: silent");
    c = Run(31000, 33000, 550, y, true, 0);
    Check(c.plays[audio::kTarget] >= 1 && c.plays[audio::kJumpNow] == 0, "within 12 tiles, out of jump reach: the pluck");
    Check(c.last[audio::kTarget].pan > 0.3f && c.last[audio::kTarget].semitones > 3.f, "the pluck: to the right, higher");
    cues::OnCue("fwd_on", 900, y, 33000);  // (B44e: the standing jump drifts only while a direction is held)
    c = Run(33000, 34000, 900, y, true, 0);
    cues::OnCue("fwd_off", 900, y, 34000);
    Check(c.plays[audio::kJumpNow] >= 4 && c.plays[audio::kTarget] == 0, "a jump now reaches it (and the far side): the chirp");
    c = Run(34000, 35000, 900, y + 300, true, 0);
    Check(c.plays[audio::kJumpNow] <= 2, "in the air: no jump-now chirp (beyond the 200 ms hold)");
    // The far side alone (no swing point): from x 700 a long jump lands short (1245 < 1300); from 900 it makes it.
    level_geometry::LoadFromString(
        "[g]\n"
        "surface 0 - wall 640 0 drop -1 1 2 0 192 1000 192\n"
        "surface 1 - drop -1 1 wall 640 0 2 1300 192 2000 192\n");
    level_geometry::SetLevel("g");
    cues::Reset();
    c = Run(35000, 36000, 700, y, true, 0);
    Check(c.plays[audio::kDeadly] >= 1 && c.plays[audio::kJumpNow] == 0, "a deadly gap too wide from here: the buzz only");
    c = Run(36000, 37000, 900, y, true, 0);
    // B44-2 / B44-3 (the user: "a jump alert should not sound if a standing jump won't reach it, but should sound as soon as
    // Shank has enough speed"): standing, only the long jump makes it: the pluck; running at it, the chirp.
    Check(c.plays[audio::kDeadly] >= 1 && c.plays[audio::kJumpNow] == 0 && c.plays[audio::kTarget] >= 1,
          "close enough for a long jump, standing: the buzz and the pluck, no chirp");
    cues::Reset();
    c = Run(36500, 36900, 860, y, true, 300);  // (x 860..980: in the long jump's window, still on the floor)
    Check(c.plays[audio::kJumpNow] >= 2, "...running at it: the jump-now chirp");
    c = Run(37000, 38000, 900, y, false, 0);
    Check(c.plays[audio::kJumpNow] == 0, "facing away from the gap: no chirp");
    // B5b: running at a swing point at speed (the user: the jump alert "triggered for such a short time that
    // I couldn't hear it"): a countdown of plucks, then at least 2 chirps in the window; and none while
    // hanging from it. A long floor so he doesn't run off it.
    level_geometry::LoadFromString(
        "[s]\n"
        "surface 0 - wall 640 0 wall 640 0 2 0 192 8000 192\n"
        "feature swing_point 1 4000 620\n");  // (B44-2: running, the long jump: its grab spot passes ~620; 700 was the standing jump's)
    level_geometry::SetLevel("s");
    cues::Reset();
    {
        int plucks_before = 0, chirps = 0;
        bool chirped = false;
        for (unsigned t = 50000; t < 53000; t += 10) {
            const float x = 1500 + 770.f * (t - 50000) / 1000.f;
            if (x > 4200) break;
            for (const cues::PlayCmd& p : cues::Tick(t, At(x, y, true, 770)).plays) {
                if (p.sound == audio::kJumpNow) {
                    ++chirps;
                    chirped = true;
                }
                if (p.sound == audio::kTarget && !chirped) ++plucks_before;
            }
        }
        printf("running at the swing point: %d plucks before, %d chirps\n", plucks_before, chirps);
        Check(plucks_before >= 3 && chirps >= 2, "at speed: a countdown of plucks, then at least 2 chirps");
    }
    c = Run(53000, 54000, 4000 - 97, 620 - 148, true, 0);  // hanging: a measured swing position (dist 177)
    Check(c.plays[audio::kTarget] + c.plays[audio::kJumpNow] == 0, "hanging from it: silent");
    // B5d: at the top of 1-c's tall pole (x 2929.9, y 1481..3557; he climbs 80 px to one side), the wall-climb
    // zone to the left (1478..2546, y 2939..3343) is reached by the pole jump (the wall jump, away from it).
    level_geometry::LoadFromString(
        "[p]\n"
        "feature pole 2 2929.94 1481.01 2929.94 3557.57\n"
        "feature wallrun_zone 2 1477.94 2939.28 2545.94 3343.28\n");
    level_geometry::SetLevel("p");
    cues::Reset();
    c = Run(55000, 56000, 2849.9f, 3553.f, false, 0);
    Check(c.plays[audio::kJumpNow] >= 4, "on the pole's left side at the top: the zone to the left chirps");
    cues::Reset();  // (no carry-over of the 200 ms hold from the scenario above)
    c = Run(56000, 57000, 3009.9f, 3553.f, true, 0);
    Check(c.plays[audio::kJumpNow] >= 4,
          "on its right side: the zone on the left chirps too (B10b: jumping left through the pole, the game moves him across first)");
    // B5e: hanging from the end of 1-c's bar (1577..2601 at y 4181) at (2601, 3996), the platform below and to
    // the right (2624..3328 at y 3904) is a landing: the bar jump (facing right) lands on it.
    level_geometry::LoadFromString(
        "[b]\n"
        "surface 0 - drop 1984 0 drop 2752 0 2 2624 3904 3328 3904\n"
        "feature shimmy_line 2 2600.96 4181.23 1577.07 4181.23\n");
    level_geometry::SetLevel("b");
    cues::Reset();
    {
        position::Pos p = At(2601, 3996, true, 0);
        p.ping_facing_right = true;
        int chirps = 0;
        for (unsigned t = 57000; t < 58000; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) chirps += q.sound == audio::kJumpNow;
        // (B41-4: the bar jump forward flies over it; the jump up lands on it.) B44-2 (the user: "a floor reachable from a
        // shimmy line only by holding up should not sound if holding right"): not holding Up, the pluck; holding Up, the chirp.
        Check(chirps == 0, "hanging at the bar's end facing right, not holding Up: no chirp for the platform");
        cues::Reset();
        int plucks = 0;
        for (unsigned t = 57000; t < 58000; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) plucks += q.sound == audio::kTarget;
        Check(plucks >= 1, "...it plucks (a jump up would reach it)");
        cues::Reset();
        cues::OnCue("up_on", p.x, p.y, 57500);
        for (unsigned t = 57500; t < 58500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) chirps += q.sound == audio::kJumpNow;
        // B44e (the user, 2-b: Up alone on a bar went straight up, not onto a landing aside): Up only, straight up: no chirp
        Check(chirps == 0, "...holding Up only: the jump up goes straight up, past the platform's end: no chirp");
        cues::OnCue("fwd_on", p.x, p.y, 58500);
        chirps = 0;
        for (unsigned t = 58500; t < 59500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) chirps += q.sound == audio::kJumpNow;
        Check(chirps >= 4, "...holding Up and right (forward): the platform chirps (a landing)");
        cues::Reset();
        cues::OnCue("up_on", p.x, p.y, 59500);
        p.facing_right = p.ping_facing_right = false;
        chirps = 0;
        for (unsigned t = 59500; t < 60500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) chirps += q.sound == audio::kJumpNow;
        Check(chirps == 0, "facing left at the bar's end, holding Up: straight up, no chirp (B44e: holding right turns him first)");
        // B44f: he dies holding Up and Right (no release report from the new Shank): after the death nothing is held, so the
        // bar's forward jump is judged again (it flies over: no chirp; the platform plucks).
        cues::Reset();
        p.facing_right = p.ping_facing_right = true;
        cues::OnCue("up_on", p.x, p.y, 60500);
        cues::OnCue("fwd_on", p.x, p.y, 60500);
        cues::OnGameSound("Shank/Character/Voices/Shank/Shank_Death", p.x, p.y, 60600);
        chirps = 0;
        for (unsigned t = 60700; t < 61700; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) chirps += q.sound == audio::kJumpNow;
        Check(chirps == 0, "B44f: after a death nothing counts as held (the jump up no longer judged)");
        cues::Reset();
        p = At(2300, 3996, false, 0);
        p.ping_facing_right = false;
        chirps = 0;
        for (unsigned t = 59000; t < 60000; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) chirps += q.sound == audio::kJumpNow;
        Check(chirps == 0, "300 px along the bar facing left: no landing chirp");
        // B6-7: the same platform inside a fatal pit zone (a grinder floor): no landing.
        level_geometry::LoadFromString(
            "[b2]\n"
            "surface 0 - drop 1984 0 drop 2752 0 2 2624 3904 3328 3904\n"
            "feature shimmy_line 2 2600.96 4181.23 1577.07 4181.23\n"
            "pit 2500 3700 3400 3950\n");
        level_geometry::SetLevel("b2");
        cues::Reset();
        p = At(2601, 3996, true, 0);
        p.ping_facing_right = true;
        chirps = 0;
        for (unsigned t = 60000; t < 60500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) chirps += q.sound == audio::kJumpNow;
        Check(chirps == 0, "a platform inside a fatal pit zone: no landing chirp");
    }
    // Clinging to a climbable wall (1-c's climb, simplified): the street at y 192 ends at a wall at x 5376
    // climbable to 1600; a swing point at (4725, 1044); another climbable wall facing him at x 4944.
    level_geometry::LoadFromString(
        "[w]\n"
        "surface 0 - wall 640 0 cwall 1408 0 2 3000 192 5376 192\n"
        "wall left 5376 192 1600 1\n"
        "wall left 5376 1600 1792 0\n"
        "wall right 4944 1000 1600 1\n"
        "feature swing_point 1 4725 1044\n");
    level_geometry::SetLevel("w");
    cues::Reset();
    c = Run(38000, 39000, 5344, 1130, true, 0);
    Check(c.plays[audio::kJumpNow] >= 4, "clinging at y 1130: a wall jump reaches the swing point / wall: chirps");
    c = Run(39000, 40000, 5344, 2400, true, 0);
    Check(c.plays[audio::kJumpNow] == 0, "clinging far too high (off the climbable part): no chirp");
    c = Run(40000, 41000, 4000, 224, true, 0);  // on the street facing the end wall 1376 px away
    Check(c.plays[audio::kWall] == 0, "the end wall beyond range: silent");
    c = Run(41000, 42000, 4800, 224, true, 0);
    Check(c.plays[audio::kWall] >= 1 && c.last[audio::kWall].semitones > 4.f, "a climbable wall knocks higher");
    level_geometry::LoadFromString(  // (LoadFromString replaces every level: the first test level again)
        "[t]\n"
        "surface 0 - wall 640 0 drop 128 0 2 0 192 2000 192\n"
        "surface 1 - drop 128 0 drop -1 1 2 2200 192 3000 192\n"
        "surface 2 - drop -1 1 step 64 0 2 4000 192 4500 192\n");
    level_geometry::SetLevel("t");
    cues::Reset();
    // B5-2: an arena bound at x 1500 stops him before the drop at 2000: a wall there, not the drop.
    cues::Area arena;
    arena.known = true;
    arena.min_x = 0;
    arena.max_x = 1500;
    arena.min_y = 0;
    arena.max_y = 2000;
    cues::SetArea(arena);
    cues::Reset();  // (Reset forgets the area too: set it again)
    cues::SetArea(arena);
    c = Run(9600, 10600, 1300, y, true, 0);
    Check(c.plays[audio::kWall] >= 2 && c.plays[audio::kDrop] == 0, "a bound before the drop: the wall sound, not the drop");
    c = Run(10600, 11100, 1460, y, true, 0);
    Check(c.plays[audio::kWall] == 0, "against the bound: silent, like a wall");
    c = Run(11100, 12100, 600, y, false, 0);
    Check(c.plays[audio::kWall] >= 1, "facing left: the real wall at x 0 (inside the bounds)");
    c = Run(12100, 13100, 1000, y, true, 0, {{"beacon_health", 1800.f, 224.f, 500}});
    Check(c.plays[audio::kPickup] == 0, "a pickup beyond the bound: silent");
    Check(cues::PickupSummary(13100, At(1000, y)) == "No pickups nearby", "a pickup beyond the bound: not in P");
    cues::OnCue("beacon_health", 1400.f, 224.f, 13100);
    Check(cues::PickupSummary(13100, At(1000, y)) == "Health, 6 tiles right.", "a pickup inside: in P");
    cues::SetArea(cues::Area());
    level_geometry::LoadFromString(
        "[f]\n"
        "feature swing_point 1 1320 800\n"
        "feature pole 2 500 224 500 1000\n"
        "feature wallrun_zone 2 3000 300 4000 600\n"
        "feature shimmy_line 2 9000 500 9500 700\n");
    level_geometry::SetLevel("f");
    // The pole's nearest point is its foot (500, 224); the wall-run box is 2001 px away (out of range).
    Check(cues::TraversalSummary(At(1000, 224)) == "Pole, 8 tiles left. Swing point, 5 tiles right, 9 above.",
          "T: nearest first, points on lines, range");
    Check(cues::TraversalSummary(At(2500, 224)) == "Wall run, 8 tiles right. Swing point, 18 tiles left, 9 above.",
          "T: a wall-run box by its nearest point");
    Check(cues::TraversalSummary(At(20000, 224)) == "Nothing to climb or swing on nearby", "T: nothing in range");
    Check(cues::TraversalSummary(position::Pos()) == "No position yet", "T: no position");
    cues::Area left_part;  // bounds x 0..2600: the wall run (from x 3000) is outside
    left_part.known = true;
    left_part.max_x = 2600;
    left_part.max_y = 2000;
    cues::SetArea(left_part);
    Check(cues::TraversalSummary(At(2500, 224)) == "Swing point, 18 tiles left, 9 above.", "T: beyond the bounds left out");
    cues::SetArea(cues::Area());
    level_geometry::SetLevel("none");
    Check(Run(9700, 10500, 1900, y, true, 0).plays[audio::kDrop] == 0, "no geometry: silent");

    // Pickups relative to Shank (at 1000, 500): right and above -> panned right, higher.
    cues::Reset();
    c = Run(20000, 23000, 1000, 500, true, 0, {{"beacon_health", 1600.f, 692.f, 500}});
    Check(c.plays[audio::kPickup] >= 3 && c.plays[audio::kPickup] <= 5, "pickup 630 px away: a chime about every 0.7 s");
    Check(c.last[audio::kPickup].pan > 0.45f && c.last[audio::kPickup].pan < 0.55f, "pickup 600 px right: pan 0.5");
    Check(c.last[audio::kPickup].semitones > 1.9f && c.last[audio::kPickup].semitones < 2.1f, "pickup 192 px above: 2 semitones up");
    const position::Pos here = At(1000, 500);
    Check(cues::PickupSummary(23000, here) == "Health, 9 tiles right, 3 above.", "summary: one pickup");
    cues::OnCue("beacon_grenades", 900.f, 500.f, 23000);
    Check(cues::PickupSummary(23000, here) == "Grenades, 2 tiles left. Health, 9 tiles right, 3 above.", "summary: nearest first");
    cues::OnCue("beacon_health", 1610.f, 690.f, 23400);  // the same pickup, nudged
    const std::string s = cues::PickupSummary(23400, here);
    Check(s.find("Health") != std::string::npos && s.find("Health", s.find("Health") + 1) == std::string::npos,
          "a nudged report is the same pickup");
    Run(23500, 25000, 1000, 500, true, 0, {{"beacon_grenades", 900.f, 500.f, 500}});
    Check(cues::PickupSummary(25000, here) == "Grenades, 2 tiles left.", "health not reported for 1.6 s: gone");
    Run(25000, 26600, 1000, 500, true, 0);
    Check(cues::PickupSummary(26600, here) == "No pickups nearby", "all gone");
    Check(cues::PickupSummary(26600, position::Pos()) == "No position yet", "no position");
    // In reach: spoken once, a different sound while in reach; again only after leaving for a while.
    c = Run(27000, 27010, 1000, 500, true, 0, {{"inreach_minigun", 1030.f, 500.f, 250}});
    Check(c.said == "Minigun in reach" && c.plays[audio::kInReach] == 1, "in reach: spoken, the in-reach sound at once");
    c = Run(27010, 28500, 1000, 500, true, 0, {{"inreach_minigun", 1030.f, 500.f, 250}});
    Check(c.said.empty() && c.plays[audio::kInReach] >= 2 && c.plays[audio::kPickup] == 0,
          "staying in reach: in-reach pings, not repeated in speech");
    c = Run(28500, 30100, 1000, 500, true, 0, {{"beacon_minigun", 1030.f, 500.f, 500}});
    Check(c.plays[audio::kPickupItem] >= 2 && c.plays[audio::kPickup] == 0, "left the reach box: its beacon again (B23-3: the item sound)");
    c = Run(30100, 30110, 1000, 500, true, 0, {{"inreach_minigun", 1030.f, 500.f, 250}});
    Check(c.said == "Minigun in reach", "back in reach after 1.6 s: spoken again");
    Check(cues::KindName("grenadelauncher") == "Grenade launcher" && cues::KindName("sword") == "Katana", "kind names");

    // B6-2 wall runs: a pit (1000..2400) under a wall-run zone (1100..2100, y 300..700); the far floor at 2400.
    level_geometry::LoadFromString(
        "[wr]\n"
        "surface 0 - wall 64 0 drop -1 1 2 0 192 1000 192\n"
        "surface 1 - drop -1 1 wall 64 0 2 2400 192 3400 192\n"
        "feature wallrun_zone 2 1100 300 2100 700\n"
        "pit 1000 -2000 2400 100\n");
    level_geometry::SetLevel("wr");
    cues::Reset();
    auto run = [](unsigned from, unsigned to, float x0, float vx) {
        Counts k;
        for (unsigned t = from; t < to; t += 10) {
            position::Pos p = At(x0 + vx * (t - from) / 1000.f, 450, vx > 0, vx);
            p.ping_facing_right = vx > 0;
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) ++k.plays[q.sound];
        }
        return k;
    };
    c = run(61000, 61500, 1300, 768);
    Check(c.plays[audio::kDeadly] >= 2 && c.plays[audio::kDrop] == 0, "wall running right: the run's end pulses deadly");
    c = run(62000, 62400, 1750, 768);
    Check(c.plays[audio::kJumpNow] >= 2, "near the run's end: the far floor chirps (the wall-run jump)");
    cues::Reset();
    c = run(63000, 63500, 1300, 0);
    Check(c.plays[audio::kDeadly] == 0, "hanging still in the zone: not wall running, no run-end pulse");
    // The same with a floor under the run's end instead of the pit: a plain drop.
    level_geometry::LoadFromString(
        "[wr2]\n"
        "surface 0 - wall 64 0 drop -1 1 2 0 192 1000 192\n"
        "surface 1 - drop -1 0 drop -1 0 2 1900 -300 2800 -300\n"
        "feature wallrun_zone 2 1100 300 2100 700\n");
    level_geometry::SetLevel("wr2");
    cues::Reset();
    c = run(64000, 64500, 1300, 768);
    Check(c.plays[audio::kDrop] >= 2 && c.plays[audio::kDeadly] == 0, "a floor below the run's end: a safe drop");

    // B6-3 slides. A slide pole (x 500, y 800..1500) with nothing under its bottom: sliding down it (80 px
    // aside, 768 px/s down), its bottom pulses deadly; a floor under it makes it a safe drop; a rope carrying
    // on from its bottom, no edge.
    auto slide = [](unsigned from, unsigned to, float y0, float vy) {
        Counts k;
        for (unsigned t = from; t < to; t += 10) {
            position::Pos p = At(580, y0 + vy * (t - from) / 1000.f, true, 0);
            p.vy = vy;
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) ++k.plays[q.sound];
        }
        return k;
    };
    level_geometry::LoadFromString("[sp]\nfeature slide_pole 2 500 1500 500 800\n");
    level_geometry::SetLevel("sp");
    cues::Reset();
    c = slide(65000, 65400, 1400, -768);
    Check(c.plays[audio::kDeadly] >= 2, "sliding down a slide pole over nothing: its bottom pulses deadly");
    cues::Reset();
    c = slide(65500, 65900, 1400, 0);
    Check(c.plays[audio::kDeadly] == 0, "holding still on it: no pulse");
    level_geometry::LoadFromString("[sp2]\nfeature slide_pole 2 500 1500 500 800\nsurface 0 - drop -1 0 drop -1 0 2 300 400 900 400\n");
    level_geometry::SetLevel("sp2");
    cues::Reset();
    c = slide(66000, 66400, 1400, -768);
    Check(c.plays[audio::kDrop] >= 2 && c.plays[audio::kDeadly] == 0, "a floor under the slide pole: a safe drop");
    level_geometry::LoadFromString(
        "[sp3]\nfeature slide_pole 2 500 1500 500 800\nfeature shimmy_line 2 500 800 1500 600\n");
    level_geometry::SetLevel("sp3");
    cues::Reset();
    c = slide(67000, 67400, 1400, -768);
    Check(c.plays[audio::kDeadly] == 0 && c.plays[audio::kDrop] == 0, "a rope carrying on from its bottom: no edge");
    // A slippery slope (sliding right at 1248 px/s) ending in a deadly drop: the ground edge cue covers it.
    level_geometry::LoadFromString("[ss]\nsurface 0 slipperyright wall 64 0 drop -1 1 2 0 1000 1000 500\n");
    level_geometry::SetLevel("ss");
    cues::Reset();
    {
        Counts k;
        for (unsigned t = 68000; t < 68300; t += 10) {
            const float x = 100 + 1248.f * (t - 68000) / 1000.f;
            position::Pos p = At(x, 1000 - x * 0.5f + 32, true, 1248);
            p.vy = -624;  // down the slope (grounded needs |vy| < 150, but the edge cue doesn't)
            for (const cues::PlayCmd& q : cues::Tick(t, p).plays) ++k.plays[q.sound];
        }
        Check(k.plays[audio::kDeadly] >= 2, "sliding down a slippery slope to a deadly drop: the deadly pulse");
    }

    // B7 hazard warnings (flat test level, no bounds).
    level_geometry::LoadFromString("[hz]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 5000 192\n");
    level_geometry::SetLevel("hz");
    cues::Reset();
    {
        const position::Pos me = At(1000, 224);
        auto count = [](const cues::Output& o, audio::Sound snd) {
            int n = 0;
            for (const cues::PlayCmd& q : o.plays) n += q.sound == snd;
            return n;
        };
        // A rock falling straight onto him: reported every 100 ms, fast warning pulses.
        int falls = 0;
        for (unsigned t = 70000; t < 71000; t += 10) {
            if (t % 100 == 0) cues::OnCue("hz_rock", 1040.f, 900.f - (t - 70000) * 0.6f, t);
            falls += count(cues::Tick(t, me), audio::kHazardFall);
        }
        Check(falls >= 8, "a rock falling on him: rapid falling-whistle warnings");
        Check(cues::HazardCount() == 1, "the moving rock is tracked as one hazard");
        cues::Tick(71500, me);
        Check(cues::HazardCount() == 0, "no reports for 0.5 s: the rock is gone");
        // A rock falling 1500 px to the side: silent.
        falls = 0;
        for (unsigned t = 72000; t < 72500; t += 10) {
            if (t % 100 == 0) cues::OnCue("hz_rock", 2500.f, 900.f, t);
            falls += count(cues::Tick(t, me), audio::kHazardFall);
        }
        Check(falls == 0, "a rock far to the side: no warning");
        // A rocket flying at him from the right: the warble, panned right.
        cues::Reset();
        int warbles = 0;
        cues::PlayCmd last{};
        for (unsigned t = 73000; t < 73800; t += 10) {
            if (t % 100 == 0) cues::OnCue("hz_rocket", 1800.f - (t - 73000) * 0.8f, 260.f, t);
            for (const cues::PlayCmd& q : cues::Tick(t, me).plays) {
                if (q.sound == audio::kHazardProjectile) {
                    ++warbles;
                    last = q;
                }
            }
        }
        printf("  (rocket: %d warbles, last pan %.2f)\n", warbles, last.pan);
        Check(warbles >= 4 && last.pan > 0.f, "a rocket coming from the right: warbles, panned right");
        // An enemy grenade 150 px away (inside the blast): rapid beeps; a barrel 250 px away: slow beeps.
        cues::Reset();
        int beeps = 0;
        for (unsigned t = 74000; t < 75000; t += 10) {
            if (t % 100 == 0) cues::OnCue("hz_grenade", 1150.f, 224.f, t);
            beeps += count(cues::Tick(t, me), audio::kHazardExplosive);
        }
        Check(beeps >= 10, "an enemy grenade inside the blast: rapid beeps");
        // B15-5: a grenade thrown from 700 px away (as in the B13b log: ~600 px/s toward him): heard from the throw,
        // panned from where it is in the air.
        cues::Reset();
        beeps = 0;
        int first_beep_t = 0;
        for (unsigned t = 74000; t < 74400; t += 10) {
            if (t % 100 == 0) cues::OnCue("hz_grenade", 1700.f - (t - 74000) * 0.6f, 330.f, t);
            const int b = count(cues::Tick(t, me), audio::kHazardExplosive);
            if (b && !first_beep_t) first_beep_t = static_cast<int>(t);
            beeps += b;
        }
        printf("  (flying grenade: %d beeps, first at +%d ms)\n", beeps, first_beep_t ? first_beep_t - 74000 : -1);
        Check(beeps >= 1 && first_beep_t && first_beep_t - 74000 <= 200, "a grenade in flight 700 px away: heard at once (it was silent until 500 px)");
        cues::Reset();
        beeps = 0;
        for (unsigned t = 76000; t < 77000; t += 10) {
            if (t % 500 == 0) cues::OnCue("hz_barrel", 1250.f, 224.f, t);
            beeps += count(cues::Tick(t, me), audio::kHazardExplosive);
        }
        Check(beeps >= 8, "a barrel 250 px away (just outside its blast): fast beeps");
        {  // B15-3: the explosives hint, once per level
            cues::Reset();
            std::string said;
            for (unsigned t = 76000; t < 77500; t += 10) {
                if (t % 500 == 0) cues::OnCue("hz_barrel", 1250.f, 224.f, t);
                said += cues::Tick(t, me).say;
            }
            Check(said == "Explosives nearby. Shoot them to hurt the enemies near them", "the first explosive in range: the hint, once");
        }
        // B13-3 fire traps: a crackle within 8 tiles on his level, faster as he nears it; silent far above.
        auto fire_crackles = [&](float fx, float fy, unsigned from) {
            cues::Reset();
            int n = 0;
            for (unsigned t = from; t < from + 1000; t += 10) {
                if (t % 500 == 0) cues::OnCue("hz_fire", fx, fy, t);
                n += count(cues::Tick(t, me), audio::kHazardFire);
            }
            return n;
        };
        const int near_fire = fire_crackles(1100.f, 192.f, 76000), far_fire = fire_crackles(1450.f, 192.f, 76000);
        printf("  (fire: %d crackles at 100 px, %d at 450 px)\n", near_fire, far_fire);
        Check(near_fire >= 8 && far_fire >= 1 && far_fire < near_fire, "a fire trap ahead: crackles, faster when close");
        Check(fire_crackles(1700.f, 192.f, 76000) == 0, "a fire trap 11 tiles away: silent");
        Check(fire_crackles(1100.f, 800.f, 76000) == 0, "a fire trap on a floor far above: silent");
        // B7b: out to the pistol's range (2560 px), only with a clear line of fire.
        auto barrel_beeps = [&](float bx, unsigned from) {
            cues::Reset();
            int n = 0;
            for (unsigned t = from; t < from + 1500; t += 10) {
                if (t % 500 == 0) cues::OnCue("hz_barrel", bx, 224.f, t);
                n += count(cues::Tick(t, me), audio::kHazardExplosive);
            }
            return n;
        };
        const int far_beeps = barrel_beeps(3200.f, 78000);
        Check(far_beeps >= 1 && far_beeps <= 4, "a barrel 2200 px away in the open: slow beeps");
        Check(barrel_beeps(3700.f, 80000) == 0, "a barrel 2700 px away (beyond the pistol's range): silent");
        level_geometry::LoadFromString(
            "[hz2]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 5000 192\nwall left 2000 192 800 1\n");
        level_geometry::SetLevel("hz2");
        Check(barrel_beeps(3200.f, 82000) == 0, "the same barrel behind a wall: silent");
        level_geometry::LoadFromString("[hz]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 5000 192\n");
        level_geometry::SetLevel("hz");
        // B7b rockets: heard where it is now (carried on between reports), dropped soon after its reports stop,
        // and silent once it has gone past him and away.
        cues::Reset();
        for (unsigned t = 84000; t <= 84300; t += 10) {
            if (t % 100 == 0) cues::OnCue("hz_rocket", 1900.f - (t - 84000) * 1.5f, 260.f, t);
            cues::Tick(t, me);
        }
        Check(cues::HazardCount() == 1, "(rocket tracked)");
        for (unsigned t = 84310; t <= 84550; t += 10) cues::Tick(t, me);
        Check(cues::HazardCount() == 0, "a rocket 250 ms without a report (exploded): gone");
        cues::Reset();
        int past = 0;
        for (unsigned t = 86000; t < 86600; t += 10) {
            if (t % 100 == 0) cues::OnCue("hz_rocket", 300.f - (t - 86000) * 1.5f, 260.f, t);
            past += count(cues::Tick(t, me), audio::kHazardProjectile);
        }
        Check(past == 0, "a rocket 700+ px past him, flying away: silent");
    }

    // B9-2 platform overhead: a floor at y 192 (0..3000) and a one-way platform at y 400 (900..1300) above it.
    level_geometry::LoadFromString(
        "[oh]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 3000 192\nsurface 1 skinny drop 208 0 drop 208 0 2 900 400 1300 400\n"
        "surface 2 skinny drop 700 0 drop 700 0 2 2000 900 2400 900\n");
    level_geometry::SetLevel("oh");
    cues::Reset();
    {
        auto chirps = [](unsigned from, unsigned to, float x) {
            int n = 0;
            for (unsigned t = from; t < to; t += 10) {
                for (const cues::PlayCmd& q : cues::Tick(t, At(x, 224, true, 0)).plays) n += q.sound == audio::kJumpNow;
            }
            return n;
        };
        Check(chirps(110000, 111000, 1000) == 1, "standing under a platform a jump reaches: one chirp");
        Check(chirps(111000, 112000, 1000) == 0, "staying there: no more");
        Check(chirps(112000, 113500, 2600) == 0, "away (under nothing reachable; a platform 700 px up is too high): silent");
        Check(chirps(113500, 114000, 1000) == 1, "back under it after a while: one chirp again");
    }
    // B9b: beside a 2-tile step (not under anything): no chirp (the step is the edge cue's; he climbs it himself).
    level_geometry::LoadFromString("[st]\nsurface 0 - wall 64 0 wall 128 0 2 0 192 1500 192\nsurface 1 - step 128 0 wall 64 0 2 1500 320 2500 320\n");
    level_geometry::SetLevel("st");
    cues::Reset();
    {
        int n = 0;
        for (unsigned t = 114500; t < 115500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, At(1460, 224, true, 0)).plays) n += q.sound == audio::kJumpNow;
        Check(n == 0, "beside a 2-tile step: no platform-overhead chirp");
    }
    // B9b: the locked enemy's own tick, and the in-line ting for a dog below (the user, hanging from a swing point).
    level_geometry::LoadFromString("[lk]\nsurface 0 - wall 64 0 wall 64 0 2 0 -2000 20000 -2000\n");
    level_geometry::SetLevel("lk");
    cues::Reset();
    {
        enemies::Enemy dog;
        dog.item = 30;
        dog.name = "dog_black_teeth";
        dog.cls = enemies::kDog;
        dog.x = 1000 + 576;  // ~55 degrees below and to the right (the B9 log: 9 tiles right, 13 below)
        dog.y = 224 - 832;
        dog.team = 1;
        enemies::SetCurrentForTests({dog});
        position::Pos hang = At(1000, 224, true, 0);
        cues::LockNext(hang, false);
        int lock_ticks = 0, dog_ticks = 0, tings = 0;
        float ting_semis = 99;
        for (unsigned t = 115500; t < 116500; t += 10) {
            for (const cues::PlayCmd& q : cues::Tick(t, hang).plays) {
                lock_ticks += q.sound == audio::kLockTick;
                dog_ticks += q.sound == audio::kEnemyDog || q.sound == audio::kEnemyDogBehind;
                if (q.sound == audio::kLockInLine) {
                    ++tings;
                    ting_semis = q.semitones;
                }
            }
        }
        Check(lock_ticks >= 2 && dog_ticks == 0, "locked: its own tick, not the dog's");
        Check(tings >= 2 && ting_semis == -4.f, "a dog ~55 degrees below: in line for the diagonal-down shot");
        dog.x = 1000;
        dog.y = 224 - 600;  // straight below
        enemies::SetCurrentForTests({dog});
        tings = 0;
        for (unsigned t = 116500; t < 117500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, hang).plays)
                if (q.sound == audio::kLockInLine) {
                    ++tings;
                    ting_semis = q.semitones;
                }
        Check(tings >= 2 && ting_semis == -7.f, "straight below (in the air): in line for the down shot");
        cues::LockNext(hang, false);
        // B20-4: really hanging (a bar 185 px above him, as 1-c's): no straight-down shot from a bar; 45 below still.
        level_geometry::LoadFromString("[lk2]\nsurface 0 - wall 64 0 wall 64 0 2 0 -2000 20000 -2000\n"
                                       "feature shimmy_line 2 500 409 1500 409\n");
        level_geometry::SetLevel("lk2");
        cues::Reset();
        enemies::SetCurrentForTests({dog});  // (straight below)
        cues::LockNext(hang, false);
        tings = 0;
        for (unsigned t = 117500; t < 118500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, hang).plays) tings += q.sound == audio::kLockInLine;
        const int below_tings = tings;
        dog.x = 1000 + 600;
        dog.y = 224 - 600;  // 45 below, ahead
        enemies::SetCurrentForTests({dog});
        tings = 0;
        for (unsigned t = 118500; t < 119500; t += 10)
            for (const cues::PlayCmd& q : cues::Tick(t, hang).plays)
                if (q.sound == audio::kLockInLine) {
                    ++tings;
                    ting_semis = q.semitones;
                }
        Check(below_tings == 0 && tings >= 2 && ting_semis == -4.f,
              "hanging from a bar: straight below is not in line (no such shot); 45 below is");
        cues::LockNext(hang, false);
        enemies::SetCurrentForTests({});
    }

    // B9c boss openings: an en_vuln report (a "canbegrappled" state) or the grapple prompt makes the boss's tick an
    // energetic bell; the prompt is spoken at once.
    level_geometry::LoadFromString("[bo]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 5000 192\n");
    level_geometry::SetLevel("bo");
    cues::Reset();
    {
        enemies::Enemy boss;
        boss.item = 40;
        boss.name = "boss_butcher";
        boss.cls = enemies::kBoss;
        boss.x = 1400;
        boss.y = 224;
        boss.team = 1;
        enemies::Enemy goon = boss;
        goon.item = 41;
        goon.name = "med_thug_knife";
        goon.cls = enemies::kMedium;
        goon.x = 700;
        enemies::SetCurrentForTests({boss, goon});
        const position::Pos me = At(1000, 224, true, 0);
        struct Heard {
            int bells = 0, boss_ticks = 0;
            std::string now;
        };
        auto listen = [&](unsigned from, unsigned to) {
            Heard h;
            for (unsigned t = from; t < to; t += 10) {
                const cues::Output o = cues::Tick(t, me);
                h.now += o.say_now;
                for (const cues::PlayCmd& q : o.plays) {
                    h.bells += q.sound == audio::kEnemyOpening;
                    h.boss_ticks += q.sound == audio::kEnemyBoss || q.sound == audio::kEnemyBossBehind;
                }
            }
            return h;
        };
        cues::OnCue("en_vuln", 1400.f, 224.f, 120000);
        Heard h = listen(120000, 121000);
        Check(h.bells >= 5 && h.boss_ticks == 0, "a stunned boss: the bell (fast), not its tick; cued before the nearer goon");
        h = listen(121600, 122600);
        Check(h.bells == 0, "no opening report for 1.5 s: the bell stops");
        cues::OnCue("prompt_rt", 1400.f, 224.f, 123000);
        h = listen(123000, 124000);
        Check(h.now == "Grapple now" && h.bells >= 5, "the grapple prompt: 'Grapple now' at once, and the bell");
        cues::OnCue("prompt_rt", 1400.f, 224.f, 124100);
        h = listen(124100, 124500);
        Check(h.now.empty(), "the same prompt again within 3 s: not repeated");
        cues::OnCue("prompt_rt_stop", 1400.f, 224.f, 124500);
        h = listen(124600, 125600);
        Check(h.bells == 0, "the prompt gone: the bell stops");
        cues::OnCue("en_vuln", 700.f, 224.f, 126000);  // a dazed ordinary goon
        h = listen(126000, 127000);
        Check(h.bells == 0, "an ordinary goon's opening: no bell (bosses only)");
        cues::OnCue("prompt_x", 1400.f, 224.f, 127100);
        h = listen(127100, 127200);
        Check(h.now == "Mash attack", "the Butcher's choke prompt: 'Mash attack'");
        enemies::SetCurrentForTests({});
    }

    // B8 enemy cues.
    level_geometry::LoadFromString("[en]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 5000 192\n");
    level_geometry::SetLevel("en");
    cues::Reset();
    {
        auto enemy = [](uintptr_t id, const char* name, float x, float y) {
            enemies::Enemy e;
            e.item = id;
            e.name = name;
            e.cls = enemies::ClassOf(name);
            e.x = x;
            e.y = y;
            e.team = 1;
            return e;
        };
        auto run_en = [](unsigned from, unsigned to, const position::Pos& me) {
            Counts k;
            for (unsigned t = from; t < to; t += 10) {
                const cues::Output o = cues::Tick(t, me);
                for (const cues::PlayCmd& q : o.plays) {
                    ++k.plays[q.sound];
                    k.last[q.sound] = q;
                }
                k.said += o.say;
            }
            return k;
        };
        const position::Pos facing_right = At(1000, 224, true);
        const position::Pos facing_left = At(1000, 224, false);
        enemies::SetCurrentForTests({enemy(1, "med_thug_knifepistol", 1400, 224), enemy(2, "large_biker_charger", 2300, 224)});
        c = run_en(90000, 91000, facing_right);
        Check(c.plays[audio::kEnemyMedium] >= 2 && c.last[audio::kEnemyMedium].pan > 0.f && c.plays[audio::kEnemyLarge] == 0,
              "the nearest enemy (a goon 400 px ahead) ticks, panned right; only the nearest");
        c = run_en(91000, 92000, facing_left);
        Check(c.plays[audio::kEnemyMediumBehind] >= 2 && c.plays[audio::kEnemyMedium] == 0, "facing away: the muffled 'behind' tick");
        enemies::SetCurrentForTests({enemy(2, "large_biker_charger", 1300, 224)});
        c = run_en(92000, 93000, facing_right);
        Check(c.plays[audio::kEnemyLarge] >= 2, "a big goon: its own (deep) tick");
        enemies::SetCurrentForTests({enemy(3, "dog_black_teeth", 2800, 224)});
        c = run_en(93000, 94000, facing_right);
        Check(c.plays[audio::kEnemyDog] == 0, "beyond 1600 px: silent");
        // Attacks (B9-1): standard ones silent; a charge = the heavy buzz, once, from where it starts.
        enemies::SetCurrentForTests({});
        cues::OnCue("en_windup_std", 1300.f, 224.f, 93600);
        c = run_en(93600, 94000, facing_right);
        Check(c.plays[audio::kEnemyWindup] == 0 && c.plays[audio::kEnemyGrab] == 0, "a standard attack by a goon: silent");
        cues::OnCue("en_windup_charge", 1300.f, 224.f, 94000);
        c = run_en(94000, 94500, facing_right);
        Check(c.plays[audio::kEnemyWindup] == 1 && c.last[audio::kEnemyWindup].pan > 0.f, "a charge 300 px right: the heavy buzz, panned right");
        cues::OnCue("en_windup_charge", 3000.f, 224.f, 94600);
        c = run_en(94600, 95000, facing_right);
        Check(c.plays[audio::kEnemyWindup] == 0, "a charge 2000 px away: silent");
        // B13-4: a gunman aiming: the whine at once, repeated while he aims; his shot ends it.
        cues::OnCue("en_aim", 1800.f, 224.f, 94650);
        c = run_en(94650, 95000, facing_right);
        Check(c.plays[audio::kEnemyAim] == 1 && c.last[audio::kEnemyAim].pan > 0.f, "a gunman aiming 800 px right: the whine, panned right");
        cues::OnCue("en_aim", 1800.f, 224.f, 95000);  // (his aiming state again)
        c = run_en(95000, 95500, facing_right);
        Check(c.plays[audio::kEnemyAim] >= 1, "...repeated while he aims");
        cues::OnCue("en_windup_std", 1800.f, 224.f, 95500);  // he fires
        c = run_en(95500, 96000, facing_right);
        Check(c.plays[audio::kEnemyAim] == 0, "...and stops when he fires");
        cues::OnCue("en_aim", 1800.f, 224.f, 96000);
        c = run_en(96000, 97200, facing_right);
        Check(c.plays[audio::kEnemyAim] >= 1 && c.plays[audio::kEnemyAim] <= 3, "aiming reports stop: the whine stops within 0.8 s");
        cues::Reset();
        int whooshes = 0;
        for (unsigned t = 95100; t < 95600; t += 50) {
            if (t == 95100) cues::OnCue("en_windup_charge", 1300.f, 224.f, t);
            if (t == 95250) cues::OnCue("en_windup_charge", 1310.f, 224.f, t);  // the attack's next states
            if (t == 95400) {
                cues::OnCue("en_windup_charge", 1320.f, 224.f, t);
                cues::OnCue("en_windup_charge", 1000.f, 224.f, t);  // at Shank himself
            }
            whooshes += run_en(t, t + 50, facing_right).plays[audio::kEnemyWindup];
        }
        const int combo_whooshes = whooshes;
        cues::OnCue("en_windup_charge", 1300.f, 224.f, 96200);  // the same goon attacking again later
        whooshes += run_en(96200, 96300, facing_right).plays[audio::kEnemyWindup];
        Check(whooshes == combo_whooshes + 1, "a new attack 0.8 s later: another warning");
        whooshes = combo_whooshes;
        Check(whooshes == 1, "one attack (3 reports from one spot) = one warning; none at Shank's own spot");
        // A standard attack by a big goon: heavy. A grab: the grab chirps.
        enemies::SetCurrentForTests({enemy(20, "large_thug_grappler", 1310, 224)});
        cues::OnCue("en_windup_std", 1300.f, 224.f, 97000);
        c = run_en(97000, 97100, facing_right);
        Check(c.plays[audio::kEnemyWindup] == 1, "a big goon's standard attack: the heavy buzz");
        // B26: out of reach: a punch 15 tiles away is silent; a charge from there still warns; a gun's shot never does.
        enemies::SetCurrentForTests({enemy(20, "large_thug_grappler", 1960, 224)});
        cues::OnCue("en_windup_std", 1960.f, 224.f, 97500);
        const int far_std = run_en(97500, 97600, facing_right).plays[audio::kEnemyWindup];
        cues::OnCue("en_windup_charge", 1960.f, 224.f, 98200);
        const int far_charge = run_en(98200, 98300, facing_right).plays[audio::kEnemyWindup];
        cues::OnCue("en_windup_shot", 1300.f, 224.f, 98900);
        const cues::Output shot = cues::Tick(98910, facing_right);
        bool shot_silent = true;
        for (const cues::PlayCmd& q : shot.plays) shot_silent = shot_silent && q.sound != audio::kEnemyWindup && q.sound != audio::kEnemyGrab;
        Check(far_std == 0 && far_charge == 1 && shot_silent, "B26: a far punch silent, a far charge warns, a shot never warns");
        cues::OnCue("en_windup_grab", 1300.f, 224.f, 97600);
        c = run_en(97600, 97700, facing_right);
        Check(c.plays[audio::kEnemyGrab] == 1 && c.plays[audio::kEnemyWindup] == 0, "a grab: the grab chirps");
        enemies::SetCurrentForTests({});
        // Scan summary.
        enemies::SetCurrentForTests({enemy(1, "med_thug_knifepistol", 1400, 224), enemy(4, "med_biker_pistol", 700, 224),
                                     enemy(5, "girl_viper_uzi", 400, 416)});
        const std::string sum = cues::EnemySummary(facing_right);
        printf("  (summary: %s)\n", sum.c_str());
        Check(sum == "3 enemies. Nearest pistol goon, 5 tiles left", "N: the total and the nearest (B8d, shorter)");
        // Lock-on: the locked one is cued (not the nearest); the in-line ting when a level shot would hit it.
        std::string said = cues::LockNext(facing_right, false);
        Check(said == "pistol goon, 5 tiles left, 1 of 3", "L: the nearest first");
        c = run_en(95000, 96000, facing_left);
        Check(c.plays[audio::kLockInLine] >= 2 && c.last[audio::kLockInLine].semitones == 0.f, "locked, facing it, level: the in-line ting (straight)");
        c = run_en(96000, 97000, facing_right);
        Check(c.plays[audio::kLockInLine] >= 2 && c.last[audio::kLockInLine].semitones < -6.f, "facing away: in line for the back shot (low ting)");
        Check(cues::LockNext(facing_right, false) == "knife and pistol goon, 6 tiles right, 2 of 3", "L again: the next one out");
        said = cues::LockNext(facing_right, false);
        printf("  (third: %s)\n", said.c_str());
        Check(said == "girl with uzi, 9 tiles left, 3 tiles above, 3 of 3", "L again: the third");
        Check(cues::LockNext(facing_right, false) == "Lock off", "L after the last: off");
        Check(cues::LockNext(facing_right, true) == "No special enemies in pistols range", "K: none special here");
        enemies::SetCurrentForTests({enemy(1, "med_thug_knifepistol", 1400, 224), enemy(7, "large_biker_charger", 2000, 224),
                                     enemy(8, "med_thug_grenade", 600, 224)});
        Check(cues::LockNext(facing_right, true) == "grenadier, 6 tiles left, 1 of 2", "K: the nearest special (grenadier)");
        Check(cues::LockNext(facing_right, true) == "charger big goon, 16 tiles right, 2 of 2", "K again: the big goon");
        enemies::SetCurrentForTests({enemy(1, "med_thug_knifepistol", 1400, 224)});
        c = run_en(97000, 97100, facing_right);
        Check(c.said.empty() && c.plays[audio::kTargetDown] == 1 && c.last[audio::kTargetDown].pan > 0.f,
              "the locked enemy gone: the falling tone where it was (B23-2; no 'Target down' speech)");
        cues::LockNext(facing_right, false);
        Check(cues::LockNext(facing_right, false) == "Lock off", "and off");
        enemies::SetCurrentForTests({});
        Check(cues::LockNext(facing_right, false) == "No enemies in pistols range" && cues::EnemySummary(facing_right) == "No enemies nearby",
              "none: said so");
        // B8b: the lock-on range follows the gun he last armed (pistols 40 tiles until then; shotgun 8).
        enemies::SetCurrentForTests({enemy(6, "med_thug_knife", 1700, 224)});
        cues::Tick(97200, facing_right);
        Check(cues::CurrentGun().range_px == 40 * 64.f, "pistols by default");
        cues::OnGameSound("Shank/Character/Sounds/Attacks/Shotgun/Shotgun_Arm", 3000.f, 224.f, 97210);
        Check(cues::CurrentGun().range_px == 40 * 64.f, "someone else's arm sound far away: no change");
        cues::OnGameSound("Shank/Character/Sounds/Attacks/Shotgun/Shotgun_Arm", 1000.f, 224.f, 97220);
        Check(cues::CurrentGun().range_px == 8 * 64.f, "Shank arms the shotgun: 8 tiles");
        Check(cues::LockNext(facing_right, false) == "No enemies in shotgun range", "a goon 700 px away: out of shotgun range");
        cues::OnGameSound("Shank/Character/armPistols", 1000.f, 224.f, 97230);
        Check(cues::LockNext(facing_right, false) == "knife goon, 11 tiles right, 1 of 1", "pistols again: locked at 11 tiles");
        cues::LockNext(facing_right, false);
        // B8d: an enemy crossing to his other side: the pass whoosh on the side it went to.
        cues::Reset();
        {
            int passes = 0;
            cues::PlayCmd last_pass{};
            for (unsigned t = 98000; t < 99000; t += 10) {
                const float ex = 1200.f - (t - 98000) * 0.4f;  // 200 px right to 200 px left
                enemies::SetCurrentForTests({enemy(9, "med_thug_knife", ex, 224)});
                for (const cues::PlayCmd& q : cues::Tick(t, facing_right).plays) {
                    if (q.sound == audio::kEnemyPass) {
                        ++passes;
                        last_pass = q;
                    }
                }
            }
            Check(passes == 1 && last_pass.pan < 0.f, "a goon running past him right to left: one pass whoosh, on the left");
            // A special enemy coming near is named once.
            cues::Reset();
            enemies::SetCurrentForTests({enemy(10, "large_biker_charger", 1500, 224)});
            std::string heard;
            for (unsigned t = 99000; t < 99500; t += 10) heard += cues::Tick(t, facing_right).say;
            Check(heard == "charger big goon, right", "a special enemy coming near: named once");
            // Close enough to be on top of him: nearly continuous; louder than B8.
            enemies::SetCurrentForTests({enemy(11, "med_thug_knife", 1100, 224)});
            c = run_en(99500, 100500, facing_right);
            Check(c.plays[audio::kEnemyMedium] >= 15 && c.last[audio::kEnemyMedium].pan >= 0.24f, "on top of him (100 px): nearly continuous, panned clearly");
        }
        // B8e: the camera pan (test mode ;). A camera centred 1000 px right of Shank (half-width 1600): an enemy 200 px
        // right of him sounds right around Shank, but left by the camera, like its footsteps.
        cues::SetCameraPan([](float x, float* pan) {
            *pan = (x - 2000.f) / 1600.f;
            return true;
        });
        enemies::SetCurrentForTests({enemy(12, "med_thug_knife", 1200, 224)});
        c = run_en(101600, 102100, facing_right);
        Check(c.last[audio::kEnemyMedium].pan > 0.4f, "Shank-relative (default): right");
        Check(cues::ToggleEnemyCameraPan(), "; on: camera pan");
        c = run_en(102100, 102600, facing_right);
        Check(c.last[audio::kEnemyMedium].pan < -0.4f, "camera pan: left, where the game puts its footsteps");
        Check(!cues::ToggleEnemyCameraPan(), "; again: off");
        cues::SetCameraPan(nullptr);
        // B8d: a collected pickup stops at once.
        cues::Reset();
        cues::OnCue("beacon_health", 1300.f, 224.f, 100600);
        cues::Tick(100610, facing_right);
        cues::OnPickedUp("health", 1290.f, 224.f);
        c = run_en(100620, 101500, facing_right);
        Check(c.plays[audio::kPickup] == 0, "collected: the pickup beacon stops at once");
        Check(enemies::Describe("med_thug_machette") == "machete goon", "the game's spelling \"machette\"");
    }

    // B19-2: the turn whoosh, once per turn, panned a little to the new facing; not for the first report.
    {
        cues::Reset();
        position::Pos p;
        p.known = true;
        p.x = 1000.f;
        p.y = 224.f;
        auto turns = [&](unsigned t) {
            std::vector<float> pans;
            for (const cues::PlayCmd& c : cues::Tick(t, p).plays) {
                if (c.sound == audio::kTurn) pans.push_back(c.pan);
            }
            return pans;
        };
        cues::OnCue("turn_r", 1000.f, 224.f, 900000);
        const auto first = turns(900010);
        cues::OnCue("turn_l", 1000.f, 224.f, 900100);
        const auto left = turns(900110);
        const auto none = turns(900200);
        cues::OnCue("turn_r", 1000.f, 224.f, 900300);
        const auto right = turns(900310);
        Check(first.empty() && left.size() == 1 && left[0] < -0.2f && left[0] > -0.5f && none.empty() && right.size() == 1 &&
                  right[0] > 0.2f,
              "turn whoosh: once per turn, slightly to the new side, none for the first report");
    }
    // B19-1: the Butcher's hanging meat is listed as an enemy while it reports, then leaves the list.
    {
        cues::Reset();
        enemies::OnLevel();
        cues::OnCue("en_target_meat", 36940.f, 850.f, 950000);
        cues::OnCue("en_target_meat", 36300.f, 850.f, 950010);
        cues::OnCue("en_target_meat", 36940.f, 850.f, 950500);  // the same slab again
        auto meat = [] {
            int n = 0;
            for (const enemies::Enemy& e : enemies::Current()) {
                if (e.name == "meatslab" && e.item > 0 && e.item < enemies::kTargetIdLimit) ++n;
            }
            return n;
        };
        const int both = meat();
        position::Pos unknown;
        enemies::Update(951500, unknown);  // (B22-1: a 1.5 s gap, as in slow motion: still listed)
        const int still = meat();
        enemies::Update(953200, unknown);  // 36300 last reported at 950010: stale (B22-1: 3 s)
        const int one = meat();
        enemies::Update(954000, unknown);
        Check(both == 2 && still == 2 && one == 1 && meat() == 0 && enemies::Describe("meatslab") == "hanging meat" && enemies::Describe("doorbreakopen") == "breakable door",
              "hanging meat: listed while it reports, gone once shot down");
    }
    // B23-4..7: set up for an opening = the slow bell (kEnemySetup) on the boss: Toro's charge (reported), the Butcher
    // with a lowered slab and Shank in front of him, the Gimp with a slave between, the Priest with a fire trap between.
    {
        level_geometry::LoadFromString("[su]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 100000 192\n");
        level_geometry::SetLevel("su");
        auto mk = [](uintptr_t id, const char* name, float x, float y) {
            enemies::Enemy e;
            e.item = id;
            e.name = name;
            e.cls = enemies::ClassOf(name);
            e.x = x;
            e.y = y;
            e.team = 1;
            return e;
        };
        struct Bells {
            int setup = 0, open = 0, lock = 0;
        };
        auto bells = [](unsigned from, unsigned to, const position::Pos& p, const char* report = nullptr, float rx = 0,
                        float ry = 0) {
            Bells b;
            for (unsigned t = from; t < to; t += 10) {
                if (report && t % 500 == 0) cues::OnCue(report, rx, ry, t);
                for (const cues::PlayCmd& q : cues::Tick(t, p).plays) {
                    b.setup += q.sound == audio::kEnemySetup;
                    b.open += q.sound == audio::kEnemyOpening;
                    b.lock += q.sound == audio::kLockTick;
                }
            }
            return b;
        };
        const position::Pos p = At(1000, 224, true, 0);
        // Toro's charge: en_setup .. en_setup_end; then en_vuln = the fast bell.
        cues::Reset();
        enemies::OnLevel();
        enemies::SetCurrentForTests({mk(50, "boss_toro", 1800, 224)});
        const Bells t0 = bells(1000000, 1002000, p);
        cues::OnCue("en_setup", 1800, 224, 1002000);
        const Bells t1 = bells(1002000, 1004000, p);
        cues::OnCue("en_setup_end", 1800, 224, 1004000);
        const Bells t2 = bells(1004000, 1006000, p);
        cues::OnCue("en_vuln", 1800, 224, 1006000);
        const Bells t3 = bells(1006000, 1006500, p);
        Check(t0.setup == 0 && t1.setup >= 2 && t2.setup == 0 && t3.open >= 2 && t3.setup == 0,
              "Toro's charge: the slow bell from en_setup to en_setup_end; open: the fast bell");
        // The Butcher at 1500 facing Shank at 1000: a lowered slab at 1200 (300 in front of him) lines him up.
        cues::Reset();
        enemies::OnLevel();
        enemies::SetCurrentForTests({mk(51, "boss_butcher", 1500, 224)});
        const Bells b0 = bells(1010000, 1012000, p);
        const Bells b1 = bells(1012000, 1014000, p, "en_target_meat_low", 1200, 850);
        const Bells b2 = bells(1014000, 1016000, At(1900, 224, false, 0), "en_target_meat_low", 1200, 850);  // Shank behind him
        Check(b0.setup == 0 && b1.setup >= 2 && b2.setup == 0,
              "the Butcher: the slow bell with a lowered slab and Shank in front of him, not with Shank behind him");
        // ... over the lock (auto-locked on the lowered slab): the bell, not the lock tick.
        Check(b1.lock == 0, "the Butcher's slow bell is cued over the lock on the slab");
        // The Gimp at 1600, Shank at 1000 (600 away): a slave at 1300 between them.
        cues::Reset();
        enemies::OnLevel();
        enemies::SetCurrentForTests({mk(52, "boss_gimp", 1600, 224), mk(53, "med_gimp_slave", 1300, 224)});
        const Bells g1 = bells(1020000, 1022000, p);
        enemies::SetCurrentForTests({mk(52, "boss_gimp", 1600, 224), mk(53, "med_gimp_slave", 1900, 224)});
        const Bells g2 = bells(1022000, 1024000, p);
        enemies::SetCurrentForTests({mk(52, "boss_gimp", 1150, 224), mk(53, "med_gimp_slave", 1100, 224)});
        const Bells g3 = bells(1024000, 1026000, p);  // (too close: he grabs, doesn't charge)
        Check(g1.setup >= 2 && g2.setup == 0 && g3.setup == 0, "the Gimp: the slow bell with a slave between them (Shank far enough)");
        // (B23 session) Shank clinging high on the end wall above the slave: the Gimp still charges into the slave.
        enemies::SetCurrentForTests({mk(52, "boss_gimp", 1600, 224), mk(53, "med_gimp_slave", 1050, 224)});
        const Bells g4 = bells(1026000, 1028000, At(1000, 1050, true, 0));
        Check(g4.setup >= 2, "the Gimp: the slow bell with Shank high on the wall above the slave");
        // The Priest at 1700: a fire trap at 1400 between him and Shank.
        cues::Reset();
        enemies::OnLevel();
        enemies::SetCurrentForTests({mk(54, "boss_priest", 1700, 224)});
        const Bells r0 = bells(1030000, 1032000, p);
        const Bells r1 = bells(1032000, 1034000, p, "hz_fire", 1400, 224);
        Check(r0.setup == 0 && r1.setup >= 2, "the Priest: the slow bell with a fire trap between him and Shank");
        // B24 (the Priest session): a trap 5 tiles behind him, Shank on the other side (the hits knock him into it).
        cues::Reset();
        enemies::SetCurrentForTests({mk(54, "boss_priest", 1400, 224)});
        const Bells r2 = bells(1034000, 1036000, p, "hz_fire", 1720, 224);
        enemies::SetCurrentForTests({mk(54, "boss_priest", 1400, 224)});
        const Bells r3 = bells(1036000, 1038000, p, "hz_fire", 2100, 224);  // (11 tiles behind: too far)
        Check(r2.setup >= 2 && r3.setup == 0, "the Priest: the slow bell with a trap close behind him (knock him into it)");
        // B25: stunned in the flames: "Wait" at once, "Grapple now" and the fast bell only when he's out of them.
        {
            struct Heard {
                std::string said;
                int open = 0;
            };
            auto run = [&](unsigned from, unsigned to, float fire_x) {
                Heard h;
                for (unsigned t = from; t < to; t += 10) {
                    if (t % 500 == 0) cues::OnCue("hz_fire", fire_x, 224, t);
                    const cues::Output o = cues::Tick(t, p);
                    h.said += o.say_now.empty() ? "" : o.say_now + "|";
                    for (const cues::PlayCmd& q : o.plays) h.open += q.sound == audio::kEnemyOpening;
                }
                return h;
            };
            cues::Reset();
            enemies::SetCurrentForTests({mk(54, "boss_priest", 1850, 224)});  // at the flames' edge (trap 1940)
            run(1040000, 1040500, 1940);
            cues::OnCue("prompt_rt", 1850, 224, 1040500);
            const Heard w = run(1040500, 1040800, 1940);
            enemies::SetCurrentForTests({mk(54, "boss_priest", 1600, 224)});  // walked out toward Shank
            const Heard g = run(1040800, 1041300, 1940);
            Check(w.said == "Wait|" && w.open == 0 && g.said == "Grapple now|" && g.open >= 2,
                  "the Priest stunned in the flames: 'Wait', then 'Grapple now' and the fast bell once he's clear");
            // Away from the fire: at once, as before.
            cues::Reset();
            enemies::SetCurrentForTests({mk(54, "boss_priest", 1500, 224)});
            run(1042000, 1042500, 1940);
            cues::OnCue("prompt_rt", 1500, 224, 1042500);
            const Heard a = run(1042500, 1042800, 1940);
            Check(a.said == "Grapple now|" && a.open >= 1, "the Priest stunned away from the fire: 'Grapple now' at once");
            // B25b: still near the fire (within 300 px): no "Grapple now", however long; knocked back near it after the
            // release: "Wait" again, the bell stops; clear again: "Grapple now".
            cues::Reset();
            enemies::SetCurrentForTests({mk(54, "boss_priest", 1770, 224)});  // 170 px out: not clear yet
            run(1044000, 1044500, 1940);
            cues::OnCue("prompt_rt", 1770, 224, 1044500);
            const Heard s1 = run(1044500, 1047000, 1940);
            enemies::SetCurrentForTests({mk(54, "boss_priest", 1600, 224)});
            const Heard s2 = run(1047000, 1047500, 1940);
            enemies::SetCurrentForTests({mk(54, "boss_priest", 1750, 224)});  // Shank's hits pushed him back
            const Heard s3 = run(1047500, 1048000, 1940);
            enemies::SetCurrentForTests({mk(54, "boss_priest", 1580, 224)});
            const Heard s4 = run(1048000, 1048500, 1940);
            Check(s1.said == "Wait|" && s1.open == 0 && s2.said == "Grapple now|" && s3.said == "Wait|" &&
                      s4.said == "Grapple now|" && s4.open >= 2,
                  "the Priest near the fire: 'Wait' until he's 300 px out; pushed back: 'Wait' again, then 'Grapple now'");
        }
        cues::Reset();
        enemies::OnLevel();
        enemies::SetCurrentForTests({});
    }
    // B21: the hanging meats lock on by themselves; shot down = the falling tone (not "Target down") and the next one.
    {
        level_geometry::LoadFromString("[bf]\nsurface 0 - wall 64 0 wall 64 0 2 35000 192 38000 192\n");
        level_geometry::SetLevel("bf");
        cues::Reset();
        enemies::OnLevel();
        enemies::SetCurrentForTests({});
        position::Pos p = At(36700, 224, true, 0);
        struct Got {
            int lock_ticks = 0, downs = 0;
            float down_pan = 0;
            std::string said;
        };
        auto run = [&](unsigned from, unsigned to, bool meat_a, bool meat_b, float bx = 36300.f) {
            Got g;
            for (unsigned t = from; t < to; t += 10) {
                if (t % 500 == 0) {
                    if (meat_a) cues::OnCue("en_target_meat", 36940.f, 850.f, t);
                    if (meat_b) cues::OnCue("en_target_meat", bx, 850.f, t);
                }
                const cues::Output o = cues::Tick(t, p);
                for (const cues::PlayCmd& q : o.plays) {
                    g.lock_ticks += q.sound == audio::kLockTick;
                    if (q.sound == audio::kTargetDown) {
                        ++g.downs;
                        g.down_pan = q.pan;
                    }
                }
                g.said += o.say;
            }
            return g;
        };
        const Got a = run(960000, 962000, true, true);  // no L pressed
        cues::OnCue("en_tgdown_meat", 36940.f, 850.f, 962000);
        const Got b = run(962000, 964000, false, true);
        Check(a.lock_ticks >= 2 && b.downs == 1 && b.down_pan > 0.f && b.said.find("Target down") == std::string::npos &&
                  b.lock_ticks >= 2,
              "hanging meat: locked by itself; shot down plays the falling tone (right), no speech; the other one locked");
        const std::string off = cues::LockNext(p, false);  // (the only candidate: L turns it off)
        const Got c = run(964000, 966000, false, true);
        const Got d = run(966000, 968000, false, true, 36000.f);  // a meat newly shootable (another spot)
        printf("  (after L to off: %d lock ticks; a new meat: %d)\n", c.lock_ticks, d.lock_ticks);
        Check(off == "Lock off" && c.lock_ticks == 0 && d.lock_ticks >= 2,
              "L turns the lock off: no auto lock until a meat newly becomes shootable");
        cues::Reset();
        enemies::OnLevel();
    }

    if (argc > 1) CoInitializeEx(nullptr, COINIT_MULTITHREADED);  // XAudio2 needs COM (0x800401f0 without it)
    if (argc > 1 && std::strcmp(argv[1], "--start") == 0) Check(audio::Start(), "XAudio2 started (nothing played)");
    if (argc > 1 && std::strcmp(argv[1], "--play") == 0) {
        Check(audio::Start(), "XAudio2 started");
        const struct {
            audio::Sound s;
            float pan, semis;
            const char* what;
        } demo[] = {{audio::kDrop, -0.5f, 0.f, "drop, left"}, {audio::kDrop, 0.5f, 0.f, "drop, right"},
                    {audio::kDeadly, 0.5f, 0.f, "deadly drop, right"}, {audio::kWall, 0.5f, 0.f, "wall, right"},
                    {audio::kPickup, -1.f, 0.f, "pickup, far left"}, {audio::kPickup, 0.f, 5.f, "pickup, centre, above"},
                    {audio::kPickup, 1.f, -5.f, "pickup, right, below"}, {audio::kInReach, 0.f, 0.f, "in reach"}};
        for (const auto& d : demo) {
            printf("playing: %s\n", d.what);
            audio::Play(d.s, d.pan, d.semis, 1.f);
            Sleep(700);
        }
    }
    // B29-1 / B29-4: deaths heard from the game's sounds.
    level_geometry::LoadFromString("[dd]\nsurface 0 - wall 64 0 wall 64 0 2 0 192 9000 192\n");
    level_geometry::SetLevel("dd");
    cues::Reset();
    {
        auto enemy = [](uintptr_t id, const char* name, float x, float y) {
            enemies::Enemy e;
            e.item = id;
            e.name = name;
            e.cls = enemies::ClassOf(name);
            e.x = x;
            e.y = y;
            e.team = 1;
            return e;
        };
        auto run = [](unsigned from, unsigned to, const position::Pos& me) {
            Counts k;
            for (unsigned t = from; t < to; t += 10) {
                for (const cues::PlayCmd& q : cues::Tick(t, me).plays) {
                    ++k.plays[q.sound];
                    k.last[q.sound] = q;
                }
            }
            return k;
        };
        const position::Pos me = At(1000, 224, true);
        // B30-1 (the B29 log): a death = the enemy leaves the list, and its death sound comes in the same ms (after it).
        // Two goons on screen; the near one dies: no tone (another is on screen).
        enemies::SetCurrentForTests({enemy(1, "med_thug_knife", 1300, 224), enemy(2, "med_thug_knife", 1600, 224)});
        run(200000, 201000, me);
        enemies::SetCurrentForTests({enemy(2, "med_thug_knife", 1600, 224)});
        cues::OnGameSound("Shank/Character/enemyDeath", 1300, 224, 201000);
        cues::OnGameSound("Shank/Character/Voices/MediumGoon/MediumGoon_Death", 1300, 224, 201010);  // (both sounds: one death)
        Counts c = run(201000, 202500, me);
        Check(c.plays[audio::kTargetDown] == 0, "B29-1: a goon dies near, another on screen: no tone");
        // The last one on screen dies: the tone (its death sound arrives a tick after it left the list).
        enemies::SetCurrentForTests({});
        run(202500, 202520, me);
        cues::OnGameSound("Shank/Character/enemyDeath", 1600, 224, 202520);
        c = run(202520, 203000, me);
        Check(c.plays[audio::kTargetDown] == 1, "B29-1 / B30-1: the last enemy on screen dies: the tone");
        // One leaves the list without a death sound (a despawn): no tone.
        enemies::SetCurrentForTests({enemy(10, "med_thug_knife", 1400, 224)});
        run(203000, 203200, me);
        enemies::SetCurrentForTests({});
        c = run(203200, 204000, me);
        Check(c.plays[audio::kTargetDown] == 0, "B31-1: an enemy killed within a second of appearing (3-c's rockets): no tone");
        // One dies beyond the cue range (blown off a platform, the user) while another is near: the tone.
        enemies::SetCurrentForTests({enemy(3, "med_thug_knife", 1200, 224), enemy(4, "med_thug_pistol", 3100, 224)});
        run(204000, 205200, me);  // (listed over a second: not a fresh spawn)
        enemies::SetCurrentForTests({enemy(3, "med_thug_knife", 1200, 224)});
        cues::OnGameSound("Shank/Character/enemyDeath", 3100, 224, 205200);
        c = run(205200, 205800, me);
        Check(c.plays[audio::kTargetDown] == 1 && c.last[audio::kTargetDown].pan > 0.f, "B29-1: a death beyond the cue range: the tone");
        // One screams as it falls to its death, far away, then dies (the last one): never a tone.
        enemies::SetCurrentForTests({enemy(5, "med_thug_knife", 3000, 224)});
        run(205800, 206000, me);
        cues::OnGameSound("Shank/Character/Voices/MediumGoon/MediumGoon_YellFalling", 3050, 150, 206000);
        run(206000, 206500, me);
        enemies::SetCurrentForTests({});
        cues::OnGameSound("Shank/Character/enemyDeath", 3000, 224, 206500);
        c = run(206500, 207000, me);
        Check(c.plays[audio::kTargetDown] == 0, "B29-1: an enemy that fell to its death: no tone");
        // B31-1: Shank dies (a respawn empties the list): no tone; nor when several leave at once.
        enemies::SetCurrentForTests({enemy(11, "med_thug_knife", 1300, 224)});
        run(208000, 209500, me);
        cues::OnGameSound("Shank/Character/Voices/Shank/Shank_Death", 1000, 224, 209500);
        enemies::SetCurrentForTests({});
        c = run(209500, 210200, me);
        Check(c.plays[audio::kTargetDown] == 0, "B31-1: the list emptied as Shank dies: no tone");
        enemies::SetCurrentForTests({enemy(12, "med_thug_knife", 1300, 224), enemy(13, "med_thug_knife", 1400, 224),
                                     enemy(14, "med_thug_knife", 1500, 224)});
        run(211000, 212500, me);
        enemies::SetCurrentForTests({});
        c = run(212500, 213200, me);
        Check(c.plays[audio::kTargetDown] == 0, "B31-1: three leave at once (a despawn): no tone");
        // B31-1: a kill with no death sound at all (finishers, grapple kills): the last on screen still gets the tone.
        enemies::SetCurrentForTests({enemy(15, "med_thug_knife", 1300, 224)});
        run(214000, 215500, me);
        enemies::SetCurrentForTests({});
        c = run(215500, 216200, me);
        Check(c.plays[audio::kTargetDown] == 1, "B31-1: the last on screen killed without a death sound: the tone");
        // Shank's own death voice is not an enemy's death.
        enemies::SetCurrentForTests({enemy(6, "med_thug_knife", 1050, 224)});
        run(207000, 207300, me);
        cues::OnGameSound("Shank/Character/Voices/Shank/Shank_Death", 1000, 224, 207300);
        c = run(207300, 207800, me);
        Check(c.plays[audio::kTargetDown] == 0 && c.plays[audio::kEnemyMedium] >= 1, "B29-1: Shank's death voice isn't an enemy's");
        // B29-4: a boss open (the grapple prompt): Shank grapples (the finisher starts): the bell stops at once and stays off
        // while the finisher runs, although its state still reports open.
        enemies::SetCurrentForTests({enemy(9, "boss_cesar", 1300, 224)});
        cues::OnCue("prompt_rt", 1300, 224, 208000);
        c = run(208000, 208500, me);
        Check(c.plays[audio::kEnemyOpening] >= 1, "B29-4: the boss open: the bell");
        cues::OnGameSound("Shank/Character/shankGrapple", 1010, 224, 208500);
        Counts during;
        for (unsigned t = 208500; t < 210500; t += 100) {
            cues::OnCue("en_vuln", 1300, 224, t);
            for (const cues::PlayCmd& q : cues::Tick(t, me).plays) ++during.plays[q.sound];
        }
        Check(during.plays[audio::kEnemyOpening] == 0, "B29-4: Shank grapples: no bell during the finisher");
        // The boss bar reaches 0: the boss is out of the cues at once.
        cues::OnBossHealth(12.f);
        cues::OnBossHealth(0.f);
        c = run(211000, 212000, me);
        Check(c.plays[audio::kEnemyBoss] == 0 && c.plays[audio::kEnemyBossBehind] == 0, "B29-4: the boss bar at 0: the boss isn't cued");
        // B35-1: at 0 health from weapons the boss waits open for the finisher ("Grapple now"): the open bell plays.
        cues::OnCue("prompt_rt", 1300, 224, 212000);
        c = run(212000, 212800, me);
        Check(c.plays[audio::kEnemyOpening] >= 1, "B35-1: a boss at 0 health, open to the finisher: the open bell");
        cues::OnCue("prompt_rt_stop", 1300, 224, 212800);
        c = run(212800, 213500, me);
        Check(c.plays[audio::kEnemyOpening] == 0 && c.plays[audio::kEnemyBoss] == 0, "B35-1: the prompt over: out of the cues again");
        enemies::SetCurrentForTests({});
        run(213500, 214500, me);  // (the defeated boss's leave decided)
        // B36-1 (the B35 log, 2-c's final fight): three on screen shot within 125 ms: one tone, for the last.
        cues::Reset();
        enemies::SetListLostForTests(0);
        enemies::SetCurrentForTests({enemy(20, "large_viper_grappler", 1300, 224), enemy(21, "large_viper_minigun", 700, 224),
                                     enemy(22, "large_viper_charger", 690, 224)});
        run(220000, 221500, me);
        enemies::SetCurrentForTests({enemy(21, "large_viper_minigun", 700, 224), enemy(22, "large_viper_charger", 690, 224)});
        c = run(221500, 221560, me);
        enemies::SetCurrentForTests({enemy(22, "large_viper_charger", 690, 224)});
        Counts c2 = run(221560, 221620, me);
        enemies::SetCurrentForTests({});
        Counts c3 = run(221620, 222500, me);
        Check(c.plays[audio::kTargetDown] + c2.plays[audio::kTargetDown] + c3.plays[audio::kTargetDown] == 1 &&
                  c3.last[audio::kTargetDown].pan < 0.f,
              "B36-1: three killed in quick succession: one tone, where the last one died");
        // B36-1: the list lost as the level unloads (after Denny's end video): no tone.
        enemies::SetCurrentForTests({enemy(23, "boss_gimp", 1300, 224), enemy(24, "med_gimp_slave", 1400, 224)});
        run(223000, 224500, me);
        enemies::SetListLostForTests(224500);
        enemies::SetCurrentForTests({});
        c = run(224500, 225500, me);
        Check(c.plays[audio::kTargetDown] == 0, "B36-1: the enemy list lost as the level unloads: no tone");
        enemies::SetListLostForTests(0);
        // B36-1: a boss leaving undefeated (3-c's start: the Priest walks off), even far away: no tone.
        enemies::SetCurrentForTests({enemy(25, "boss_priest", 2700, 224)});
        run(226000, 227500, me);
        enemies::SetCurrentForTests({});
        c = run(227500, 228500, me);
        Check(c.plays[audio::kTargetDown] == 0, "B36-1: a boss leaving undefeated: no tone");
        // ...but a defeated one (his bar at 0 first) dying as the last on screen: the tone.
        enemies::SetCurrentForTests({enemy(26, "boss_gimp", 1300, 224)});
        run(229000, 230500, me);
        cues::OnBossHealth(40.f);
        cues::OnBossHealth(0.f);
        enemies::SetCurrentForTests({});
        c = run(230500, 231500, me);
        Check(c.plays[audio::kTargetDown] == 1, "B36-1: a defeated boss dies, the last on screen: the tone");
        // B36b-2 (4-c): a rifle goon perched 2300 px left, just outside an arena (its left edge 300 px right of him).
        cues::Reset();
        cues::Area arena;
        arena.known = true;
        arena.arena = true;
        arena.min_x = -1000;
        arena.max_x = 1400;
        arena.min_y = -500;
        arena.max_y = 1500;
        cues::SetArea(arena);
        enemies::SetCurrentForTests({enemy(30, "med_mobster_ak47", -1300, 224)});
        c = run(232000, 234000, me);
        Check(c.plays[audio::kEnemyMedium] + c.plays[audio::kEnemyMediumBehind] >= 1,
              "B36b-2: an enemy in the arena (within its margin) beyond the cue range: still cued");
        enemies::SetCurrentForTests({enemy(30, "med_mobster_ak47", -1300, 224), enemy(31, "med_mobster_knife", 1200, 224)});
        run(234000, 235500, me);
        enemies::SetCurrentForTests({enemy(30, "med_mobster_ak47", -1300, 224)});
        c = run(235500, 236500, me);
        Check(c.plays[audio::kTargetDown] == 0, "B36b-2: one dies while another is left in the arena off screen: no tone");
        arena.arena = false;  // the level's default bounds: no arena
        cues::SetArea(arena);
        enemies::SetCurrentForTests({enemy(32, "med_mobster_ak47", -1300, 224)});
        c = run(237000, 239000, me);
        Check(c.plays[audio::kEnemyMedium] + c.plays[audio::kEnemyMediumBehind] == 0, "B36b-2: no arena: beyond the range, not cued");
        cues::SetArea(cues::Area{});
        enemies::SetCurrentForTests({});
    }

    // B44-4 (the user: the strings hot / cold, "use the speed values for the pickup sounds"): a pole no jump reaches from
    // here plucks every ~0.4 s close by, ~0.7 s 10 tiles off (the pickups' 400 + 800 ms over 1600 px).
    {
        level_geometry::LoadFromString(
            "[p]\n"
            "surface 0 - wall 640 0 wall 640 0 2 0 192 8000 192\n"
            "feature pole 2 4000 2000 4000 3000\n");  // high above: a target in range, never reached
        level_geometry::SetLevel("p");
        cues::Reset();
        Counts nearc = Run(240000, 246000, 3800, 2000, true, 0);  // (in the air beside it, 3 tiles off: no jump judged)
        cues::Reset();
        Counts farc = Run(246000, 252000, 3800, 1400, true, 0);  // (10 tiles off)
        printf("pluck hot / cold: %d near, %d far in 6 s\n", nearc.plays[audio::kTarget], farc.plays[audio::kTarget]);
        Check(nearc.plays[audio::kTarget] >= 11 && nearc.plays[audio::kJumpNow] == 0, "B44-4: close to a target out of reach: quick plucks, no chirp");
        Check(farc.plays[audio::kTarget] < nearc.plays[audio::kTarget] && farc.plays[audio::kTarget] >= 6, "B44-4: further off: slower plucks");
    }

    printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "PASSED", g_failures);
    return g_failures ? 1 : 0;
}
