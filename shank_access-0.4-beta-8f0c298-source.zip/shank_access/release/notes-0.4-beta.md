Shank Access 0.4 beta adds a Cheats menu, makes the boss grapple bell more reliable, and tells new players how to pick
up items. It also includes the fixes from 0.3.1 and 0.3.2.

## Installing or updating

Download **shank-access-setup.exe** below and run it. Your settings are kept, and updating takes a few seconds because
the routes between checkpoints don't need working out again.

## Cheats

The mod menu (F7) has a new Cheats category. Everything in it starts off, and your choices are remembered.

- **Cheats** turns all the cheats you've chosen on or off together.
- **Spawn items** drops a minigun, a flamethrower, a health pickup or a grenade pickup in front of Shank. Choose one in
  the menu and it drops when you unpause; choose it again before then to cancel. You can have one of each at a time.
  If one is already on screen, or Shank is carrying that weapon, the mod tells you where it is instead.
- **Go to checkpoint**, shown while you're in a level, restarts the level at any of its checkpoints.
- **Skip startup movies** skips the logo and intro movies from the next start.
- **Infinite health**, **infinite grenades**, and the game's own **god mode** (enemies go down in one hit) and **super
  speed**. Infinite health can't save Shank from pits and other instant deaths.
- The Cheats switch, each cheat and each item can have its own key and controller button. None are set until you give
  them one. Delete now clears a key as well as a controller button.

## Other changes

- A boss's grapple bell now stops when his finisher actually starts. Before, a grapple that only just missed could
  stop it early.
- The Butcher's "lined up" bell now rings in more of the spots where his hook will catch a lowered slab, including
  slabs right above him and near the far end of his reach.
- The first two times an item comes in reach, the mod says how to pick it up: "Health in reach, hold Down and press
  Grapple" (on the classic version, Attack). The game itself never explains this.
- From 0.3.1 and 0.3.2: setup works with Windows in any language and with any letters in folder names, and Shank no
  longer sometimes hangs when it starts.

Single player only. Copies of Shank from outside Steam aren't supported yet; on those, the mod says it's disabled.

Version 0.4-beta-REV. The source zip below has the full source for this version.
