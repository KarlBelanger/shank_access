# shank-access — project memory

Screen-reader and audio accessibility mod for **Shank** (Klei, 2010; Steam PC build of 2012) for a blind player.
The user directs the work and does all gameplay testing. Claude writes the code, does the reverse engineering, and reads the logs.

## Start every session here (and after every compaction)
A SessionStart hook (`.claude/settings.json` → `tools/session_context.py`) injects a briefing on startup, resume, `/clear` and **after compaction**. The briefing contains:
- the PLAN Status and **In flight** sections;
- tests awaiting the user;
- the recent work log;
- git status and recent commits.

Then:
1. **After a compaction, don't trust the summary for details.** Re-read the In flight section and any doc it points to before acting.
2. Read the docs relevant to the task:
   - [docs/PLAN.md](docs/PLAN.md): plan, decisions, work log.
   - [docs/RE-NOTES.md](docs/RE-NOTES.md): engine facts. Check here before any reverse engineering, and don't re-derive what's recorded.
   - [docs/DESIGN.md](docs/DESIGN.md): cues, hotkeys, config, the user's goals and feedback.
   - [docs/TESTING.md](docs/TESTING.md): test session records.

## Memory discipline (mandatory; the user has lost details to compaction before)
Anything that exists only in the conversation is at risk. Write things down **when they happen**, not in batches:
- **Starting a task, asking the user a question, asking for a test, or promising something** → update PLAN **In flight** right away. Clear it when resolved.
- **Decision made** → PLAN Decision log, with the reason.
- **Task done** → PLAN checkboxes, the Status block, and a Work log line.
- **Engine fact learned** (including negative results) → RE-NOTES, marked **(hypothesis)** or **(confirmed date, how)**.
- **Test session** → a TESTING.md entry: write it before the user plays, and complete it after.
- **The user says how something should sound, feel or work** → DESIGN.md, dated, close to their wording.
- **Standing preference or rule from the user** → CLAUDE.md.
- **Something earlier gets settled** (a question answered, an option picked, a deploy tested, a hypothesis confirmed, an offer declined, a feature dropped) → change the **original** open marker in place, everywhere it appears: the In flight record, the checkbox, the Status block, TESTING's header, DESIGN, RE-NOTES. A new entry alone leaves the old "waiting" behind. A 2026-09-29 audit found about 30 of these left stale (`/sync-memory` step 4; `tools/open_items.py` lists every open-looking line).

**Run the `/sync-memory` skill** (a full comparison of the conversation against the docs; the user can also type it). Note: `/checkpoint` is a *built-in* Claude Code command, not ours:
- at the end of every task or test session;
- before any long-running or risky operation;
- whenever the conversation has grown long since the last checkpoint (roughly every 150k tokens);
- whenever the user asks.

Commit docs together with the code they describe. A new session must be able to continue from the docs and the briefing alone.

## Hard rules
- **The game folder** (`C:\Program Files (x86)\Steam\steamapps\common\Shank`; moved there from `D:\SteamLibrary\...` by the user through Steam on 2026-09-28) is modified **only** through `tools/deploy.py`, and only when the user is ready to test.
  - Reading the game folder (analysis, `collect_logs.py`, `record-pristine`) is fine.
  - Never hand-edit or copy files into it.
- **Never commit Klei assets** (Lua scripts, gfx, sounds, textures, levels) or anything derived that reproduces them. Ship our own files (`mod/files/`) and patches (`mod/patches/*.patch.json`). `build/` is gitignored and holds the regenerable derived data.
- **All game-side Lua must be Lua 5.0:**
  - No `#`: use `table.getn`.
  - No `...` in expressions: use `arg`.
  - No `%`: use `math.mod`.
  - No `string.gmatch`: use `string.gfind`.
  - Run `tools/luacheck50.py` before every deploy. A Lua error at load kills the game.
- **The game is 32-bit.** All native code is built for x86 (`-A Win32`). Third-party DLLs must be x86.
- **Text with backslashes (C++ or docs with Windows paths):** use the Edit/Write tools. A Python heredoc string containing `C:\Program Files\...\userdata\...` failed with a unicode-escape error (2026-09-25).
- **Editing C++ source:** use the Edit/Write tools, not Python heredocs with escaped strings. Backslashes in C++ string literals got mangled twice that way, and only compiler warning C4129 caught it. Treat every C4129 as a bug. It happened again on 2026-09-25/26: a `\n` in a Python string became a real line break in a C++ test, and an `r` escape became a control character. **Any C++ or doc text with a backslash: use the Edit tool, never Python.** It happened again on 2026-09-26 (test strings with `\n`, a Python line continuation, and this very sentence in CLAUDE.md). It also bites Python and sed run through the Bash tool (2026-09-27): even a quoted `<<'EOF'` heredoc lost `\\` → `\` (Python syntax errors, a PLAN line lost its backslashes). Write Python files that contain backslashes with the Write tool too. And when Python edits a UTF-8 file, open it with `encoding='utf-8'`: a `°` written in the Windows code page broke jump_model.h (warning C4828).
- **Addresses** are only valid for Shank.exe SHA-256 `a3b58dde…9e2a`. Native code must verify this at startup and disable itself on a mismatch.
- **Deploying is outward-facing to the user's game install.** Ask before running `deploy`/`uninstall`, unless the user has just said to deploy.

## Layout
- `docs/PLAN.md`: the phased plan, Status, **In flight**, decisions, work log.
- `docs/RE-NOTES.md`: engine facts: addresses, sound system, Lua/stategraphs, levels, UI.
- `docs/DESIGN.md`: sound vocabulary, cue/hotkey/config registry, the user's goals and feedback.
- `docs/TESTING.md`: the test session procedure and one record per gameplay test.
- `docs/COOP-PLAN.md`: a plan for solo co-op (the mod follows one player, a bot plays the other through a virtual pad); not started, co-op out of scope for now.
- `.claude/settings.json`: SessionStart hook → `tools/session_context.py` (the briefing; standard library only).
- `.claude/skills/sync-memory/`: the `/sync-memory` context-to-docs sync procedure (step 4 closes stale open items).
- `tools/open_items.py`: lists every open-looking line in the docs (waiting, awaiting, untested, hypothesis, unchecked boxes, unfinished TESTING headers) for `/sync-memory`'s sweep; `--all` includes the PLAN logs and finished TESTING entries.
- `tools/deploy.py`: plan/deploy/status/verify/uninstall/record-pristine. Backups are in `%LOCALAPPDATA%\shank-access\deploy\`. Since 2026-09-27 patches of `data/` files are written to the same path under `data-pc/` (new files; the game's PhysFS searches data-pc first), so the game's own files stay vanilla and Steam's verify has nothing to undo.
- `tools/luacheck50.py`: Lua 5.0 syntax check of everything that would be deployed (uses `build/lua50/Release/luac50.exe`).
- `tools/loadtest50.py`: **runs** patched game scripts under real Lua 5.0 (harness `tools/lua50/loadtest.lua`) to catch load-time errors. `--check tests/lua/<file>.lua` asserts the result. Run it before every deploy that touches Lua; its undefined-global list must match vanilla (see RE-NOTES).
- `tools/lua50/`: CMake project for the Lua 5.0.3 host tools (source in `third_party/lua-5.0.3`, MIT).
- `tools/levels/extract_levels.py`: per-level JSON and text reports in `build/levels/` (pits, pickups, hazards, enemies, checkpoints).
- `tools/levels/slev.py`: decoder of the `.slev` collision files (complete). `tools/levels/geometry.py`: walkable surfaces (seams joined), what's at each end (wall/step height, drop depth, deadly), swing points, wall-run zones, poles, slide poles, shimmy lines, skinny ledges.
- `tools/movements.py` (B42-1): the movement corpus: cuts every flight (launch kind, fitted speeds in game time, what it ended on), run up a wall, wall run, shimmy and slope slide out of every collected `a11y.log` (traj samples + Shank's own sounds) and labels them against `build/levels/<level>.geometry.json`; `build/movements/` (derived; never commit). `native/tests/movement_check.cpp` (B42-2): replays them through jump_model (the graph's Reach* per kind, the real speeds through `ReachAtSpeed`, the jump-now chirps kept or broken), totals per kind / level, `--baseline` diff. Use both for every model fix instead of single log flights (RE-NOTES "The movement corpus").
- `tools/session_report.py` (B42-3): one session's trouble report (runs movements.py --session + movement_check for it); read it first after a session.
- **The public beta:** https://github.com/KarlBelanger/shank_access (public; this repo stays private). `tools/make_public.py` assembles build/public (its own git repo, pushed to the public one): the readme (release/README.md), licences, issue forms (release/.github), the setup and a source zip. Publishing an update is outward-facing: only when the user says.
- `tools/collect_logs.py`: copies the game's `*.log` into `build/logs/<timestamp>/` after a test session. Release builds log to `Documents\Shank Access\logs\<session>\` instead: `--documents` (newest session) or `--from <folder>` (a tester's folder).
- **Release branches** (`release/0.1`, PLAN 4c): logs per session under Documents (the storage difference from main, to carry into every future test release), `tools/package.py` → `dist/shank-access-<n>.zip` (extract into the game folder; uninstall .bat inside), `mod/release/README.txt` (the player's readme). The repo stays private.
- `tools/re/sounds.py`: event → sound definition → wave file → mono/stereo/duration (FEV + FSB4 banks). Use it when picking game sounds for cues.
- `tools/re/pe.py`: static analysis of Shank.exe (imports, string xrefs, call sites, disassembly, RTTI).
- `tools/re/shank_moves.py`: every state in Shank's stategraph with a Jump() (the traversal launch inventory, B6-1).
- `tools/re/windup_states.py`: which goon / boss states the State() patch reports as attack wind-ups (its rules applied offline; `<folder>` lists one, no argument counts all). Use it before changing make_windup_patch.py's rules.
- `native/`: C++ (x86, static CRT). `proxy/` = the `dinput8.dll` proxy; `core/` = `shank_access.dll`:
  - `log`, `session_logs` (B38-4c: a release build saves a session with an F2 mark as Documents\Shank Access\logs\shank-access-<timestamp>.zip, miniz, at the mark and at exit), `exe_check`, `config` (`shank_access.ini`);
  - `sound_hooks` (MinHook, 0x55ab90/0x55ab10; our Lua `a11y/<cue>` messages go to a cue listener and never reach FMOD; a game-sound listener (B8b arm sounds); B8f: a hook on the per-frame sound update 0x55b0d0 puts Shank's position in the pan centre, C toggles), `patches` (movie skips, testing only);
  - `speech` (Tolk on a worker thread; `SayFinal` = last message, then mute; B16: three channels (menu, stats, auto) each to the screen reader or our own SAPI `ISpVoice` with voice / rate / volume), `hotkeys` (F9 repeat last, F8 repeat last long message, H health (+ boss), G grenades, P pickups nearby, T traversal nearby, N enemies nearby, L / K lock on (all / special enemies, cycling), E safe edges, W waypoint mode, Q next move, C game sounds around Shank or by the camera, F7 settings, F3 test mode on/off (B18: saved per player; the startup movie skips follow it), plus F4/F5/F6 and ; (enemy cue pan), which do nothing while test mode is off; the game binds no letters; B13-2: all but F9 and F4/F5/F6/; are rebindable by id);
  - B14 `marks` (F2 feedback marks: context line to a11y.log and the game root's `a11y_marks.log` (appended across sessions), then a Win32 comment window);
  - B13-2 settings: `mod_menu` (the F7 spoken settings menu), `input_block` (hooks user32 GetRawInputData: the game gets no keys while the menu is open), `announce` (the automatic-announcement toggles), `config` (shank_access.ini, then the player's `shank_access_user.ini`, written by the menu); `shank_access.cpp` also hooks kernel32 ExitProcess ("Exiting" backstop);
  - `ui_hooks` (also SwfScreen::Update 0x553d50 for screen shown/hidden):
    - Scaleform hooks: the Flash → game callback 0x5534d0, SetVariableInternal 0x559a50, InvokeV 0x559b50 and InvokeMethodInternal 0x559920 (game → Flash method calls; the latter has edi = method), SwfScreen::Update 0x553d50;
    - GetVariable reads (`ReadValue`) and `InvokeMethod`;
    - it sends UI events to one listener.
  - `localization`: IDS_* → English from the game's XLIFF.
  - `menu_reader`: Phase 2, what to speak:
    - focus rules, names, roles and values;
    - level select cell lists and polling;
    - re-announce on an unmoved key press; dialog/page/pop-up text; weapons (own slot, equipped); list boxes (key bindings rows, rebinds); screen titles and restores; the F8 long-message store.
  - `level_hooks` (hooks LevelData::LoadSimData 0x495e30: the level name at each load; and cSetBoundsAction::Execute 0x4eb940: the arena bounds, read from the simulation +0xb0..0xc0) and `level_geometry` (loads bin/shank_access_geometry.txt, generated by tools/levels/geometry.py; surfaces, walls, features; SurfaceUnder / EdgeAhead / WallBeside);
  - `position`: Shank's live position (memory-scan tracker seeded by the Lua ping); `jump_model`: every modelled launch (standing/long, wall, running-up-wall, pole, swing, bar, jump-up, wall-run, walking off) and catches, calibrated from `traj:` logs, flown as sampled paths blocked by the level's walls/ceilings/floors; `Land` predicts where a fall comes down; the cue thread also logs `traj:`, `cues: played in 5 s` and `cues: quiet/active`;
  - `enemies` (B8): finds the game's cGameItemManager by a vtable scan and reads every item (team, attributes hash → character name from `data/attributes/characters/*.lua`, position); `cues` turns them into the nearest-enemy tick, pass whooshes, attack whooshes (from the `State()` patch, `tools/make_windup_patch.py`), N scan, L / K lock-on cycling;
  - `pathing` (B10): loads bin/shank_access_paths.txt (the traversal graph, generated offline by `native/tests/path_graph.cpp`) and finds shortest paths; `cues` runs waypoint mode on it (W, Q; checkpoints from `level_geometry::Checkpoints()`);
  - `edge_guard` (B7 safe edges, key E): hooks HasTag_ParseNode::Evaluate 0x4f92c0 and answers yes for (ground, nofall) while Shank is at a guarded drop, so Klei's own anti-fall rule stops him; "another tap" lets him over;
  - `ui_text`: loads bin/shank_access_ui_text.txt (drawn UI text extracted by tools/ui_text/extract_ui_text.py), e.g. How to Play explanations by page title;
  - `status`: Phase 3 readouts from HUD value writes (health drops at 75/50/25, grenade pickups, boss names and boss health, combo once it ends) and pickup messages (`got_<kind>`);
  - `audio`: Phase 4 cue player (XAudio2 loaded at run time, sounds synthesized in code; started on its own COM thread in `shank_access.cpp`); `cues`: positioned sounds relative to Shank: the edge cue from the geometry (drops, deadly drops, walls, bounds, wall-run ends, slide-pole bottoms), jump targets (pluck nearby, chirp when a jump now reaches), pickup beacons and "in reach" from Lua reports; the P and T summaries;
  - B39 / B40 controller: hotkeys reads XInput (bindings, menu navigation), input_block hides the pad from the game while the menu is open, `game_pads` reads the game's own controller bindings (conflict check);
  - B38-3 `mod_state.h` (F11: the whole mod off / on; every hook, listener, the cue thread, speech and the hotkey poll check it);
  - B38-2 `focus_window` (a focused window of ours while the mod menu is open in play: the game pauses on focus loss);
  - B34 `checkpoint_jump` (test mode's F7 > Go to checkpoint: the game's restart-checkpoint setter 0x406b80 + LoadToLastCheckpoint 0x781580 on the game's frame; the simulation from level_hooks or a scan for cShankSimulation's vtables); B30-3 / B31 `sound_hooks` also hooks FMOD's Event::start (the `[sound] quieter=` list in shank_access.ini) and logs volumes (B32 / B33);
  - `game.h` holds all addresses.
  - `tests/` = host-side tests (the offline B42-2 `movement_check` and B42-6 `q_dump` tools too; `proxy_smoketest`, `hook_test`, `ui_hook_test`, `menu_reader_test`, `status_test`, `cues_test`, `jump_model_test`, `level_geometry_test`, `level_hook_test`, `position_test`, `edge_guard_test`, `enemies_test`, `pathing_test`, `waypoint_test`, `settings_test`, `speech_test`) and the offline `path_graph` tool (B10-2) and the offline `traversal_audit` tool (B6-6).
  - Third party: `third_party/minhook` (BSD-2), `third_party/tolk` (LGPL-3.0, plus x86 client DLLs). Outputs go to `build/native/out/`; deployed via `mod/artifacts.json`. `a11y.log` is written in the game root.
- `mod/files/bin/shank_access.ini`: the deployed mod settings (B18: `test_mode=0`; F3 saves the player's choice to `shank_access_user.ini`). Edit this repo copy, not the game copy.
- `saves/`: backups of the user's own save (Steam Cloud: `C:\Program Files (x86)\Steam\userdata\<steam-user-id>\6120\remote\savedata.dat` + `settings.dat`). See `saves/README.md` for the fresh-save/restore procedure. **Swapping saves is outward-facing: only when the user asks, and only with the game closed.**
- `mod/`: what gets deployed. `mod/pristine.json` holds the SHA-256 of the vanilla Klei files (1,046 entries).
- `tests/`: `python -m unittest discover -s tests`.

## Commands (Git Bash, repo root)
```bash
.venv/Scripts/python -m unittest discover -s tests          # tests
.venv/Scripts/python tools/levels/extract_levels.py         # level data -> build/levels
build/native/out/traversal_audit.exe build/levels/shank_access_geometry.txt build/levels/audit   # B6-6: which launches reach each traversal feature, per level
build/native/out/path_graph.exe build/levels/shank_access_geometry.txt build/levels/shank_access_paths.txt   # B10-2, BEFORE deploy (after geometry.py): the waypoint graph (deployed as bin/shank_access_paths.txt; never commit)
.venv/Scripts/python tools/levels/path_check.py campaign_1c_meatpacking 768 320   # B10-2: the path from a spot to the next checkpoint
.venv/Scripts/python tools/levels/path_check.py --all      # B12: every checkpoint leg has a path? (after path_graph); --all <level>: one level's legs
.venv/Scripts/python tools/regen_level.py 1c_meat           # B42-5: one level: path_graph --merge (others kept) + its legs + movement_check + its risky moves (~16 s for 1-c); a jump_model change still needs the full path_graph before a deploy
.venv/Scripts/python tools/levels/path_check.py campaign_1c_meatpacking 768 320 --to f12   # directions to one place (a node: s12, f7, p20L, w53) from a checkpoint's spawn: for test instructions
.venv/Scripts/python tools/session_report.py --latest       # B42-3, FIRST after collect_logs: one session's trouble report (marks, deaths with the 6 s before, flights the model gets wrong, Too high, waypoint targets) -> build/logs/<session>/report.txt
build/native/out/cue_replay.exe <geometry> <paths> build/movements/movements.txt build/movements/timelines build/movements/replay.txt [--trace <session:t>]   # B47-1: today's jump-now cue along every old launch (kept / false / missing / quiet); after movements.py
.venv/Scripts/python tools/levels/evidence.py               # B47-2: per route move: proven / mixed / contradicted / model-doubt / untested (after movement_check + cue_replay) -> build/levels/evidence.txt
.venv/Scripts/python tools/levels/test_plan.py              # B47-4: the manual test plan from the evidence (sessions by the user's rule) -> build/levels/test_plan.txt
.venv/Scripts/python tools/levels/risky_moves.py [level]    # B42-4: the risky moves on every checkpoint route (one spot, small deadly floors, long falls, catches near an end, corpus trouble) with directions from the checkpoint -> build/levels/risky_moves.txt (after path_graph, movements.py, movement_check)
build/native/out/q_dump.exe build/levels/shank_access_geometry.txt build/levels/shank_access_paths.txt build/levels/q_dump.txt [level]   # B42-6: Q's own text along every checkpoint leg's route, for reviewing the wording in bulk
.venv/Scripts/python tools/movements.py                     # B42-1: every movement in build/logs -> build/movements/ (movements.json, movements.txt, summary.txt: measured vs jump_model's numbers); --show <session:t> prints one with its log
build/native/out/movement_check.exe build/levels/shank_access_geometry.txt build/movements/movements.txt build/movements/check.txt --baseline build/movements/check_base.txt   # B42-2: the jump model vs every real movement; BEFORE any jump_model / path_graph change: save check.txt as check_base.txt first, then the run after the change lists what it newly breaks / fixes
.venv/Scripts/python tools/make_windup_patch.py            # regenerates the stategraphutil.lua patch (wind-ups, openings, B13-4 aims)
.venv/Scripts/python tools/loadtest50.py stategraphs/props/firetrap_stategraph.lua --check tests/lua/check_aim_rules.lua   # B13-4 aim rules (goon entries: use the *_stategraph_1.lua variants)
.venv/Scripts/python tools/loadtest50.py --check tests/lua/check_carry_ping.lua   # B15-4: the position ping is never inside the carried weapons' drop wrappers
.venv/Scripts/python tools/loadtest50.py stategraphs/goon/boss_toro/toro_stategraph.lua --check tests/lua/check_flash_windups.lua   # B24: flash-telegraphed states warn (Priest, SWAT, Cesar by rule)
.venv/Scripts/python tools/loadtest50.py stategraphs/goon/boss_toro/toro_stategraph.lua --check tests/lua/check_boss_setups.lua   # B23: the setup reports (Toro's charge; Cesar's blocks by rule: his stategraph doesn't load in the harness)
.venv/Scripts/python tools/levels/geometry.py              # AFTER extract_levels, and BEFORE every deploy: collision (.slev via slev.py) -> build/levels/<level>.geometry.* and build/levels/shank_access_geometry.txt (deployed as bin/shank_access_geometry.txt; never commit)
.venv/Scripts/python tools/luacheck50.py                    # Lua 5.0 syntax check of the deployable mod
.venv/Scripts/python tools/loadtest50.py --check tests/lua/check_shank_cues.lua  # execute patched Shank stategraph (pickups: --check tests/lua/check_pickup_beacon.lua stategraphs/props/<x>pickup_stategraph.lua)
.venv/Scripts/python tools/ui_text/extract_ui_text.py        # BEFORE deploy: drawn UI text (How to Play) from the install -> build/ui_text (deployed as bin/shank_access_ui_text.txt; never commit)
.venv/Scripts/python tools/setup/build_setup.py             # B37-3: build/setup/shank-access-setup.exe (the player's setup: patches + generated files on their machine; after building path_graph)
.venv/Scripts/python tools/deploy.py plan                   # dry run (no writes)
.venv/Scripts/python tools/collect_logs.py --label test1    # after a test session
.venv/Scripts/python tools/package.py                      # release branch only: dist/shank-access-<n>.zip (after cmake configure + build)
"/c/Program Files/CMake/bin/cmake.exe" -S native -B build/native -G "Visual Studio 17 2022" -A Win32   # native DLLs (re-run to refresh the version)
"/c/Program Files/CMake/bin/cmake.exe" --build build/native --config Release
"/c/Program Files/CMake/bin/cmake.exe" -S native -B build/native_rel -G "Visual Studio 17 2022" -A Win32 -DSHANK_ACCESS_RELEASE=ON   # B37-2: a public release build (no F3 / test mode); settings_test_release checks the menu
build/native/out/proxy_smoketest.exe "$(cygpath -w build/native/out)"   # proxy forwards + mod loads (expects exe MISMATCH)
build/native/out/hook_test.exe                                       # sound-hook shims vs stand-in functions
build/native/out/ui_hook_test.exe                                    # UI hooks (Scaleform callback + SetVariableInternal) vs stand-ins
build/native/out/speech_test.exe "$(cygpath -w build/native/out)"      # Tolk loads + detects the screen reader (silent; --speak talks)
build/native/out/menu_reader_test.exe "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Shank"   # menu reading logic + real localization file (read only)
build/native/out/level_geometry_test.exe "$(cygpath -w build/levels/shank_access_geometry.txt)"   # geometry queries (+ real 1-a spots)
build/native/out/level_hook_test.exe                                 # LoadSimData + bounds hooks vs stand-ins
build/native/out/position_test.exe                                   # position tracker (fake memory + a real scan)
build/native/out/jump_model_test.exe                                 # jump model vs measured 1-a/1-c jumps
build/native/out/status_test.exe                                     # Phase 3 status logic (health/grenades/boss/combo/pickups)
build/native/out/pathing_test.exe "$(cygpath -w build/levels/shank_access_paths.txt)"   # B10 path search (+ real 1-c route); the argument is the PATHS file
build/native/out/waypoint_test.exe "$(cygpath -w build/levels/shank_access_geometry.txt)" "$(cygpath -w build/levels/shank_access_paths.txt)"   # waypoint mode / Q / P / T on real levels
build/native/out/cues_test.exe                                       # Phase 4 cue logic + synthesized sounds (silent; --start = XAudio2 starts; --play plays them aloud)
build/native/out/settings_test.exe                                   # B13-2: user ini save/load, the raw-input filter, the F7 menu, announcement toggles
# host tests that load shank_access.dll: set SHANK_ACCESS_SILENT=1 so they don't talk through the user's NVDA
"/c/Program Files/CMake/bin/cmake.exe" -S tools/lua50 -B build/lua50 -G "Visual Studio 17 2022" -A Win32
"/c/Program Files/CMake/bin/cmake.exe" --build build/lua50 --config Release
```
Toolchain: VS 2022 Build Tools 17.14 (MSVC x86/x64, Win11 SDK), CMake (`C:\Program Files\CMake\bin`), Ninja, Python 3.14 venv in `.venv` (`requirements.txt`).
If `.venv` is missing: `py -m venv .venv && .venv/Scripts/python -m pip install -r requirements.txt`.

## Working with the user
- The user uses a screen reader. Keep chat output well structured, and avoid ASCII-art tables where a list reads better.
- **Feedback marks (the user, 2026-09-27):** the user presses F2 during play and types a comment per mark. After a session, read the newest session in `a11y_marks.log` first and map each MARK to a11y.log by its time (TESTING "How the user reports feedback").
- For each test, follow `docs/TESTING.md`: say which level and checkpoint, what to do, and what to listen for, and remind them **not to relaunch** the game before logs are collected (each launch overwrites them). Afterwards, collect the logs and record the results in TESTING.md, with a one-line summary in the PLAN work log.
- **Directions to an interaction to test (the user, 2026-10-01):** "when there is a specific interaction that needs in-game testing, tell me the level, preceeding checkpoint, and the specific path steps to reach the interaction. This way I can use the go to checkpoint feature and follow the steps to reach the exact interaction in question." For every spot to test: the level, the checkpoint before it (its name as Go to checkpoint lists it), then numbered moves from the spawn in player terms (which way, what kind of move, onto what, about how many tiles), worked out from the graph (`tools/levels/path_check.py`) and checked against the geometry; then exactly what to do there and what to listen for. Put the same directions in the TESTING entry.
- **Level names (the user, 2026-10-02: "The thumper checkpoint is in venom, not red light. Verify we're both working from the right level."):** to the user, name a place by the game's **chapter** (the geometry's `chapter <checkpoint> <name>` lines: the chapter containing that checkpoint, e.g. "Venom of the Vipers", "Leap of Faith"), never by our level file names (campaign_2c_redlight is Venom of the Vipers / World of Warriors; "Red Lights" is campaign_2a_brothel; campaign_2b_lovehotel is On The Run / Sweet Love). risky_moves.txt and q_dump.txt print the chapter.
- **Test session size (the user, 2026-10-02):** "group by level. If only a couple test points at specific checkpoints, string 10-15 tests together. If there's enough testing needed for a given level that a full playthrough of the level is basically required, especially in a longer level like on the run, venom, or underworld, that one level could be its own session." The plan can be given in chat.
- **Deaths in a session (the user, 2026-10-02):** "You shouldn't exclude any given death as a definitive execution issue on my word, but you should treat an execution issue as a possibility for all deaths." Check every death against the log (inputs held, what the route expected) even when the user calls them execution; report execution as a possible cause, never assume it.
- **Routes are good enough with one safe path (the user, 2026-10-02):** "It occurs to me we are spending too much time worrying about small differences that lead to the same thing. As long as we have **at least** one valid path that doesn't require pixel perfect jumps or speed perfect drops, we're fine." Don't refine the model or the graph over small differences that end the same way; fix only what leaves a leg without a path that avoids pixel-perfect jumps or speed-perfect drops, or what Q / the cues say wrongly.
- **"No jump" wording (the user, 2026-10-02):** "It is my experience that most, but not all, wall runs in the game catch whatever's coming next without input, but a timed jump doesn't cause any problems. I recommend against no jump wording except in specific cases where jumping will kill but not jumping is safe."
- **The setup in Downloads (the user, 2026-10-03: "Replace it whenever you build a new setup."):** after every `tools/setup/build_setup.py` build, copy build/setup/shank-access-setup.exe to the user's Downloads folder (%USERPROFILE%\Downloads), replacing the old one, and say its version.
- **Stay on task. Don't chase tangents.** Don't investigate side issues unless they block the current task. That includes unrelated log errors, odd-looking game code, curiosities, and low-confidence hunches. If something seems worth a look, record it in PLAN "Open questions / risks" with one line, mention it briefly, and move on. Investigate only if the user asks, or if it's actually blocking. (The user has had to pull Claude back from rabbit holes in past projects.)
- **Batch testing (the user, 2026-09-26):** "rather than stop and test every change, select occasional stopping points based on the plan, and have me test in batches once you reach those points. Everything else about your planning, implementation, tracking and documentation stays exactly the same."
  - Keep building, host-testing, documenting and committing each step as before, but don't stop to deploy and test each one.
  - Mark planned **test points** in PLAN (In flight / queue).
  - At a test point: ask to deploy the batch, give one combined test plan (TESTING.md), then fix from the logs.
  - Reason: stopping for every small change used far more tokens than the overnight run.
  - Numbering: batches are B1, B2, …; a batch's steps are B6-1, B6-2, … (never bare "6-2", which reads as Phase 6); fix rounds are B5b, B5c, …. Phases (PLAN section 3) stay the roadmap; PLAN Status explains the older labels.
- **Object names (the user, 2026-09-26):** "I can't see what the objects look like or know what they're called, so treat any object names I use very loosely." Work out what they mean from the logs (Shank's positions and states: `traj:`, which side of a pole, etc.), not from the name ("first pole to second" turned out to be the same pole's two sides, or a wall and a pole).
- **No internal labels in summaries (the user, 2026-09-29):** "Indicators like f7 won't mean anything to players, exclude them from the summary." In replies, describe places in player terms ("the second swing point", "the floor above the checkpoint"), never graph or geometry ids (f7, s33, w110, p20R) or state names unless the user asks. They stay in the docs and logs.
- **Deploy messages (the user, 2026-09-26):** "Going forward no need to ever repeat details that have already been given before a deploy request." After a deploy, just confirm it's done; don't restate what the batch contains or how to test it.
- **Break big tasks up.** If a task risks focus drift, filling the context, or trouble from its size or complexity, split it into small steps, each with its own goal, verification and commit. Do one at a time. Record the breakdown in PLAN (checkboxes and In flight) so it survives a compaction. Prefer several small deploy-and-test cycles over one big one.
- The user warns when context usage is near compaction (e.g. "86%", "90%"; compaction usually happens past 95%). When warned: sync the docs **immediately**, keep In flight step-by-step current after every finding, and commit and push small increments so nothing is only in the conversation.
- The user values continuity across compaction and sessions very highly. Follow the memory discipline above strictly, and tell them after each checkpoint what was saved.
