#pragma once
// Phase 3 (status readouts), from the HUD values the game writes (ui_hooks kValueSet; RE-NOTES
// "1c-2 runtime findings"). The user's rules (2026-09-25): "grenades should be on pickup only,
// and health loss should read at set percentages, say every 25%."
#include <string>

#include "ui_hooks.h"

namespace status {

// Health is announced when it drops below one of these (percent); a level is re-armed once health
// is back above it.
constexpr double kHealthLevels[] = {75, 50, 25};

// A HUD value write. Returns the text to speak ("" = nothing):
//   _level0.HUD.player1.healthBar.value  -> "70 percent health" when it drops below 75/50/25 (number first)
//   _level0.HUD.player1.grenadeTxt.text  -> "3 grenades" when the count goes up (a pickup). Not the
//                                           first value after it was cleared/unknown, and not with a
//                                           health reset to full within kResetWindowMs (level load,
//                                           respawn: B1c)
//   _level0.HUD.enemyBoss.nameTxt.text, _level0.HUD.enemyBosses.boss1/2.nameTxt.text
//                                        -> "Boss: <name>" when it changes to a non-empty name
//   _level0.HUD.enemyBoss.healthBar.value, …enemyBosses.boss1/2.healthBar.value (3-3)
//                                        -> "40 percent boss health" when it drops below 75/50/25, like
//                                           the player's; the two-boss bars say the boss's name instead
//                                           of "boss health". A new name starts the bar afresh.
std::string OnValue(const std::string& path, const ui_hooks::FlashValue& value, unsigned now_ms);
constexpr unsigned kResetWindowMs = 250;

// 3-2 (the user, 2026-09-26: "all pickups … announce what was picked up"): a pickup message from our
// Lua patches, cue "got_<kind>" (sound_hooks cue listener). Returns the text to speak now:
//   weapons -> "Picked up minigun" (grenade launcher, flamethrower, machete, katana, Uzi, shotgun)
//   health  -> "" now; OnFrame says "Picked up health, 80 percent health" kHealthPickupDelayMs later
//              (the game adds the health over half a second)
//   grenades -> "" (the count going up says "5 grenades"); if the count doesn't go up within
//              kGrenadePickupWaitMs (already at the maximum), OnFrame says "5 grenades"
// Unknown kinds: "" (logged).
std::string OnPickup(const std::string& kind, unsigned now_ms);
constexpr unsigned kHealthPickupDelayMs = 700;
constexpr unsigned kGrenadePickupWaitMs = 500;

// 3-4 combo (the user, 2026-09-26: "just read the last combo whenever it resets"): the HUD's
// comboNum is written on every hit ("1", "2", …); a combo is over when the count starts again
// (a write below the current count; the same number is ignored) or after kComboIdleMs with no hits. Then OnValue / OnFrame
// say "12 hit combo", for combos of at least kMinCombo hits.
constexpr unsigned kComboIdleMs = 3000;
constexpr int kMinCombo = 3;

// Delayed status texts (pickup results, a combo that ran out); call every frame. Returns "" or the
// text to speak.
std::string OnFrame(unsigned now_ms);

// For the H and G keys (the user, 2026-09-26): "70 percent health" / "3 grenades". Safe from any
// thread (cached values). During a boss fight H adds the boss: "70 percent health, 40 percent boss health".
std::string HealthText();
std::string GrenadeText();

// Forget everything (tests).
// B7b: a level load: the boss bars' names aren't cleared by the game after the first level, so forget them.
void ForgetBosses();

void Reset();

}  // namespace status
