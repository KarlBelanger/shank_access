-- Run by tools/loadtest50.py after loading a hazard prop stategraph (Lua 5.0), B7.
-- Asserts that every PlaySound("a11y/hz_<kind>") sits in a state's `transitions` list (the self-disarming
-- report), that the states keeping one still have their original events / end_transitions, and that at
-- least one report exists.
local found = 0
local problems = {}
local function has_report(t, seen)
  if type(t) ~= "table" or seen[t] then return false end
  seen[t] = true
  if t.Type == "playsound" and type(t.sound) == "string" and string.find(t.sound, "^a11y/hz_") then return true end
  for _, v in pairs(t) do
    if has_report(v, seen) then return true end
  end
  return false
end
local states = (StateGraph and StateGraph.States) or PropStates or {}
for _, st in ipairs(states) do
  for key, v in pairs(st) do
    if has_report(v, {}) then
      if key ~= "transitions" then
        table.insert(problems, "a11y/hz_ report in " .. st.name .. "." .. tostring(key))
      else
        found = found + 1
        if not (st.events or st.end_transitions) then
          table.insert(problems, st.name .. " lost its events / end_transitions")
        end
        print("  report in state " .. st.name)
      end
    end
  end
end
if table.getn(problems) > 0 then error(table.concat(problems, "; ")) end
if found == 0 then error("no a11y/hz_ report found") end
return true
