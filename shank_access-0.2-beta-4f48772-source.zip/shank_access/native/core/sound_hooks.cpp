#include "sound_hooks.h"

#include <windows.h>

#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>

#include "MinHook.h"
#include "game.h"
#include "log.h"
#include "mod_state.h"

namespace sound_hooks {
namespace {
constexpr LONG kStartsToLog = 40;

// Trampolines to the original functions (filled in by MinHook).
void* g_orig_play_at = nullptr;
void* g_orig_play = nullptr;
// The pan listener: four consecutive floats (half-width, half-height, centre x, centre y).
// In the game these live at 0xae6860; the hook test points this at its own values.
volatile float* g_listener = nullptr;

// B8f: game sounds pan around Shank. The trampoline to the per-frame sound update, the switch, Shank's position
// (from the cue thread) and the camera centre saved before it's replaced.
void* g_orig_update = nullptr;
void (*g_frame_callback)() = nullptr;  // B34
volatile LONG g_around_shank = 1;
volatile LONG g_centre_known = 0;
volatile float g_centre_x = 0, g_centre_y = 0;
volatile LONG g_camera_known = 0;
volatile float g_camera_x = 0, g_camera_y = 0;

// Logging budget so busy scenes (footsteps, gunfire) can't flood the log or slow the game:
// at most kMaxPerSecond lines per second; the number dropped is reported once per second.
constexpr int kMaxPerSecond = 40;
DWORD g_window_start = 0;
int g_in_window = 0;
int g_dropped = 0;

bool Budget() {
    if (!mod_state::Active()) return false;  // B38-3: nothing logged while the mod is off
    const DWORD now = GetTickCount();
    if (now - g_window_start >= 1000) {
        if (g_dropped) alog::Write("sound: (%d lines dropped by the rate limit)", g_dropped);
        g_window_start = now;
        g_in_window = 0;
        g_dropped = 0;
    }
    if (g_in_window >= kMaxPerSecond) {
        ++g_dropped;
        return false;
    }
    ++g_in_window;
    return true;
}

CueListener g_cue_listener = nullptr;
SoundListener g_sound_listener = nullptr;

// "Shank/Character/a11y/<cue>" (a Lua PlaySound("a11y/<cue>") from our patches) -> "<cue>"; else nullptr.
const char* CueName(const char* name) {
    if (!name) return nullptr;
    const char* p = std::strstr(name, "a11y/");
    if (!p || (p != name && p[-1] != '/')) return nullptr;
    return p + 5;
}

bool ReadBlock(const void* p, void* out, size_t n) {
    __try {
        std::memcpy(out, p, n);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// B3c runtime RE (log only, the first few position pings): does the sim sound event point at the
// emitting game item? The caller (0x5219a5) passes pos = event + 4 (name at event + 0x3c). Dump the
// event's dwords, and for each one that points at readable memory, look for Shank's (x, y) floats
// in the first 0x800 bytes there. A hit gives a way to read Shank's position without Lua pings.
void ProbeEvent(const float* pos, float x, float y) {
    static int probes = 0;
    if (probes >= 3 || !pos) return;
    ++probes;
    const unsigned char* event = reinterpret_cast<const unsigned char*>(pos) - 4;
    unsigned words[0x60 / 4] = {};
    if (!ReadBlock(event, words, sizeof words)) return;
    char line[512];
    int len = 0;
    for (int i = 0; i < 0x60 / 4 && len < 480; ++i) len += _snprintf_s(line + len, sizeof line - len, _TRUNCATE, " %08x", words[i]);
    alog::Write("probe: event %p (pos %.0f, %.0f):%s", event, x, y, line);
    static unsigned char block[0x800];
    for (int i = 0; i < 0x60 / 4; ++i) {
        const unsigned w = words[i];
        if (w < 0x10000 || (w & 3)) continue;
        if (!ReadBlock(reinterpret_cast<const void*>(static_cast<uintptr_t>(w)), block, sizeof block)) continue;
        for (unsigned off = 0; off + 8 <= sizeof block; off += 4) {
            float fx, fy;
            std::memcpy(&fx, block + off, 4);
            std::memcpy(&fy, block + off + 4, 4);
            if (fx == x && fy == y) alog::Write("probe: event+0x%02x -> %08x has (x, y) at +0x%x", i * 4, w, off);
        }
    }
}

// Called from the naked shims on the game's thread, with all registers saved. Returns nonzero to
// skip the game's function: our own a11y/ messages aren't FMOD events, so they never reach FMOD
// (no "Could not play" line in sound.log for each one).
// B30-3 (the user: "The rockets in bad confession are so loud they drown out most of the mod sounds. See if there is a way to
// lower the volume of the rockets some"): some game events are started quieter. B31-2: the hook on FMOD::Event::start asks
// the event its own name (Event::getInfo), so events started by any path count (the rockets' flight is a looping sound,
// PlayLoopingSound, not PlaySoundAt); the event's first volume is kept per name (instances are reused: no compounding).
SRWLOCK g_quieter_lock = SRWLOCK_INIT;
std::vector<std::pair<std::string, float>> g_quieter;  // event name (the key's last path part) -> volume factor
std::map<std::string, float> g_base_volume;            // event name -> its own volume, first seen
void* g_orig_event_start = nullptr;
using EventVolumeGet = int(__stdcall*)(void* event, float* volume);
using EventVolumeSet = int(__stdcall*)(void* event, float volume);
using EventGetInfo = int(__stdcall*)(void* event, int* index, char** name, void* info);
EventVolumeGet g_event_get_volume = nullptr;
EventVolumeSet g_event_set_volume = nullptr;
EventGetInfo g_event_get_info = nullptr;
volatile LONG g_starts_logged = 0;  // B31-3: the first starts after launch are logged (the menu music's volume)

float QuieterFactor(const char* name) {
    if (!name) return 0.f;
    float f = 0.f;
    AcquireSRWLockShared(&g_quieter_lock);
    for (const auto& q : g_quieter) {
        const size_t slash = q.first.find_last_of('/');
        const std::string key = slash == std::string::npos ? q.first : q.first.substr(slash + 1);
        if (std::strstr(name, key.c_str())) f = q.second;
    }
    ReleaseSRWLockShared(&g_quieter_lock);
    return f;
}

int __stdcall HookEventStart(void* event) {
    if (!mod_state::Active()) return reinterpret_cast<int(__stdcall*)(void*)>(g_orig_event_start)(event);  // B38-3: as vanilla
    PollVolumes("a sound starts");  // (B33: the game's own threads, before the first UI frame too)
    char* name = nullptr;
    if (event && g_event_get_info) g_event_get_info(event, nullptr, &name, nullptr);
    const float f = QuieterFactor(name);
    if (f > 0.f && g_event_get_volume && g_event_set_volume) {
        float v = 1.f;
        AcquireSRWLockExclusive(&g_quieter_lock);
        auto it = g_base_volume.find(name);
        if (it == g_base_volume.end()) {
            if (g_event_get_volume(event, &v) == 0) g_base_volume[name] = v;
            else v = -1.f;
        } else {
            v = it->second;
        }
        ReleaseSRWLockExclusive(&g_quieter_lock);
        if (v >= 0.f) g_event_set_volume(event, v * f);
    }
    // B31-3 (the user: "The menu music also seems to be louder at the start of the game"): the first events after launch,
    // with the game's own volume settings as it holds them then (music [0x8899fc], effects [0x8899f8]).
    if (InterlockedIncrement(&g_starts_logged) <= kStartsToLog) {
        float v = -1.f;
        if (g_event_get_volume) g_event_get_volume(event, &v);
        alog::Write("sound: event %s starts (its volume %.2f; the game's music volume %.2f, effects %.2f)", name ? name : "?", v,
                    *reinterpret_cast<const volatile float*>(game::kMusicVolume),
                    *reinterpret_cast<const volatile float*>(game::kGameVolume));
    }
    return reinterpret_cast<int(__stdcall*)(void*)>(g_orig_event_start)(event);
}

int __cdecl OnPlaySoundAt(const char* name, const float* pos) {
    if (!mod_state::Active()) return CueName(name) ? 1 : 0;  // B38-3: ours still swallowed (not FMOD events); nothing else
    if (const char* cue = CueName(name)) {
        const float x = pos ? pos[0] : 0.f, y = pos ? pos[1] : 0.f;
        // Position pings come several times a second: not logged (they'd crowd out everything else).
        if (std::strncmp(cue, "pos_", 4) != 0 && Budget()) alog::Write("cue: %s pos=(%.0f, %.0f)", cue, x, y);
        if (std::strncmp(cue, "pos_", 4) == 0) ProbeEvent(pos, x, y);
        if (g_cue_listener) g_cue_listener(cue, x, y);
        return 1;
    }
    const float x = pos ? pos[0] : 0.f, y = pos ? pos[1] : 0.f;
    if (g_sound_listener && name) g_sound_listener(name, x, y);
    if (!Budget()) return 0;
    const float hw = g_listener[0], hh = g_listener[1], lx = g_listener[2], ly = g_listener[3];
    const float pan = hw > 0.f ? (x - lx) / hw : 0.f;  // the same formula the game uses
    alog::Write("sound at: %s pos=(%.0f, %.0f) listener=(%.0f, %.0f) half=(%.0f, %.0f) pan=%.2f",
                name ? name : "(null)", x, y, lx, ly, hw, hh, pan);
    return 0;
}

void __cdecl OnPlaySound(const char* name) {
    if (!Budget()) return;
    alog::Write("sound 2d: %s", name ? name : "(null)");
}

// PlaySoundAt(esi = name, [esp+4] = pos). After pushad (32 bytes) and pushfd (4 bytes) the
// caller's return address is at [esp+36] and pos at [esp+40]. Every register and the flags are
// restored before jumping to the original, so the game sees exactly what its caller passed.
// For our own a11y/ cues it returns straight to the caller instead: the game's function ends in a
// plain `ret` (caller cleans the position argument) and its result isn't used (the only caller,
// 0x5219a5, goes on with `add esp, 4`; RE-NOTES "Sound system").
__declspec(naked) void HookPlaySoundAt() {
    __asm {
        pushad
        pushfd
        push dword ptr [esp + 40]   // pos (pushfd added 4 bytes)
        push esi                    // name
        call OnPlaySoundAt
        add esp, 8
        test eax, eax
        jnz skip
        popfd
        popad
        jmp dword ptr [g_orig_play_at]
    skip:
        popfd
        popad
        ret
    }
}

__declspec(naked) void HookPlaySound() {
    __asm {
        pushad
        pushfd
        push esi
        call OnPlaySound
        add esp, 4
        popfd
        popad
        jmp dword ptr [g_orig_play]
    }
}

// B32 (the user: "have the logs collect the actual volume that the game is playing menu and level music at, so we can see if
// there's ever a disagree between it and what my volume setting says it should be"): the game keeps its settings at
// [0x8899fc] music / [0x8899f8] effects and sets FMOD's "music" / "game" categories (under "master") to setting × [0x889a00]
// (0x55a920). Read on the game's own UI thread (PollVolumes from the UI frame event) through fmod_event.dll's exported
// EventSystemI / EventCategoryI getters; logged when anything changes (and the first time).
using SystemGetCategory = int(__stdcall*)(void* system, const char* name, void** category);
using CategoryGetCategory = int(__stdcall*)(void* category, const char* name, void** child);
using CategoryGetVolume = int(__stdcall*)(void* category, float* volume);
SystemGetCategory g_system_get_category = nullptr;
CategoryGetCategory g_category_get_category = nullptr;
CategoryGetVolume g_category_get_volume = nullptr;
bool g_volume_getters_tried = false;
DWORD g_volumes_polled_ms = 0;
float g_volumes_last[8] = {-9, -9, -9, -9, -9, -9, -9, -9};
volatile LONG g_volumes_busy = 0;
using SystemGetMusic = int(__stdcall*)(void* system, void** music);
using MusicGetVolume = int(__stdcall*)(void* music, float* volume);
using MusicGetBool = int(__stdcall*)(void* music, bool* value);
SystemGetMusic g_system_get_music = nullptr;
MusicGetVolume g_music_get_volume = nullptr;
MusicGetBool g_music_get_mute = nullptr;

float CategoryVolume(void* system, const char* name) {
    void* master = nullptr;
    if (g_system_get_category(system, "master", &master) != 0 || !master) return -1.f;
    void* cat = master;
    if (name && (g_category_get_category(master, name, &cat) != 0 || !cat)) return -1.f;
    float v = -1.f;
    return g_category_get_volume(cat, &v) == 0 ? v : -1.f;
}

// B8f: after the game's per-frame update has copied the camera into the listener, keep the camera centre (for the
// enemy cues' camera-pan mode) and, if chosen and known, put Shank's position in its place.
void __cdecl AfterSoundUpdate() {
    if (g_frame_callback) g_frame_callback();  // B34: work that must run on the game's thread (the checkpoint jump)
    if (!g_listener) return;
    g_camera_x = g_listener[2];
    g_camera_y = g_listener[3];
    g_camera_known = 1;
    if (g_around_shank && g_centre_known && mod_state::Active()) {  // (B38-3: off, the game's camera pan)
        g_listener[2] = g_centre_x;
        g_listener[3] = g_centre_y;
    }
}

// The update takes dt on the stack (caller cleans) and the camera's half-size in esi and centre in edi. Nothing is
// touched before the original runs: a copy of dt is pushed and the trampoline called with esi/edi as the caller left
// them; then every register and the flags are saved around our part. Its return value isn't used (0x52100e).
__declspec(naked) void HookSoundUpdate() {
    __asm {
        push dword ptr [esp + 4]   // dt
        call dword ptr [g_orig_update]
        add esp, 4
        pushad
        pushfd
        call AfterSoundUpdate
        popfd
        popad
        ret
    }
}

// The first bytes of each target, from the disassembly in RE-NOTES. Refuse to hook anything else.
const unsigned char kPlaySoundAtPrologue[] = {0x83, 0xEC, 0x10, 0xA1, 0xF0, 0xFD, 0xAD, 0x00};  // sub esp,10h; mov eax,[0ADFDF0h]
const unsigned char kPlaySoundPrologue[] = {0x51, 0xA1, 0xF0, 0xFD, 0xAD, 0x00};               // push ecx; mov eax,[0ADFDF0h]

bool PrologueMatches(uintptr_t addr, const unsigned char* bytes, size_t n) {
    return std::memcmp(reinterpret_cast<const void*>(addr), bytes, n) == 0;
}

bool HookOne(const char* label, uintptr_t target, void* detour, void** orig) {
    MH_STATUS st = MH_CreateHook(reinterpret_cast<void*>(target), detour, orig);
    if (st != MH_OK) {
        alog::Write("hook %s at 0x%08x: MH_CreateHook failed: %s", label, static_cast<unsigned>(target), MH_StatusToString(st));
        return false;
    }
    st = MH_EnableHook(reinterpret_cast<void*>(target));
    if (st != MH_OK) {
        alog::Write("hook %s at 0x%08x: MH_EnableHook failed: %s", label, static_cast<unsigned>(target), MH_StatusToString(st));
        return false;
    }
    alog::Write("hook %s at 0x%08x: installed", label, static_cast<unsigned>(target));
    return true;
}

}  // namespace

void SetCueListener(CueListener listener) { g_cue_listener = listener; }

void SetFrameCallback(void (*callback)()) { g_frame_callback = callback; }

void SetSoundListener(SoundListener listener) { g_sound_listener = listener; }

bool CameraPan(float x, float* pan) {
    if (!g_listener) return false;
    const float hw = g_listener[0];
    const float lx = g_camera_known ? g_camera_x : g_listener[2];  // B8f: the camera's centre, not Shank's
    if (!(hw > 0.f)) return false;
    *pan = (x - lx) / hw;  // the same formula the game uses
    return true;
}

void SetShankCentre(bool known, float x, float y) {
    g_centre_x = x;
    g_centre_y = y;
    g_centre_known = known ? 1 : 0;
}

void SetPanAroundShank(bool on) {
    g_around_shank = on ? 1 : 0;
    alog::Write("sound: game sounds pan %s", on ? "around Shank" : "by the camera");
}

bool PanAroundShank() { return g_around_shank != 0; }

bool TogglePanAroundShank() {
    SetPanAroundShank(!g_around_shank);
    return g_around_shank != 0;
}

void SetQuieter(const std::vector<std::pair<std::string, float>>& list) {
    AcquireSRWLockExclusive(&g_quieter_lock);
    g_quieter = list;
    ReleaseSRWLockExclusive(&g_quieter_lock);
    for (const auto& q : list) alog::Write("sound: %s at %.0f%% volume", q.first.c_str(), q.second * 100.f);
}

bool InstallVolumeHook() {
    HMODULE ev = GetModuleHandleA("fmod_event.dll");
    if (!ev) {
        alog::Write("sound: fmod_event.dll not loaded; no volume changes");
        return false;
    }
    void* start = reinterpret_cast<void*>(GetProcAddress(ev, "?start@Event@FMOD@@QAG?AW4FMOD_RESULT@@XZ"));
    g_event_get_volume = reinterpret_cast<EventVolumeGet>(GetProcAddress(ev, "?getVolume@Event@FMOD@@QAG?AW4FMOD_RESULT@@PAM@Z"));
    g_event_set_volume = reinterpret_cast<EventVolumeSet>(GetProcAddress(ev, "?setVolume@Event@FMOD@@QAG?AW4FMOD_RESULT@@M@Z"));
    g_event_get_info = reinterpret_cast<EventGetInfo>(GetProcAddress(ev, "?getInfo@Event@FMOD@@QAG?AW4FMOD_RESULT@@PAHPAPADPAUFMOD_EVENT_INFO@@@Z"));
    if (!start || !g_event_get_volume || !g_event_set_volume || !g_event_get_info) {
        alog::Write("sound: FMOD Event start / getVolume / setVolume not found; no volume changes");
        return false;
    }
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) return false;
    return HookOne("FMOD Event::start (quieter sounds)", reinterpret_cast<uintptr_t>(start), reinterpret_cast<void*>(&HookEventStart),
                   &g_orig_event_start);
}

void PollVolumes(const char* what) {
    const DWORD now = GetTickCount();
    if (now - g_volumes_polled_ms < 500) return;
    // (B33: called from several game hooks: one at a time)
    if (InterlockedCompareExchange(&g_volumes_busy, 1, 0) != 0) return;
    g_volumes_polled_ms = now;
    if (!g_volume_getters_tried) {
        g_volume_getters_tried = true;
        if (HMODULE ev = GetModuleHandleA("fmod_event.dll")) {
            g_system_get_category = reinterpret_cast<SystemGetCategory>(
                GetProcAddress(ev, "?getCategory@EventSystemI@FMOD@@UAG?AW4FMOD_RESULT@@PBDPAPAVEventCategory@2@@Z"));
            g_category_get_category = reinterpret_cast<CategoryGetCategory>(
                GetProcAddress(ev, "?getCategory@EventCategoryI@FMOD@@UAG?AW4FMOD_RESULT@@PBDPAPAVEventCategory@2@@Z"));
            g_category_get_volume =
                reinterpret_cast<CategoryGetVolume>(GetProcAddress(ev, "?getVolume@EventCategoryI@FMOD@@UAG?AW4FMOD_RESULT@@PAM@Z"));
            g_system_get_music = reinterpret_cast<SystemGetMusic>(
                GetProcAddress(ev, "?getMusicSystem@EventSystemI@FMOD@@UAG?AW4FMOD_RESULT@@PAPAVMusicSystem@2@@Z"));
            g_music_get_volume =
                reinterpret_cast<MusicGetVolume>(GetProcAddress(ev, "?getVolume@MusicSystemI@FMOD@@UAG?AW4FMOD_RESULT@@PAM@Z"));
            g_music_get_mute = reinterpret_cast<MusicGetBool>(GetProcAddress(ev, "?getMute@MusicSystemI@FMOD@@UAG?AW4FMOD_RESULT@@PA_N@Z"));
        }
        if (!g_system_get_category || !g_category_get_category || !g_category_get_volume || !g_system_get_music ||
            !g_music_get_volume || !g_music_get_mute) {
            alog::Write("sound: some FMOD volume getters not found; the volume log shows what it can");
        }
    }
    float v[8];
    v[0] = *reinterpret_cast<const volatile float*>(game::kMusicVolume);  // the settings as the game holds them
    v[1] = *reinterpret_cast<const volatile float*>(game::kGameVolume);
    v[2] = *reinterpret_cast<const volatile float*>(game::kVolumeScale);
    v[3] = v[4] = v[5] = v[6] = v[7] = -1.f;
    void* system = *reinterpret_cast<void* const volatile*>(game::kEventSystemPtr);
    if (system && g_system_get_category && g_category_get_category && g_category_get_volume) {
        v[3] = CategoryVolume(system, "music");  // what FMOD actually applies
        v[4] = CategoryVolume(system, "game");
        v[5] = CategoryVolume(system, nullptr);  // master
    }
    // B33: the music system (FMOD Designer's interactive music; the menu and level music aren't ordinary events) has its own
    // volume and mute
    void* music = nullptr;
    if (system && g_system_get_music && g_system_get_music(system, &music) == 0 && music) {
        float mv = -1.f;
        if (g_music_get_volume && g_music_get_volume(music, &mv) == 0) v[6] = mv;
        bool muted = false;
        if (g_music_get_mute && g_music_get_mute(music, &muted) == 0) v[7] = muted ? 1.f : 0.f;
    }
    bool changed = false;
    for (int i = 0; i < 8; ++i) changed = changed || std::fabs(v[i] - g_volumes_last[i]) > 0.001f;
    if (changed) {
        for (int i = 0; i < 8; ++i) g_volumes_last[i] = v[i];
        alog::Write("volume (%s): setting music %.3f, effects %.3f, scale %.3f -> FMOD music %.3f, game %.3f, master %.3f; "
                    "music system %.3f%s",
                    what, v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7] > 0.5f ? " (muted)" : v[7] < -0.5f ? " (?)" : "");
    }
    InterlockedExchange(&g_volumes_busy, 0);
}

// B33: from launch, before the first UI frame (our own thread; the game's globals only, no FMOD calls from here).
DWORD WINAPI EarlyVolumeThread(LPVOID) {
    float last[3] = {-9, -9, -9};
    const DWORD t0 = GetTickCount();
    while (GetTickCount() - t0 < 15000) {
        const float v[3] = {*reinterpret_cast<const volatile float*>(game::kMusicVolume),
                            *reinterpret_cast<const volatile float*>(game::kGameVolume),
                            *reinterpret_cast<const volatile float*>(game::kVolumeScale)};
        const void* system = *reinterpret_cast<void* const volatile*>(game::kEventSystemPtr);
        if (v[0] != last[0] || v[1] != last[1] || v[2] != last[2]) {
            alog::Write("volume (launch +%u ms, settings only): music %.3f, effects %.3f, scale %.3f; FMOD event system %s",
                        GetTickCount() - t0, v[0], v[1], v[2], system ? "up" : "not yet");
            for (int i = 0; i < 3; ++i) last[i] = v[i];
        }
        Sleep(100);
    }
    return 0;
}

void StartEarlyVolumeLog() {
    HANDLE t = CreateThread(nullptr, 0, EarlyVolumeThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t);
}

bool InstallPanHookAt(unsigned update) {
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) return false;
    return HookOne("sound update (pan around Shank)", update, reinterpret_cast<void*>(&HookSoundUpdate), &g_orig_update);
}

bool InstallPanHook() {
    // 0x55b0d0: push ecx; fldz; fld dword ptr [0ADFE00h]
    static const unsigned char kPrologue[] = {0x51, 0xD9, 0xEE, 0xD9, 0x05, 0x00, 0xFE, 0xAD, 0x00};
    if (!PrologueMatches(game::kSoundUpdate, kPrologue, sizeof kPrologue)) {
        alog::Write("sound hooks: the sound update's bytes don't match the expected build; game sounds keep the camera pan");
        return false;
    }
    return InstallPanHookAt(game::kSoundUpdate);
}

bool Install() {
    if (!PrologueMatches(game::kPlaySoundAt, kPlaySoundAtPrologue, sizeof kPlaySoundAtPrologue) ||
        !PrologueMatches(game::kPlaySound, kPlaySoundPrologue, sizeof kPlaySoundPrologue)) {
        alog::Write("sound hooks: function bytes don't match the expected build; not hooking");
        return false;
    }
    return InstallAt(game::kPlaySoundAt, game::kPlaySound, game::kListenerHalfW);
}

bool InstallAt(unsigned play_at, unsigned play, unsigned listener) {
    g_listener = reinterpret_cast<volatile float*>(static_cast<uintptr_t>(listener));
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        alog::Write("sound hooks: MH_Initialize failed: %s", MH_StatusToString(st));
        return false;
    }
    g_window_start = GetTickCount();
    const bool a = HookOne("PlaySoundAt", play_at, reinterpret_cast<void*>(&HookPlaySoundAt), &g_orig_play_at);
    const bool b = HookOne("PlaySound", play, reinterpret_cast<void*>(&HookPlaySound), &g_orig_play);
    return a && b;
}

}  // namespace sound_hooks
