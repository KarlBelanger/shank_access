#pragma once
// Speech output. All backend calls happen on one dedicated speech thread (Tolk initialises COM on the thread that
// loads it, and screen-reader calls can block), so Say() never stalls the game.
// B16 (2026-09-27): three channels, each spoken by the screen reader (through Tolk) or by our own SAPI voice (an
// ISpVoice we drive ourselves: Tolk has no voice / rate / volume API). Design: docs/DESIGN.md "Speech".
#include <string>
#include <vector>

namespace speech {

enum Channel {
    kMenu,   // menu reading: focus, titles, dialogs, credits
    kStats,  // what a key press asks for: H, G, N, P, T, Q, toggles, the F7 menu, F2 marks, repeats
    kAuto,   // spoken on its own: health warnings, pickups, combos, checkpoints, prompts, hints, tutorials, tips
    kChannelCount
};
enum Engine { kScreenReader, kSapi };

// Starts the speech thread with Tolk loaded from `dll_dir` (Tolk.dll and the screen reader client DLLs live next to
// Shank.exe) and our SAPI voice. Safe to call once; Say() before Start() is dropped.
void Start(const std::wstring& dll_dir);

// Queues UTF-8 text on a channel. interrupt=true silences what that channel's engine is speaking first (the other
// engine keeps talking).
void Say(const std::string& utf8, bool interrupt = true, Channel channel = kStats);

// Like Say(), but waits (on its own thread) until the game has a visible window plus a short delay.
// Used for start-up messages: speaking while the game opens its audio device clipped the first
// word under SAPI (user report, 2026-09-24).
void SayWhenGameReady(const std::string& utf8, Channel channel = kAuto);

// Repeats the most recent message, on the channel it was spoken on.
void RepeatLast();

// B14: the most recent message (UTF-8), for the feedback marks' context.
std::string Last();

// Speaks `utf8` (interrupting, on the menu channel's engine) and mutes all later speech, then waits up to
// `timeout_ms` (0 = don't wait) for it to be handed over (SAPI: spoken). A second call speaks nothing and just waits
// for the first. For the game exiting: nothing after it may be heard.
void SayFinal(const std::string& utf8, unsigned timeout_ms);

// B16 settings (any thread; applied on the speech thread).
void SetEngine(Channel channel, Engine engine);
Engine EngineOf(Channel channel);
std::vector<std::string> SapiVoices();  // the installed SAPI voices' names (empty until the thread has started)
void SetSapiVoice(const std::string& name);  // "" or unknown = the Windows default voice
std::string SapiVoice();                     // the chosen name ("" = default)
void SetSapiRate(int rate);                  // -10..10 (0 = normal)
int SapiRate();
void SetSapiVolume(int volume);              // 0..100
int SapiVolume();
// Speaks through SAPI whatever the channels say (the settings menu's preview of a voice / rate / volume).
void SaySapiSample(const std::string& utf8);
bool SapiAvailable();  // our SAPI voice started

}  // namespace speech
