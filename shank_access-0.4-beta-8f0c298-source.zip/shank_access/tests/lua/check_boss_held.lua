-- Run by tools/loadtest50.py after loading a boss stategraph (Lua 5.0), B65. The patched State() puts
-- PlaySound("a11y/en_held") first in the on_enter of every goon state that holds someone (A11Y_Holds) and isn't itself
-- open (tag canbegrappled), and in no other. The finishers each boss's open states lead to must be among them:
-- REQUIRED lists them per boss (a list's states found in the loaded graph are checked).
local REQUIRED = {
  butcher = { "grapple_butcher", "grapple_butcher_back", "grapple_chain", "grapple_butcher_finisher" },
  fakebutcher = { "tor_grapple_climb", "tor_grapple_climb_bk", "tor_grapple_finisher" },
  toro = { "tor_grapple_climb", "tor_grapple_climb_bk", "tor_grapple_finisher" },
  gimp = { "gimp_grapple_climb", "gimp_grapple_climb_back" },
  swat = { "swat_grapple_stunned" },
  bodyguard = { "bg_grapple_climb", "bg_grapple_climb_bk", "bg_grapple_climb2" },
  maskedbutcher = { "but_grapple_climb", "but_grapple_climb_atk_frnt" },
}

local function reports(st)
  return type(st.on_enter) == "table" and type(st.on_enter[1]) == "table" and st.on_enter[1].Type == "playsound" and
    st.on_enter[1].sound == "a11y/en_held"
end

local with, problems, by_name = {}, {}, {}
for _, st in ipairs(StateGraph.States) do
  local open = type(st.tags) == "string" and string.find(st.tags, "canbegrappled", 1, true) ~= nil
  local want = A11Y_Holds(st) and not open
  local has = reports(st)
  if has then table.insert(with, st.name) end
  by_name[st.name] = has
  if has ~= want then table.insert(problems, st.name .. " (" .. tostring(st.tags) .. ")") end
end
local checked = 0  -- (the graphs have no name: every listed finisher this graph has must report)
for _, list in pairs(REQUIRED) do
  for _, f in ipairs(list) do
    if by_name[f] ~= nil then
      checked = checked + 1
      if not by_name[f] then table.insert(problems, f .. " (a finisher) doesn't report") end
    end
  end
end
print("  en_held in " .. table.getn(with) .. " states; " .. checked .. " listed finishers here, all reporting")
if table.getn(problems) > 0 then error("wrong states: " .. table.concat(problems, "; ")) end
return true
