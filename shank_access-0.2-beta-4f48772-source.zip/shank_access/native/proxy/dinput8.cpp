// dinput8.dll proxy for Shank. Placed in Shank's bin/ folder, it is loaded instead of the
// system DLL. Every export forwards to the real %SystemRoot%\System32\dinput8.dll (SysWOW64 for
// this 32-bit process). Its only other job: load shank_access.dll next to it, once, outside the
// loader lock, and call ShankAccess_Init.
#include <windows.h>
#include <unknwn.h>

namespace {

HMODULE g_self = nullptr;
HMODULE g_real = nullptr;
volatile LONG g_mod_loaded = 0;

HMODULE RealDll() {
    if (!g_real) {
        wchar_t path[MAX_PATH];
        UINT n = GetSystemDirectoryW(path, MAX_PATH);
        if (n == 0 || n > MAX_PATH - 16) return nullptr;
        lstrcatW(path, L"\\dinput8.dll");
        g_real = LoadLibraryW(path);
    }
    return g_real;
}

FARPROC Real(const char* name) {
    HMODULE m = RealDll();
    return m ? GetProcAddress(m, name) : nullptr;
}

void LoadMod() {
    if (InterlockedExchange(&g_mod_loaded, 1)) return;
    wchar_t path[MAX_PATH];
    DWORD n = GetModuleFileNameW(g_self, path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return;
    wchar_t* slash = path;
    for (wchar_t* p = path; *p; ++p)
        if (*p == L'\\' || *p == L'/') slash = p + 1;
    lstrcpynW(slash, L"shank_access.dll", MAX_PATH - static_cast<int>(slash - path));
    if (HMODULE mod = LoadLibraryW(path)) {
        using InitFn = void(__cdecl*)();
        if (auto init = reinterpret_cast<InitFn>(GetProcAddress(mod, "ShankAccess_Init"))) init();
    }
}

DWORD WINAPI LoaderThread(LPVOID) {
    LoadMod();  // runs after DllMain returns, so no loader-lock problems
    return 0;
}

}  // namespace

extern "C" {

HRESULT WINAPI Proxy_DirectInput8Create(HINSTANCE hinst, DWORD version, REFIID riid, LPVOID* out, LPUNKNOWN outer) {
    LoadMod();
    using Fn = HRESULT(WINAPI*)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
    auto f = reinterpret_cast<Fn>(Real("DirectInput8Create"));
    return f ? f(hinst, version, riid, out, outer) : E_FAIL;
}

HRESULT WINAPI Proxy_DllCanUnloadNow() {
    using Fn = HRESULT(WINAPI*)();
    auto f = reinterpret_cast<Fn>(Real("DllCanUnloadNow"));
    return f ? f() : S_FALSE;
}

HRESULT WINAPI Proxy_DllGetClassObject(REFCLSID clsid, REFIID riid, LPVOID* out) {
    using Fn = HRESULT(WINAPI*)(REFCLSID, REFIID, LPVOID*);
    auto f = reinterpret_cast<Fn>(Real("DllGetClassObject"));
    return f ? f(clsid, riid, out) : CLASS_E_CLASSNOTAVAILABLE;
}

HRESULT WINAPI Proxy_DllRegisterServer() {
    using Fn = HRESULT(WINAPI*)();
    auto f = reinterpret_cast<Fn>(Real("DllRegisterServer"));
    return f ? f() : E_FAIL;
}

HRESULT WINAPI Proxy_DllUnregisterServer() {
    using Fn = HRESULT(WINAPI*)();
    auto f = reinterpret_cast<Fn>(Real("DllUnregisterServer"));
    return f ? f() : E_FAIL;
}

LPCVOID WINAPI Proxy_GetdfDIJoystick() {
    using Fn = LPCVOID(WINAPI*)();
    auto f = reinterpret_cast<Fn>(Real("GetdfDIJoystick"));
    return f ? f() : nullptr;
}

}  // extern "C"

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = inst;
        DisableThreadLibraryCalls(inst);
        if (HANDLE t = CreateThread(nullptr, 0, LoaderThread, nullptr, 0, nullptr)) CloseHandle(t);
    }
    return TRUE;
}
