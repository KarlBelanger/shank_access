#include "enemies.h"

#include <windows.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <map>
#include <set>

#include "log.h"

namespace enemies {
namespace {

SRWLOCK g_lock = SRWLOCK_INIT;
std::map<uint32_t, std::string> g_names;  // attributes hash -> character name
uintptr_t g_manager = 0;
unsigned g_last_scan_ms = 0;
bool g_scanned_once = false;
std::vector<Enemy> g_enemies;
// B19-1: props to shoot, from Lua reports (the Butcher's hanging meat): listed while reported lately.
struct Target {
    std::string name;
    float x, y;
    unsigned seen_ms;
    uintptr_t id;
    bool listed = true;
};
std::vector<Target> g_targets;
unsigned g_now_ms = 0;       // the latest Update / ReportTarget time
unsigned g_lost_ms = 0;      // B36-1: when the manager was last lost (the level unloading) or OnLevel ran; 0 never
uintptr_t g_next_target_id = 1;
std::map<uintptr_t, std::string> g_seen;  // items logged as enemies (for "new" / "gone" lines)
std::set<uint32_t> g_unknown_logged;      // unknown hashes already logged
std::set<uint32_t> g_prop_hashes;         // props' attributes (not characters; not logged as unknown)
int g_shank_team = -1;

bool DefaultRead(uintptr_t addr, void* out, size_t n) {
    __try {
        std::memcpy(out, reinterpret_cast<const void*>(addr), n);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool ScanRegion(const unsigned char* base, size_t size, uint32_t value, std::vector<uintptr_t>* out) {
    __try {
        const uint32_t* p = reinterpret_cast<const uint32_t*>(base);
        const size_t n = size / 4;
        for (size_t i = 0; i < n; ++i) {
            if (p[i] == value) {
                out->push_back(reinterpret_cast<uintptr_t>(p + i));
                if (out->size() >= 256) return true;
            }
        }
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

std::vector<uintptr_t> DefaultScan(uint32_t value) {
    std::vector<uintptr_t> out;
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    const unsigned char* p = static_cast<const unsigned char*>(si.lpMinimumApplicationAddress);
    const unsigned char* end = static_cast<const unsigned char*>(si.lpMaximumApplicationAddress);
    MEMORY_BASIC_INFORMATION mbi;
    while (p < end && VirtualQuery(p, &mbi, sizeof mbi) == sizeof mbi && out.size() < 256) {
        const unsigned char* next = static_cast<const unsigned char*>(mbi.BaseAddress) + mbi.RegionSize;
        const DWORD prot = mbi.Protect & 0xff;
        if (mbi.State == MEM_COMMIT && mbi.Type == MEM_PRIVATE &&
            !(mbi.Protect & (PAGE_GUARD | PAGE_NOCACHE | PAGE_WRITECOMBINE)) &&
            (prot == PAGE_READWRITE || prot == PAGE_EXECUTE_READWRITE)) {
            ScanRegion(static_cast<const unsigned char*>(mbi.BaseAddress), mbi.RegionSize, value, &out);
        }
        if (next <= p) break;
        p = next;
    }
    return out;
}

ReadFn g_read = DefaultRead;
ScanFn g_scan = DefaultScan;

template <typename T>
bool Read(uintptr_t addr, T* out) {
    return addr && g_read(addr, out, sizeof(T));
}

// The item vector of a manager candidate: false if it doesn't look like one.
bool ItemsOf(uintptr_t manager, std::vector<uint32_t>* items) {
    uint32_t vt = 0, first = 0, last = 0;
    if (!Read(manager, &vt) || vt != kManagerVtable) return false;
    if (!Read(manager + kItemsFirst, &first) || !Read(manager + kItemsLast, &last)) return false;
    if (!first || last < first || (last - first) % 4 != 0 || (last - first) / 4 > kMaxItems) return false;
    items->resize((last - first) / 4);
    return items->empty() || g_read(first, items->data(), items->size() * 4);
}

bool IsItemVtable(uint32_t vt) { return vt == kShankItemVtable || vt == kGameItemVtable; }

// Scans for the manager: the candidate whose item vector holds the most real items.
uintptr_t FindManager() {
    uintptr_t best = 0;
    size_t best_items = 0;
    const std::vector<uintptr_t> cands = g_scan(kManagerVtable);
    for (uintptr_t c : cands) {
        std::vector<uint32_t> items;
        if (!ItemsOf(c, &items) || items.empty()) continue;
        size_t real = 0;
        for (size_t i = 0; i < items.size() && i < 16; ++i) {
            uint32_t vt = 0;
            if (Read(items[i], &vt) && IsItemVtable(vt)) ++real;
        }
        if (real * 2 < std::min<size_t>(items.size(), 16)) continue;
        if (items.size() > best_items) {
            best = c;
            best_items = items.size();
        }
    }
    alog::Write("enemies: scanned for the item manager: %u candidates, %s", static_cast<unsigned>(cands.size()),
                best ? "found" : "none usable");
    if (best) alog::Write("enemies: item manager at %08x (%u items)", static_cast<unsigned>(best), static_cast<unsigned>(best_items));
    return best;
}

// File names here are plain ASCII.
std::string Narrow(const std::wstring& w) {
    std::string s;
    for (wchar_t c : w) s += static_cast<char>(c < 128 ? c : '?');
    return s;
}

std::string Lower(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

}  // namespace

uint32_t Hash(const std::string& name) {
    uint32_t h = 0;
    for (unsigned char c : Lower(name)) h = h * 0x1003f + c;
    return h;
}

void AddName(const std::string& name) {
    AcquireSRWLockExclusive(&g_lock);
    g_names[Hash(name)] = Lower(name);
    ReleaseSRWLockExclusive(&g_lock);
}

size_t LoadPropNames(const std::wstring& props_dir) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((props_dir + L"\\*.lua").c_str(), &fd);
    size_t n = 0;
    if (h != INVALID_HANDLE_VALUE) {
        do {
            std::wstring w = fd.cFileName;
            w = w.substr(0, w.size() - 4);
            AcquireSRWLockExclusive(&g_lock);
            g_prop_hashes.insert(Hash(Narrow(w)));
            ReleaseSRWLockExclusive(&g_lock);
            ++n;
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    return n;
}

size_t LoadNames(const std::wstring& characters_dir) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((characters_dir + L"\\*.lua").c_str(), &fd);
    size_t n = 0;
    if (h != INVALID_HANDLE_VALUE) {
        do {
            std::wstring w = fd.cFileName;
            w = w.substr(0, w.size() - 4);  // ".lua"
            AddName(Narrow(w));
            ++n;
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    alog::Write("enemies: %u character names", static_cast<unsigned>(n));
    return n;
}

Class ClassOf(const std::string& raw) {
    const std::string n = Lower(raw);
    auto starts = [&](const char* p) { return n.compare(0, std::strlen(p), p) == 0; };
    if (starts("boss_")) return kBoss;
    if (starts("dog") || starts("class_dog")) return kDog;
    if (starts("girl") || starts("class_grl") || starts("grl")) return kGirl;
    if (starts("large") || starts("class_lrg") || starts("lrg")) return kLarge;
    if (starts("med") || starts("class_med")) return kMedium;
    return kOther;
}

std::string Describe(const std::string& raw) {
    const std::string n = Lower(raw);
    if (n == "meatslab") return "hanging meat";       // B19-1
    if (n == "meatslab_low") return "lowered meat";   // B23-5
    if (n == "doorbreakopen") return "breakable door";  // B19-5
    const Class c = ClassOf(n);
    if (c == kBoss) {
        std::string who = n.substr(5);
        std::replace(who.begin(), who.end(), '_', ' ');
        return "boss " + who;
    }
    if (c == kDog) return "dog";
    // Weapons, in a fixed order (a name can hold two, e.g. "knifepistol").
    static const struct {
        const char* key;
        const char* word;
    } kWeapons[] = {{"minigun", "minigun"},     {"flamethrower", "flamethrower"}, {"grenadelauncher", "grenade launcher"},
                    {"shieldshotgun", "shield and shotgun"}, {"shieldbaton", "shield and baton"}, {"shotgun", "shotgun"},
                    {"ak47", "rifle"},          {"uzi", "uzi"},                   {"knife", "knife"},
                    {"machete", "machete"},     {"machette", "machete"}, {"pistol", "pistol"},             {"baton", "baton"},
                    {"whip", "whip"},           {"charger", "charger"},           {"ram", "rammer"},
                    {"fists", "brawler"},       {"grappler", "grappler"},         {"rangemelee", "thrower"}};
    std::string what;
    std::string rest = n;
    for (const auto& w : kWeapons) {
        const size_t at = rest.find(w.key);
        if (at == std::string::npos) continue;
        if (std::strcmp(w.key, "shotgun") == 0 && n.find("shieldshotgun") != std::string::npos) continue;
        if (std::strcmp(w.key, "baton") == 0 && n.find("shieldbaton") != std::string::npos) continue;
        if (std::strcmp(w.key, "ram") == 0 && (at + 3 < rest.size() && rest[at + 3] != '_')) continue;  // "ram" only as a word end
        what += what.empty() ? w.word : std::string(" and ") + w.word;
    }
    const bool grenadier = what.empty() && n.find("grenade") != std::string::npos;  // B8d: "grenadier"
    if (c == kGirl) {
        if (what.empty() && n.size() >= 3 && n.compare(n.size() - 3, 3, "_bo") == 0) what = "staff";
        return what.empty() ? "girl" : "girl with " + what;
    }
    if (grenadier && c != kGirl) return c == kLarge ? "big grenadier" : "grenadier";
    if (grenadier) what = "grenades";
    const std::string noun = c == kLarge ? "big goon" : "goon";
    return what.empty() ? noun : what + " " + noun;
}

bool IsSpecial(const std::string& raw) {
    const std::string n = Lower(raw);
    const Class c = ClassOf(n);
    if (c == kLarge || c == kBoss) return true;
    static const char* const kSpecial[] = {"grenade", "minigun", "flamethrower", "shotgun", "ak47", "shield"};
    for (const char* k : kSpecial) {
        if (n.find(k) != std::string::npos) return true;
    }
    return false;
}

void SetMemory(ReadFn read, ScanFn scan) {
    g_read = read ? read : ReadFn(DefaultRead);
    g_scan = scan ? scan : ScanFn(DefaultScan);
}

void OnLevel() {
    AcquireSRWLockExclusive(&g_lock);
    g_manager = 0;
    g_enemies.clear();
    g_seen.clear();
    g_shank_team = -1;
    g_targets.clear();  // B19-1
    g_last_scan_ms = 0;
    g_scanned_once = false;
    g_lost_ms = g_now_ms ? g_now_ms : 1;
    ReleaseSRWLockExclusive(&g_lock);
}

void SetCurrentForTests(const std::vector<Enemy>& list) {
    AcquireSRWLockExclusive(&g_lock);
    g_enemies = list;
    ReleaseSRWLockExclusive(&g_lock);
}

unsigned ListLostMs() {
    AcquireSRWLockShared(&g_lock);
    const unsigned ms = g_lost_ms;
    ReleaseSRWLockShared(&g_lock);
    return ms;
}

void SetListLostForTests(unsigned ms) {
    AcquireSRWLockExclusive(&g_lock);
    g_lost_ms = ms;
    ReleaseSRWLockExclusive(&g_lock);
}

std::vector<Enemy> Current() {
    AcquireSRWLockShared(&g_lock);
    std::vector<Enemy> out = g_enemies;
    for (const Target& t : g_targets) {
        if (g_now_ms - t.seen_ms > kTargetStaleMs) continue;
        Enemy e;
        e.item = t.id;
        e.name = t.name;
        e.cls = ClassOf(t.name);
        e.x = t.x;
        e.y = t.y;
        e.team = -1;
        out.push_back(e);
    }
    ReleaseSRWLockShared(&g_lock);
    return out;
}

namespace {
// the props' own names (B19-5: the wine cellar's doors that must be broken)
// (B23-5: "meat_low" = a slab shot down and lowered, waiting for the Butcher's hook)
std::string TargetName(const std::string& kind) {
    return kind == "meat" ? "meatslab" : kind == "meat_low" ? "meatslab_low" : kind == "door" ? "doorbreakopen" : kind;
}
}  // namespace

bool IsTarget(const std::string& name) { return name == "meatslab" || name == "meatslab_low" || name == "doorbreakopen"; }

// B36b-1: Mello's stategraph has only idle / walk / talk / phone states (no attack, hit or death): 2-b's scripted bar
// owner, cued as a boss before the Denny fight (the user: "the mod detects the boss but he is invulnerable").
bool IsNonCombatant(const std::string& name) { return name == "boss_mello"; }

bool TargetDown(const std::string& kind, float x, float y, unsigned now_ms) {
    const std::string name = TargetName(kind);
    AcquireSRWLockExclusive(&g_lock);
    g_now_ms = now_ms;
    bool found = false;
    for (Target& t : g_targets) {
        if (t.name != name || std::fabs(t.x - x) >= kTargetMatchPx || std::fabs(t.y - y) >= kTargetMatchPx) continue;
        t.seen_ms = now_ms - kTargetStaleMs - 1;
        t.listed = false;
        found = true;
    }
    ReleaseSRWLockExclusive(&g_lock);
    alog::Write("enemies: target %s at (%.0f, %.0f) shot down%s", name.c_str(), x, y, found ? "" : " (not listed)");
    return found;
}

void ReportTarget(const std::string& kind, float x, float y, unsigned now_ms) {
    const std::string name = TargetName(kind);
    AcquireSRWLockExclusive(&g_lock);
    g_now_ms = now_ms;
    Target* same = nullptr;
    for (Target& t : g_targets) {
        if (t.name == name && std::fabs(t.x - x) < kTargetMatchPx && std::fabs(t.y - y) < kTargetMatchPx) same = &t;
    }
    if (same) {
        const bool back = now_ms - same->seen_ms > kTargetStaleMs;
        same->x = x;
        same->y = y;
        same->seen_ms = now_ms;
        same->listed = true;
        if (back) alog::Write("enemies: target %s at (%.0f, %.0f) can be shot again", name.c_str(), x, y);
    } else {
        g_targets.push_back(Target{name, x, y, now_ms, g_next_target_id++, true});
        if (g_next_target_id >= kTargetIdLimit) g_next_target_id = 1;
        alog::Write("enemies: target %s at (%.0f, %.0f) can be shot", name.c_str(), x, y);
    }
    ReleaseSRWLockExclusive(&g_lock);
}

void Update(unsigned now_ms, const position::Pos& shank) {
    AcquireSRWLockExclusive(&g_lock);
    g_now_ms = now_ms;
    for (Target& t : g_targets) {  // B19-1: a target that stopped reporting (shot down) leaves the list
        const bool listed = now_ms - t.seen_ms <= kTargetStaleMs;
        if (t.listed && !listed) alog::Write("enemies: target %s at (%.0f, %.0f) no longer shootable", t.name.c_str(), t.x, t.y);
        t.listed = listed;
    }
    std::vector<uint32_t> items;
    if (g_manager && !ItemsOf(g_manager, &items)) {
        alog::Write("enemies: item manager at %08x no longer valid", static_cast<unsigned>(g_manager));
        g_manager = 0;
        g_lost_ms = now_ms ? now_ms : 1;
    }
    if (!g_manager) {
        g_enemies.clear();
        // Look for it once Shank's position is known (he's in a level), not more than every few seconds.
        // B8b: Shank's ping is enough (standing still, the tracker isn't live yet: after a checkpoint restart
        // the user sniped for two minutes without a list).
        if (shank.known && (!g_scanned_once || now_ms - g_last_scan_ms >= kScanEveryMs)) {
            g_scanned_once = true;
            g_last_scan_ms = now_ms;
            g_manager = FindManager();
            if (g_manager) ItemsOf(g_manager, &items);
        }
        if (!g_manager) {
            ReleaseSRWLockExclusive(&g_lock);
            return;
        }
    }
    struct Raw {
        uintptr_t item;
        std::string name;
        int team;
        float x, y;
    };
    std::vector<Raw> chars;
    for (uint32_t it : items) {
        unsigned char hdr[kLife + 4];
        if (!g_read(it, hdr, sizeof hdr)) continue;
        uint32_t vt, team, hash, phys, life;
        std::memcpy(&vt, hdr, 4);
        if (!IsItemVtable(vt)) continue;
        std::memcpy(&team, hdr + kTeam, 4);
        std::memcpy(&hash, hdr + kAttrHash, 4);
        std::memcpy(&phys, hdr + kPhysics, 4);
        std::memcpy(&life, hdr + kLife, 4);
        const auto nm = g_names.find(hash);
        if (nm == g_names.end()) {
            if (!g_prop_hashes.count(hash) && g_unknown_logged.size() < 64 && g_unknown_logged.insert(hash).second) {
                alog::Write("enemies: item %08x (vtable %08x) with an unknown attributes hash %08x, team %u", it, vt, hash, team);
            }
            continue;
        }
        if (life) {  // the closest-enemy filter skips items whose life record says so (dead / disabled)
            unsigned char flag = 0;
            if (Read(life + kLifeFlag, &flag) && flag) continue;
        }
        float pos[2];
        if (!phys || !g_read(phys + kPhysicsPos, pos, sizeof pos) || !std::isfinite(pos[0]) || !std::isfinite(pos[1])) continue;
        chars.push_back(Raw{it, nm->second, static_cast<int>(team), pos[0], pos[1]});
    }
    // Shank: the "shank*" character (nearest the tracked position if there are several, e.g. co-op).
    int shank_team = -1;
    float best = 1e18f;
    for (const Raw& r : chars) {
        if (r.name.compare(0, 5, "shank") != 0) continue;
        const float d = shank.known ? std::hypot(r.x - shank.x, r.y - shank.y) : 0.f;
        if (d < best) {
            best = d;
            shank_team = r.team;
        }
    }
    if (shank_team != g_shank_team) {
        alog::Write("enemies: Shank's team %d (%u characters)", shank_team, static_cast<unsigned>(chars.size()));
        g_shank_team = shank_team;
    }
    std::vector<Enemy> out;
    std::map<uintptr_t, std::string> seen;
    for (const Raw& r : chars) {
        if (shank_team < 0 || r.team == shank_team || r.name.compare(0, 5, "shank") == 0) continue;
        if (IsNonCombatant(r.name)) continue;
        Enemy e;
        e.item = r.item;
        e.name = r.name;
        e.cls = ClassOf(r.name);
        e.x = r.x;
        e.y = r.y;
        e.team = r.team;
        out.push_back(e);
        seen[r.item] = r.name;
        if (!g_seen.count(r.item)) {
            alog::Write("enemies: %s (%s) team %d at (%.0f, %.0f)", r.name.c_str(), Describe(r.name).c_str(), r.team, r.x, r.y);
        }
    }
    for (const auto& kv : g_seen) {
        if (!seen.count(kv.first)) alog::Write("enemies: %s gone", kv.second.c_str());
    }
    g_seen.swap(seen);
    g_enemies.swap(out);
    ReleaseSRWLockExclusive(&g_lock);
}

}  // namespace enemies
